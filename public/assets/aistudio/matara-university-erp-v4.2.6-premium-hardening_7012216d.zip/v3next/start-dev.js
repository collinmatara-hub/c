const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const [major, minor] = process.versions.node.split('.').map(Number);
if (major < 22 || (major === 22 && minor < 5)) {
  console.error(`Node.js 22.5+ is required. You are using ${process.version}.`);
  process.exit(1);
}
const root = __dirname;
const envFile = path.join(root, 'backend', '.env');
if (!fs.existsSync(envFile)) {
  const secret = require('crypto').randomBytes(48).toString('base64url');
  fs.writeFileSync(envFile, `NODE_ENV=development\nPORT=5000\nJWT_SECRET=${secret}\nFRONTEND_URL=http://127.0.0.1:5173\n`, 'utf8');
  console.log('Created backend/.env with a strong local JWT_SECRET.');
}
for (const dir of ['backend/node_modules','frontend/node_modules']) {
  if (!fs.existsSync(path.join(root, dir))) {
    console.error(`Missing ${dir}. Run: npm run install:all`);
    process.exit(1);
  }
}
const children = [];
function run(cwd, command, args, label) {
  const p = spawn(command, args, {cwd:path.join(root,cwd), stdio:'inherit', shell:process.platform==='win32'});
  p.on('exit', code => { if (code && !process.exitCode) process.exitCode=code; });
  children.push(p);
}
run('backend', process.platform==='win32'?'npm.cmd':'npm', ['run','start'], 'backend');
run('frontend', process.platform==='win32'?'npm.cmd':'npm', ['run','dev','--','--host','127.0.0.1'], 'frontend');
function stop(){ for(const p of children) if(!p.killed) p.kill('SIGTERM'); }
process.on('SIGINT',()=>{stop();process.exit();});
process.on('SIGTERM',()=>{stop();process.exit();});
