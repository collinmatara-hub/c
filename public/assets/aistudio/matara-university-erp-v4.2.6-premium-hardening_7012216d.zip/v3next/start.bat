@echo off
cd /d "%~dp0"
if not exist "backend\node_modules" (
  echo Installing backend dependencies...
  call npm install --prefix backend
  if errorlevel 1 pause & exit /b 1
)
if not exist "frontend\node_modules" (
  echo Installing frontend dependencies...
  call npm install --prefix frontend
  if errorlevel 1 pause & exit /b 1
)
call npm run dev
pause
