#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
[ -d backend/node_modules ] || npm install --prefix backend
[ -d frontend/node_modules ] || npm install --prefix frontend
npm run dev
