// Writes frontend/src/config/rolesCatalog.js from backend/lib/roles.js so the
// browser and the API always agree on the list of roles.
// Run: node scripts/sync-roles.js        (add --check to only verify)
const fs = require('fs');
const path = require('path');
const { ROLES, CATEGORIES } = require('../backend/lib/roles');

function build() {
  const roles = ROLES.map((r) => ({
    value: r.key, label: r.label, group: r.group, category: r.category, acts_as: r.acts_as,
    read_only: Boolean(r.read_only), temporary: Boolean(r.temporary), limited_nav: Boolean(r.limited_nav),
    caps: r.caps || [], description: r.description,
  }));
  return `// AUTO-GENERATED from backend/lib/roles.js by scripts/sync-roles.js. Do not edit by hand.\n`
    + `export const ROLE_CATEGORIES = ${JSON.stringify(CATEGORIES.map(([key, label]) => ({ key, label })), null, 2)};\n\n`
    + `export const ROLE_CATALOG = ${JSON.stringify(roles, null, 2)};\n`;
}

const target = path.join(__dirname, '..', 'frontend', 'src', 'config', 'rolesCatalog.js');
const next = build();
if (process.argv.includes('--check')) {
  const current = fs.existsSync(target) ? fs.readFileSync(target, 'utf8') : '';
  if (current !== next) { console.error('rolesCatalog.js is out of date. Run: node scripts/sync-roles.js'); process.exit(1); }
  console.log('rolesCatalog.js is up to date.');
} else {
  fs.writeFileSync(target, next);
  console.log('Wrote', path.relative(process.cwd(), target));
}
module.exports = { build };
