// Prints every API endpoint and the kind of guard it has. Run: npm run audit:routes
process.env.JWT_SECRET = process.env.JWT_SECRET || 'local-audit-secret-please-change-1234567890';
process.env.NODE_ENV = 'test';
const { app } = require('../app');
const { collectRoutes, isAuthed, PUBLIC } = require('../lib/routeAudit');

const routes = collectRoutes(app);
const isPublic = (r) => PUBLIC.some(([m, p]) => m === r.method && p === r.path);
const guarded = (r) => r.guards.some((g) => /^(requireRole|requireCap|requirePermission)$/.test(g));
const writes = (r) => r.method !== 'GET';

const open = routes.filter((r) => !isAuthed(r) && !isPublic(r));
const sessionOnly = routes.filter((r) => isAuthed(r) && !guarded(r));
const sessionOnlyWrites = sessionOnly.filter(writes);

console.log('Total API endpoints:', routes.length);
console.log('Public (allow-listed):', routes.filter(isPublic).length);
console.log('Unauthenticated and NOT allow-listed:', open.length);
console.log('Session-only (no named role/permission guard; may check inline):', sessionOnly.length);
console.log('  of which change data:', sessionOnlyWrites.length);
if (process.argv.includes('--list')) {
  for (const r of sessionOnlyWrites) console.log('  ', r.method, r.path);
}
for (const r of open) console.log('OPEN', r.method, r.path);
process.exit(open.length ? 1 : 0);
