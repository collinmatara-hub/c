const test = require('node:test');
const assert = require('node:assert/strict');
const { PERMISSIONS, ALL_CODES, permissionsForRole, hasPermission, scopeAllows } = require('../lib/rbac');
const { ROLES } = require('../lib/roles');

test('permission catalog has unique, well-formed codes', () => {
  assert.ok(PERMISSIONS.length >= 80);
  assert.equal(new Set(ALL_CODES).size, ALL_CODES.length);
  for (const p of PERMISSIONS) {
    assert.match(p.code, /^[a-z][a-z0-9]*(\.[a-z][a-z0-9_]*)+$/);
    assert.ok(p.module && p.action);
  }
});

test('every known role receives an explicit permission set and unknown roles fail closed', () => {
  for (const role of ROLES) assert.ok(Array.isArray(permissionsForRole(role.key)), role.key);
  assert.deepEqual(permissionsForRole('not_a_role'), []);
  assert.equal(hasPermission('not_a_role', 'users.view'), false);
  assert.equal(hasPermission('lecturer', 'system.configure'), false);
  assert.equal(hasPermission('admin', 'results.publish'), false, 'technical Root must not bypass academic approval authority');
  assert.equal(hasPermission('admin', 'system.configure'), true);
});

test('role permissions follow least privilege for sensitive actions', () => {
  assert.equal(hasPermission('lecturer', 'marks.enter'), true);
  assert.equal(hasPermission('lecturer', 'results.publish'), false);
  assert.equal(hasPermission('teaching_assistant', 'lms.assignment.grade'), true);
  assert.equal(hasPermission('teaching_assistant', 'results.publish'), false);
  assert.equal(hasPermission('cashier', 'payments.record'), true);
  assert.equal(hasPermission('cashier', 'refunds.approve'), false);
  assert.equal(hasPermission('auditor', 'finance.transactions.review'), true);
  assert.equal(hasPermission('auditor', 'finance.transactions.create'), false);
});

test('record scope checks deny missing scope and require an explicit matching assignment', () => {
  assert.equal(scopeAllows(undefined, { type: 'faculty', id: 2 }), false);
  assert.equal(scopeAllows({ faculty: ['2'] }, { type: 'faculty', id: 2 }), true);
  assert.equal(scopeAllows({ faculty: ['3'] }, { type: 'faculty', id: 2 }), false);
  assert.equal(scopeAllows({ university: true }, { type: 'faculty', id: 2 }), true);
  assert.equal(scopeAllows({ own: true }, { type: 'own' }), true);
  assert.equal(scopeAllows({}, { type: 'own' }), false);
});
