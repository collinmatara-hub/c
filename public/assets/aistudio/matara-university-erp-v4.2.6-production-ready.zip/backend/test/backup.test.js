'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');
const { createVerifiedBackup, verifyBackupFile } = require('../lib/backup');

test('verified backup includes committed SQLite data and passes integrity check', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'matara-backup-test-'));
  const target = path.join(dir, 'snapshot.db');
  const db = new DatabaseSync(path.join(dir, 'source.db'));
  try {
    db.exec('PRAGMA journal_mode=WAL; CREATE TABLE records(id INTEGER PRIMARY KEY, value TEXT NOT NULL); INSERT INTO records(value) VALUES (\'persisted\')');
    const result = await createVerifiedBackup(db, target);
    assert.equal(result.verified, true);
    assert.ok(result.size > 0);
    assert.match(result.sha256, /^[a-f0-9]{64}$/);
    assert.equal(verifyBackupFile(target), true);
    const snapshot = new DatabaseSync(target, { readOnly: true });
    try { assert.equal(snapshot.prepare('SELECT value FROM records WHERE id=1').get().value, 'persisted'); }
    finally { snapshot.close(); }
  } finally {
    db.close();
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

test('backup verification rejects a non-SQLite file', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'matara-backup-invalid-'));
  const target = path.join(dir, 'invalid.db');
  try { fs.writeFileSync(target, 'not a database'); assert.throws(() => verifyBackupFile(target)); }
  finally { fs.rmSync(dir, { recursive: true, force: true }); }
});
