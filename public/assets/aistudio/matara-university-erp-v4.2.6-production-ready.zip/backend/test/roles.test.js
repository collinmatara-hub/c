// End-to-end checks for the role model. Runs against a throwaway database.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const http = require('node:http');

process.env.JWT_SECRET = process.env.JWT_SECRET || 'local-test-secret-please-change-1234567890';
process.env.NODE_ENV = 'test';
process.env.DEMO_PASSWORD = 'Test-Pass-2026';
process.env.RATE_LIMIT_MAX = '100000';
process.env.MATARA_DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'matara-roles-'));

const { app } = require('../app');
const { db } = require('../db');
const { ROLES, BY_KEY, effectiveRole } = require('../lib/roles');

let server; let base;
test.before(async () => { await new Promise((r) => { server = http.createServer(app).listen(0, r); }); base = `http://127.0.0.1:${server.address().port}`; });
test.after(() => { server.close(); });

async function call(method, url, { cookie, body, headers } = {}) {
  const res = await fetch(base + url, { method, headers: { 'content-type': 'application/json', ...(cookie ? { cookie } : {}), ...(headers || {}) }, body: body ? JSON.stringify(body) : undefined });
  let data = null; try { data = await res.json(); } catch (_) {}
  return { status: res.status, data, cookie: (res.headers.get('set-cookie') || '').split(';')[0] };
}
async function login(email, password = 'Test-Pass-2026') {
  const r = await call('POST', '/api/auth/login', { body: { email, password } });
  return { ...r, cookie: r.cookie };
}
let adminCookie;
let counter = 0;
async function makeUser(role, extra = {}) {
  counter += 1;
  const r = await call('POST', '/api/users', { cookie: adminCookie, body: { role, name: `Test ${role} ${counter}`, username: `t${role.replaceAll('_', '')}${counter}`, password: 'Test-Pass-2026', ...extra } });
  assert.equal(r.status, 201, `create ${role}: ${JSON.stringify(r.data)}`);
  const l = await login(r.data.email);
  return { id: r.data.id, email: r.data.email, cookie: l.cookie, loginStatus: l.status };
}

test('role catalog is consistent', () => {
  const keys = new Set(ROLES.map((r) => r.key));
  assert.equal(keys.size, ROLES.length, 'duplicate role keys');
  ROLES.forEach((r) => {
    assert.ok(r.label, `${r.key} needs a label`);
    assert.ok(r.acts_as === 'suspended' || keys.has(r.acts_as), `${r.key} acts as unknown role ${r.acts_as}`);
    assert.equal(BY_KEY[r.acts_as === 'suspended' ? 'suspended_student' : r.acts_as].acts_as === r.acts_as || r.acts_as === 'suspended' || true, true);
  });
  for (const k of ['helpdesk_l1', 'helpdesk_l2', 'machine_user', 'senate_member', 'external_examiner', 'gate_guard', 'deferred_student', 'suspended_student', 'cashier']) assert.ok(keys.has(k), `${k} missing`);
  assert.equal(effectiveRole('helpdesk_l1'), 'staff');
});

test('database accepts every role and keeps existing columns', async () => {
  const sql = db.prepare("SELECT sql FROM sqlite_master WHERE name='users'").get().sql;
  for (const r of ROLES) assert.ok(sql.includes(`'${r.key}'`), `${r.key} missing from users CHECK`);
  const cols = db.prepare('PRAGMA table_info(users)').all().map((c) => c.name);
  for (const c of ['two_factor_secret', 'profile_image_url', 'access_expires_at', 'locked_until', 'activated_at']) assert.ok(cols.includes(c), `${c} column lost`);
});

test('every role can be created and signs in (API-only account excepted)', async () => {
  const a = await login('admin@matara.ac.ke');
  assert.equal(a.status, 200);
  adminCookie = a.cookie;
  for (const r of ROLES) {
    if (r.key === 'admin') continue;
    const extra = r.temporary ? { access_expires_at: '2099-01-01' } : {};
    const u = await makeUser(r.key, extra);
    if (r.api_only) assert.equal(u.loginStatus, 403, 'machine user must not sign in with a password');
    else assert.equal(u.loginStatus, 200, `${r.key} could not sign in`);
  }
  const bad = await call('POST', '/api/users', { cookie: adminCookie, body: { role: 'invigilator_x', name: 'Nope', username: 'nope', password: 'Test-Pass-2026' } });
  assert.equal(bad.status, 400);
  const noEnd = await call('POST', '/api/users', { cookie: adminCookie, body: { role: 'exam_invigilator', name: 'No End', username: 'noend', password: 'Test-Pass-2026' } });
  assert.equal(noEnd.status, 400);
});

test('/auth/me reports the real role, not the inherited one', async () => {
  const u = await makeUser('helpdesk_l1');
  const me = await call('GET', '/api/auth/me', { cookie: u.cookie });
  assert.equal(me.data.user.role, 'helpdesk_l1');
});

test('read-only roles cannot change data but can use their own desk', async () => {
  const audit = await makeUser('security_audit_officer');
  const r = await call('POST', '/api/announcements', { cookie: audit.cookie, body: { title: 'x', body: 'y' } });
  assert.equal(r.status, 403);
  const ov = await call('GET', '/api/role-ops/audit/overview', { cookie: audit.cookie });
  assert.equal(ov.status, 200);
  assert.ok(Array.isArray(ov.data.logins));
  const staff = await makeUser('helpdesk_l1');
  assert.equal((await call('GET', '/api/role-ops/audit/overview', { cookie: staff.cookie })).status, 403);
});

test('helpdesk level 1 vs level 2 vs administrators', async () => {
  const l1 = await makeUser('helpdesk_l1');
  const l2 = await makeUser('helpdesk_l2');
  const victim = await makeUser('student');
  const second = await makeUser('lecturer');
  // L1 resets passwords and unlocks
  const reset = await call('PUT', `/api/users/${victim.id}/password`, { cookie: l1.cookie, body: {} });
  assert.equal(reset.status, 200);
  db.prepare("UPDATE users SET locked_until = datetime('now','+1 hour'), failed_login_count = 5 WHERE id = ?").run(victim.id);
  assert.equal((await call('POST', `/api/users/${victim.id}/unlock`, { cookie: l1.cookie })).status, 200);
  assert.equal(db.prepare('SELECT locked_until FROM users WHERE id = ?').get(victim.id).locked_until, null);
  // L1 cannot change roles, create or delete users
  assert.equal((await call('PUT', `/api/users/${second.id}/role`, { cookie: l1.cookie, body: { role: 'staff' } })).status, 403);
  assert.equal((await call('DELETE', `/api/users/${second.id}`, { cookie: l1.cookie })).status, 403);
  assert.equal((await call('POST', '/api/users', { cookie: l1.cookie, body: {} })).status, 403);
  // L2 can change roles but never to or from admin
  assert.equal((await call('PUT', `/api/users/${second.id}/role`, { cookie: l2.cookie, body: { role: 'senior_lecturer' } })).status, 200);
  assert.equal((await call('PUT', `/api/users/${second.id}/role`, { cookie: l2.cookie, body: { role: 'admin' } })).status, 403);
  const admin = db.prepare("SELECT id FROM users WHERE role='admin'").get();
  assert.equal((await call('PUT', `/api/users/${admin.id}/password`, { cookie: l2.cookie, body: {} })).status, 403);
  // L1 cannot touch an L2 account
  assert.equal((await call('PUT', `/api/users/${l2.id}/password`, { cookie: l1.cookie, body: {} })).status, 403);
  // integrity check is L2 only
  assert.equal((await call('GET', '/api/role-ops/helpdesk/integrity', { cookie: l1.cookie })).status, 403);
  assert.equal((await call('GET', '/api/role-ops/helpdesk/integrity', { cookie: l2.cookie })).status, 200);
  // L1 cannot view grades or finance
  assert.equal((await call('GET', '/api/fees', { cookie: l1.cookie })).status, 403);
});

test('grade lock stops lecturers and teaching assistants, not the examinations director', async () => {
  const director = await makeUser('examinations_director');
  const lecturer = await makeUser('lecturer');
  const lecturerOther = await makeUser('lecturer');
  const ta = await makeUser('teaching_assistant');
  assert.equal((await call('PUT', '/api/role-ops/grade-lock', { cookie: lecturer.cookie, body: { locked: true } })).status, 403);
  const on = await call('PUT', '/api/role-ops/grade-lock', { cookie: director.cookie, body: { locked: true } });
  assert.equal(on.status, 200);
  assert.equal(on.data.locked, true);
  const marks = { exam_id: 1, subject_id: 1, marks: [] };
  assert.equal((await call('PUT', '/api/assessments/marks', { cookie: lecturer.cookie, body: marks })).status, 423);
  assert.equal((await call('PUT', '/api/assessments/marks', { cookie: ta.cookie, body: marks })).status, 423);
  const off = await call('PUT', '/api/role-ops/grade-lock', { cookie: director.cookie, body: { locked: false } });
  assert.equal(off.data.locked, false);
  assert.notEqual((await call('PUT', '/api/assessments/marks', { cookie: lecturerOther.cookie, body: marks })).status, 423);
  // a deadline in the past locks automatically
  await call('PUT', '/api/role-ops/grade-lock', { cookie: director.cookie, body: { locked: false, deadline: '2020-01-01T00:00:00Z' } });
  assert.equal((await call('PUT', '/api/assessments/marks', { cookie: lecturer.cookie, body: marks })).status, 423);
  await call('PUT', '/api/role-ops/grade-lock', { cookie: director.cookie, body: { locked: false, deadline: null } });
});

test('teaching assistants cannot touch final exams', async () => {
  const ta = await makeUser('teaching_assistant');
  const exam = db.prepare("SELECT id FROM exams WHERE kind='Exam' LIMIT 1").get();
  const cat = db.prepare("SELECT id FROM exams WHERE kind='CAT' LIMIT 1").get();
  if (exam) assert.equal((await call('PUT', '/api/assessments/marks', { cookie: ta.cookie, body: { exam_id: exam.id, subject_id: 1, marks: [] } })).status, 403);
  if (cat) assert.notEqual((await call('PUT', '/api/assessments/marks', { cookie: ta.cookie, body: { exam_id: cat.id, subject_id: 1, marks: [] } })).status, 403);
  assert.equal((await call('POST', '/api/assessments/exams', { cookie: ta.cookie, body: { name: 'Final', kind: 'Exam' } })).status, 403);
  assert.equal((await call('POST', '/api/university/results/1/submit', { cookie: ta.cookie })).status, 403);
});

test('financial holds block registration and document issue, and release restores it', async () => {
  const collector = await makeUser('collections_officer');
  const cashier = await makeUser('cashier');
  const student = await makeUser('student');
  const rec = db.prepare('SELECT id, adm_no FROM students WHERE user_id = ?').get(student.id);
  assert.equal((await call('POST', '/api/role-ops/holds', { cookie: cashier.cookie, body: { student_id: rec.id, reason: 'Arrears' } })).status, 403);
  const hold = await call('POST', '/api/role-ops/holds', { cookie: collector.cookie, body: { code: rec.adm_no, reason: 'Arrears', amount: 5000 } });
  assert.equal(hold.status, 201);
  assert.equal((await call('POST', '/api/role-ops/holds', { cookie: collector.cookie, body: { student_id: rec.id, reason: 'again' } })).status, 400);
  const subject = db.prepare('SELECT id FROM subjects LIMIT 1').get();
  const blocked = await call('POST', '/api/portal/units/register', { cookie: student.cookie, body: { subject_id: subject.id } });
  assert.equal(blocked.status, 403);
  const mine = await call('GET', '/api/role-ops/my-status', { cookie: student.cookie });
  assert.equal(mine.data.hold.reason, 'Arrears');
  await call('POST', `/api/role-ops/holds/${hold.data.id}/release`, { cookie: collector.cookie, body: { note: 'Paid' } });
  const ok = await call('POST', '/api/portal/units/register', { cookie: student.cookie, body: { subject_id: subject.id } });
  assert.equal(ok.status, 201);
});

test('gate scan shows only green or red to guards, and bans turn people red', async () => {
  const guard = await makeUser('gate_guard');
  const cso = await makeUser('security_officer');
  const student = await makeUser('student');
  const rec = db.prepare('SELECT adm_no FROM students WHERE user_id = ?').get(student.id);
  const g = await call('POST', '/api/role-ops/gate/scan', { cookie: guard.cookie, body: { code: rec.adm_no } });
  assert.deepEqual(g.data, { result: 'green' });
  assert.equal((await call('POST', '/api/role-ops/gate/scan', { cookie: guard.cookie, body: { code: 'NOPE/0/0' } })).data.result, 'red');
  assert.equal((await call('POST', '/api/role-ops/bans', { cookie: guard.cookie, body: { code: rec.adm_no, reason: 'x' } })).status, 403);
  const ban = await call('POST', '/api/role-ops/bans', { cookie: cso.cookie, body: { code: rec.adm_no, reason: 'Fighting' } });
  assert.equal(ban.status, 201);
  assert.equal((await call('POST', '/api/role-ops/gate/scan', { cookie: guard.cookie, body: { code: rec.adm_no } })).data.result, 'red');
  const detail = await call('POST', '/api/role-ops/gate/scan', { cookie: cso.cookie, body: { code: rec.adm_no } });
  assert.equal(detail.data.reason, 'Banned from campus');
  await call('POST', `/api/role-ops/bans/${ban.data.id}/lift`, { cookie: cso.cookie });
  assert.equal((await call('POST', '/api/role-ops/gate/scan', { cookie: guard.cookie, body: { code: rec.adm_no } })).data.result, 'green');
});

test('invigilators record attendance and flag malpractice; discipline suspends and reinstates', async () => {
  const inv = await makeUser('exam_invigilator', { access_expires_at: '2099-01-01' });
  const committee = await makeUser('disciplinary_member');
  const student = await makeUser('student');
  const rec = db.prepare('SELECT id, adm_no FROM students WHERE user_id = ?').get(student.id);
  const scan = await call('POST', '/api/role-ops/exam-attendance/scan', { cookie: inv.cookie, body: { code: rec.adm_no, exam_label: 'BIT 2216 Final' } });
  assert.equal(scan.status, 200);
  assert.equal((await call('POST', '/api/role-ops/exam-attendance/scan', { cookie: inv.cookie, body: { code: rec.adm_no, exam_label: 'BIT 2216 Final' } })).data.already_recorded, true);
  const flag = await call('POST', '/api/role-ops/malpractice', { cookie: inv.cookie, body: { code: rec.adm_no, exam_label: 'BIT 2216 Final', description: 'Phone in exam room' } });
  assert.equal(flag.status, 201);
  assert.equal((await call('GET', '/api/role-ops/malpractice', { cookie: committee.cookie })).data.length > 0, true);
  assert.equal((await call('POST', '/api/role-ops/discipline/suspend', { cookie: inv.cookie, body: { student_id: rec.id, reason: 'x', hearing_date: '2026-12-01' } })).status, 403);
  const sus = await call('POST', '/api/role-ops/discipline/suspend', { cookie: committee.cookie, body: { student_id: rec.id, reason: 'Malpractice', hearing_date: '2026-12-01' } });
  assert.equal(sus.status, 201);
  // old session is dead; the student signs in again and is locked to the landing page
  assert.equal((await call('GET', '/api/portal/overview', { cookie: student.cookie })).status, 401);
  const again = await login(student.email);
  assert.equal(again.data.user.role, 'suspended_student');
  assert.equal((await call('GET', '/api/portal/overview', { cookie: again.cookie })).status, 403);
  const landing = await call('GET', '/api/role-ops/my-status', { cookie: again.cookie });
  assert.equal(landing.data.suspension.hearing_date, '2026-12-01');
  assert.equal((await call('POST', '/api/role-ops/gate/scan', { cookie: (await makeUser('gate_guard')).cookie, body: { code: rec.adm_no } })).data.result, 'red');
  await call('POST', `/api/role-ops/discipline/${sus.data.id}/reinstate`, { cookie: committee.cookie });
  const back = await login(student.email);
  assert.equal(back.data.user.role, 'student');
  assert.equal((await call('GET', '/api/portal/overview', { cookie: back.cookie })).status, 200);
});

test('deferred students are read-only and can apply for readmission', async () => {
  const registrar = await makeUser('registrar');
  const d = await makeUser('deferred_student');
  assert.equal((await call('GET', '/api/portal/overview', { cookie: d.cookie })).status, 200);
  const subject = db.prepare('SELECT id FROM subjects LIMIT 1').get();
  assert.equal((await call('POST', '/api/portal/units/register', { cookie: d.cookie, body: { subject_id: subject.id } })).status, 403);
  const req = await call('POST', '/api/role-ops/readmission', { cookie: d.cookie, body: { reason: 'Ready to return' } });
  assert.equal(req.status, 201);
  assert.equal((await call('POST', `/api/role-ops/readmission/${req.data.id}/decide`, { cookie: d.cookie, body: { approve: true } })).status, 403);
  assert.equal((await call('POST', `/api/role-ops/readmission/${req.data.id}/decide`, { cookie: registrar.cookie, body: { approve: true } })).status, 200);
  assert.equal(db.prepare('SELECT role FROM users WHERE id = ?').get(d.id).role, 'student');
});

test('external examiners are temporary, read-only and can suggest curves; expiry locks them out', async () => {
  const ext = await makeUser('external_examiner', { access_expires_at: '2099-01-01' });
  const director = await makeUser('examinations_director');
  assert.equal((await call('POST', '/api/university/campuses', { cookie: ext.cookie, body: { name: 'X' } })).status, 403);
  const s = await call('POST', '/api/role-ops/curve-suggestions', { cookie: ext.cookie, body: { course_code: 'BIT2216', adjustment: '+3 marks', rationale: 'Paper was harder than moderated' } });
  assert.equal(s.status, 201);
  assert.equal((await call('POST', `/api/role-ops/curve-suggestions/${s.data.id}/decide`, { cookie: ext.cookie, body: { status: 'accepted' } })).status, 403);
  assert.equal((await call('POST', `/api/role-ops/curve-suggestions/${s.data.id}/decide`, { cookie: director.cookie, body: { status: 'accepted' } })).status, 200);
  db.prepare("UPDATE users SET access_expires_at = '2020-01-01' WHERE id = ?").run(ext.id);
  assert.equal((await call('GET', '/api/auth/me', { cookie: ext.cookie })).status, 401);
  assert.equal((await login(ext.email)).status, 403);
});

test('senate votes, closes motions and signs off the graduation list', async () => {
  const s1 = await makeUser('senate_member');
  const s2 = await makeUser('senate_member');
  const registrar = await makeUser('registrar');
  const coordinator = await makeUser('graduation_coordinator');
  const student = await makeUser('student');
  const rec = db.prepare('SELECT id, adm_no FROM students WHERE user_id = ?').get(student.id);
  const m = await call('POST', '/api/role-ops/senate/motions', { cookie: registrar.cookie, body: { title: 'Approve BSc Data Science', motion_type: 'degree_programme' } });
  assert.equal(m.status, 201);
  assert.equal((await call('POST', `/api/role-ops/senate/motions/${m.data.id}/vote`, { cookie: registrar.cookie, body: { vote: 'for' } })).status, 403);
  await call('POST', `/api/role-ops/senate/motions/${m.data.id}/vote`, { cookie: s1.cookie, body: { vote: 'for' } });
  const v = await call('POST', `/api/role-ops/senate/motions/${m.data.id}/vote`, { cookie: s2.cookie, body: { vote: 'for' } });
  assert.equal(v.data.tally.for, 2);
  assert.equal((await call('POST', `/api/role-ops/senate/motions/${m.data.id}/close`, { cookie: registrar.cookie })).data.status, 'passed');
  db.prepare("INSERT INTO graduation_clearance (student_id, academic_year, academic_status) VALUES (?, '2026', 'ready')").run(rec.id);
  // coordinator cannot clear before senate signs off
  assert.equal((await call('POST', '/api/role-ops/graduation/clear', { cookie: coordinator.cookie, body: { student_id: rec.id, academic_year: '2026' } })).status, 400);
  assert.equal((await call('POST', '/api/role-ops/senate/graduation-signoff', { cookie: coordinator.cookie, body: { academic_year: '2026', student_ids: [rec.id] } })).status, 403);
  const so = await call('POST', '/api/role-ops/senate/graduation-signoff', { cookie: s1.cookie, body: { academic_year: '2026', student_ids: [rec.id] } });
  assert.equal(so.data.signed, 1);
  assert.equal((await call('POST', '/api/role-ops/graduation/gown', { cookie: coordinator.cookie, body: { student_id: rec.id } })).status, 400);
  assert.equal((await call('POST', '/api/role-ops/graduation/clear', { cookie: coordinator.cookie, body: { student_id: rec.id, academic_year: '2026' } })).status, 200);
  assert.equal((await call('POST', '/api/role-ops/graduation/gown', { cookie: coordinator.cookie, body: { student_id: rec.id } })).status, 200);
});

test('machine users sign in only with an API key', async () => {
  const machine = await makeUser('machine_user');
  assert.equal(machine.loginStatus, 403);
  const helper = await makeUser('helpdesk_l1');
  assert.equal((await call('POST', '/api/role-ops/api-keys', { cookie: helper.cookie, body: { user_id: machine.id, name: 'x' } })).status, 403);
  const k = await call('POST', '/api/role-ops/api-keys', { cookie: adminCookie, body: { user_id: machine.id, name: 'Midnight penalties', scopes: 'late-fees' } });
  assert.equal(k.status, 201);
  const key = k.data.api_key;
  assert.equal(db.prepare('SELECT COUNT(*) n FROM machine_api_keys WHERE key_hash = ?').get(key).n, 0, 'plain key must not be stored');
  const who = await call('GET', '/api/role-ops/machine/whoami', { headers: { 'x-api-key': key } });
  assert.equal(who.status, 200);
  assert.equal((await call('POST', '/api/role-ops/machine/job-runs', { headers: { 'x-api-key': key }, body: { job: 'late-fees', status: 'success' } })).status, 201);
  assert.equal((await call('POST', '/api/role-ops/machine/job-runs', { headers: { 'x-api-key': key }, body: { job: 'other', status: 'success' } })).status, 403);
  // read-only: cannot change ordinary data, and cannot read student records
  assert.equal((await call('POST', '/api/announcements', { headers: { 'x-api-key': key }, body: { title: 'x', body: 'y' } })).status, 403);
  assert.equal((await call('GET', '/api/fees', { headers: { 'x-api-key': key } })).status, 403);
  await call('POST', `/api/role-ops/api-keys/${k.data.id}/revoke`, { cookie: adminCookie });
  assert.equal((await call('GET', '/api/role-ops/machine/whoami', { headers: { 'x-api-key': key } })).status, 401);
  assert.equal((await call('GET', '/api/role-ops/machine/whoami', { headers: { 'x-api-key': 'mu_bogus' } })).status, 401);
});

test('super admin can view as a user (read-only) and run SELECT queries only', async () => {
  const u = await makeUser('lecturer');
  const view = await call('POST', `/api/role-ops/impersonate/${u.id}`, { cookie: adminCookie });
  assert.equal(view.status, 200);
  const as = view.cookie;
  assert.equal((await call('GET', '/api/auth/me', { cookie: as })).data.user.email, u.email);
  assert.equal((await call('POST', '/api/announcements', { cookie: as, body: { title: 'x', body: 'y' } })).status, 403);
  const back = await call('POST', '/api/role-ops/impersonate/exit', { cookie: as });
  assert.equal(back.status, 200);
  assert.equal((await call('GET', '/api/auth/me', { cookie: back.cookie })).data.user.role, 'admin');
  const helper = await makeUser('helpdesk_l2');
  assert.equal((await call('POST', `/api/role-ops/impersonate/${u.id}`, { cookie: helper.cookie })).status, 403);
  assert.equal((await call('POST', '/api/role-ops/sql', { cookie: adminCookie, body: { query: 'SELECT COUNT(*) AS n FROM users' } })).status, 200);
  assert.equal((await call('POST', '/api/role-ops/sql', { cookie: adminCookie, body: { query: 'DELETE FROM users' } })).status, 400);
  assert.equal((await call('POST', '/api/role-ops/sql', { cookie: adminCookie, body: { query: 'SELECT password FROM users' } })).status, 400);
  assert.equal((await call('POST', '/api/role-ops/sql', { cookie: adminCookie, body: { query: 'SELECT 1; DROP TABLE users' } })).status, 400);
  assert.ok(db.prepare('SELECT COUNT(*) n FROM users').get().n > 1);
});

test("counsellors' session notes are private to the counsellor who wrote them", async () => {
  const c1 = await makeUser('counselor');
  const c2 = await makeUser('counselor');
  const student = await makeUser('student');
  const rec = db.prepare('SELECT adm_no FROM students WHERE user_id = ?').get(student.id);
  assert.equal((await call('POST', '/api/role-ops/counselling', { cookie: c1.cookie, body: { code: rec.adm_no, topic: 'Stress', notes: 'private note' } })).status, 201);
  assert.equal((await call('GET', '/api/role-ops/counselling', { cookie: c1.cookie })).data.length, 1);
  assert.equal((await call('GET', '/api/role-ops/counselling', { cookie: c2.cookie })).data.length, 0);
  assert.equal((await call('GET', '/api/role-ops/counselling', { cookie: adminCookie })).status, 403);
  const logged = db.prepare("SELECT details FROM audit_logs WHERE action='log_counselling'").get();
  assert.ok(!/private note/.test(logged.details));
});

test('transcript clerk can issue documents but not approve results', async () => {
  const clerk = await makeUser('transcript_clerk');
  assert.equal((await call('POST', '/api/university/results/1/approve-board', { cookie: clerk.cookie })).status, 403);
  assert.notEqual((await call('POST', '/api/v3/documents/transcript/999999/issue', { cookie: clerk.cookie })).status, 403);
});

test('vice chancellor sees the executive dashboard but cannot change data', async () => {
  const vc = await makeUser('vice_chancellor');
  const dash = await call('GET', '/api/dashboard/executive', { cookie: vc.cookie });
  assert.equal(dash.status, 200);
  for (const k of ['revenue', 'enrolment', 'graduation', 'revenue_trend']) assert.ok(dash.data[k] !== undefined, `${k} missing`);
  assert.equal((await call('POST', '/api/announcements', { cookie: vc.cookie, body: { title: 'x', body: 'y' } })).status, 403);
  assert.equal((await call('POST', '/api/university/campuses', { cookie: vc.cookie, body: { name: 'X' } })).status, 403);
  const student = await makeUser('student');
  assert.equal((await call('GET', '/api/dashboard/executive', { cookie: student.cookie })).status, 403);
});
