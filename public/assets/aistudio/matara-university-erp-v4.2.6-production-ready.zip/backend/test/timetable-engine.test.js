const test = require('node:test');
const assert = require('node:assert/strict');
const { generate, validate } = require('../lib/timetableEngine');

const rooms = [
  { id: 1, name: 'LH1', capacity: 120, room_type: 'Lecture hall', active: 1 },
  { id: 2, name: 'SR1', capacity: 30, room_type: 'Lecture hall', active: 1 },
  { id: 3, name: 'LAB1', capacity: 30, room_type: 'Laboratory', active: 1 },
];
const unit = (id, code, cohort, lecturer, extra = {}) => ({ id, unit_code: code, unit_name: code, cohort, lecturer_user_id: lecturer, lecturer_name: `L${lecturer}`, sessions_per_week: 2, session_minutes: 120, class_size: 25, room_type_required: '', class_type: 'Lecture', shared_group: '', ...extra });

test('generated timetable has no hard conflicts and is repeatable for a seed', () => {
  const units = [unit(1, 'BIT101', 'Y1', 1), unit(2, 'BIT102', 'Y1', 2), unit(3, 'BIT201', 'Y2', 1), unit(4, 'BIT202', 'Y2', 3), unit(5, 'BIT301', 'Y3', 2, { class_size: 90 })];
  const a = generate({ units, rooms, roomBlocks: [], lecturerBlocks: [], seed: 7 });
  const b = generate({ units, rooms, roomBlocks: [], lecturerBlocks: [], seed: 7 });
  assert.deepEqual(a.slots, b.slots);
  assert.equal(a.unscheduled.length, 0);
  assert.equal(a.slots.length, 10);
  assert.deepEqual(validate({ slots: a.slots, units, rooms, roomBlocks: [], lecturerBlocks: [] }), []);
});

test('lecturer blocks, room capacity and protected break are respected', () => {
  const units = [unit(1, 'BIT101', 'Y1', 1, { class_size: 100 })];
  const lecturerBlocks = [{ lecturer_user_id: 1, day: 'Monday', start_time: '08:00', end_time: '18:00' }];
  const out = generate({ units, rooms, roomBlocks: [], lecturerBlocks, seed: 1 });
  for (const s of out.slots) {
    assert.notEqual(s.day, 'Monday');
    assert.equal(s.room_id, 1); // only LH1 seats 100
    assert.ok(!(s.start_time < '14:00' && s.end_time > '13:00'), 'must avoid the 13:00-14:00 break');
  }
});

test('an impossible unit is reported with a reason, never fabricated', () => {
  const units = [unit(1, 'BIT999', 'Y1', 1, { class_size: 500 }), unit(2, 'BIT101', 'Y1', 2)];
  const out = generate({ units, rooms, roomBlocks: [], lecturerBlocks: [], seed: 1 });
  assert.equal(out.unscheduled.length, 1);
  assert.match(out.unscheduled[0].reason, /BIT999.*seats 500/);
  assert.ok(out.slots.every((s) => s.unit_code !== 'BIT999'));
});

test('one lecturer for two cohorts is never double-booked', () => {
  const units = [unit(1, 'A1', 'Y1', 1, { sessions_per_week: 5 }), unit(2, 'A2', 'Y2', 1, { sessions_per_week: 5 })];
  const out = generate({ units, rooms, roomBlocks: [], lecturerBlocks: [], seed: 3 });
  assert.deepEqual(validate({ slots: out.slots, units, rooms, roomBlocks: [], lecturerBlocks: [] }), []);
});

test('shared classes are one meeting for several cohorts', () => {
  const units = [unit(1, 'SHR1', 'Y1A', 1, { shared_group: 'shr', class_size: 40 }), unit(2, 'SHR1', 'Y1B', 1, { shared_group: 'shr', class_size: 40 })];
  const out = generate({ units, rooms, roomBlocks: [], lecturerBlocks: [], seed: 1 });
  assert.equal(out.slots.length, 4); // 2 sessions x 2 cohort rows
  const key = (s) => `${s.day}${s.start_time}`;
  assert.equal(new Set(out.slots.map(key)).size, 2);
  assert.ok(out.slots.every((s) => s.room_id === 1)); // 80 students need LH1
});

test('validate catches clashes, capacity and maintenance', () => {
  const units = [unit(1, 'A', 'Y1', 1, { class_size: 60 })];
  const slots = [
    { id: 1, unit_id: 1, unit_code: 'A', cohort: 'Y1', lecturer_user_id: 1, lecturer_name: 'L1', day: 'Monday', start_time: '09:00', end_time: '11:00', room_id: 2 },
    { id: 2, unit_id: 9, unit_code: 'B', cohort: 'Y1', lecturer_user_id: 1, lecturer_name: 'L1', day: 'Monday', start_time: '10:00', end_time: '12:00', room_id: 2 },
  ];
  const types = validate({ slots, units, rooms, roomBlocks: [{ room_id: 2, day: 'Monday', start_time: '09:00', end_time: '10:00' }], lecturerBlocks: [] }).map((i) => i.type);
  for (const t of ['capacity', 'room_block', 'room_clash', 'lecturer_clash', 'cohort_clash']) assert.ok(types.includes(t), t);
});

test('locked sessions are kept and respected when regenerating', () => {
  const units = [unit(1, 'A', 'Y1', 1, { sessions_per_week: 1 })];
  const locked = [{ unit_id: 1, unit_code: 'A', unit_name: 'A', cohort: 'Y1', lecturer_user_id: 1, lecturer_name: 'L1', day: 'Tuesday', start_time: '09:00', end_time: '11:00', room_id: 1 }];
  const out = generate({ units, rooms, roomBlocks: [], lecturerBlocks: [], locked, seed: 1 });
  assert.equal(out.slots.length, 1);
  assert.equal(out.slots[0].day, 'Tuesday');
});
