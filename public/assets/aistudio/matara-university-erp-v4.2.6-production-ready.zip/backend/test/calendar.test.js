// University calendar: who may manage which category, the approval flow, and who can see what.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const http = require('node:http');

process.env.JWT_SECRET = process.env.JWT_SECRET || 'local-test-secret-please-change-1234567890';
process.env.NODE_ENV = 'test';
process.env.DEMO_PASSWORD = 'Test-Pass-2026';
process.env.RATE_LIMIT_MAX = '100000';
process.env.MATARA_DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'matara-cal-'));

const { app } = require('../app');
const { db } = require('../db');

let server; let base; let adminCookie; let n = 0;
test.before(async () => { await new Promise((r) => { server = http.createServer(app).listen(0, r); }); base = `http://127.0.0.1:${server.address().port}`; });
test.after(() => { server.close(); });

async function call(method, url, { cookie, body } = {}) {
  const res = await fetch(base + url, { method, headers: { 'content-type': 'application/json', ...(cookie ? { cookie } : {}) }, body: body ? JSON.stringify(body) : undefined });
  const type = res.headers.get('content-type') || '';
  const data = type.includes('json') ? await res.json().catch(() => null) : await res.text();
  return { status: res.status, data, cookie: (res.headers.get('set-cookie') || '').split(';')[0] };
}
async function makeUser(role) {
  n += 1;
  const r = await call('POST', '/api/users', { cookie: adminCookie, body: { role, name: `Cal ${role} ${n}`, username: `cal${role.replaceAll('_', '')}${n}`, password: 'Test-Pass-2026' } });
  assert.equal(r.status, 201, `${role}: ${JSON.stringify(r.data)}`);
  const l = await call('POST', '/api/auth/login', { body: { email: r.data.email, password: 'Test-Pass-2026' } });
  return { id: r.data.id, cookie: l.cookie };
}
const who = {};
const P = '/api/calendar';
const event = (extra = {}) => ({ title: 'Semester 1 2026/27', category: 'academic', event_type: 'Semester', start_date: '2026-09-07', end_date: '2026-12-18', academic_year: '2026/2027', audience: 'all', ...extra });
const ids = (r) => r.data.map((e) => e.title);

test('setup', async () => {
  adminCookie = (await call('POST', '/api/auth/login', { body: { email: 'admin@matara.ac.ke', password: 'Test-Pass-2026' } })).cookie;
  for (const r of ['registrar', 'deputy_registrar', 'vice_chancellor', 'deputy_vc', 'dean', 'dean_of_students', 'hr_director', 'examinations_director', 'lecturer', 'student', 'finance_director']) who[r] = await makeUser(r);
  assert.equal((await call('GET', `${P}/events`)).status, 401);
});

test('each officer can add events only to the categories they own', async () => {
  const allowed = { registrar: ['academic', 'holiday', 'governance'], examinations_director: ['examination'], dean: ['faculty'], dean_of_students: ['student'], hr_director: ['staff', 'holiday'], vice_chancellor: ['general'] };
  const cats = ['academic', 'examination', 'holiday', 'governance', 'faculty', 'student', 'staff', 'general'];
  for (const [r, own] of Object.entries(allowed)) {
    for (const c of cats) {
      const res = await call('POST', `${P}/events`, { cookie: who[r].cookie, body: event({ title: `${r}-${c}`, category: c, event_type: 'Event', academic_year: `x-${r}-${c}` }) });
      assert.equal(res.status, own.includes(c) ? 201 : 403, `${r} -> ${c}`);
    }
  }
  for (const r of ['lecturer', 'student', 'finance_director']) assert.equal((await call('POST', `${P}/events`, { cookie: who[r].cookie, body: event({ category: 'general' }) })).status, 403, r);
  assert.equal((await call('POST', `${P}/events`, { cookie: adminCookie, body: event({ category: 'general' }) })).status, 403, 'admin');
});

let semesterId;
test('academic dates are proposed by the Registrar and published by the VC or DVC', async () => {
  const r = await call('POST', `${P}/events`, { cookie: who.registrar.cookie, body: event() });
  semesterId = r.data.id;
  assert.equal((await call('POST', `${P}/events/${semesterId}/submit`, { cookie: who.registrar.cookie })).data.status, 'pending'); // registrar cannot publish it
  assert.equal((await call('POST', `${P}/events/${semesterId}/approve`, { cookie: who.registrar.cookie })).status, 403);
  assert.equal((await call('POST', `${P}/events/${semesterId}/approve`, { cookie: who.dean.cookie })).status, 404); // dean cannot even see it
  assert.equal((await call('POST', `${P}/events/${semesterId}/approve`, { cookie: adminCookie })).status, 404);
  assert.equal((await call('POST', `${P}/events/${semesterId}/return`, { cookie: who.deputy_vc.cookie, body: {} })).status, 400); // needs a reason
  assert.equal((await call('POST', `${P}/events/${semesterId}/approve`, { cookie: who.deputy_vc.cookie })).data.status, 'published');
});

test('drafts and pending events are hidden from everyone who does not own the category', async () => {
  const d = await call('POST', `${P}/events`, { cookie: who.registrar.cookie, body: event({ title: 'Secret draft', event_type: 'Event', category: 'governance' }) });
  for (const r of ['student', 'lecturer', 'dean', 'finance_director']) {
    const list = await call('GET', `${P}/events`, { cookie: who[r].cookie });
    assert.ok(!ids(list).includes('Secret draft'), r);
    assert.equal((await call('GET', `${P}/events/${d.data.id}/history`, { cookie: who[r].cookie })).status, 404);
  }
  assert.ok(ids(await call('GET', `${P}/events`, { cookie: who.registrar.cookie })).includes('Secret draft'));
});

test('published events reach the right audience only', async () => {
  const mk = async (cookie, category, audience, title) => { const e = await call('POST', `${P}/events`, { cookie, body: event({ title, category, audience, event_type: 'Event', academic_year: title, start_date: '2026-10-20', end_date: '2026-10-20' }) }); await call('POST', `${P}/events/${e.data.id}/submit`, { cookie }); return e.data.id; };
  await mk(who.dean_of_students.cookie, 'student', 'students', 'Students only');
  await mk(who.hr_director.cookie, 'staff', 'staff', 'Staff only');
  await mk(who.dean.cookie, 'faculty', 'lecturers', 'Lecturers only');
  const seen = async (r) => ids(await call('GET', `${P}/events`, { cookie: who[r].cookie }));
  const stu = await seen('student'); const lec = await seen('lecturer'); const fin = await seen('finance_director');
  assert.ok(stu.includes('Students only') && !stu.includes('Staff only') && !stu.includes('Lecturers only'));
  assert.ok(lec.includes('Staff only') && lec.includes('Lecturers only') && !lec.includes('Students only'));
  assert.ok(fin.includes('Staff only') && !fin.includes('Lecturers only') && !fin.includes('Students only'));
  assert.ok(stu.includes('Semester 1 2026/27') && lec.includes('Semester 1 2026/27') && fin.includes('Semester 1 2026/27'));
  // owners who self-publish also notified the audience
  const note = db.prepare("SELECT COUNT(*) n FROM notifications WHERE user_id=? AND title LIKE '%Students only%'").get(who.student.id).n;
  assert.equal(note, 1);
  assert.equal(db.prepare("SELECT COUNT(*) n FROM notifications WHERE user_id=? AND title LIKE '%Students only%'").get(who.lecturer.id).n, 0);
});

test('only the publishing officer can change or cancel a published event, and it is never deleted', async () => {
  const body = event({ end_date: '2026-12-11' });
  assert.equal((await call('PUT', `${P}/events/${semesterId}`, { cookie: who.registrar.cookie, body })).status, 403);
  assert.equal((await call('PUT', `${P}/events/${semesterId}`, { cookie: who.deputy_vc.cookie, body })).status, 200);
  assert.ok(db.prepare("SELECT COUNT(*) n FROM notifications WHERE title LIKE 'Calendar change%'").get().n > 0);
  assert.equal((await call('DELETE', `${P}/events/${semesterId}`, { cookie: who.registrar.cookie })).status, 409);
  assert.equal((await call('POST', `${P}/events/${semesterId}/cancel`, { cookie: who.registrar.cookie, body: { note: 'x' } })).status, 403);
  assert.equal((await call('POST', `${P}/events/${semesterId}/cancel`, { cookie: who.deputy_vc.cookie, body: {} })).status, 400);
  const c = await call('POST', `${P}/events/${semesterId}/cancel`, { cookie: who.deputy_vc.cookie, body: { note: 'Dates replaced' } });
  assert.equal(c.data.status, 'cancelled');
  assert.equal((await call('PUT', `${P}/events/${semesterId}`, { cookie: who.deputy_vc.cookie, body })).status, 409);
});

test('overlapping semesters in one academic year are refused; bad dates are refused', async () => {
  const a = await call('POST', `${P}/events`, { cookie: who.registrar.cookie, body: event({ title: 'Sem A', academic_year: '2030/2031', start_date: '2030-09-01', end_date: '2030-12-15' }) });
  assert.equal(a.status, 201);
  await call('POST', `${P}/events/${a.data.id}/submit`, { cookie: who.registrar.cookie });
  const overlapping = event({ title: 'Sem B', academic_year: '2030/2031', start_date: '2030-12-01', end_date: '2031-03-01' });
  assert.equal((await call('POST', `${P}/events`, { cookie: who.registrar.cookie, body: overlapping })).status, 409); // while A is pending
  await call('POST', `${P}/events/${a.data.id}/approve`, { cookie: who.vice_chancellor.cookie });
  assert.equal((await call('POST', `${P}/events`, { cookie: who.registrar.cookie, body: overlapping })).status, 409); // and once A is published
  assert.equal((await call('POST', `${P}/events`, { cookie: who.registrar.cookie, body: { ...overlapping, start_date: '2030-12-16' } })).status, 201);
  assert.equal((await call('POST', `${P}/events`, { cookie: who.registrar.cookie, body: event({ start_date: '2026-10-10', end_date: '2026-10-01' }) })).status, 400);
  assert.equal((await call('POST', `${P}/events`, { cookie: who.registrar.cookie, body: event({ title: '' }) })).status, 400);
});

test('calendar file export lists only published events the person may see', async () => {
  const stu = await call('GET', `${P}/export.ics`, { cookie: who.student.cookie });
  assert.equal(stu.status, 200);
  assert.match(stu.data, /BEGIN:VCALENDAR/);
  assert.match(stu.data, /SUMMARY:Students only/);
  assert.doesNotMatch(stu.data, /Staff only/);
  assert.doesNotMatch(stu.data, /Secret draft/);
});

test('what each person can manage is reported honestly', async () => {
  const me = await call('GET', `${P}/me`, { cookie: who.registrar.cookie });
  assert.equal(me.data.manages, true);
  assert.deepEqual(me.data.categories.filter((c) => c.canAuthor).map((c) => c.key).sort(), ['academic', 'governance', 'holiday']);
  assert.equal((await call('GET', `${P}/me`, { cookie: who.student.cookie })).data.manages, false);
});
