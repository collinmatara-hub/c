const test = require('node:test');
const assert = require('node:assert/strict');
process.env.JWT_SECRET = process.env.JWT_SECRET || 'local-test-secret-please-change-1234567890';
process.env.NODE_ENV = 'test';
process.env.RATE_LIMIT_MAX = '100000';
const http = require('node:http');
const { app } = require('../app');
const { collectRoutes, isAuthed, PUBLIC } = require('../lib/routeAudit');

const routes = collectRoutes(app);
const isPublic = (r) => PUBLIC.some(([m, p]) => m === r.method && p === r.path);

test('every API route is either allow-listed as public or sits behind requireAuth', () => {
  const open = routes.filter((r) => !isAuthed(r) && !isPublic(r)).map((r) => `${r.method} ${r.path}`);
  assert.deepEqual(open, []);
});

test('anonymous requests to every protected route are rejected with 401', async () => {
  const server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  const port = server.address().port;
  const failures = [];
  for (const r of routes.filter((x) => !isPublic(x))) {
    const path = r.path.replace(/:[A-Za-z]+/g, '1');
    const status = await new Promise((resolve, reject) => {
      const req = http.request({ host: '127.0.0.1', port, path, method: r.method, agent: false, headers: { 'content-type': 'application/json', connection: 'close' } }, (res) => { res.resume(); resolve(res.statusCode); });
      req.setTimeout(5000, () => { req.destroy(new Error(`timeout ${r.method} ${r.path}`)); });
      req.on('error', (e) => resolve('ERR ' + e.message));
      req.end(r.method === 'GET' ? undefined : '{}');
    });
    if (status !== 401) failures.push(`${r.method} ${r.path} -> ${status}`);
  }
  server.closeAllConnections();
  server.close();
  assert.deepEqual(failures, []);
});

test('M-Pesa callback rejects requests when the shared secret is missing or wrong', async () => {
  const send = (query, secret) => new Promise((resolve, reject) => {
    if (secret === undefined) delete process.env.MPESA_CALLBACK_SECRET; else process.env.MPESA_CALLBACK_SECRET = secret;
    const server = http.createServer(app).listen(0, () => {
      const req = http.request({ host: '127.0.0.1', port: server.address().port, path: '/api/v3/payments/mpesa/callback' + query, method: 'POST', headers: { 'content-type': 'application/json' } }, (res) => { res.resume(); server.close(); resolve(res.statusCode); });
      req.on('error', reject);
      req.end(JSON.stringify({ Body: { stkCallback: { CheckoutRequestID: 'x', ResultCode: 0 } } }));
    });
  });
  assert.equal(await send('', undefined), 401);
  assert.equal(await send('?token=anything', undefined), 401);
  assert.equal(await send('?token=wrong', 'a-long-enough-callback-secret'), 401);
  assert.equal(await send('?token=a-long-enough-callback-secret', 'a-long-enough-callback-secret'), 200);
});
