// Who can reach the timetable maker, and what each person can do with it.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const http = require('node:http');

process.env.JWT_SECRET = process.env.JWT_SECRET || 'local-test-secret-please-change-1234567890';
process.env.NODE_ENV = 'test';
process.env.DEMO_PASSWORD = 'Test-Pass-2026';
process.env.RATE_LIMIT_MAX = '100000';
process.env.MATARA_DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'matara-tt-'));

const { app } = require('../app');
const { db } = require('../db');

let server; let base; let adminCookie; let n = 0;
test.before(async () => { await new Promise((r) => { server = http.createServer(app).listen(0, r); }); base = `http://127.0.0.1:${server.address().port}`; });
test.after(() => { server.close(); });

async function call(method, url, { cookie, body } = {}) {
  const res = await fetch(base + url, { method, headers: { 'content-type': 'application/json', ...(cookie ? { cookie } : {}) }, body: body ? JSON.stringify(body) : undefined });
  let data = null; try { data = await res.json(); } catch (_) {}
  return { status: res.status, data, cookie: (res.headers.get('set-cookie') || '').split(';')[0] };
}
async function makeUser(role, name) {
  n += 1;
  const r = await call('POST', '/api/users', { cookie: adminCookie, body: { role, name: name || `TT ${role} ${n}`, username: `tt${role.replaceAll('_', '')}${n}`, password: 'Test-Pass-2026' } });
  assert.equal(r.status, 201, `${role}: ${JSON.stringify(r.data)}`);
  const l = await call('POST', '/api/auth/login', { body: { email: r.data.email, password: 'Test-Pass-2026' } });
  return { id: r.data.id, cookie: l.cookie };
}
const TERM = '2026/2027 Semester 1';
const P = '/api/timetable-maker';
const who = {};

test('setup people, rooms and units', async () => {
  adminCookie = (await call('POST', '/api/auth/login', { body: { email: 'admin@matara.ac.ke', password: 'Test-Pass-2026' } })).cookie;
  for (const r of ['timetabling_officer', 'registrar', 'deputy_registrar', 'dean', 'hod', 'lecturer', 'student', 'finance_director', 'librarian']) who[r] = await makeUser(r);
  who.lecturer2 = await makeUser('lecturer');
  const T = who.timetabling_officer.cookie;
  assert.equal((await call('POST', `${P}/rooms`, { cookie: T, body: { name: 'LH1', capacity: 120 } })).status, 201);
  assert.equal((await call('POST', `${P}/rooms`, { cookie: T, body: { name: 'SR1', capacity: 40 } })).status, 201);
  const unit = (code, cohort, lec) => ({ term: TERM, unit_code: code, unit_name: code, cohort, lecturer_user_id: lec.id, lecturer_name: 'x', sessions_per_week: 2, session_minutes: 120, class_size: 30, department: 'Computing' });
  assert.equal((await call('POST', `${P}/units`, { cookie: T, body: unit('BIT101', 'Y1', who.lecturer) })).status, 201);
  assert.equal((await call('POST', `${P}/units`, { cookie: T, body: unit('BIT102', 'Y1', who.lecturer2) })).status, 201);
});

test('only the right roles can open the maker or its drafts', async () => {
  for (const r of ['timetabling_officer', 'registrar', 'deputy_registrar', 'dean', 'hod', 'admin']) {
    const cookie = r === 'admin' ? adminCookie : who[r].cookie;
    assert.equal((await call('GET', `${P}/versions`, { cookie })).status, 200, `${r} should view`);
  }
  for (const r of ['lecturer', 'student', 'finance_director', 'librarian']) {
    for (const p of ['/versions', '/rooms', '/units', '/audit']) assert.equal((await call('GET', P + p, { cookie: who[r].cookie })).status, 403, `${r} ${p}`);
    assert.equal((await call('POST', `${P}/versions/generate`, { cookie: who[r].cookie, body: { term: TERM } })).status, 403, `${r} generate`);
  }
  assert.equal((await call('GET', `${P}/versions`)).status, 401);
});

test('administrators, registrars, deans and HODs cannot build or edit timetables', async () => {
  for (const cookie of [adminCookie, who.registrar.cookie, who.dean.cookie, who.hod.cookie]) {
    assert.equal((await call('POST', `${P}/versions/generate`, { cookie, body: { term: TERM } })).status, 403);
    assert.equal((await call('POST', `${P}/rooms`, { cookie, body: { name: 'X', capacity: 10 } })).status, 403);
    assert.equal((await call('POST', `${P}/units`, { cookie, body: {} })).status, 403);
  }
});

let versionId;
test('timetabling officer generates a draft; it is never published automatically', async () => {
  const r = await call('POST', `${P}/versions/generate`, { cookie: who.timetabling_officer.cookie, body: { term: TERM, seed: 5 } });
  assert.equal(r.status, 201, JSON.stringify(r.data));
  versionId = r.data.id;
  assert.equal(r.data.placed, 4);
  const v = await call('GET', `${P}/versions/${versionId}`, { cookie: who.timetabling_officer.cookie });
  assert.equal(v.data.version.status, 'draft');
  assert.equal(v.data.issues.length, 0);
});

test('lecturers and students see nothing until publication', async () => {
  for (const r of ['lecturer', 'student']) {
    const m = await call('GET', `${P}/mine`, { cookie: who[r].cookie });
    assert.equal(m.status, 200);
    assert.equal(m.data.published, false);
    assert.deepEqual(m.data.slots, []);
  }
});

test('manual moves that create a clash are refused', async () => {
  const T = who.timetabling_officer.cookie;
  const v = await call('GET', `${P}/versions/${versionId}`, { cookie: T });
  const [a, b] = v.data.slots;
  const r = await call('PATCH', `${P}/versions/${versionId}/slots/${b.id}`, { cookie: T, body: { day: a.day, start_time: a.start_time, end_time: a.end_time, room_id: a.room_id } });
  assert.equal(r.status, 409);
});

test('approval needs a different person, then registrar publishes', async () => {
  const T = who.timetabling_officer.cookie;
  assert.equal((await call('POST', `${P}/versions/${versionId}/approve`, { cookie: who.registrar.cookie })).status, 409); // still draft
  assert.equal((await call('POST', `${P}/versions/${versionId}/submit`, { cookie: T })).status, 200);
  assert.equal((await call('POST', `${P}/versions/${versionId}/approve`, { cookie: T })).status, 403); // officer cannot approve
  assert.equal((await call('POST', `${P}/versions/${versionId}/approve`, { cookie: adminCookie })).status, 403);
  assert.equal((await call('POST', `${P}/versions/${versionId}/approve`, { cookie: who.dean.cookie })).status, 403);
  assert.equal((await call('POST', `${P}/versions/${versionId}/publish`, { cookie: who.registrar.cookie })).status, 409); // not approved yet
  assert.equal((await call('POST', `${P}/versions/${versionId}/approve`, { cookie: who.registrar.cookie })).status, 200);
  assert.equal((await call('POST', `${P}/versions/${versionId}/publish`, { cookie: T })).status, 403);
  assert.equal((await call('POST', `${P}/versions/${versionId}/publish`, { cookie: who.registrar.cookie })).status, 200);
  assert.equal((await call('PATCH', `${P}/versions/${versionId}/slots/1`, { cookie: T, body: { day: 'Friday' } })).status, 409); // published is frozen
});

test('lecturers see only their own sessions after publication', async () => {
  const mine = await call('GET', `${P}/mine`, { cookie: who.lecturer.cookie });
  assert.equal(mine.data.published, true);
  assert.deepEqual([...new Set(mine.data.slots.map((s) => s.unit_code))], ['BIT101']);
  const other = await call('GET', `${P}/mine`, { cookie: who.lecturer2.cookie });
  assert.deepEqual([...new Set(other.data.slots.map((s) => s.unit_code))], ['BIT102']);
});

test('students see only the units they registered', async () => {
  const stu = db.prepare('SELECT id FROM students WHERE user_id=?').get(who.student.id);
  db.prepare("INSERT OR IGNORE INTO subjects(name,code) VALUES('Unit','BIT101')").run();
  const sub = db.prepare("SELECT id FROM subjects WHERE code='BIT101'").get();
  db.prepare('INSERT INTO unit_registrations(student_id,subject_id,term) VALUES(?,?,?)').run(stu.id, sub.id, TERM);
  const mine = await call('GET', `${P}/mine`, { cookie: who.student.cookie });
  assert.deepEqual([...new Set(mine.data.slots.map((s) => s.unit_code))], ['BIT101']);
});

test('lecturers can set only their own unavailability', async () => {
  const body = { day: 'Monday', start_time: '08:00', end_time: '10:00', reason: 'Clinic' };
  const own = await call('POST', `${P}/availability`, { cookie: who.lecturer.cookie, body });
  assert.equal(own.status, 201);
  const forOther = await call('POST', `${P}/availability`, { cookie: who.lecturer.cookie, body: { ...body, lecturer_user_id: who.lecturer2.id } });
  assert.equal(forOther.status, 201);
  const rows = db.prepare('SELECT lecturer_user_id FROM tt_lecturer_blocks').all();
  assert.ok(rows.every((r) => r.lecturer_user_id === who.lecturer.id), 'lecturer_user_id from a lecturer is ignored');
  assert.equal((await call('DELETE', `${P}/availability/${own.data.id}`, { cookie: who.lecturer2.cookie })).status, 403);
  assert.equal((await call('POST', `${P}/availability`, { cookie: who.student.cookie, body })).status, 403);
});

test('restore creates a new draft that must be approved again', async () => {
  const r = await call('POST', `${P}/versions/${versionId}/restore`, { cookie: who.timetabling_officer.cookie });
  assert.equal(r.status, 201);
  const v = await call('GET', `${P}/versions/${r.data.id}`, { cookie: who.timetabling_officer.cookie });
  assert.equal(v.data.version.status, 'draft');
  assert.equal(v.data.slots.length, 4);
});
