const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const multer = require('multer');
const { db, dataDir } = require('../db');
const { createVerifiedBackup, verifyBackupFile } = require('../lib/backup');
const { requireAuth, requireRole } = require('../middleware/auth');
const router = express.Router();
router.use(requireAuth, requireRole('admin'));

const brandingDir = path.join(__dirname, '..', 'uploads', 'branding');
fs.mkdirSync(brandingDir, { recursive: true });
const brandingStorage = multer.diskStorage({
  destination: brandingDir,
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, `dashboard-${Date.now()}${ext}`);
  },
});
const brandingUpload = multer({
  storage: brandingStorage,
  limits: { fileSize: 8 * 1024 * 1024 },
  fileFilter: (req, file, cb) => cb(null, ['image/jpeg', 'image/png', 'image/webp'].includes(file.mimetype)),
});

const csvEscape = v => `"${String(v ?? '').replaceAll('"','""')}"`;
function audit(req, action, entity, entityId, details='') {
  db.prepare('INSERT INTO audit_logs(user_id,action,entity,entity_id,details) VALUES(?,?,?,?,?)').run(req.user.id, action, entity, entityId || null, details);
}
function safe(fn,res){ try{res.json(fn())}catch(e){console.error(e);res.status(400).json({error:e.message});} }

router.get('/overview',(req,res)=>safe(()=>({
  university: db.prepare("SELECT COUNT(*) c FROM system_settings").get().c,
  users: db.prepare('SELECT COUNT(*) c FROM users').get().c,
  students: db.prepare('SELECT COUNT(*) c FROM students').get().c,
  teachers: db.prepare('SELECT COUNT(*) c FROM teachers').get().c,
  active_year: db.prepare('SELECT * FROM academic_years WHERE active=1 ORDER BY id DESC LIMIT 1').get() || null,
  terms: db.prepare('SELECT COUNT(*) c FROM terms').get().c,
  classes: db.prepare('SELECT COUNT(*) c FROM classes').get().c,
  subjects: db.prepare('SELECT COUNT(*) c FROM subjects').get().c,
  outstanding: db.prepare('SELECT COALESCE(SUM(amount_due-amount_paid),0) total FROM fees').get().total,
  recent_audit: db.prepare('SELECT a.*,u.name user_name FROM audit_logs a LEFT JOIN users u ON u.id=a.user_id ORDER BY a.created_at DESC LIMIT 15').all()
}),res));

router.get('/settings',(req,res)=>safe(()=>db.prepare('SELECT * FROM system_settings ORDER BY key').all(),res));
router.post('/branding/dashboard-image', brandingUpload.single('image'), (req,res) => {
  if (!req.file) return res.status(400).json({ error: 'Please choose a JPG, PNG or WEBP image up to 8 MB.' });
  const url = `/uploads/branding/${req.file.filename}`;
  const previous = db.prepare("SELECT value FROM system_settings WHERE key='dashboard_image_url'").get()?.value;
  db.prepare("INSERT INTO system_settings(key,value) VALUES('dashboard_image_url',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value").run(url);
  if (previous && previous.startsWith('/uploads/branding/')) {
    const oldPath = path.join(__dirname, '..', previous.replace(/^\//, ''));
    try { if (fs.existsSync(oldPath)) fs.unlinkSync(oldPath); } catch (_) {}
  }
  audit(req, 'UPDATE_DASHBOARD_IMAGE', 'system_settings', null, url);
  res.json({ success: true, dashboard_image_url: url });
});
router.delete('/branding/dashboard-image', (req,res)=>{
  const previous = db.prepare("SELECT value FROM system_settings WHERE key='dashboard_image_url'").get()?.value;
  db.prepare("INSERT INTO system_settings(key,value) VALUES('dashboard_image_url','') ON CONFLICT(key) DO UPDATE SET value=''").run();
  if (previous && previous.startsWith('/uploads/branding/')) { const oldPath=path.join(__dirname,'..',previous.replace(/^\//,'')); try{if(fs.existsSync(oldPath))fs.unlinkSync(oldPath);}catch(_){} }
  audit(req,'RESET_DASHBOARD_IMAGE','system_settings',null,'Dashboard image reset to built-in illustration');
  res.json({success:true,dashboard_image_url:''});
});
router.put('/settings/:key',(req,res)=>safe(()=>{const value=String(req.body.value??'');db.prepare('INSERT INTO system_settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').run(req.params.key,value);audit(req,'UPDATE_SETTING','system_settings',null,`${req.params.key} updated`);return {success:true}},res));

router.get('/roles',(req,res)=>safe(()=>db.prepare('SELECT * FROM custom_roles ORDER BY name').all().map(r=>({...r,permissions:db.prepare('SELECT * FROM role_permissions WHERE role_id=? ORDER BY module,permission').all(r.id)})),res));
router.post('/roles',(req,res)=>safe(()=>{const {name,description,permissions=[]}=req.body;if(!name)throw Error('Role name is required');const x=db.prepare('INSERT INTO custom_roles(name,description) VALUES(?,?)').run(name,description||'');for(const p of permissions){db.prepare('INSERT INTO role_permissions(role_id,module,permission) VALUES(?,?,?)').run(x.lastInsertRowid,p.module,p.permission)}audit(req,'CREATE_ROLE','custom_roles',x.lastInsertRowid,name);return {id:x.lastInsertRowid}},res));
router.put('/roles/:id',(req,res)=>safe(()=>{db.prepare('UPDATE custom_roles SET name=?,description=? WHERE id=?').run(req.body.name,req.body.description||'',req.params.id);db.prepare('DELETE FROM role_permissions WHERE role_id=?').run(req.params.id);for(const p of (req.body.permissions||[]))db.prepare('INSERT INTO role_permissions(role_id,module,permission) VALUES(?,?,?)').run(req.params.id,p.module,p.permission);audit(req,'UPDATE_ROLE','custom_roles',req.params.id,req.body.name||'');return {success:true}},res));
router.delete('/roles/:id',(req,res)=>safe(()=>{db.prepare('DELETE FROM custom_roles WHERE id=?').run(req.params.id);audit(req,'DELETE_ROLE','custom_roles',req.params.id);return {success:true}},res));

router.get('/admissions',(req,res)=>safe(()=>db.prepare('SELECT * FROM admissions ORDER BY id DESC').all(),res));
router.post('/admissions',(req,res)=>safe(()=>{const f=['application_no','applicant_name','guardian_name','guardian_phone','class_applied','status','notes'];const x=db.prepare(`INSERT INTO admissions(${f.join(',')}) VALUES(${f.map(()=>'?').join(',')})`).run(...f.map(k=>req.body[k]??''));audit(req,'CREATE_ADMISSION','admissions',x.lastInsertRowid,req.body.applicant_name||'');return {id:x.lastInsertRowid}},res));
router.put('/admissions/:id',(req,res)=>safe(()=>{db.prepare('UPDATE admissions SET status=?,notes=? WHERE id=?').run(req.body.status||'pending',req.body.notes||'',req.params.id);audit(req,'UPDATE_ADMISSION','admissions',req.params.id,req.body.status||'');return {success:true}},res));

router.post('/promote',(req,res)=>safe(()=>{const {from_class_id,to_class_id,student_ids}=req.body;if(!to_class_id)throw Error('Target class is required');const ids=Array.isArray(student_ids)&&student_ids.length?student_ids:db.prepare("SELECT id FROM students WHERE class_id=? AND status='active'").all(from_class_id).map(x=>x.id);const stmt=db.prepare('UPDATE students SET class_id=? WHERE id=?');for(const id of ids)stmt.run(to_class_id,id);audit(req,'BULK_PROMOTION','students',null,`${ids.length} students promoted to class ${to_class_id}`);return {updated:ids.length}},res));

router.get('/exports/:dataset',(req,res)=>{
  const maps={students:['SELECT id,adm_no,name,gender,dob,class_id,guardian_name,guardian_phone,status,enrolled_on FROM students ORDER BY id','students'],users:['SELECT id,name,email,role,active,created_at,password_changed_at FROM users ORDER BY id','users'],fees:['SELECT id,student_id,term,amount_due,amount_paid,due_date FROM fees ORDER BY id','fees'],audit:['SELECT * FROM audit_logs ORDER BY id','audit_logs']};
  const m=maps[req.params.dataset];if(!m)return res.status(404).json({error:'Unknown export dataset'});
  const rows=db.prepare(m[0]).all();const headers=rows.length?Object.keys(rows[0]):[];const csv=[headers.map(csvEscape).join(','),...rows.map(r=>headers.map(h=>csvEscape(r[h])).join(','))].join('\n');audit(req,'EXPORT_CSV',m[1],null,`${rows.length} rows`);res.setHeader('Content-Type','text/csv; charset=utf-8');res.setHeader('Content-Disposition',`attachment; filename=${m[1]}.csv`);res.send(csv);
});

router.get('/export-all',(req,res)=>{
  try {
    // Full administrative data export. Authentication is admin-only via router middleware.
    // Password hashes, reset tokens, recovery hashes and API-key hashes are deliberately excluded.
    const blockedColumns = {
      users: new Set(['password']),
      password_reset_tokens: new Set(['token_hash']),
      account_recovery: new Set(['recovery_code_hash']),
      api_keys: new Set(['key_hash'])
    };
    const tables = db.prepare(`SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name`).all();
    const exportData = {
      export_name: 'Matara University - Complete University Data Export',
      exported_at: new Date().toISOString(),
      exported_by: { id: req.user.id, name: req.user.name, email: req.user.email },
      security_note: 'Authentication secrets, password hashes, password-reset tokens, recovery hashes and API-key hashes are excluded.',
      tables: {}
    };
    let totalRows = 0;
    for (const {name} of tables) {
      const columns = db.prepare(`PRAGMA table_info(${name})`).all().map(c => c.name);
      const blocked = blockedColumns[name] || new Set();
      const safeColumns = columns.filter(c => !blocked.has(c));
      const rows = safeColumns.length ? db.prepare(`SELECT ${safeColumns.map(c => `"${c.replaceAll('"','""')}"`).join(',')} FROM "${name.replaceAll('"','""')}"`).all() : [];
      exportData.tables[name] = { columns: safeColumns, rows };
      totalRows += rows.length;
    }
    exportData.summary = { table_count: tables.length, total_rows: totalRows };
    audit(req,'EXPORT_ALL_DATA','university_data',null,`${tables.length} tables, ${totalRows} rows`);
    const filename = `matara-university-data-${new Date().toISOString().slice(0,10)}.json`;
    res.setHeader('Content-Type','application/json; charset=utf-8');
    res.setHeader('Content-Disposition',`attachment; filename=${filename}`);
    res.send(JSON.stringify(exportData, null, 2));
  } catch (e) {
    console.error(e);
    res.status(500).json({error:'Could not create the full university data export', details:e.message});
  }
});

router.get('/backup',async(req,res)=>{
  try { const dir=path.join(dataDir,'backups');fs.mkdirSync(dir,{recursive:true});const name=`matara-backup-${new Date().toISOString().replace(/[:.]/g,'-')}.db`;const out=path.join(dir,name);const result=await createVerifiedBackup(db,out);db.prepare('INSERT INTO backup_history(filename,created_by,size_bytes,verified) VALUES(?,?,?,?)').run(name,req.user.id,result.size,1);audit(req,'CREATE_VERIFIED_BACKUP','database',null,`${name}; sha256=${result.sha256}`);res.download(out,name); } catch(e) { console.error('[backup] admin backup failed',e.message);res.status(500).json({error:'Backup creation or integrity verification failed.'}); }
});
router.get('/backups',(req,res)=>safe(()=>db.prepare('SELECT * FROM backup_history ORDER BY created_at DESC').all(),res));
router.post('/backup/restore/:filename',(req,res)=>{
  try {
    const filename=path.basename(req.params.filename);
    if(filename!==req.params.filename||!filename.endsWith('.db'))return res.status(400).json({error:'Invalid backup filename'});
    const source=path.join(dataDir,'backups',filename), target=path.join(dataDir,'matara.db');
    if(!fs.existsSync(source))return res.status(404).json({error:'Backup not found'});
    verifyBackupFile(source);
    // The running process uses SQLite WAL. Checkpoint before replacement, then copy the verified backup.
    try{db.exec('PRAGMA wal_checkpoint(TRUNCATE)')}catch(_){}
    fs.copyFileSync(source,target);
    db.prepare('INSERT INTO audit_logs(user_id,action,entity,details) VALUES(?,?,?,?)').run(req.user.id,'RESTORE_BACKUP','database',filename);
    res.json({success:true,message:'Backup restored. Restart the Matara University server before continuing.'});
  }catch(e){console.error(e);res.status(500).json({error:'Restore failed',details:e.message});}
});

router.get('/security',(req,res)=>safe(()=>({login_count:db.prepare("SELECT COUNT(*) c FROM audit_logs WHERE action LIKE '%LOGIN%'").get().c,password_events:db.prepare("SELECT COUNT(*) c FROM password_history").get().c,active_users:db.prepare('SELECT COUNT(*) c FROM users WHERE active=1').get().c,disabled_users:db.prepare('SELECT COUNT(*) c FROM users WHERE active=0').get().c,custom_roles:db.prepare('SELECT COUNT(*) c FROM custom_roles').get().c}),res));

module.exports=router;
