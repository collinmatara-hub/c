const express = require('express');
const { db } = require('../db');
const { requireAuth } = require('../middleware/auth');
const { requirePermission, hasPermission } = require('../lib/rbac');
const router = express.Router();
const LEGACY_EDIT_ROLES_REPLACED = ['admin','super_admin','registrar','deputy_registrar','dean','deputy_dean','hod','examination_officer','exam_board','timetabler','academic_staff','lecturer','senior_lecturer','professor'];
const days = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'];
function audit(req, entryId, action, details='') {
  db.prepare('INSERT INTO university_timetable_audit(entry_id,action,actor_id,actor_name,details) VALUES(?,?,?,?,?)')
    .run(entryId, action, req.user?.id || null, req.user?.name || '', details);
}
function conflict(input, excludeId=null) {
  const start=input.start_time, end=input.end_time;
  if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(start||'') || !/^([01]\d|2[0-3]):[0-5]\d$/.test(end||'') || start>=end) return 'End time must be later than start time and both times must be valid.';
  if (!days.includes(input.day)) return 'Select a valid teaching day.';
  if (Number(input.expected_attendance||0)<0) return 'Expected attendance cannot be negative.';
  if (start<'08:00' || end>'20:00') return 'Classes must be scheduled between 08:00 and 20:00.';
  const params=[input.day,end,start];
  let sql=`SELECT * FROM university_timetable_entries WHERE day=? AND start_time < ? AND end_time > ? AND status!='archived'`;
  if(excludeId){sql+=' AND id != ?';params.push(excludeId);}
  const rows=db.prepare(sql).all(...params);
  const same=(a,b)=>String(a||'').trim().toLowerCase() && String(a||'').trim().toLowerCase()===String(b||'').trim().toLowerCase();
  for(const r of rows){
    if(input.room && same(r.room,input.room)) return `Room conflict: ${input.room} is already booked for ${r.unit_code} (${r.start_time}–${r.end_time}).`;
    if(input.lecturer && same(r.lecturer,input.lecturer)) return `Lecturer conflict: ${input.lecturer} is already assigned to ${r.unit_code} (${r.start_time}–${r.end_time}).`;
    if(input.cohort && same(r.cohort,input.cohort)) return `Cohort conflict: ${input.cohort} already has ${r.unit_code} (${r.start_time}–${r.end_time}).`;
  }
  return null;
}
router.get('/dashboard', requireAuth, requirePermission('timetable.view'), (req,res)=>{
 const entries=db.prepare("SELECT * FROM university_timetable_entries WHERE status!='archived' ORDER BY day,start_time").all();
 const count=(fn)=>entries.filter(fn).length;
 const conflicts=[];
 for(const e of entries){const issue=conflict(e,e.id); if(issue) conflicts.push({entry_id:e.id,unit_code:e.unit_code,day:e.day,start_time:e.start_time,message:issue});}
 const rooms=[...new Set(entries.map(e=>e.room).filter(Boolean))];
 const units=[...new Set(entries.map(e=>e.unit_code))];
 res.json({entries,stats:{scheduled:entries.length,unscheduled:null,completion:null,conflicts:conflicts.length,rooms:rooms.length,roomUtilization:rooms.length?Math.min(100,Math.round(entries.length/(rooms.length*5)*100)):0,lecturers:new Set(entries.map(e=>e.lecturer).filter(Boolean)).size,pending:count(e=>e.status==='pending'),published:count(e=>e.status==='published'),examinations:count(e=>e.class_type==='Examination')},conflicts,units,updatedAt:new Date().toISOString()});
});
router.get('/audit', requireAuth, requirePermission('timetable.view'), (req,res)=>res.json(db.prepare('SELECT * FROM university_timetable_audit ORDER BY id DESC LIMIT 100').all()));
router.post('/entries', requireAuth, requirePermission('timetable.manage'), (req,res)=>{
 const x=req.body||{}; for(const f of ['unit_code','unit_name','day','start_time','end_time']) if(!String(x[f]||'').trim()) return res.status(400).json({error:`${f.replaceAll('_',' ')} is required.`});
 const issue=conflict(x); if(issue)return res.status(409).json({error:issue});
 const q=db.prepare(`INSERT INTO university_timetable_entries(academic_year,semester,campus,school,department,programme,cohort,unit_code,unit_name,lecturer,class_type,room,day,start_time,end_time,expected_attendance,status,notes,created_by) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
 const r=q.run(x.academic_year||'2026/2027',x.semester||'Semester 1',x.campus||'Main Campus',x.school||'',x.department||'',x.programme||'',x.cohort||'',x.unit_code.trim(),x.unit_name.trim(),x.lecturer||'',x.class_type||'Lecture',x.room||'',x.day,x.start_time,x.end_time,Number(x.expected_attendance||0),'draft',x.notes||'',req.user.id);
 audit(req,r.lastInsertRowid,'created',`${x.unit_code} ${x.day} ${x.start_time}-${x.end_time}`); res.status(201).json(db.prepare('SELECT * FROM university_timetable_entries WHERE id=?').get(r.lastInsertRowid));
});
router.patch('/entries/:id', requireAuth, requirePermission('timetable.manage'), (req,res)=>{
 const old=db.prepare('SELECT * FROM university_timetable_entries WHERE id=?').get(req.params.id); if(!old)return res.status(404).json({error:'Timetable entry not found.'});
 const x={...old,...req.body}; if(['approved','published','archived'].includes(old.status) && !hasPermission(req.user.actual_role||req.user.role,'timetable.publish'))return res.status(403).json({error:'Only an authorized academic approver may change an approved or published timetable.'});
 if(req.body.status==='published' && !hasPermission(req.user.actual_role||req.user.role,'timetable.publish'))return res.status(403).json({error:'You do not have permission to publish timetables.'});
 const issue=conflict(x,old.id); if(issue)return res.status(409).json({error:issue});
 const fields=['academic_year','semester','campus','school','department','programme','cohort','unit_code','unit_name','lecturer','class_type','room','day','start_time','end_time','expected_attendance','status','notes'];
 db.prepare(`UPDATE university_timetable_entries SET ${fields.map(f=>`${f}=?`).join(',')},updated_at=datetime('now') WHERE id=?`).run(...fields.map(f=>x[f]??''),old.id);
 audit(req,old.id,'updated',JSON.stringify({from:old.status,to:x.status})); res.json(db.prepare('SELECT * FROM university_timetable_entries WHERE id=?').get(old.id));
});
router.delete('/entries/:id', requireAuth, requirePermission('timetable.manage'), (req,res)=>{const old=db.prepare('SELECT * FROM university_timetable_entries WHERE id=?').get(req.params.id);if(!old)return res.status(404).json({error:'Timetable entry not found.'}); if(old.status==='published'&&!hasPermission(req.user.actual_role||req.user.role,'timetable.publish'))return res.status(403).json({error:'Published classes require registrar-level authorization to remove.'});audit(req,old.id,'deleted',old.unit_code);db.prepare('DELETE FROM university_timetable_entries WHERE id=?').run(old.id);res.json({success:true});});
router.post('/validate', requireAuth, requirePermission('timetable.manage'), (req,res)=>{const entries=db.prepare("SELECT * FROM university_timetable_entries WHERE status!='archived'").all();const issues=[];for(const e of entries){const message=conflict(e,e.id);if(message)issues.push({id:e.id,unit_code:e.unit_code,message});}res.json({valid:issues.length===0,issues,checked:entries.length});});
router.post('/generate', requireAuth, requirePermission('timetable.manage'), (req,res)=>{
 const x=req.body||{}; const units=Array.isArray(x.units)?x.units:[]; if(!units.length)return res.status(400).json({error:'Add units to the generation request. The generator will not invent university units.'});
 const slots=[]; for(const day of days.slice(0,5))for(const start of ['08:00','10:00','12:00','14:00','16:00'])slots.push({day,start_time:start,end_time:String(Number(start.slice(0,2))+2).padStart(2,'0')+':00'});
 const placed=[],unplaced=[]; for(const u of units){let found=null;for(const slot of slots){const candidate={...u,...slot,room:u.room||'',lecturer:u.lecturer||'',cohort:u.cohort||''};if(!conflict(candidate)&&!placed.some(p=>p.day===slot.day&&p.start_time===slot.start_time&&((p.room&&candidate.room&&p.room===candidate.room)||(p.lecturer&&candidate.lecturer&&p.lecturer===candidate.lecturer)||(p.cohort&&candidate.cohort&&p.cohort===candidate.cohort)))){found=candidate;break;}}if(found)placed.push(found);else unplaced.push({unit_code:u.unit_code||'Unknown',reason:'No conflict-free slot found with the supplied room, lecturer and cohort data.'});}
 res.json({status:'draft',algorithm:'constraint-aware greedy draft; requires review',placed,unplaced,notice:'This is a draft only. Review all constraints and save entries before submitting for approval.'});
});
router.post('/entries/:id/submit', requireAuth, requirePermission('timetable.manage'), (req,res)=>{const e=db.prepare('SELECT * FROM university_timetable_entries WHERE id=?').get(req.params.id);if(!e)return res.status(404).json({error:'Entry not found.'});const issue=conflict(e,e.id);if(issue)return res.status(409).json({error:issue});db.prepare("UPDATE university_timetable_entries SET status='pending',updated_at=datetime('now') WHERE id=?").run(e.id);audit(req,e.id,'submitted','Submitted for review');res.json({success:true,status:'pending'});});
module.exports=router;
