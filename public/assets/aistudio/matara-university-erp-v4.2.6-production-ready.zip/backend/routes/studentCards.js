const express = require('express');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { db } = require('../db');
const { requireAuth } = require('../middleware/auth');
const router = express.Router();
const photoDir = path.join(__dirname, '..', 'uploads', 'student-photos');
fs.mkdirSync(photoDir, { recursive: true });
const photoUpload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 5 * 1024 * 1024 }, fileFilter: (_req, file, cb) => cb(null, /^image\/(jpeg|png|webp)$/.test(file.mimetype)) });
const CARD_STAFF = ['admin','super_admin','ict','registrar','deputy_registrar','admissions_officer'];
const SECURITY_STAFF = ['admin','super_admin','security','security_officer','gate_security'];
const canManage = req => CARD_STAFF.includes(String(req.user?.role || '').toLowerCase());
const canSecurity = req => SECURITY_STAFF.includes(String(req.user?.role || '').toLowerCase());
const hasStudent = id => db.prepare('SELECT id FROM students WHERE id=?').get(id);
const ownStudentId = req => {
  const u=req.user||{};
  const direct=db.prepare('SELECT id FROM students WHERE user_id=?').get(u.id);
  if(direct) return direct.id;
  const byEmail=u.email ? db.prepare('SELECT s.id FROM students s JOIN users u ON lower(u.email)=lower(?) AND (lower(s.email)=lower(u.email) OR lower(s.guardian_email)=lower(u.email)) LIMIT 1').get(u.email) : null;
  return byEmail?.id || null;
};
// Additive schema migrations: existing student records and databases are preserved.
db.exec(`
CREATE TABLE IF NOT EXISTS student_data_consent (
 id INTEGER PRIMARY KEY AUTOINCREMENT, student_id INTEGER NOT NULL, notice_version TEXT NOT NULL,
 consent_given INTEGER NOT NULL CHECK(consent_given IN (0,1)), purposes TEXT NOT NULL,
 recorded_by INTEGER, recorded_at TEXT NOT NULL DEFAULT(datetime('now')), withdrawn_at TEXT,
 ip_hint TEXT, FOREIGN KEY(student_id) REFERENCES students(id) ON DELETE CASCADE,
 FOREIGN KEY(recorded_by) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS student_card_issues (
 id INTEGER PRIMARY KEY AUTOINCREMENT, student_id INTEGER NOT NULL, card_type TEXT NOT NULL CHECK(card_type IN ('id','exam')),
 card_number TEXT, academic_year TEXT, semester TEXT, status TEXT NOT NULL DEFAULT 'issued',
 issued_by INTEGER, issued_at TEXT NOT NULL DEFAULT(datetime('now')), updated_at TEXT NOT NULL DEFAULT(datetime('now')),
 notes TEXT, FOREIGN KEY(student_id) REFERENCES students(id) ON DELETE CASCADE, FOREIGN KEY(issued_by) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS student_card_gate_control (
 card_number TEXT PRIMARY KEY, student_id INTEGER NOT NULL, access_status TEXT NOT NULL DEFAULT 'active' CHECK(access_status IN ('active','blocked')),
 reason TEXT, updated_by INTEGER, updated_at TEXT NOT NULL DEFAULT(datetime('now')), FOREIGN KEY(student_id) REFERENCES students(id) ON DELETE CASCADE, FOREIGN KEY(updated_by) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS student_card_audit (
 id INTEGER PRIMARY KEY AUTOINCREMENT, student_id INTEGER NOT NULL, actor_id INTEGER, action TEXT NOT NULL,
 details TEXT, created_at TEXT NOT NULL DEFAULT(datetime('now')),
 FOREIGN KEY(student_id) REFERENCES students(id) ON DELETE CASCADE, FOREIGN KEY(actor_id) REFERENCES users(id)
);
`);
const addCol=(table,col,def)=>{const cols=db.prepare(`PRAGMA table_info(${table})`).all().map(x=>x.name);if(cols.length&&!cols.includes(col))db.exec(`ALTER TABLE ${table} ADD COLUMN ${col} ${def}`);};
[
 ['students','email','TEXT'],['students','phone','TEXT'],['students','address','TEXT'],['students','county','TEXT'],['students','nationality','TEXT'],['students','passport_no','TEXT'],['students','gender','TEXT'],
 ['student_profiles','personal_email','TEXT'],['student_profiles','alternative_phone','TEXT'],['student_profiles','postal_address','TEXT'],['student_profiles','country_of_birth','TEXT'],['student_profiles','marital_status','TEXT'],['student_profiles','accessibility_requirements','TEXT'],['student_profiles','kcse_index','TEXT'],['student_profiles','kcse_grades','TEXT'],['student_profiles','aggregate_points','TEXT'],['student_profiles','previous_institution','TEXT'],['student_profiles','qualification_verification_status','TEXT'],['student_profiles','application_reference','TEXT'],['student_profiles','faculty_name','TEXT'],['student_profiles','department_name','TEXT'],['student_profiles','programme_name','TEXT'],['student_profiles','campus','TEXT'],['student_profiles','study_mode','TEXT'],['student_profiles','intake','TEXT'],['student_profiles','year_of_study','TEXT'],['student_profiles','current_semester','TEXT'],['student_profiles','reporting_date','TEXT'],['student_profiles','offer_status','TEXT']
].forEach(([t,c,d])=>addCol(t,c,d));
function studentCardData(id){return db.prepare(`SELECT s.id,s.adm_no,s.name,s.gender,s.dob,s.email,s.phone,s.address,s.county,s.nationality,s.passport_no,s.photo_url,s.class_id,s.status,c.name class_name,c.stream class_stream,sp.*,ue.academic_year,ue.intake,ue.status enrollment_status,p.name program_name,p.code program_code FROM students s LEFT JOIN classes c ON c.id=s.class_id LEFT JOIN student_profiles sp ON sp.student_id=s.id LEFT JOIN university_enrollments ue ON ue.student_id=s.id AND ue.status='active' LEFT JOIN programs p ON p.id=ue.program_id WHERE s.id=?`).get(id);}
function audit(req,id,action,details=''){db.prepare('INSERT INTO student_card_audit(student_id,actor_id,action,details) VALUES(?,?,?,?)').run(id,req.user.id,action,String(details).slice(0,1000));}
router.get('/me',requireAuth,(req,res)=>{const id=ownStudentId(req);if(!id)return res.status(404).json({error:'No student record is linked to this account.'});const student=studentCardData(id);const consent=db.prepare('SELECT consent_given,notice_version,recorded_at,withdrawn_at FROM student_data_consent WHERE student_id=? ORDER BY id DESC LIMIT 1').get(id)||null;res.json({student,consent});});
router.post('/me/consent',requireAuth,(req,res)=>{const id=ownStudentId(req);if(!id)return res.status(404).json({error:'No student record is linked to this account.'});const {consent,noticeVersion='2026-01',purposes}=req.body||{};if(typeof consent!=='boolean')return res.status(400).json({error:'Please record whether you consent.'});const purposeText=Array.isArray(purposes)?purposes.join(', '):String(purposes||'Student administration, identity card and examination card generation');if(!purposeText.trim())return res.status(400).json({error:'The data-use purposes are required.'});db.prepare('INSERT INTO student_data_consent(student_id,notice_version,consent_given,purposes,recorded_by,ip_hint,withdrawn_at) VALUES(?,?,?,?,?,?,?)').run(id,noticeVersion,consent?1:0,purposeText,req.user.id,req.ip||'',consent?null:new Date().toISOString());audit(req,id,consent?'CONSENT_GIVEN':'CONSENT_DECLINED',`notice=${noticeVersion}; purposes=${purposeText}`);res.status(201).json({success:true,consent});});
router.get('/students',requireAuth,(req,res)=>{if(!canManage(req))return res.status(403).json({error:'ICT Officer or authorized administrator access required.'});const rows=db.prepare(`SELECT s.id,s.adm_no,s.name,s.email,s.phone,s.photo_url,s.status,c.name class_name,sp.programme_name,sp.faculty_name,sp.department_name,(SELECT consent_given FROM student_data_consent x WHERE x.student_id=s.id ORDER BY x.id DESC LIMIT 1) consent_given,(SELECT card_number FROM student_card_issues i WHERE i.student_id=s.id AND i.card_type='id' AND i.status='issued' ORDER BY i.id DESC LIMIT 1) id_card_number FROM students s LEFT JOIN classes c ON c.id=s.class_id LEFT JOIN student_profiles sp ON sp.student_id=s.id ORDER BY s.name`).all();res.json(rows);});
router.get('/students/:id',requireAuth,(req,res)=>{const id=Number(req.params.id);if(!canManage(req)&&ownStudentId(req)!==id)return res.status(403).json({error:'You may only view your own card record.'});const student=studentCardData(id);if(!student)return res.status(404).json({error:'Student not found.'});const consent=db.prepare('SELECT * FROM student_data_consent WHERE student_id=? ORDER BY id DESC LIMIT 1').get(id)||null;const issues=db.prepare('SELECT * FROM student_card_issues WHERE student_id=? ORDER BY issued_at DESC').all(id);res.json({student,consent,issues});});
router.post('/students/:id/photo',requireAuth,(req,res)=>{
 if(!canManage(req)) return res.status(403).json({error:'ICT Officer or authorized administrator access required.'});
 photoUpload.single('photo')(req,res,err=>{
  if(err) return res.status(400).json({error:err.message||'Photo upload failed.'});
  if(!req.file) return res.status(400).json({error:'Choose a JPEG, PNG or WebP image up to 5 MB.'});
  const id=Number(req.params.id); if(!hasStudent(id)) return res.status(404).json({error:'Student not found.'});
  const ext={'image/jpeg':'jpg','image/png':'png','image/webp':'webp'}[req.file.mimetype];
  const name=`student-${id}-${crypto.randomBytes(8).toString('hex')}.${ext}`;
  fs.writeFileSync(path.join(photoDir,name),req.file.buffer,{flag:'wx'});
  const photoUrl=`/uploads/student-photos/${name}`;
  db.prepare('UPDATE students SET photo_url=? WHERE id=?').run(photoUrl,id);
  db.prepare('INSERT OR IGNORE INTO student_profiles(student_id,photo_url) VALUES(?,?)').run(id,photoUrl);
  db.prepare("UPDATE student_profiles SET photo_url=?,updated_at=datetime('now') WHERE student_id=?").run(photoUrl,id);
  audit(req,id,'STUDENT_PHOTO_UPLOADED',name); res.status(201).json({success:true,photo_url:photoUrl});
 });
});
router.put('/students/:id/profile',requireAuth,(req,res)=>{if(!canManage(req))return res.status(403).json({error:'ICT Officer or authorized administrator access required.'});const id=Number(req.params.id);if(!hasStudent(id))return res.status(404).json({error:'Student not found.'});const allowed=['name','gender','dob','email','phone','address','county','nationality','passport_no','photo_url'];const profileAllowed=['personal_email','alternative_phone','postal_address','country_of_birth','marital_status','accessibility_requirements','previous_school','kcse_index','kcse_grades','aggregate_points','previous_institution','qualification_verification_status','application_reference','faculty_name','department_name','programme_name','campus','study_mode','intake','year_of_study','current_semester','reporting_date','offer_status'];const body=req.body||{};const sf=allowed.filter(k=>body[k]!==undefined);const pf=profileAllowed.filter(k=>body[k]!==undefined);const tx=db.transaction(()=>{if(sf.length)db.prepare(`UPDATE students SET ${sf.map(k=>`${k}=?`).join(',')} WHERE id=?`).run(...sf.map(k=>body[k]),id);if(pf.length){db.prepare('INSERT OR IGNORE INTO student_profiles(student_id) VALUES(?)').run(id);db.prepare(`UPDATE student_profiles SET ${pf.map(k=>`${k}=?`).join(',')},updated_at=datetime('now') WHERE student_id=?`).run(...pf.map(k=>body[k]),id);}audit(req,id,'STUDENT_CARD_PROFILE_UPDATED',[...sf,...pf].join(','));});tx();res.json({success:true,student:studentCardData(id)});});
router.post('/students/:id/issue',requireAuth,(req,res)=>{if(!canManage(req))return res.status(403).json({error:'ICT Officer or authorized administrator access required.'});const id=Number(req.params.id),type=req.body?.cardType;if(!hasStudent(id))return res.status(404).json({error:'Student not found.'});if(!['id','exam'].includes(type))return res.status(400).json({error:'Card type must be id or exam.'});let latest=db.prepare('SELECT consent_given,withdrawn_at FROM student_data_consent WHERE student_id=? ORDER BY id DESC LIMIT 1').get(id);if(req.body?.consentConfirmed===true){db.prepare('INSERT INTO student_data_consent(student_id,notice_version,consent_given,purposes,recorded_by,ip_hint,withdrawn_at) VALUES(?,?,?,?,?,?,NULL)').run(id,'admission-physical-assessment','1','Consent confirmed by authorized staff based on admission physical assessment; identity card, exam card and university access control',req.user.id,req.ip||'');audit(req,id,'CONSENT_CONFIRMED_BY_STAFF','Admission physical assessment ticked by authorized staff');latest={consent_given:1,withdrawn_at:null};}if(!latest||latest.consent_given!==1||latest.withdrawn_at)return res.status(409).json({error:'Tick the consent confirmation only if consent was recorded during admission physical assessment.'});const student=studentCardData(id);if(!student.photo_url)return res.status(409).json({error:'Add the student photograph before issuing a card.'});const year=String(req.body.academicYear||'').slice(0,20),semester=String(req.body.semester||'').slice(0,40);if(type==='exam'&&(!year||!semester))return res.status(400).json({error:'Academic year and semester are required for an examination card.'});const number=`MU-${type.toUpperCase()}-${student.adm_no}-${Date.now().toString().slice(-6)}`;const result=db.prepare('INSERT INTO student_card_issues(student_id,card_type,card_number,academic_year,semester,issued_by,notes) VALUES(?,?,?,?,?,?,?)').run(id,type,number,year||null,semester||null,req.user.id,String(req.body.notes||''));db.prepare(`INSERT OR REPLACE INTO student_card_gate_control(card_number,student_id,access_status,updated_by,updated_at) VALUES(?,?,'active',?,datetime('now'))`).run(number,id,req.user.id);audit(req,id,`${type.toUpperCase()}_CARD_ISSUED`,number);res.status(201).json({success:true,issueId:result.lastInsertRowid,cardNumber:number,student:studentCardData(id),academicYear:year,semester,accessStatus:'active'});});

// Gate verification and access control. Only designated security staff can verify or block a card.
router.get('/gate/cards',requireAuth,(req,res)=>{if(!canSecurity(req))return res.status(403).json({error:'Security staff access required.'});const rows=db.prepare(`SELECT i.card_number,i.card_type,i.issued_at,i.status issue_status,s.id student_id,s.name,s.adm_no,g.access_status,g.reason,g.updated_at FROM student_card_issues i JOIN students s ON s.id=i.student_id LEFT JOIN student_card_gate_control g ON g.card_number=i.card_number WHERE i.status='issued' ORDER BY i.issued_at DESC LIMIT 500`).all();res.json(rows);});
router.get('/gate/verify/:cardNumber',requireAuth,(req,res)=>{if(!canSecurity(req))return res.status(403).json({error:'Security staff access required.'});const row=db.prepare(`SELECT i.card_number,i.card_type,i.status issue_status,s.id student_id,s.name,s.adm_no,s.status student_status,g.access_status,g.reason FROM student_card_issues i JOIN students s ON s.id=i.student_id LEFT JOIN student_card_gate_control g ON g.card_number=i.card_number WHERE i.card_number=? ORDER BY i.id DESC LIMIT 1`).get(String(req.params.cardNumber));if(!row)return res.status(404).json({valid:false,decision:'REJECT',reason:'Unknown card'});const active=row.issue_status==='issued'&&String(row.student_status||'').toLowerCase()!=='suspended'&&String(row.student_status||'').toLowerCase()!=='inactive'&&(row.access_status||'active')==='active';res.json({valid:active,decision:active?'ALLOW':'REJECT',...row,reason:active?'Card active':(row.reason||'Card blocked, revoked or student inactive')});});
router.patch('/gate/cards/:cardNumber',requireAuth,(req,res)=>{if(!canSecurity(req))return res.status(403).json({error:'Security staff access required.'});const card=String(req.params.cardNumber);const issue=db.prepare(`SELECT student_id FROM student_card_issues WHERE card_number=? AND status='issued' ORDER BY id DESC LIMIT 1`).get(card);if(!issue)return res.status(404).json({error:'Issued card not found.'});const status=req.body?.accessStatus;if(!['active','blocked'].includes(status))return res.status(400).json({error:'accessStatus must be active or blocked.'});const reason=String(req.body?.reason||'').slice(0,500);db.prepare(`INSERT INTO student_card_gate_control(card_number,student_id,access_status,reason,updated_by,updated_at) VALUES(?,?,?,?,?,datetime('now')) ON CONFLICT(card_number) DO UPDATE SET access_status=excluded.access_status,reason=excluded.reason,updated_by=excluded.updated_by,updated_at=datetime('now')`).run(card,issue.student_id,status,reason,req.user.id);audit(req,issue.student_id,status==='blocked'?'GATE_ACCESS_BLOCKED':'GATE_ACCESS_RESTORED',`${card}: ${reason}`);res.json({success:true,cardNumber:card,accessStatus:status,reason});});

router.get('/students/:id/consent-history',requireAuth,(req,res)=>{const id=Number(req.params.id);if(!canManage(req)&&ownStudentId(req)!==id)return res.status(403).json({error:'Not authorized.'});res.json(db.prepare('SELECT id,notice_version,consent_given,purposes,recorded_at,withdrawn_at FROM student_data_consent WHERE student_id=? ORDER BY id DESC').all(id));});
module.exports=router;
