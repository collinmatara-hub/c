'use strict';
// University timetable maker. Every route needs a session AND a specific timetable permission
// (see lib/rbac.js). Drafts are visible only to roles with timetable.view; lecturers and
// students only ever receive their own entries from a PUBLISHED timetable.
const express = require('express');
const { db } = require('../db');
require('../lib/timetableSchema');
const { requireAuth } = require('../middleware/auth');
const { requirePermission, hasPermission } = require('../lib/rbac');
const engine = require('../lib/timetableEngine');

const router = express.Router();
router.use(requireAuth);

const view = requirePermission('timetable.view');
const manage = requirePermission('timetable.manage');
const generate = requirePermission('timetable.generate');
const approve = requirePermission('timetable.approve');
const publish = requirePermission('timetable.publish');
const viewPublished = requirePermission('timetable.view_published');

const role = (req) => req.user.actual_role || req.user.role;
const can = (req, code) => hasPermission(role(req), code);
const TIME = /^([01]\d|2[0-3]):[0-5]\d$/;
const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

function audit(req, versionId, action, details = '') {
  db.prepare('INSERT INTO tt_audit(version_id,action,actor_id,actor_name,actor_role,details) VALUES(?,?,?,?,?,?)')
    .run(versionId || null, action, req.user.id, req.user.name || '', role(req), String(details).slice(0, 1000));
}
const bad = (res, msg, code = 400) => res.status(code).json({ error: msg });
const int = (v, d = 0) => (Number.isFinite(Number(v)) ? Math.trunc(Number(v)) : d);

// HODs only see their own departments; everyone else with timetable.view sees the whole university.
function departmentScope(req) {
  if (role(req) !== 'hod') return null;
  return db.prepare('SELECT name FROM university_departments WHERE hod_id = ?').all(req.user.id).map((r) => r.name);
}
function visibleSlots(req, slots) {
  const scope = departmentScope(req);
  if (!scope) return slots;
  const units = new Map(db.prepare('SELECT id, department FROM tt_units').all().map((u) => [u.id, u.department]));
  return slots.filter((s) => scope.includes(units.get(s.unit_id)));
}

function loadContext(term, config) {
  return {
    units: db.prepare('SELECT * FROM tt_units WHERE term = ?').all(term),
    rooms: db.prepare('SELECT * FROM tt_rooms').all(),
    roomBlocks: db.prepare('SELECT * FROM tt_room_blocks').all(),
    lecturerBlocks: db.prepare('SELECT * FROM tt_lecturer_blocks').all(),
    config: engine.cleanConfig(config),
  };
}
const getVersion = (id) => db.prepare('SELECT * FROM tt_versions WHERE id = ?').get(id);
const versionSlots = (id) => db.prepare('SELECT * FROM tt_slots WHERE version_id = ? ORDER BY day, start_time').all(id);
const parseJson = (s, d) => { try { return JSON.parse(s); } catch { return d; } };

function validateVersion(version, slots) {
  const ctx = loadContext(version.term, parseJson(version.config, {}));
  return engine.validate({ ...ctx, slots });
}

function tx(fn) {
  db.exec('BEGIN');
  try { const out = fn(); db.exec('COMMIT'); return out; } catch (e) { db.exec('ROLLBACK'); throw e; }
}

function stats(version, slots) {
  const ctx = loadContext(version.term, parseJson(version.config, {}));
  const rooms = new Map(ctx.rooms.map((r) => [r.id, r]));
  const hours = (s) => (engine.toMin(s.end_time) - engine.toMin(s.start_time)) / 60;
  const openHours = ctx.config.days.length * (engine.toMin(ctx.config.dayEnd) - engine.toMin(ctx.config.dayStart)) / 60;
  const roomUse = {}; const load = {};
  for (const s of slots) {
    const r = rooms.get(s.room_id); if (r) roomUse[r.name] = (roomUse[r.name] || 0) + hours(s);
    const l = s.lecturer_name || 'Unassigned'; load[l] = (load[l] || 0) + hours(s);
  }
  return {
    sessions: slots.length,
    room_utilisation: Object.entries(roomUse).map(([name, h]) => ({ name, hours: h, percent: Math.round((h / openHours) * 100) })),
    lecturer_load: Object.entries(load).map(([name, h]) => ({ name, hours: h })).sort((a, b) => b.hours - a.hours),
  };
}

// ---------- who am I ----------
router.get('/me', (req, res) => {
  res.json({
    role: role(req),
    can: {
      view: can(req, 'timetable.view'), manage: can(req, 'timetable.manage'), generate: can(req, 'timetable.generate'),
      approve: can(req, 'timetable.approve'), publish: can(req, 'timetable.publish'),
      viewPublished: can(req, 'timetable.view_published'), ownAvailability: can(req, 'timetable.availability.own'),
    },
  });
});

// ---------- rooms ----------
router.get('/rooms', view, (req, res) => res.json(db.prepare('SELECT * FROM tt_rooms ORDER BY name').all()));
function roomInput(b) {
  const name = String(b.name || '').trim();
  const capacity = int(b.capacity);
  if (!name) return { error: 'Room name is required.' };
  if (capacity < 1 || capacity > 5000) return { error: 'Capacity must be between 1 and 5000.' };
  return { v: [name, String(b.campus || 'Main Campus'), String(b.building || ''), capacity, String(b.room_type || 'Lecture hall'), String(b.facilities || '')] };
}
router.post('/rooms', manage, (req, res) => {
  const { v, error } = roomInput(req.body || {}); if (error) return bad(res, error);
  try {
    const r = db.prepare('INSERT INTO tt_rooms(name,campus,building,capacity,room_type,facilities) VALUES(?,?,?,?,?,?)').run(...v);
    audit(req, null, 'room_created', v[0]);
    res.status(201).json(db.prepare('SELECT * FROM tt_rooms WHERE id=?').get(r.lastInsertRowid));
  } catch (e) { bad(res, 'A room with that name already exists.', 409); }
});
router.put('/rooms/:id', manage, (req, res) => {
  const { v, error } = roomInput(req.body || {}); if (error) return bad(res, error);
  const r = db.prepare('UPDATE tt_rooms SET name=?,campus=?,building=?,capacity=?,room_type=?,facilities=?,active=? WHERE id=?').run(...v, req.body.active === 0 ? 0 : 1, req.params.id);
  if (!r.changes) return bad(res, 'Room not found.', 404);
  audit(req, null, 'room_updated', v[0]);
  res.json(db.prepare('SELECT * FROM tt_rooms WHERE id=?').get(req.params.id));
});
router.delete('/rooms/:id', manage, (req, res) => {
  const used = db.prepare("SELECT COUNT(*) n FROM tt_slots s JOIN tt_versions v ON v.id=s.version_id WHERE s.room_id=? AND v.status!='archived'").get(req.params.id).n;
  if (used) { db.prepare('UPDATE tt_rooms SET active=0 WHERE id=?').run(req.params.id); audit(req, null, 'room_deactivated', req.params.id); return res.json({ deactivated: true, message: 'Room is used by timetables, so it was deactivated instead of deleted.' }); }
  db.prepare('DELETE FROM tt_rooms WHERE id=?').run(req.params.id); audit(req, null, 'room_deleted', req.params.id);
  res.json({ deleted: true });
});
router.get('/room-blocks', view, (req, res) => res.json(db.prepare('SELECT b.*, r.name room_name FROM tt_room_blocks b JOIN tt_rooms r ON r.id=b.room_id ORDER BY r.name, b.day').all()));
function blockInput(b) {
  if (!DAYS.includes(b.day)) return 'Choose a valid day.';
  if (!TIME.test(b.start_time || '') || !TIME.test(b.end_time || '') || b.start_time >= b.end_time) return 'Start and end times must be valid and end after start.';
  return null;
}
router.post('/room-blocks', manage, (req, res) => {
  const b = req.body || {}; const err = blockInput(b); if (err) return bad(res, err);
  if (!db.prepare('SELECT 1 FROM tt_rooms WHERE id=?').get(b.room_id)) return bad(res, 'Room not found.', 404);
  const r = db.prepare('INSERT INTO tt_room_blocks(room_id,day,start_time,end_time,reason) VALUES(?,?,?,?,?)').run(b.room_id, b.day, b.start_time, b.end_time, String(b.reason || ''));
  audit(req, null, 'room_block_added', `room ${b.room_id} ${b.day} ${b.start_time}-${b.end_time}`);
  res.status(201).json({ id: r.lastInsertRowid });
});
router.delete('/room-blocks/:id', manage, (req, res) => { db.prepare('DELETE FROM tt_room_blocks WHERE id=?').run(req.params.id); audit(req, null, 'room_block_removed', req.params.id); res.json({ deleted: true }); });

// ---------- units (teaching requirements) ----------
router.get('/units', view, (req, res) => {
  const term = String(req.query.term || '');
  let rows = term ? db.prepare('SELECT * FROM tt_units WHERE term=? ORDER BY unit_code, cohort').all(term) : db.prepare('SELECT * FROM tt_units ORDER BY term DESC, unit_code, cohort').all();
  const scope = departmentScope(req);
  if (scope) rows = rows.filter((u) => scope.includes(u.department));
  res.json(rows);
});
function unitInput(b) {
  for (const f of ['term', 'unit_code', 'unit_name', 'cohort']) if (!String(b[f] || '').trim()) return { error: `${f.replace('_', ' ')} is required.` };
  const sessions = int(b.sessions_per_week, 1); const minutes = int(b.session_minutes, 120); const size = int(b.class_size);
  if (sessions < 1 || sessions > 5) return { error: 'Sessions per week must be 1 to 5.' };
  if (minutes < 60 || minutes > 240 || minutes % 60) return { error: 'Session length must be 60, 120, 180 or 240 minutes.' };
  if (size < 1) return { error: 'Class size must be at least 1.' };
  return { v: [String(b.term).trim(), String(b.unit_code).trim().toUpperCase(), String(b.unit_name).trim(), String(b.department || ''), String(b.programme || ''), String(b.cohort).trim(), b.lecturer_user_id ? int(b.lecturer_user_id) : null, String(b.lecturer_name || ''), sessions, minutes, size, String(b.room_type_required || ''), String(b.class_type || 'Lecture'), String(b.shared_group || '').trim()] };
}
const UNIT_COLS = 'term,unit_code,unit_name,department,programme,cohort,lecturer_user_id,lecturer_name,sessions_per_week,session_minutes,class_size,room_type_required,class_type,shared_group';
router.post('/units', manage, (req, res) => {
  const { v, error } = unitInput(req.body || {}); if (error) return bad(res, error);
  try {
    const r = db.prepare(`INSERT INTO tt_units(${UNIT_COLS},created_by) VALUES(${v.map(() => '?').join(',')},?)`).run(...v, req.user.id);
    audit(req, null, 'unit_created', `${v[1]} ${v[5]}`);
    res.status(201).json(db.prepare('SELECT * FROM tt_units WHERE id=?').get(r.lastInsertRowid));
  } catch (e) { bad(res, 'That unit already exists for this cohort and term.', 409); }
});
router.put('/units/:id', manage, (req, res) => {
  const { v, error } = unitInput(req.body || {}); if (error) return bad(res, error);
  const set = UNIT_COLS.split(',').map((c) => `${c}=?`).join(',');
  try {
    const r = db.prepare(`UPDATE tt_units SET ${set} WHERE id=?`).run(...v, req.params.id);
    if (!r.changes) return bad(res, 'Unit not found.', 404);
    audit(req, null, 'unit_updated', `${v[1]} ${v[5]}`);
    res.json(db.prepare('SELECT * FROM tt_units WHERE id=?').get(req.params.id));
  } catch (e) { bad(res, 'That unit already exists for this cohort and term.', 409); }
});
router.delete('/units/:id', manage, (req, res) => { db.prepare('DELETE FROM tt_units WHERE id=?').run(req.params.id); audit(req, null, 'unit_deleted', req.params.id); res.json({ deleted: true }); });

// Lecturers that can be assigned to units (people, never invented).
router.get('/lecturers', view, (req, res) => {
  const keys = ['teacher', 'lecturer', 'senior_lecturer', 'professor', 'academic_staff', 'hod', 'dean'];
  res.json(db.prepare(`SELECT id, name FROM users WHERE active=1 AND role IN (${keys.map(() => '?').join(',')}) ORDER BY name`).all(...keys));
});

// ---------- lecturer availability ----------
router.get('/availability', (req, res) => {
  if (can(req, 'timetable.view')) return res.json(db.prepare('SELECT * FROM tt_lecturer_blocks ORDER BY lecturer_name, day, start_time').all());
  if (can(req, 'timetable.availability.own')) return res.json(db.prepare('SELECT * FROM tt_lecturer_blocks WHERE lecturer_user_id=? ORDER BY day, start_time').all(req.user.id));
  return bad(res, 'You do not have permission to do that.', 403);
});
router.post('/availability', (req, res) => {
  const b = req.body || {}; const err = blockInput(b); if (err) return bad(res, err);
  let userId; let name;
  if (can(req, 'timetable.manage') && b.lecturer_user_id) {
    const u = db.prepare('SELECT id, name FROM users WHERE id=?').get(int(b.lecturer_user_id)); if (!u) return bad(res, 'Lecturer not found.', 404);
    userId = u.id; name = u.name;
  } else if (can(req, 'timetable.availability.own')) { userId = req.user.id; name = req.user.name || ''; }
  else return bad(res, 'You do not have permission to do that.', 403);
  const r = db.prepare('INSERT INTO tt_lecturer_blocks(lecturer_user_id,lecturer_name,day,start_time,end_time,reason,created_by) VALUES(?,?,?,?,?,?,?)').run(userId, name, b.day, b.start_time, b.end_time, String(b.reason || ''), req.user.id);
  audit(req, null, 'availability_added', `${name} ${b.day} ${b.start_time}-${b.end_time}`);
  res.status(201).json({ id: r.lastInsertRowid });
});
router.delete('/availability/:id', (req, res) => {
  const row = db.prepare('SELECT * FROM tt_lecturer_blocks WHERE id=?').get(req.params.id);
  if (!row) return bad(res, 'Not found.', 404);
  const own = row.lecturer_user_id === req.user.id && can(req, 'timetable.availability.own');
  if (!own && !can(req, 'timetable.manage')) return bad(res, 'You do not have permission to do that.', 403);
  db.prepare('DELETE FROM tt_lecturer_blocks WHERE id=?').run(row.id); audit(req, null, 'availability_removed', `${row.lecturer_name} ${row.day}`);
  res.json({ deleted: true });
});

// ---------- versions ----------
router.get('/versions', view, (req, res) => {
  const rows = db.prepare('SELECT v.*, (SELECT COUNT(*) FROM tt_slots s WHERE s.version_id=v.id) AS slot_count FROM tt_versions v ORDER BY v.id DESC LIMIT 200').all();
  res.json(rows.map((v) => ({ ...v, config: parseJson(v.config, {}), unscheduled: parseJson(v.unscheduled, []) })));
});

router.post('/versions/generate', generate, (req, res) => {
  const b = req.body || {};
  const term = String(b.term || '').trim();
  if (!term) return bad(res, 'Choose the term to generate for.');
  const ctx = loadContext(term, b.config);
  if (!ctx.units.length) return bad(res, 'There are no units for this term. Add real teaching requirements first; the generator does not invent units.');
  if (!ctx.rooms.some((r) => r.active)) return bad(res, 'Add at least one room before generating.');
  const seed = int(b.seed, Date.now() % 100000);
  let locked = [];
  if (b.base_version_id) {
    const base = getVersion(b.base_version_id);
    if (!base || base.term !== term) return bad(res, 'The base version must be for the same term.');
    locked = versionSlots(base.id).filter((s) => s.locked);
  }
  const out = engine.generate({ ...ctx, locked, seed });
  const name = String(b.name || '').trim() || `${term} draft ${new Date().toISOString().slice(0, 16).replace('T', ' ')}`;
  const id = tx(() => {
    const r = db.prepare('INSERT INTO tt_versions(term,name,status,config,unscheduled,score,seed,parent_version_id,created_by,created_by_name) VALUES(?,?,?,?,?,?,?,?,?,?)')
      .run(term, name, 'draft', JSON.stringify(ctx.config), JSON.stringify(out.unscheduled), out.score, seed, b.base_version_id || null, req.user.id, req.user.name || '');
    const ins = db.prepare('INSERT INTO tt_slots(version_id,unit_id,unit_code,unit_name,cohort,class_type,day,start_time,end_time,room_id,lecturer_user_id,lecturer_name,locked,group_key) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
    for (const s of out.slots) ins.run(r.lastInsertRowid, s.unit_id, s.unit_code, s.unit_name, s.cohort, s.class_type, s.day, s.start_time, s.end_time, s.room_id, s.lecturer_user_id, s.lecturer_name, s.locked ? 1 : 0, s.group_key || '');
    return r.lastInsertRowid;
  });
  audit(req, id, 'generated', `${out.slots.length} sessions placed, ${out.unscheduled.length} unit(s) not fully placed, seed ${seed}`);
  res.status(201).json({ id, placed: out.slots.length, totalSessions: out.totalSessions, unscheduled: out.unscheduled, notice: 'Draft only. Review it, then submit it for approval. Nothing is published automatically.' });
});

function loadVersionFor(req, res) {
  const v = getVersion(req.params.id);
  if (!v) { bad(res, 'Timetable version not found.', 404); return null; }
  return v;
}

router.get('/versions/:id', view, (req, res) => {
  const v = loadVersionFor(req, res); if (!v) return;
  const slots = visibleSlots(req, versionSlots(v.id));
  const issues = validateVersion(v, versionSlots(v.id));
  res.json({ version: { ...v, config: parseJson(v.config, {}), unscheduled: parseJson(v.unscheduled, []) }, slots, issues, stats: stats(v, slots) });
});

router.post('/versions/:id/validate', view, (req, res) => {
  const v = loadVersionFor(req, res); if (!v) return;
  const issues = validateVersion(v, versionSlots(v.id));
  res.json({ valid: issues.length === 0, issues });
});

function editable(v, res) {
  if (v.status !== 'draft') { bad(res, 'Only a draft can be edited. Restore this version as a new draft to change it.', 409); return false; }
  return true;
}
// Rejects a change that introduces a hard conflict that was not already present.
function checkedChange(v, mutate) {
  const before = versionSlots(v.id);
  const beforeSet = new Set(validateVersion(v, before).map((i) => i.message));
  const after = mutate(before.map((s) => ({ ...s })));
  const introduced = validateVersion(v, after).filter((i) => !beforeSet.has(i.message));
  return introduced;
}
function slotFields(b, base = {}) {
  const x = { ...base, ...b };
  return { day: x.day, start_time: x.start_time, end_time: x.end_time, room_id: int(x.room_id) || null };
}

router.post('/versions/:id/slots', manage, (req, res) => {
  const v = loadVersionFor(req, res); if (!v || !editable(v, res)) return;
  const b = req.body || {};
  const unit = db.prepare('SELECT * FROM tt_units WHERE id=? AND term=?').get(int(b.unit_id), v.term);
  if (!unit) return bad(res, 'Choose a unit from this term.');
  const f = slotFields(b);
  if (!TIME.test(f.start_time || '') || !TIME.test(f.end_time || '')) return bad(res, 'Valid start and end times are required.');
  const candidate = { id: -1, version_id: v.id, unit_id: unit.id, unit_code: unit.unit_code, unit_name: unit.unit_name, cohort: unit.cohort, class_type: unit.class_type, lecturer_user_id: unit.lecturer_user_id, lecturer_name: unit.lecturer_name, locked: 1, group_key: '', ...f };
  const introduced = checkedChange(v, (all) => [...all, candidate]);
  if (introduced.length) return res.status(409).json({ error: introduced[0].message, issues: introduced });
  const r = db.prepare('INSERT INTO tt_slots(version_id,unit_id,unit_code,unit_name,cohort,class_type,day,start_time,end_time,room_id,lecturer_user_id,lecturer_name,locked) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,1)')
    .run(v.id, unit.id, unit.unit_code, unit.unit_name, unit.cohort, unit.class_type, f.day, f.start_time, f.end_time, f.room_id, unit.lecturer_user_id, unit.lecturer_name);
  db.prepare("UPDATE tt_versions SET updated_at=datetime('now') WHERE id=?").run(v.id);
  audit(req, v.id, 'slot_added', `${unit.unit_code} ${f.day} ${f.start_time}-${f.end_time}`);
  res.status(201).json({ id: r.lastInsertRowid });
});

router.patch('/versions/:id/slots/:slotId', manage, (req, res) => {
  const v = loadVersionFor(req, res); if (!v || !editable(v, res)) return;
  const slot = db.prepare('SELECT * FROM tt_slots WHERE id=? AND version_id=?').get(req.params.slotId, v.id);
  if (!slot) return bad(res, 'Slot not found.', 404);
  const b = req.body || {};
  if (b.locked !== undefined && b.day === undefined && b.room_id === undefined && b.start_time === undefined) {
    db.prepare('UPDATE tt_slots SET locked=? WHERE id=?').run(b.locked ? 1 : 0, slot.id);
    audit(req, v.id, b.locked ? 'slot_locked' : 'slot_unlocked', `${slot.unit_code}`);
    return res.json({ id: slot.id, locked: b.locked ? 1 : 0 });
  }
  const f = slotFields(b, slot);
  if (!TIME.test(f.start_time || '') || !TIME.test(f.end_time || '')) return bad(res, 'Valid start and end times are required.');
  // A shared class moves as one: every row taught together changes with it.
  const together = slot.group_key ? db.prepare('SELECT id FROM tt_slots WHERE version_id=? AND group_key=? AND day=? AND start_time=? AND end_time=?').all(v.id, slot.group_key, slot.day, slot.start_time, slot.end_time).map((r) => r.id) : [slot.id];
  const introduced = checkedChange(v, (all) => all.map((s) => (together.includes(s.id) ? { ...s, ...f } : s)));
  if (introduced.length) return res.status(409).json({ error: introduced[0].message, issues: introduced });
  for (const id of together) db.prepare('UPDATE tt_slots SET day=?,start_time=?,end_time=?,room_id=?,locked=1 WHERE id=?').run(f.day, f.start_time, f.end_time, f.room_id, id);
  db.prepare("UPDATE tt_versions SET updated_at=datetime('now') WHERE id=?").run(v.id);
  audit(req, v.id, 'slot_moved', `${slot.unit_code} ${slot.day} ${slot.start_time} -> ${f.day} ${f.start_time}-${f.end_time}`);
  res.json({ moved: together.length });
});

router.delete('/versions/:id/slots/:slotId', manage, (req, res) => {
  const v = loadVersionFor(req, res); if (!v || !editable(v, res)) return;
  const slot = db.prepare('SELECT * FROM tt_slots WHERE id=? AND version_id=?').get(req.params.slotId, v.id);
  if (!slot) return bad(res, 'Slot not found.', 404);
  db.prepare('DELETE FROM tt_slots WHERE id=?').run(slot.id);
  audit(req, v.id, 'slot_removed', `${slot.unit_code} ${slot.day} ${slot.start_time}`);
  res.json({ deleted: true });
});

// ---------- workflow: draft -> pending -> approved -> published ----------
router.post('/versions/:id/submit', manage, (req, res) => {
  const v = loadVersionFor(req, res); if (!v) return;
  if (v.status !== 'draft') return bad(res, 'Only a draft can be submitted.', 409);
  const slots = versionSlots(v.id);
  if (!slots.length) return bad(res, 'An empty timetable cannot be submitted.', 409);
  const issues = validateVersion(v, slots);
  if (issues.length) return res.status(409).json({ error: `Fix ${issues.length} conflict(s) before submitting.`, issues });
  db.prepare("UPDATE tt_versions SET status='pending', submitted_by=?, review_note='', updated_at=datetime('now') WHERE id=?").run(req.user.id, v.id);
  audit(req, v.id, 'submitted', `${slots.length} sessions, ${parseJson(v.unscheduled, []).length} unit(s) not fully placed`);
  res.json({ status: 'pending' });
});
router.post('/versions/:id/approve', approve, (req, res) => {
  const v = loadVersionFor(req, res); if (!v) return;
  if (v.status !== 'pending') return bad(res, 'Only a submitted timetable can be approved.', 409);
  if (v.created_by === req.user.id || v.submitted_by === req.user.id) return bad(res, 'You cannot approve a timetable you prepared or submitted.', 403);
  const issues = validateVersion(v, versionSlots(v.id));
  if (issues.length) return res.status(409).json({ error: 'The timetable now has conflicts and cannot be approved.', issues });
  db.prepare("UPDATE tt_versions SET status='approved', approved_by=?, approved_by_name=?, updated_at=datetime('now') WHERE id=?").run(req.user.id, req.user.name || '', v.id);
  audit(req, v.id, 'approved', String((req.body || {}).note || ''));
  res.json({ status: 'approved' });
});
router.post('/versions/:id/reject', approve, (req, res) => {
  const v = loadVersionFor(req, res); if (!v) return;
  if (v.status !== 'pending') return bad(res, 'Only a submitted timetable can be returned.', 409);
  const note = String((req.body || {}).note || '').trim();
  if (!note) return bad(res, 'Say what must be changed.');
  db.prepare("UPDATE tt_versions SET status='draft', review_note=?, updated_at=datetime('now') WHERE id=?").run(note, v.id);
  audit(req, v.id, 'returned_to_draft', note);
  res.json({ status: 'draft' });
});
router.post('/versions/:id/publish', publish, (req, res) => {
  const v = loadVersionFor(req, res); if (!v) return;
  if (v.status !== 'approved') return bad(res, 'Only an approved timetable can be published.', 409);
  const issues = validateVersion(v, versionSlots(v.id));
  if (issues.length) return res.status(409).json({ error: 'The timetable has conflicts and cannot be published.', issues });
  tx(() => {
    db.prepare("UPDATE tt_versions SET status='archived', updated_at=datetime('now') WHERE term=? AND status='published'").run(v.term);
    db.prepare("UPDATE tt_versions SET status='published', published_by=?, published_at=datetime('now'), updated_at=datetime('now') WHERE id=?").run(req.user.id, v.id);
  });
  audit(req, v.id, 'published', `term ${v.term}; previous published version archived`);
  res.json({ status: 'published' });
});
// Rollback is a restore: copy any earlier version into a fresh draft that goes through approval again.
router.post('/versions/:id/restore', manage, (req, res) => {
  const v = loadVersionFor(req, res); if (!v) return;
  const id = tx(() => {
    const r = db.prepare('INSERT INTO tt_versions(term,name,status,config,unscheduled,score,seed,parent_version_id,created_by,created_by_name) VALUES(?,?,?,?,?,?,?,?,?,?)')
      .run(v.term, `${v.name} (restored)`, 'draft', v.config, v.unscheduled, v.score, v.seed, v.id, req.user.id, req.user.name || '');
    db.prepare('INSERT INTO tt_slots(version_id,unit_id,unit_code,unit_name,cohort,class_type,day,start_time,end_time,room_id,lecturer_user_id,lecturer_name,locked,group_key) SELECT ?,unit_id,unit_code,unit_name,cohort,class_type,day,start_time,end_time,room_id,lecturer_user_id,lecturer_name,locked,group_key FROM tt_slots WHERE version_id=?').run(r.lastInsertRowid, v.id);
    return r.lastInsertRowid;
  });
  audit(req, id, 'restored_from', `version ${v.id}`);
  res.status(201).json({ id });
});
router.delete('/versions/:id', manage, (req, res) => {
  const v = loadVersionFor(req, res); if (!v) return;
  if (v.status !== 'draft') return bad(res, 'Only drafts can be deleted.', 409);
  db.prepare('DELETE FROM tt_slots WHERE version_id=?').run(v.id); db.prepare('DELETE FROM tt_versions WHERE id=?').run(v.id);
  audit(req, v.id, 'draft_deleted', v.name);
  res.json({ deleted: true });
});
router.get('/versions/:id/audit', view, (req, res) => res.json(db.prepare('SELECT * FROM tt_audit WHERE version_id=? ORDER BY id DESC LIMIT 300').all(req.params.id)));
router.get('/audit', view, (req, res) => res.json(db.prepare('SELECT * FROM tt_audit ORDER BY id DESC LIMIT 300').all()));

const csvCell = (x) => `"${String(x ?? '').replace(/"/g, '""')}"`;
router.get('/versions/:id/export.csv', view, (req, res) => {
  const v = loadVersionFor(req, res); if (!v) return;
  const rooms = new Map(db.prepare('SELECT id,name FROM tt_rooms').all().map((r) => [r.id, r.name]));
  const rows = visibleSlots(req, versionSlots(v.id));
  const head = ['Day', 'Start', 'End', 'Unit code', 'Unit', 'Cohort', 'Type', 'Lecturer', 'Room', 'Status'];
  const lines = [head.map(csvCell).join(','), ...rows.map((s) => [s.day, s.start_time, s.end_time, s.unit_code, s.unit_name, s.cohort, s.class_type, s.lecturer_name, rooms.get(s.room_id) || '', v.status].map(csvCell).join(','))];
  audit(req, v.id, 'exported', `${rows.length} rows`);
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="timetable-${v.id}.csv"`);
  res.send(lines.join('\n'));
});

// ---------- my timetable (lecturers and students; published versions only) ----------
router.get('/mine', viewPublished, (req, res) => {
  const published = db.prepare("SELECT id FROM tt_versions WHERE status='published'").all().map((r) => r.id);
  if (!published.length) return res.json({ published: false, slots: [] });
  const marks = published.map(() => '?').join(',');
  const rooms = new Map(db.prepare('SELECT id,name,building FROM tt_rooms').all().map((r) => [r.id, r]));
  let slots = [];
  const student = db.prepare('SELECT id FROM students WHERE user_id=?').get(req.user.id);
  if (student) {
    const codes = db.prepare('SELECT sub.code FROM unit_registrations r JOIN subjects sub ON sub.id=r.subject_id WHERE r.student_id=?').all(student.id).map((r) => String(r.code).toUpperCase());
    if (codes.length) slots = db.prepare(`SELECT * FROM tt_slots WHERE version_id IN (${marks}) AND UPPER(unit_code) IN (${codes.map(() => '?').join(',')})`).all(...published, ...codes);
  } else {
    slots = db.prepare(`SELECT * FROM tt_slots WHERE version_id IN (${marks}) AND (lecturer_user_id = ? OR (lecturer_user_id IS NULL AND LOWER(lecturer_name) = LOWER(?)))`).all(...published, req.user.id, req.user.name || '');
  }
  res.json({
    published: true,
    slots: slots.map((s) => ({ day: s.day, start_time: s.start_time, end_time: s.end_time, unit_code: s.unit_code, unit_name: s.unit_name, class_type: s.class_type, lecturer: s.lecturer_name, room: rooms.get(s.room_id)?.name || '', building: rooms.get(s.room_id)?.building || '' }))
      .sort((a, b) => DAYS.indexOf(a.day) - DAYS.indexOf(b.day) || a.start_time.localeCompare(b.start_time)),
  });
});

module.exports = router;
