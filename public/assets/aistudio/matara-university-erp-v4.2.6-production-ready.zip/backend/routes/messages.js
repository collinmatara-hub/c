// routes/messages.js
// Direct messages between students and lecturers (and admins).
// One "thread" is every message between two people.

const express = require('express');
const { db } = require('../db');
const { requireAuth } = require('../middleware/auth');
const { studentFor } = require('../lib/academic');

const router = express.Router();
router.use(requireAuth);

function toId(value) {
  const number = parseInt(value, 10);
  return Number.isNaN(number) ? null : number;
}

// The people this user is allowed to start a conversation with
function contactsFor(user) {
  if (user.role === 'student') {
    const student = studentFor(user.id);
    if (!student) return [];

    const rows = db.prepare(`
      SELECT te.user_id, te.name,
        (SELECT group_concat(DISTINCT sub.name)
           FROM timetables t2 JOIN subjects sub ON sub.id = t2.subject_id
          WHERE t2.teacher_id = te.id AND t2.class_id = ?) AS detail
      FROM teachers te
      WHERE te.user_id IS NOT NULL AND (
        te.id IN (SELECT teacher_id FROM timetables WHERE class_id = ?)
        OR te.id IN (SELECT class_teacher_id FROM classes WHERE id = ?)
      )
      ORDER BY te.name
    `).all(student.class_id || 0, student.class_id || 0, student.class_id || 0);
    if (rows.length > 0) return rows.map((r) => ({ ...r, role: 'teacher' }));

    // No timetable yet, so any lecturer with a login can be reached
    return db.prepare('SELECT user_id, name, specialty AS detail FROM teachers WHERE user_id IS NOT NULL ORDER BY name')
      .all().map((r) => ({ ...r, role: 'teacher' }));
  }

  if (user.role === 'teacher') {
    return db.prepare(`
      SELECT u.id AS user_id, u.name, s.adm_no || ' · ' || COALESCE(c.name || ' ' || c.stream, 'No class') AS detail
      FROM students s JOIN users u ON u.id = s.user_id LEFT JOIN classes c ON c.id = s.class_id
      WHERE s.status = 'active' ORDER BY u.name
    `).all().map((r) => ({ ...r, role: 'student' }));
  }

  if (user.role === 'admin' || ['staff','accounts','librarian','nurse','ict'].includes(user.role)) {
    const roles = user.role === 'admin'
      ? ['admin','teacher','student','staff','accounts','librarian','nurse','ict']
      : ['admin','teacher','staff','accounts','librarian','nurse','ict'];
    const placeholders = roles.map(() => '?').join(',');
    return db.prepare(`SELECT id AS user_id, name, role AS detail, role FROM users WHERE id != ? AND active = 1 AND role IN (${placeholders}) ORDER BY name`)
      .all(user.id, ...roles);
  }
  return [];
}

// You can write to your contacts, or reply to anyone who has already written to you
function canMessage(user, otherId) {
  if (contactsFor(user).some((c) => c.user_id === otherId)) return true;
  return Boolean(db.prepare('SELECT 1 AS found FROM messages WHERE sender_id = ? AND recipient_id = ? LIMIT 1').get(otherId, user.id));
}

router.get('/contacts', (req, res) => {
  res.json(contactsFor(req.user));
});

router.get('/unread-count', (req, res) => {
  const row = db.prepare('SELECT COUNT(*) c FROM messages WHERE recipient_id = ? AND read_at IS NULL').get(req.user.id);
  res.json({ count: row.c });
});

// One row per conversation, newest first
router.get('/threads', (req, res) => {
  const me = req.user.id;
  const rows = db.prepare(`
    SELECT id, sender_id, recipient_id, subject, body, read_at, created_at
    FROM messages
    WHERE (sender_id = ? OR recipient_id = ?) AND sender_id IS NOT NULL AND recipient_id IS NOT NULL
    ORDER BY created_at DESC, id DESC
  `).all(me, me);

  const threads = new Map();
  rows.forEach((m) => {
    const otherId = m.sender_id === me ? m.recipient_id : m.sender_id;
    if (!threads.has(otherId)) {
      threads.set(otherId, { user_id: otherId, last_message: m.body, last_subject: m.subject, last_at: m.created_at, last_from_me: m.sender_id === me, unread: 0 });
    }
    if (m.recipient_id === me && !m.read_at) threads.get(otherId).unread += 1;
  });

  const ids = [...threads.keys()];
  const people = ids.length === 0 ? [] : db.prepare(
    `SELECT id, name, role FROM users WHERE id IN (${ids.map(() => '?').join(',')})`
  ).all(...ids);
  const byId = new Map(people.map((p) => [p.id, p]));

  res.json([...threads.values()]
    .filter((t) => byId.has(t.user_id))
    .map((t) => ({ ...t, name: byId.get(t.user_id).name, role: byId.get(t.user_id).role })));
});

// Open a conversation. Messages sent to you are marked as read.
router.get('/threads/:userId', (req, res) => {
  const me = req.user.id;
  const otherId = toId(req.params.userId);
  const other = otherId && db.prepare('SELECT id, name, role FROM users WHERE id = ?').get(otherId);
  if (!other) return res.status(404).json({ error: 'Person not found.' });

  db.prepare(
    "UPDATE messages SET read_at = datetime('now') WHERE recipient_id = ? AND sender_id = ? AND read_at IS NULL"
  ).run(me, otherId);

  const messages = db.prepare(`
    SELECT id, sender_id, recipient_id, subject, body, created_at
    FROM messages
    WHERE (sender_id = ? AND recipient_id = ?) OR (sender_id = ? AND recipient_id = ?)
    ORDER BY created_at ASC, id ASC
  `).all(me, otherId, otherId, me).map((m) => ({ ...m, mine: m.sender_id === me }));

  res.json({ person: other, messages });
});

router.post('/', (req, res) => {
  const recipientId = toId(req.body.recipient_id);
  const body = String(req.body.body || '').trim();
  const subject = String(req.body.subject || '').trim().slice(0, 150) || null;

  if (!recipientId || recipientId === req.user.id) return res.status(400).json({ error: 'Choose who to send this to.' });
  if (!body) return res.status(400).json({ error: 'Write a message first.' });
  if (body.length > 5000) return res.status(400).json({ error: 'That message is too long (5000 characters at most).' });
  if (!db.prepare('SELECT id FROM users WHERE id = ? AND active = 1').get(recipientId)) {
    return res.status(404).json({ error: 'That person was not found.' });
  }
  if (!canMessage(req.user, recipientId)) {
    return res.status(403).json({ error: 'You cannot message that person.' });
  }

  const result = db.prepare('INSERT INTO messages (sender_id, recipient_id, subject, body) VALUES (?, ?, ?, ?)')
    .run(req.user.id, recipientId, subject, body);
  res.status(201).json({ id: Number(result.lastInsertRowid) });
});

module.exports = router;
