const express = require('express');
const { db } = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');
const { gradeLockGuard, noAssistantMarks } = require('../lib/gradeLock');

const router = express.Router();

router.get('/subjects', requireAuth, (req, res) => {
  res.json(db.prepare('SELECT * FROM subjects ORDER BY name').all());
});

router.get('/exams', requireAuth, requireRole('admin','vice_chancellor','deputy_vc','registrar','dean','deputy_dean','hod','lecturer','senior_lecturer','professor','academic_staff','examination_officer','exam_board','auditor'), (req, res) => {
  res.json(db.prepare('SELECT * FROM exams ORDER BY id DESC').all());
});

router.post('/exams', requireAuth, requireRole('admin', 'teacher'), noAssistantMarks, gradeLockGuard, (req, res) => {
  const { name, term, year } = req.body;
  if (!name || !term || !year) return res.status(400).json({ error: 'Name, term and year are required.' });
  const result = db.prepare('INSERT INTO exams (name, term, year) VALUES (?, ?, ?)').run(name, term, year);
  res.status(201).json({ id: result.lastInsertRowid });
});

// Grades for a given exam, grouped by student
router.get('/grades/:examId', requireAuth, requireRole('admin','vice_chancellor','deputy_vc','registrar','dean','deputy_dean','hod','lecturer','senior_lecturer','professor','academic_staff','examination_officer','exam_board','auditor'), (req, res) => {
  const rows = db.prepare(`
    SELECT g.*, s.name as student_name, s.adm_no, sub.name as subject_name, sub.code
    FROM grades g
    JOIN students s ON s.id = g.student_id
    JOIN subjects sub ON sub.id = g.subject_id
    WHERE g.exam_id = ?
    ORDER BY s.name, sub.name
  `).all(req.params.examId);
  res.json(rows);
});

router.post('/grades', requireAuth, requireRole('admin', 'teacher'), noAssistantMarks, gradeLockGuard, (req, res) => {
  const { exam_id, student_id, subject_id, score } = req.body;
  if (!exam_id || !student_id || !subject_id || score === undefined) {
    return res.status(400).json({ error: 'exam_id, student_id, subject_id and score are required.' });
  }
  db.prepare(`
    INSERT INTO grades (exam_id, student_id, subject_id, score) VALUES (?, ?, ?, ?)
  `).run(exam_id, student_id, subject_id, score);
  res.status(201).json({ success: true });
});

// A single student's full academic record across all exams
router.get('/student/:studentId', requireAuth, (req, res) => {
  const studentId=Number(req.params.studentId);
  const academicRoles=['admin','vice_chancellor','deputy_vc','registrar','deputy_registrar','dean','deputy_dean','hod','lecturer','senior_lecturer','professor','academic_staff','examination_officer','exam_board','auditor'];
  if(!academicRoles.includes(req.user.role)){
    if(req.user.role==='student'){ const own=db.prepare('SELECT id FROM students WHERE user_id=?').get(req.user.id)?.id; if(own!==studentId)return res.status(403).json({error:'Not authorised'}); }
    else if(req.user.role==='parent'){ const p=db.prepare('SELECT id FROM parents WHERE user_id=?').get(req.user.id); const ok=p&&db.prepare('SELECT 1 FROM parent_students WHERE parent_id=? AND student_id=?').get(p.id,studentId); if(!ok)return res.status(403).json({error:'Not authorised'}); }
    else return res.status(403).json({error:'You do not have permission to view academic records.'});
  }
  const rows = db.prepare(`
    SELECT g.*, sub.name as subject_name, e.name as exam_name, e.term, e.year
    FROM grades g
    JOIN subjects sub ON sub.id = g.subject_id
    JOIN exams e ON e.id = g.exam_id
    WHERE g.student_id = ?
    ORDER BY e.id DESC, sub.name
  `).all(studentId);
  res.json(rows);
});

module.exports = router;
