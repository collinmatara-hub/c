// routes/users.js
// Admin-only user management: create logins for teachers, students, parents,
// staff and workers, issue their school email, reset passwords, switch accounts
// on or off, and remove logins.

const express = require('express');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const { db } = require('../db');
const { requireAuth } = require('../middleware/auth');
const { ALL_ROLE_KEYS, getRole, groupOf: roleGroup, hasCap, isTemporary } = require('../lib/roles');

const router = express.Router();
router.use(requireAuth);

// Who may use each user-management action:
//  - administrators: everything
//  - Helpdesk Level 1: list users, reset passwords, unlock accounts, update contact details
//  - Helpdesk Level 2: all of Level 1, plus changing roles
// Nobody except an administrator may touch an administrator account, and Level 1 may not
// touch other helpdesk accounts.
const isAdmin = (req) => req.user.actual_role === 'admin';
function allow(kind) {
  return (req, res, next) => {
    const actual = req.user.actual_role;
    const ok = isAdmin(req)
      || (kind === 'helpdesk' && hasCap(actual, 'helpdesk.l1'))
      || (kind === 'roles' && hasCap(actual, 'helpdesk.l2'));
    if (!ok) return res.status(403).json({ error: 'You do not have permission to do that.' });
    next();
  };
}
const adminOnly = allow('admin');
const helpdesk = allow('helpdesk');
const rolesDesk = allow('roles');

function guardTarget(req, target) {
  if (isAdmin(req)) return;
  if (target.role === 'admin') fail('Only an administrator can change an administrator account.', 403);
  if (!hasCap(req.user.actual_role, 'helpdesk.l2') && (hasCap(target.role, 'helpdesk.l1') || hasCap(target.role, 'helpdesk.l2'))) {
    fail('Helpdesk Level 1 cannot change helpdesk accounts.', 403);
  }
}

const SCHOOL_DOMAIN = 'matara.ac.ke';
const ALL_ROLES = ALL_ROLE_KEYS;

const DEFAULT_POSITION = {
  staff: 'Support Staff',
  accounts: 'Accounts Officer',
  librarian: 'Librarian',
  nurse: 'Medical Officer',
  ict: 'ICT Officer',
};

// Words removed from a name before building the email
const TITLES = ['mr', 'mrs', 'ms', 'miss', 'dr', 'prof', 'eng', 'hon', 'rev', 'sir', 'madam'];

// Each role keeps its personal details in one of these tables
const TABLE_BY_GROUP = { teacher: 'teachers', student: 'students', staff: 'staff' };

function groupOf(role) {
  return roleGroup(role); // null for administrators and machine accounts
}

// ---------- small helpers ----------

function fail(message, status = 400) {
  const err = new Error(message);
  err.status = status;
  throw err;
}

function sendError(res, err) {
  if (err.status) return res.status(err.status).json({ error: err.message });
  console.error(err);
  if (String(err.message).includes('UNIQUE')) {
    return res.status(400).json({ error: 'That email or ID number is already in use.' });
  }
  return res.status(500).json({ error: 'Something went wrong on the server.' });
}

function clean(value) {
  if (value === undefined || value === null) return null;
  const text = String(value).trim();
  return text === '' ? null : text;
}

function toId(value) {
  const number = parseInt(value, 10);
  return Number.isNaN(number) ? null : number;
}

function inTransaction(work) {
  db.exec('BEGIN');
  try {
    const result = work();
    db.exec('COMMIT');
    return result;
  } catch (err) {
    db.exec('ROLLBACK');
    throw err;
  }
}

function audit(req, action, userId, details) {
  db.prepare(
    'INSERT INTO audit_logs (user_id, action, entity, entity_id, details) VALUES (?, ?, ?, ?, ?)'
  ).run(req.user.id, action, 'user', userId, details);
}

function findUser(id) {
  const user = db.prepare('SELECT id, name, email, role, active FROM users WHERE id = ?').get(toId(id));
  if (!user) fail('User not found.', 404);
  return user;
}

// ---------- passwords ----------

function randomChars(count, alphabet) {
  let text = '';
  for (let i = 0; i < count; i++) {
    text += alphabet[crypto.randomInt(alphabet.length)];
  }
  return text;
}

// Easy to read out loud: no 0/O or 1/l/I
function makePassword() {
  return 'Mgs-' + randomChars(6, 'abcdefghjkmnpqrstuvwxyz23456789');
}

function checkPassword(password) {
  if (password && password.length < 6) fail('Password must be at least 6 characters.');
}

// ---------- university email ----------

// "Mr. Otieno Owino" -> "otieno.owino"
function makeUsername(name) {
  const words = String(name || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .split(/[\s.]+/)
    .map((word) => word.replace(/[^a-z]/g, ''))
    .filter((word) => word && !TITLES.includes(word));

  if (words.length === 0) return '';
  if (words.length === 1) return words[0];
  return words[0] + '.' + words[words.length - 1];
}

function emailExists(email) {
  return Boolean(db.prepare('SELECT id FROM users WHERE email = ?').get(email));
}

// If john.kamau is taken, try john.kamau2, john.kamau3 ...
function uniqueEmail(username) {
  let candidate = username;
  let count = 1;
  while (emailExists(candidate + '@' + SCHOOL_DOMAIN)) {
    count += 1;
    candidate = username + count;
  }
  return candidate + '@' + SCHOOL_DOMAIN;
}

// Accepts "john.kamau", or "john.kamau@matara.ac.ke", or nothing (built from the name)
function buildEmail(input, name) {
  const text = clean(input);
  if (!text) {
    const username = makeUsername(name);
    if (!username) fail('Enter a name so a school email can be created.');
    return uniqueEmail(username);
  }

  const lower = text.toLowerCase();
  const parts = lower.includes('@') ? lower.split('@') : [lower, SCHOOL_DOMAIN];
  const local = parts[0];
  const domain = parts[1];

  if (parts.length > 2 || domain !== SCHOOL_DOMAIN) {
    fail(`School emails must end with @${SCHOOL_DOMAIN}.`);
  }
  if (!/^[a-z0-9._-]{2,40}$/.test(local)) {
    fail('The email name can only use letters, numbers, dots, dashes and underscores (2 to 40 characters).');
  }
  return local + '@' + SCHOOL_DOMAIN;
}

// ---------- University reference numbers ----------

function nextNumber(table, column, prefix, digits) {
  const rows = db.prepare(`SELECT ${column} AS value FROM ${table}`).all();
  let highest = 0;
  rows.forEach((row) => {
    const text = String(row.value || '');
    const match = text.match(/(\d+)$/);
    if (match && text.startsWith(prefix)) {
      highest = Math.max(highest, parseInt(match[1], 10));
    }
  });
  return prefix + String(highest + 1).padStart(digits, '0');
}

function ensureFree(table, column, value, message) {
  const found = db.prepare(`SELECT 1 AS taken FROM ${table} WHERE ${column} = ?`).get(value);
  if (found) fail(message);
}

// A student's record status follows the kind of student account.
function studentStatusFor(role) {
  if (role === 'deferred_student') return 'deferred';
  if (role === 'suspended_student') return 'suspended';
  return 'active';
}

// ---------- creating the person's record ----------

function createRecord(group, role, userId, name, email, body) {
  if (group === 'teacher') {
    const staffNo = clean(body.staff_no) || nextNumber('teachers', 'staff_no', 'T', 3);
    ensureFree('teachers', 'staff_no', staffNo, 'That staff number is already in use.');
    db.prepare(
      'INSERT INTO teachers (user_id, staff_no, name, phone, specialty) VALUES (?, ?, ?, ?, ?)'
    ).run(userId, staffNo, name, clean(body.phone), clean(body.specialty));
  }

  if (group === 'student') {
    const admNo = clean(body.adm_no) || nextNumber('students', 'adm_no', 'MU-', 4);
    ensureFree('students', 'adm_no', admNo, 'That admission number is already in use.');
    const gender = ['M', 'F'].includes(body.gender) ? body.gender : null;
    db.prepare(
      `INSERT INTO students (user_id, adm_no, name, gender, dob, class_id, guardian_name, guardian_phone, status, enrolled_on)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, date('now'))`
    ).run(userId, admNo, name, gender, clean(body.dob), toId(body.class_id),
      clean(body.guardian_name), clean(body.guardian_phone), studentStatusFor(role));
  }

  if (group === 'parent') {
    const parent = db.prepare(
      'INSERT INTO parents (user_id, name, phone, email, address) VALUES (?, ?, ?, ?, ?)'
    ).run(userId, name, clean(body.phone), email, clean(body.address));

    const children = Array.isArray(body.children) ? body.children : [];
    children.forEach((child) => {
      const studentId = toId(child.student_id);
      if (!studentId) return;
      if (!db.prepare('SELECT id FROM students WHERE id = ?').get(studentId)) {
        fail('One of the selected children could not be found.');
      }
      db.prepare(
        'INSERT OR IGNORE INTO parent_students (parent_id, student_id, relationship) VALUES (?, ?, ?)'
      ).run(parent.lastInsertRowid, studentId, clean(child.relationship) || 'Guardian');
    });
  }

  if (group === 'staff') {
    const employeeNo = clean(body.employee_no) || nextNumber('staff', 'employee_no', 'E', 3);
    ensureFree('staff', 'employee_no', employeeNo, 'That employee number is already in use.');
    db.prepare(
      `INSERT INTO staff (user_id, employee_no, name, position, department_id, phone, email, employment_date, status)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'active')`
    ).run(userId, employeeNo, name, clean(body.position) || DEFAULT_POSITION[role] || role.replaceAll('_',' ').replace(/\b\w/g, c => c.toUpperCase()),
      toId(body.department_id), clean(body.phone), email, clean(body.employment_date));
  }
}

// ---------- routes ----------

// Everything the "Add user" form needs in one call
router.get('/options', adminOnly, (req, res) => {
  res.json({
    domain: SCHOOL_DOMAIN,
    classes: db.prepare('SELECT id, name, stream FROM classes ORDER BY name, stream').all(),
    departments: db.prepare('SELECT id, name FROM departments ORDER BY name').all(),
    students: db.prepare("SELECT id, name, adm_no FROM students WHERE status = 'active' ORDER BY name").all(),
    // People already in the system who do not have a login yet
    unlinked: {
      teacher: db.prepare('SELECT id, name, staff_no AS ref FROM teachers WHERE user_id IS NULL ORDER BY name').all(),
      student: db.prepare('SELECT id, name, adm_no AS ref FROM students WHERE user_id IS NULL ORDER BY name').all(),
      parent: db.prepare("SELECT id, name, COALESCE(phone, '') AS ref FROM parents WHERE user_id IS NULL ORDER BY name").all(),
      staff: db.prepare("SELECT id, name, COALESCE(employee_no, '') AS ref FROM staff WHERE user_id IS NULL ORDER BY name").all(),
    },
  });
});

router.get('/suggest-email', adminOnly, (req, res) => {
  const username = makeUsername(req.query.name);
  if (!username) return res.json({ username: '', email: '' });
  const email = uniqueEmail(username);
  res.json({ username: email.split('@')[0], email });
});

router.get('/', helpdesk, (req, res) => {
  const rows = db.prepare(`
    SELECT u.id, u.name, u.email, u.role, u.active, u.created_at, u.password_changed_at, u.activated_at, u.deactivated_at, u.email_provisioned, u.two_factor_enabled,
      (SELECT COUNT(*) FROM password_history ph WHERE ph.user_id = u.id) AS password_event_count,
      (SELECT changed_at FROM password_history ph WHERE ph.user_id = u.id ORDER BY ph.id DESC LIMIT 1) AS last_password_event,
      EXISTS(SELECT 1 FROM account_recovery ar WHERE ar.user_id = u.id) AS recovery_configured,
      COALESCE(
        (SELECT staff_no FROM teachers WHERE user_id = u.id LIMIT 1),
        (SELECT adm_no FROM students WHERE user_id = u.id LIMIT 1),
        (SELECT employee_no FROM staff WHERE user_id = u.id LIMIT 1)
      ) AS reference_no
    FROM users u
    ORDER BY u.created_at DESC, u.id DESC
  `).all();
  res.json(rows);
});

router.post('/', adminOnly, (req, res) => {
  try {
    const body = req.body;
    const role = body.role;
    if (String(role || '').toLowerCase() === 'parent') fail('Parent portal accounts are not supported in the university ERP. Record emergency contacts on the student profile instead.');
    if (!ALL_ROLES.includes(role)) fail('Choose a role for this user.');
    const group = groupOf(role);

    // Either link a login to someone already in the system, or add a new person
    let existing = null;
    if (body.existing_id) {
      if (!group) fail('Administrators do not have an existing record to link.');
      existing = db.prepare(
        `SELECT * FROM ${TABLE_BY_GROUP[group]} WHERE id = ? AND user_id IS NULL`
      ).get(toId(body.existing_id));
      if (!existing) fail('That record was not found, or it already has a login.');
    }

    const name = existing ? existing.name : clean(body.name);
    if (!name) fail('Full name is required.');

    const email = buildEmail(body.username, name);
    if (emailExists(email)) fail('That email is already in use.');

    const supplied = clean(body.password);
    checkPassword(supplied);
    const password = supplied || makePassword();

    // Invigilators and external examiners only get temporary access.
    const expires = clean(body.access_expires_at);
    if (isTemporary(role) && !expires) fail('This is a temporary role. Give the date when access ends.');
    if (expires && Number.isNaN(new Date(expires).getTime())) fail('Enter a valid access end date.');

    const userId = inTransaction(() => {
      const created = db.prepare(
        'INSERT INTO users (name, email, password, role, access_expires_at) VALUES (?, ?, ?, ?, ?)'
      ).run(name, email, bcrypt.hashSync(password, 10), role, expires);
      const id = Number(created.lastInsertRowid);

      if (existing) {
        db.prepare(`UPDATE ${TABLE_BY_GROUP[group]} SET user_id = ? WHERE id = ?`).run(id, existing.id);
      } else if (group) {
        createRecord(group, role, id, name, email, body);
      }
      return id;
    });

    db.prepare('INSERT INTO password_history (user_id, action, changed_by, reason) VALUES (?,?,?,?)').run(userId, 'initial_password', req.user.id, 'Account created by administrator');
    audit(req, 'create_user', userId, `Created ${role} login ${email}`);
    res.status(201).json({ id: userId, name, email, role, password, generated: !supplied });
  } catch (err) {
    sendError(res, err);
  }
});

router.put('/:id', helpdesk, (req, res) => {
  try {
    const user = findUser(req.params.id);
    guardTarget(req, user);
    const name = clean(req.body.name) || user.name;
    const email = clean(req.body.username) ? buildEmail(req.body.username, name) : user.email;

    const clash = db.prepare('SELECT id FROM users WHERE email = ? AND id != ?').get(email, user.id);
    if (clash) fail('That email is already in use.');

    inTransaction(() => {
      db.prepare('UPDATE users SET name = ?, email = ? WHERE id = ?').run(name, email, user.id);

      // Keep the person's record in step with their login
      ['teachers', 'students', 'staff', 'parents'].forEach((table) => {
        db.prepare(`UPDATE ${table} SET name = ? WHERE user_id = ?`).run(name, user.id);
      });
      if (email !== user.email) {
        ['staff', 'parents'].forEach((table) => {
          db.prepare(`UPDATE ${table} SET email = ? WHERE user_id = ? AND email = ?`).run(email, user.id, user.email);
        });
      }
    });

    audit(req, 'update_user', user.id, `Updated ${email}`);
    res.json({ success: true, email, name });
  } catch (err) {
    sendError(res, err);
  }
});

router.put('/:id/password', helpdesk, (req, res) => {
  try {
    const user = findUser(req.params.id);
    guardTarget(req, user);
    const supplied = clean(req.body.password);
    checkPassword(supplied);
    const password = supplied || makePassword();

    db.prepare("UPDATE users SET password = ?, session_version = session_version + 1, password_changed_at = datetime('now') WHERE id = ?").run(bcrypt.hashSync(password, 12), user.id);
    db.prepare('INSERT INTO password_history (user_id, action, changed_by, reason) VALUES (?,?,?,?)').run(user.id,'admin_reset',req.user.id,'Administrator reset password');
    audit(req, 'reset_password', user.id, `Password reset for ${user.email}`);
    // The plaintext is returned only once so the administrator can securely
    // hand the new credential to the user. Existing passwords cannot be read
    // because the database stores bcrypt hashes, not plaintext passwords.
    res.json({ name: user.name, email: user.email, password, note: 'This is the new password. Existing passwords cannot be viewed.' });
  } catch (err) {
    sendError(res, err);
  }
});


// Security centre: administrators can inspect password-event history and force logout,
// but never retrieve a user's existing password. Passwords are one-way hashes.
router.get('/:id/security', adminOnly, (req, res) => {
  try {
    const user = findUser(req.params.id);
    const history = db.prepare(`
      SELECT ph.id, ph.action, ph.changed_at, ph.reason,
             COALESCE(actor.name, 'System') AS changed_by_name,
             COALESCE(actor.email, '') AS changed_by_email
      FROM password_history ph
      LEFT JOIN users actor ON actor.id = ph.changed_by
      WHERE ph.user_id = ? ORDER BY ph.id DESC LIMIT 100
    `).all(user.id);
    const auditRows = db.prepare(`
      SELECT a.id, a.action, a.details, a.created_at, COALESCE(actor.name,'System') AS actor_name
      FROM audit_logs a LEFT JOIN users actor ON actor.id=a.user_id
      WHERE a.entity='user' AND a.entity_id=? ORDER BY a.id DESC LIMIT 100
    `).all(user.id);
    const recovery = db.prepare('SELECT updated_at FROM account_recovery WHERE user_id=?').get(user.id);
    res.json({ user:{id:user.id,name:user.name,email:user.email,role:user.role,active:user.active}, password:{changed_at:user.password_changed_at,events:history.length}, recovery_configured:!!recovery, recovery_updated_at:recovery?.updated_at||null, history, audit:auditRows });
  } catch (err) { sendError(res, err); }
});

router.post('/:id/force-logout', adminOnly, (req,res) => {
  try {
    const user=findUser(req.params.id);
    db.prepare('UPDATE users SET session_version=session_version+1 WHERE id=?').run(user.id);
    audit(req,'force_logout',user.id,`Administrator invalidated all sessions for ${user.email}`);
    res.json({success:true,message:'All active sessions for this account have been invalidated.'});
  } catch(err) { sendError(res,err); }
});

router.post('/:id/recovery-code', adminOnly, (req,res) => {
  try {
    const user=findUser(req.params.id);
    const code='MU-'+randomChars(4,'ABCDEFGHJKLMNPQRSTUVWXYZ23456789')+'-'+randomChars(4,'ABCDEFGHJKLMNPQRSTUVWXYZ23456789');
    db.prepare(`INSERT INTO account_recovery(user_id,recovery_code_hash,updated_at) VALUES(?,?,datetime('now')) ON CONFLICT(user_id) DO UPDATE SET recovery_code_hash=excluded.recovery_code_hash, updated_at=datetime('now')`).run(user.id,bcrypt.hashSync(code,12));
    audit(req,'admin_reset_recovery_code',user.id,`Administrator regenerated recovery code for ${user.email}`);
    res.json({success:true,name:user.name,email:user.email,recovery_code:code,note:'This code is shown once. Store it securely and give it to the account owner.'});
  } catch(err) { sendError(res,err); }
});

router.put('/:id/role', rolesDesk, (req, res) => {
  try {
    const user = findUser(req.params.id);
    const role = clean(req.body.role);
    if (!ALL_ROLES.includes(role)) fail('Choose a valid role.');
    guardTarget(req, user);
    if (role === 'admin' && !isAdmin(req)) fail('Only an administrator can make someone an administrator.', 403);
    if (isTemporary(role) && !clean(req.body.access_expires_at)) fail('Temporary roles need an access end date.');
    if (user.id === req.user.id) fail('You cannot change your own role.');

    const oldGroup = groupOf(user.role);
    const newGroup = groupOf(role);

    const profileTables = ['teachers', 'students', 'parents', 'staff'];
    const linked = {};
    profileTables.forEach((table) => {
      linked[table] = db.prepare(`SELECT id FROM ${table} WHERE user_id = ?`).get(user.id);
    });

    inTransaction(() => {
      // Keep one login attached to the correct profile type. Existing records are
      // retained but unlinked when the account changes to a different kind of profile.
      if (oldGroup !== newGroup) profileTables.forEach((table) => {
        if (linked[table]) db.prepare(`UPDATE ${table} SET user_id = NULL WHERE user_id = ?`).run(user.id);
      });

      if (oldGroup === newGroup) {
        // Same kind of profile (for example lecturer to senior lecturer): nothing to rebuild.
      } else if (newGroup === 'teacher') {
        const staffNo = nextNumber('teachers', 'staff_no', 'T', 3);
        db.prepare(
          'INSERT INTO teachers (user_id, staff_no, name, phone, specialty) VALUES (?, ?, ?, ?, ?)'
        ).run(user.id, staffNo, user.name, null, null);
      } else if (newGroup === 'student') {
        const admNo = nextNumber('students', 'adm_no', 'MU-', 4);
        db.prepare(
          "INSERT INTO students (user_id, adm_no, name, status, enrolled_on) VALUES (?, ?, ?, ?, date('now'))"
        ).run(user.id, admNo, user.name, studentStatusFor(role));
      } else if (newGroup === 'parent') {
        db.prepare(
          'INSERT INTO parents (user_id, name, email) VALUES (?, ?, ?)'
        ).run(user.id, user.name, user.email);
      } else if (newGroup === 'staff') {
        const employeeNo = nextNumber('staff', 'employee_no', 'E', 3);
        db.prepare(
          "INSERT INTO staff (user_id, employee_no, name, position, email, status) VALUES (?, ?, ?, ?, ?, 'active')"
        ).run(user.id, employeeNo, user.name, DEFAULT_POSITION[role] || 'Staff', user.email);
      }

      db.prepare('UPDATE users SET role = ?, access_expires_at = ?, session_version = session_version + 1 WHERE id = ?').run(role, clean(req.body.access_expires_at), user.id);
    });

    audit(req, 'change_role', user.id, `Changed role from ${user.role} to ${role}`);
    res.json({ success: true, id: user.id, role, role_label: role });
  } catch (err) {
    sendError(res, err);
  }
});

// Helpdesk: clear a lockout after repeated failed sign-ins.
router.post('/:id/unlock', helpdesk, (req, res) => {
  try {
    const user = findUser(req.params.id);
    guardTarget(req, user);
    db.prepare('UPDATE users SET locked_until = NULL, failed_login_count = 0 WHERE id = ?').run(user.id);
    audit(req, 'unlock_user', user.id, `Unlocked ${user.email}`);
    res.json({ success: true });
  } catch (err) {
    sendError(res, err);
  }
});

router.put('/:id/status', adminOnly, (req, res) => {
  try {
    const user = findUser(req.params.id);
    const active = req.body.active ? 1 : 0;
    if (!active && user.id === req.user.id) fail('You cannot deactivate your own account.');

    db.prepare("UPDATE users SET active = ?, activated_at = CASE WHEN ?=1 THEN datetime('now') ELSE activated_at END, deactivated_at = CASE WHEN ?=0 THEN datetime('now') ELSE deactivated_at END, session_version = session_version + CASE WHEN ?=0 THEN 1 ELSE 0 END WHERE id = ?").run(active, active, active, active, user.id);
    audit(req, active ? 'activate_user' : 'deactivate_user', user.id, `${active ? 'Activated' : 'Deactivated'} ${user.email}`);
    res.json({ success: true, active });
  } catch (err) {
    sendError(res, err);
  }
});

// Removes the login only. The person's record (student, teacher, staff...) stays in the system.
router.delete('/:id', adminOnly, (req, res) => {
  try {
    const user = findUser(req.params.id);
    if (user.id === req.user.id) fail('You cannot delete your own account.');

    inTransaction(() => {
      const references = [
        ['teachers', 'user_id'], ['students', 'user_id'], ['staff', 'user_id'], ['parents', 'user_id'],
        ['audit_logs', 'user_id'], ['expenses', 'created_by'], ['income', 'created_by'],
        ['messages', 'sender_id'], ['messages', 'recipient_id'],
      ];
      references.forEach(([table, column]) => {
        db.prepare(`UPDATE ${table} SET ${column} = NULL WHERE ${column} = ?`).run(user.id);
      });
      db.prepare('DELETE FROM notifications WHERE user_id = ?').run(user.id);
      db.prepare('DELETE FROM users WHERE id = ?').run(user.id);
    });

    audit(req, 'delete_user', user.id, `Deleted login ${user.email}`);
    res.json({ success: true });
  } catch (err) {
    sendError(res, err);
  }
});

module.exports = router;
