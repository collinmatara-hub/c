const express = require('express');
const { db } = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');

const router = express.Router();

router.get('/', requireAuth, (req, res) => {
  const rows = db.prepare(`
    SELECT c.*, t.name as teacher_name,
      (SELECT COUNT(*) FROM students s WHERE s.class_id = c.id AND s.status='active') as student_count
    FROM classes c LEFT JOIN teachers t ON t.id = c.class_teacher_id
    ORDER BY c.name ASC
  `).all();
  res.json(rows);
});

router.post('/', requireAuth, requireRole('admin'), (req, res) => {
  const { name, stream, class_teacher_id, capacity } = req.body;
  if (!name || !stream) return res.status(400).json({ error: 'Class name and stream are required.' });
  const result = db.prepare(`
    INSERT INTO classes (name, stream, class_teacher_id, capacity) VALUES (?, ?, ?, ?)
  `).run(name, stream, class_teacher_id || null, capacity || 40);
  res.status(201).json({ id: result.lastInsertRowid });
});

router.delete('/:id', requireAuth, requireRole('admin'), (req, res) => {
  db.prepare('DELETE FROM classes WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

module.exports = router;
