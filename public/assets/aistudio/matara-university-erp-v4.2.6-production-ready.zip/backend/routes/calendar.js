'use strict';
// University calendar. Everyone signed in reads the published events meant for them.
// Only the officers named in lib/calendarPolicy.js can create, approve, publish or cancel events,
// and only in the categories they own.
const express = require('express');
const { db } = require('../db');
const { requireAuth } = require('../middleware/auth');
const policy = require('../lib/calendarPolicy');

db.exec(`
  CREATE TABLE IF NOT EXISTS cal_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, category TEXT NOT NULL, event_type TEXT NOT NULL DEFAULT 'Event',
    start_date TEXT NOT NULL, end_date TEXT NOT NULL, start_time TEXT DEFAULT '', end_time TEXT DEFAULT '',
    location TEXT DEFAULT '', audience TEXT NOT NULL DEFAULT 'all', description TEXT DEFAULT '',
    academic_year TEXT DEFAULT '', reminder_days INTEGER NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'draft' CHECK(status IN ('draft','pending','published','cancelled')),
    review_note TEXT DEFAULT '', created_by INTEGER, created_by_name TEXT DEFAULT '', published_by_name TEXT DEFAULT '',
    published_at TEXT, created_at TEXT DEFAULT (datetime('now')), updated_at TEXT DEFAULT (datetime('now'))
  );
  CREATE INDEX IF NOT EXISTS idx_cal_events_date ON cal_events(start_date, end_date);
  CREATE TABLE IF NOT EXISTS cal_audit (
    id INTEGER PRIMARY KEY AUTOINCREMENT, event_id INTEGER, action TEXT NOT NULL, actor_id INTEGER, actor_name TEXT DEFAULT '',
    actor_role TEXT DEFAULT '', details TEXT DEFAULT '', created_at TEXT DEFAULT (datetime('now'))
  );
`);
// One-time carry-over of events that were entered in the old calendar table (published, general).
try {
  if (db.prepare('SELECT COUNT(*) n FROM cal_events').get().n === 0) {
    const old = db.prepare('SELECT * FROM calendar_events').all();
    for (const o of old) {
      const start = String(o.start_at || '').slice(0, 10);
      if (!/^\d{4}-\d{2}-\d{2}$/.test(start)) continue;
      const end = /^\d{4}-\d{2}-\d{2}/.test(o.end_at || '') ? String(o.end_at).slice(0, 10) : start;
      const aud = ['all', 'students', 'staff', 'lecturers'].includes(String(o.audience || '').toLowerCase()) ? String(o.audience).toLowerCase() : 'all';
      db.prepare("INSERT INTO cal_events(title,category,event_type,start_date,end_date,location,audience,description,status,created_by_name,published_by_name,published_at) VALUES(?,?,?,?,?,?,?,?,'published','Imported','Imported',datetime('now'))")
        .run(o.title, 'general', 'Event', start, end < start ? start : end, o.location || '', aud, o.description || '');
    }
  }
} catch (e) { /* the old table may not exist; nothing to carry over */ }

const router = express.Router();
router.use(requireAuth);

const role = (req) => req.user.actual_role || req.user.role;
const bad = (res, msg, code = 400) => res.status(code).json({ error: msg });
const DATE = /^\d{4}-\d{2}-\d{2}$/;
const TIME = /^([01]\d|2[0-3]):[0-5]\d$/;

function audit(req, eventId, action, details = '') {
  db.prepare('INSERT INTO cal_audit(event_id,action,actor_id,actor_name,actor_role,details) VALUES(?,?,?,?,?,?)')
    .run(eventId || null, action, req.user.id, req.user.name || '', role(req), String(details).slice(0, 500));
}

// Everything the person may read: published events for their audience, plus the drafts and
// pending events of categories they author or publish.
function visibleEvents(req) {
  const r = role(req);
  const aud = policy.audiencesFor(r);
  const mine = Object.keys(policy.POLICY).filter((c) => policy.canAuthor(r, c) || policy.canPublish(r, c));
  const rows = db.prepare('SELECT * FROM cal_events ORDER BY start_date, start_time').all();
  return rows.filter((e) => {
    if (['published', 'cancelled'].includes(e.status)) return aud.includes(e.audience) || mine.includes(e.category) || r === 'admin';
    return mine.includes(e.category);
  });
}

router.get('/me', (req, res) => {
  const r = role(req);
  const categories = Object.entries(policy.POLICY).map(([key, c]) => ({
    key, label: c.label, canAuthor: policy.canAuthor(r, key), canPublish: policy.canPublish(r, key), needsApproval: policy.needsApproval(key),
    owners: c.publish,
  }));
  res.json({
    role: r, categories, eventTypes: policy.EVENT_TYPES, audiences: policy.AUDIENCES,
    manages: categories.some((c) => c.canAuthor || c.canPublish),
  });
});

router.get('/events', (req, res) => {
  let rows = visibleEvents(req);
  if (req.query.from) rows = rows.filter((e) => e.end_date >= String(req.query.from));
  if (req.query.to) rows = rows.filter((e) => e.start_date <= String(req.query.to));
  if (req.query.category) rows = rows.filter((e) => e.category === req.query.category);
  res.json(rows);
});

function readInput(b, category) {
  const title = String(b.title || '').trim();
  if (!title) return { error: 'A title is required.' };
  if (!policy.POLICY[category]) return { error: 'Choose a valid category.' };
  if (!DATE.test(b.start_date || '')) return { error: 'A valid start date is required.' };
  const end = DATE.test(b.end_date || '') ? b.end_date : b.start_date;
  if (end < b.start_date) return { error: 'The end date cannot be before the start date.' };
  const st = b.start_time || ''; const et = b.end_time || '';
  if ((st && !TIME.test(st)) || (et && !TIME.test(et))) return { error: 'Times must look like 08:00.' };
  if (st && et && b.start_date === end && et <= st) return { error: 'The end time must be after the start time.' };
  const audience = policy.AUDIENCES.includes(b.audience) ? b.audience : 'all';
  const type = policy.EVENT_TYPES.includes(b.event_type) ? b.event_type : 'Event';
  const reminder = Math.max(0, Math.min(60, Math.trunc(Number(b.reminder_days) || 0)));
  return { v: { title, category, event_type: type, start_date: b.start_date, end_date: end, start_time: st, end_time: et, location: String(b.location || ''), audience, description: String(b.description || ''), academic_year: String(b.academic_year || ''), reminder_days: reminder } };
}

// Two semesters of the same academic year must not overlap.
function semesterClash(v, ignoreId) {
  if (v.event_type !== 'Semester' || v.category !== 'academic') return null;
  const hit = db.prepare("SELECT title FROM cal_events WHERE category='academic' AND event_type='Semester' AND status IN ('pending','published') AND id != ? AND academic_year = ? AND start_date <= ? AND end_date >= ?")
    .get(ignoreId || 0, v.academic_year, v.end_date, v.start_date);
  return hit ? `This semester overlaps "${hit.title}".` : null;
}

// Tells the people the event is for. One insert, no per-user loop.
function notify(event, headline) {
  const body = `${event.title}: ${event.start_date}${event.end_date !== event.start_date ? ` to ${event.end_date}` : ''}${event.location ? `, ${event.location}` : ''}.`;
  const lec = policy.LECTURER_ROLES.map(() => '?').join(',');
  const where = { all: "role != 'machine_user'", students: "role = 'student'", staff: "role NOT IN ('student','machine_user')", lecturers: `role IN (${lec})` }[event.audience];
  const params = event.audience === 'lecturers' ? [headline, body, ...policy.LECTURER_ROLES] : [headline, body];
  db.prepare(`INSERT INTO notifications(user_id,title,body) SELECT id, ?, ? FROM users WHERE active=1 AND ${where}`).run(...params);
}

router.post('/events', (req, res) => {
  const b = req.body || {};
  if (!policy.canAuthor(role(req), b.category)) return bad(res, 'Your role cannot add events to this category.', 403);
  const { v, error } = readInput(b, b.category); if (error) return bad(res, error);
  const clash = semesterClash(v); if (clash) return bad(res, clash, 409);
  const cols = Object.keys(v);
  const r = db.prepare(`INSERT INTO cal_events(${cols.join(',')},status,created_by,created_by_name) VALUES(${cols.map(() => '?').join(',')},'draft',?,?)`).run(...Object.values(v), req.user.id, req.user.name || '');
  audit(req, r.lastInsertRowid, 'created', `${v.title} (${v.category})`);
  res.status(201).json(db.prepare('SELECT * FROM cal_events WHERE id=?').get(r.lastInsertRowid));
});

function loadEvent(req, res) {
  const e = db.prepare('SELECT * FROM cal_events WHERE id=?').get(req.params.id);
  // An event the person cannot see is reported as missing, not as forbidden.
  if (!e || !visibleEvents(req).some((x) => x.id === e.id)) { bad(res, 'Event not found.', 404); return null; }
  return e;
}

router.put('/events/:id', (req, res) => {
  const e = loadEvent(req, res); if (!e) return;
  const r = role(req);
  const editingPublished = ['published', 'cancelled'].includes(e.status);
  if (editingPublished ? !policy.canPublish(r, e.category) : !policy.canAuthor(r, e.category)) return bad(res, 'Your role cannot change this event.', 403);
  if (e.status === 'cancelled') return bad(res, 'A cancelled event cannot be edited.', 409);
  const { v, error } = readInput({ ...req.body, category: e.category }, e.category); if (error) return bad(res, error);
  const clash = semesterClash(v, e.id); if (clash) return bad(res, clash, 409);
  const cols = Object.keys(v);
  const nextStatus = e.status === 'pending' ? 'draft' : e.status; // editing a submitted event pulls it back for resubmission
  db.prepare(`UPDATE cal_events SET ${cols.map((c) => `${c}=?`).join(',')}, status=?, updated_at=datetime('now') WHERE id=?`).run(...Object.values(v), nextStatus, e.id);
  audit(req, e.id, editingPublished ? 'changed_published' : 'edited', v.title);
  const updated = db.prepare('SELECT * FROM cal_events WHERE id=?').get(e.id);
  if (editingPublished) notify(updated, `Calendar change: ${updated.title}`);
  res.json(updated);
});

// Send for approval, or publish straight away when the author also owns publication.
router.post('/events/:id/submit', (req, res) => {
  const e = loadEvent(req, res); if (!e) return;
  const r = role(req);
  if (!policy.canAuthor(r, e.category)) return bad(res, 'Your role cannot submit this event.', 403);
  if (e.status !== 'draft') return bad(res, 'Only a draft can be submitted.', 409);
  if (policy.canPublish(r, e.category)) {
    db.prepare("UPDATE cal_events SET status='published', published_by_name=?, published_at=datetime('now'), updated_at=datetime('now') WHERE id=?").run(req.user.name || '', e.id);
    audit(req, e.id, 'published', 'published by its owner');
    notify(e, `New on the university calendar: ${e.title}`);
    return res.json({ status: 'published' });
  }
  db.prepare("UPDATE cal_events SET status='pending', review_note='', updated_at=datetime('now') WHERE id=?").run(e.id);
  audit(req, e.id, 'submitted', 'sent for approval');
  res.json({ status: 'pending' });
});

router.post('/events/:id/approve', (req, res) => {
  const e = loadEvent(req, res); if (!e) return;
  if (!policy.canPublish(role(req), e.category)) return bad(res, 'Your role cannot approve events in this category.', 403);
  if (e.status !== 'pending') return bad(res, 'Only a submitted event can be approved.', 409);
  if (e.created_by === req.user.id) return bad(res, 'You cannot approve an event you created.', 403);
  const clash = semesterClash(e, e.id); if (clash) return bad(res, clash, 409);
  db.prepare("UPDATE cal_events SET status='published', published_by_name=?, published_at=datetime('now'), updated_at=datetime('now') WHERE id=?").run(req.user.name || '', e.id);
  audit(req, e.id, 'approved_and_published', String((req.body || {}).note || ''));
  notify(e, `New on the university calendar: ${e.title}`);
  res.json({ status: 'published' });
});

router.post('/events/:id/return', (req, res) => {
  const e = loadEvent(req, res); if (!e) return;
  if (!policy.canPublish(role(req), e.category)) return bad(res, 'Your role cannot review events in this category.', 403);
  if (e.status !== 'pending') return bad(res, 'Only a submitted event can be returned.', 409);
  const note = String((req.body || {}).note || '').trim(); if (!note) return bad(res, 'Say what must be changed.');
  db.prepare("UPDATE cal_events SET status='draft', review_note=?, updated_at=datetime('now') WHERE id=?").run(note, e.id);
  audit(req, e.id, 'returned', note);
  res.json({ status: 'draft' });
});

router.post('/events/:id/cancel', (req, res) => {
  const e = loadEvent(req, res); if (!e) return;
  if (!policy.canPublish(role(req), e.category)) return bad(res, 'Your role cannot cancel events in this category.', 403);
  if (e.status !== 'published') return bad(res, 'Only a published event can be cancelled.', 409);
  const note = String((req.body || {}).note || '').trim(); if (!note) return bad(res, 'Give a reason for the cancellation.');
  db.prepare("UPDATE cal_events SET status='cancelled', review_note=?, updated_at=datetime('now') WHERE id=?").run(note, e.id);
  audit(req, e.id, 'cancelled', note);
  notify(e, `Cancelled: ${e.title}`);
  res.json({ status: 'cancelled' });
});

router.delete('/events/:id', (req, res) => {
  const e = loadEvent(req, res); if (!e) return;
  if (!policy.canAuthor(role(req), e.category)) return bad(res, 'Your role cannot delete this event.', 403);
  if (!['draft', 'pending'].includes(e.status)) return bad(res, 'Published events are cancelled, not deleted, so the history is kept.', 409);
  db.prepare('DELETE FROM cal_events WHERE id=?').run(e.id);
  audit(req, e.id, 'deleted', e.title);
  res.json({ deleted: true });
});

router.get('/events/:id/history', (req, res) => {
  const e = loadEvent(req, res); if (!e) return;
  if (!policy.canAuthor(role(req), e.category) && !policy.canPublish(role(req), e.category)) return bad(res, 'Your role cannot view this history.', 403);
  res.json(db.prepare('SELECT * FROM cal_audit WHERE event_id=? ORDER BY id DESC').all(e.id));
});

// Calendar file for Google Calendar, Outlook or a phone: published events the person may see.
const ics = (s) => String(s || '').replace(/\\/g, '\\\\').replace(/[,;]/g, (m) => `\\${m}`).replace(/\r?\n/g, '\\n');
const compact = (d) => d.replace(/-/g, '');
router.get('/export.ics', (req, res) => {
  const rows = visibleEvents(req).filter((e) => e.status === 'published');
  const lines = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Matara University//Calendar//EN', 'CALSCALE:GREGORIAN'];
  for (const e of rows) {
    const next = new Date(`${e.end_date}T00:00:00Z`); next.setUTCDate(next.getUTCDate() + 1);
    lines.push('BEGIN:VEVENT', `UID:cal-${e.id}@matara.ac.ke`, `DTSTAMP:${new Date().toISOString().replace(/[-:]|\.\d{3}/g, '')}`,
      `DTSTART;VALUE=DATE:${compact(e.start_date)}`, `DTEND;VALUE=DATE:${compact(next.toISOString().slice(0, 10))}`, `SUMMARY:${ics(e.title)}`);
    if (e.location) lines.push(`LOCATION:${ics(e.location)}`);
    if (e.description || e.start_time) lines.push(`DESCRIPTION:${ics([e.start_time && `Time: ${e.start_time}${e.end_time ? `-${e.end_time}` : ''}`, e.description].filter(Boolean).join(' | '))}`);
    lines.push('END:VEVENT');
  }
  lines.push('END:VCALENDAR');
  res.setHeader('Content-Type', 'text/calendar; charset=utf-8');
  res.setHeader('Content-Disposition', 'attachment; filename="matara-university-calendar.ics"');
  res.send(lines.join('\r\n'));
});

module.exports = router;
