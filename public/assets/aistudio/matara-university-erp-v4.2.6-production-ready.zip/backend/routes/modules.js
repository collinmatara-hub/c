const express = require('express');
const { db } = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');
const router = express.Router();
router.use(requireAuth);
const admin = requireRole('admin');
const staff = requireRole('admin','teacher','librarian','nurse','accounts','ict','staff');
const librarian = requireRole('admin','librarian');
const nurse = requireRole('admin','nurse');
const accounts = requireRole('admin','accounts');
const operations = requireRole('admin','teacher','librarian','nurse','accounts','ict','staff');
const safe = (fn,res)=>{try{res.json(fn())}catch(e){console.error(e);res.status(400).json({error:e.message})}};
const resources={
 departments:{table:'departments',fields:['name','description','head_id']},
 subjects:{table:'subjects',fields:['name','code']},
 parents:{table:'parents',fields:['name','phone','email','address']},
 staff:{table:'staff',fields:['employee_no','name','position','department_id','phone','email','employment_date','status']},
 years:{table:'academic_years',fields:['name','start_date','end_date','active']},
 terms:{table:'terms',fields:['academic_year_id','name','start_date','end_date','active']},
 timetable:{table:'timetables',fields:['class_id','subject_id','teacher_id','day','start_time','end_time','room']},
 assignments:{table:'assignments',fields:['teacher_id','class_id','subject_id','title','description','due_date','max_marks']},
 materials:{table:'learning_materials',fields:['teacher_id','class_id','subject_id','title','description','file_path','url']},
 books:{table:'books',fields:['title','author','isbn','category','copies','available']},
 medical:{table:'medical_visits',fields:['student_id','visit_date','complaint','treatment','officer','notes']},
 transport:{table:'transport_assignments',fields:['student_id','route_id','vehicle_id','driver_id']},
 boarding:{table:'boarding_assignments',fields:['student_id','house_id','dormitory_id','room','bed']},
 vehicles:{table:'vehicles',fields:['registration','model','capacity','status']},
 drivers:{table:'drivers',fields:['name','phone','license_no']},
 routes:{table:'routes',fields:['name','pickup_points']},
 houses:{table:'houses',fields:['name']},
 dormitories:{table:'dormitories',fields:['name','capacity']},
 discipline:{table:'discipline_incidents',fields:['student_id','incident_date','type','description','action_taken','reported_by','resolved']},
 events:{table:'events',fields:['title','description','event_date','start_time','end_time','audience']},
 expenses:{table:'expenses',fields:['category','description','amount','expense_date','payment_method','reference']},
 income:{table:'income',fields:['source','description','amount','income_date','reference']},
 grading:{table:'grading_scales',fields:['min_score','max_score','grade','points','comment']},
 admissions:{table:'admissions',fields:['application_no','applicant_name','guardian_name','guardian_phone','class_applied','status','notes']},
 alumni:{table:'alumni',fields:['student_id','graduation_year','destination','phone','email','notes']},
 curriculum:{table:'curriculum',fields:['class_id','subject_id','strand','substrand','learning_outcome']},
 lessonplans:{table:'lesson_plans',fields:['teacher_id','class_id','subject_id','topic','lesson_date','objectives','activities','status']},
 examschedules:{table:'exam_schedules',fields:['exam_id','class_id','subject_id','exam_date','start_time','end_time','room','seat_plan']},
 studentleave:{table:'student_leaves',fields:['student_id','start_date','end_date','reason','status','approved_by']},
 feestructures:{table:'fee_structures',fields:['name','class_id','term','amount','due_date','category']},
 scholarships:{table:'scholarships',fields:['student_id','name','type','amount','percentage','start_term','end_term','status']},
 staffleave:{table:'staff_leave',fields:['staff_id','leave_type','start_date','end_date','reason','status','approved_by']},
 payroll:{table:'payroll',fields:['staff_id','month','basic','allowances','deductions','net','status']},
 appraisals:{table:'appraisals',fields:['staff_id','review_date','score','comments','reviewer_id']},
 inventory:{table:'inventory_items',fields:['name','category','quantity','reorder_level','unit','location','supplier']},
 assets:{table:'assets',fields:['asset_no','name','category','purchase_date','cost','location','assigned_to','status']},
 vendors:{table:'vendors',fields:['name','phone','email','address','tax_no']},
 procurement:{table:'procurement_requisitions',fields:['requested_by','item','quantity','estimated_cost','vendor_id','status','approved_by']},
 templates:{table:'message_templates',fields:['name','channel','subject','body','active']},
 documents:{table:'documents',fields:['title','category','file_path','owner_id']},
 branches:{table:'branches',fields:['name','code','address','phone','active']},
};
Object.entries(resources).forEach(([key,cfg])=>{
  router.get('/'+key, (req,res)=>{
    const allowed = key==='books' ? ['admin','librarian']
      : key==='medical' ? ['admin','nurse']
      : ['admin','teacher','librarian','nurse','accounts','ict','staff'];
    if(!allowed.includes(req.user.role)) return res.status(403).json({error:'You do not have permission to view this module.'});
    safe(()=>db.prepare(`SELECT * FROM ${cfg.table} ORDER BY id DESC`).all(),res);
  });

  router.post('/'+key, (req,res)=>{
    const allowed = key==='books' ? ['admin','librarian']
      : key==='medical' ? ['admin','nurse']
      : key==='expenses'||key==='income' ? ['admin','accounts']
      : ['admin','teacher'];
    if(!allowed.includes(req.user.role)) return res.status(403).json({error:'You do not have permission to manage this module.'});
    safe(()=>{
      const f=cfg.fields.filter(x=>req.body[x]!==undefined);
      if(!f.length) throw Error('No valid fields supplied');
      const vals=f.map(x=>req.body[x]);
      const q=db.prepare(`INSERT INTO ${cfg.table} (${f.join(',')}) VALUES (${f.map(()=>'?').join(',')})`).run(...vals);
      return {id:q.lastInsertRowid};
    },res);
  });

  router.put('/'+key+'/:id', (req,res)=>{
    const allowed = key==='books' ? ['admin','librarian']
      : key==='medical' ? ['admin','nurse']
      : key==='expenses'||key==='income' ? ['admin','accounts']
      : ['admin','teacher'];
    if(!allowed.includes(req.user.role)) return res.status(403).json({error:'You do not have permission to manage this module.'});
    safe(()=>{
      const f=cfg.fields.filter(x=>req.body[x]!==undefined);
      if(!f.length) throw Error('No valid fields supplied');
      const vals=f.map(x=>req.body[x]);
      db.prepare(`UPDATE ${cfg.table} SET ${f.map(x=>x+'=?').join(',')} WHERE id=?`).run(...vals,req.params.id);
      return {success:true};
    },res);
  });

  router.delete('/'+key+'/:id',admin,(req,res)=>safe(()=>{db.prepare(`DELETE FROM ${cfg.table} WHERE id=?`).run(req.params.id);return {success:true}},res));
});

router.get('/parents/me',(req,res)=>safe(()=>{const p=db.prepare('SELECT * FROM parents WHERE user_id=?').get(req.user.id);if(!p)return [];return db.prepare(`SELECT s.id,s.name,s.adm_no,c.name class_name,c.stream FROM parent_students ps JOIN students s ON s.id=ps.student_id LEFT JOIN classes c ON c.id=s.class_id WHERE ps.parent_id=?`).all(p.id)},res));
router.get('/lookups',(req,res)=>safe(()=>({students:db.prepare('SELECT id,name,adm_no FROM students WHERE status=\'active\' ORDER BY name').all(),classes:db.prepare('SELECT id,name,stream FROM classes ORDER BY name').all(),teachers:db.prepare('SELECT id,name FROM teachers ORDER BY name').all(),subjects:db.prepare('SELECT id,name,code FROM subjects ORDER BY name').all(),users:db.prepare('SELECT id,name,email,role FROM users ORDER BY name').all()}),res));
router.get('/library/borrowings',(req,res)=>safe(()=>db.prepare(`SELECT b.*,bk.title,s.name student_name FROM borrowings b JOIN books bk ON bk.id=b.book_id JOIN students s ON s.id=b.student_id ORDER BY b.id DESC`).all(),res));
router.post('/library/borrow',requireRole('admin','teacher','librarian'),(req,res)=>safe(()=>{const {book_id,student_id,due_date}=req.body;const b=db.prepare('SELECT available FROM books WHERE id=?').get(book_id);if(!b||b.available<1)throw Error('Book is not available');const x=db.prepare('INSERT INTO borrowings(book_id,student_id,due_date) VALUES(?,?,?)').run(book_id,student_id,due_date);db.prepare('UPDATE books SET available=available-1 WHERE id=?').run(book_id);return {id:x.lastInsertRowid}},res));
router.post('/library/return/:id',requireRole('admin','teacher','librarian'),(req,res)=>safe(()=>{const x=db.prepare('SELECT book_id FROM borrowings WHERE id=? AND returned_at IS NULL').get(req.params.id);if(!x)throw Error('Borrowing not found or already returned');db.prepare("UPDATE borrowings SET returned_at=datetime('now') WHERE id=?").run(req.params.id);db.prepare('UPDATE books SET available=available+1 WHERE id=?').run(x.book_id);return {success:true}},res));
router.get('/reports/finance', requireRole('admin','vice_chancellor','deputy_vc','finance_director','finance_officer','auditor','registrar'),(req,res)=>safe(()=>({payments:db.prepare('SELECT COALESCE(SUM(amount_paid),0) total FROM fees').get().total,expenses:db.prepare('SELECT COALESCE(SUM(amount),0) total FROM expenses').get().total,income:db.prepare('SELECT COALESCE(SUM(amount),0) total FROM income').get().total,outstanding:db.prepare('SELECT COALESCE(SUM(amount_due-amount_paid),0) total FROM fees').get().total}),res));
router.get('/reports/academic', requireRole('admin','vice_chancellor','deputy_vc','registrar','dean','deputy_dean','hod','lecturer','senior_lecturer','professor','academic_staff','examination_officer','exam_board','auditor'),(req,res)=>safe(()=>db.prepare(`SELECT sub.name subject,ROUND(AVG(g.score),1) average,MAX(g.score) highest,MIN(g.score) lowest,COUNT(*) entries FROM grades g JOIN subjects sub ON sub.id=g.subject_id GROUP BY sub.id ORDER BY average DESC`).all(),res));
router.get('/reports/attendance', requireRole('admin','vice_chancellor','deputy_vc','registrar','dean','deputy_dean','hod','lecturer','senior_lecturer','professor','academic_staff','examination_officer','auditor'),(req,res)=>safe(()=>db.prepare(`SELECT date,SUM(status='present') present,SUM(status='absent') absent,SUM(status='late') late FROM attendance GROUP BY date ORDER BY date DESC LIMIT 30`).all(),res));
router.get('/notifications',(req,res)=>safe(()=>db.prepare('SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC').all(req.user.id),res));
router.post('/notifications/read/:id',(req,res)=>safe(()=>{db.prepare("UPDATE notifications SET read_at=datetime('now') WHERE id=? AND user_id=?").run(req.params.id,req.user.id);return {success:true}},res));
router.get('/messages',(req,res)=>safe(()=>db.prepare(`SELECT m.*,u.name sender_name FROM messages m JOIN users u ON u.id=m.sender_id WHERE m.sender_id=? OR m.recipient_id=? ORDER BY m.created_at DESC`).all(req.user.id,req.user.id),res));
router.post('/messages',requireRole('admin','teacher','staff','accounts','librarian','nurse','ict'),(req,res)=>safe(()=>{const {recipient_id,subject,body}=req.body;if(!recipient_id||!body)throw Error('recipient_id and body required');const x=db.prepare('INSERT INTO messages(sender_id,recipient_id,subject,body) VALUES(?,?,?,?)').run(req.user.id,recipient_id,subject||'',body);db.prepare('INSERT INTO notifications(user_id,title,body) VALUES(?,?,?)').run(recipient_id,'New message',subject||body);return {id:x.lastInsertRowid}},res));
router.get('/audit',requireRole('admin','ict'),(req,res)=>safe(()=>db.prepare(`SELECT a.*,u.name user_name FROM audit_logs a LEFT JOIN users u ON u.id=a.user_id ORDER BY a.created_at DESC LIMIT 200`).all(),res));
router.get('/settings',requireRole('admin','ict'),(req,res)=>safe(()=>db.prepare('SELECT * FROM system_settings ORDER BY key').all(),res));
router.put('/settings/:key',admin,(req,res)=>safe(()=>{db.prepare('INSERT INTO system_settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').run(req.params.key,String(req.body.value??''));return {success:true}},res));
module.exports=router;
