// routes/assessments.js
// For teachers and admins: create CATs, enter marks, and decide supplementary applications.

const express = require('express');
const { db } = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');
const { gradeLockGuard, noAssistantMarks } = require('../lib/gradeLock');
const { currentTerm, passMark } = require('../lib/academic');

const router = express.Router();
router.use(requireAuth, requireRole('admin', 'teacher', 'lecturer', 'senior_lecturer', 'professor', 'academic_staff', 'examination_officer', 'exam_board'));

const BROAD_ASSESSMENT_ROLES = new Set(['admin', 'examination_officer', 'exam_board']);
function canManageSubject(req, subjectId) {
  if (BROAD_ASSESSMENT_ROLES.has(String(req.user.role || '').toLowerCase())) return true;
  const teacher = db.prepare('SELECT id FROM teachers WHERE user_id = ?').get(req.user.id);
  if (!teacher) return false;
  return Boolean(db.prepare(`SELECT id FROM timetables WHERE teacher_id=? AND subject_id=? UNION SELECT id FROM assignments WHERE teacher_id=? AND subject_id=? LIMIT 1`)
    .get(teacher.id, subjectId, teacher.id, subjectId));
}

function toId(value) {
  const number = parseInt(value, 10);
  return Number.isNaN(number) ? null : number;
}

function fail(res, message, status = 400) {
  return res.status(status).json({ error: message });
}

function audit(req, action, entityId, details) {
  db.prepare(
    'INSERT INTO audit_logs (user_id, action, entity, entity_id, details) VALUES (?, ?, ?, ?, ?)'
  ).run(req.user.id, action, 'assessment', entityId, details);
}

// Everything the marks page needs to start
router.get('/setup', (req, res) => {
  res.json({
    term: currentTerm(),
    passMark: passMark(),
    exams: db.prepare('SELECT id, name, kind, term, year FROM exams ORDER BY id DESC').all(),
    units: BROAD_ASSESSMENT_ROLES.has(String(req.user.role || '').toLowerCase())
      ? db.prepare('SELECT id, name, code FROM subjects ORDER BY name').all()
      : db.prepare(`SELECT DISTINCT s.id,s.name,s.code FROM subjects s WHERE s.id IN (SELECT subject_id FROM timetables WHERE teacher_id=(SELECT id FROM teachers WHERE user_id=?)) OR s.id IN (SELECT subject_id FROM assignments WHERE teacher_id=(SELECT id FROM teachers WHERE user_id=?)) ORDER BY s.name`).all(req.user.id, req.user.id),
  });
});

router.post('/exams', noAssistantMarks, gradeLockGuard, (req, res) => {
  const name = String(req.body.name || '').trim();
  const kind = req.body.kind === 'Exam' ? 'Exam' : 'CAT';
  if (!name) return fail(res, 'Give the assessment a name, for example "CAT 1".');

  // "Term 2 2026" -> term "Term 2", year "2026"
  const now = currentTerm().match(/^(.*)\s+(\d{4})$/);
  const term = String(req.body.term || (now ? now[1] : currentTerm())).trim();
  const year = String(req.body.year || (now ? now[2] : new Date().getFullYear())).trim();

  const result = db.prepare('INSERT INTO exams (name, kind, term, year) VALUES (?, ?, ?, ?)').run(name, kind, term, year);
  res.status(201).json({ id: Number(result.lastInsertRowid) });
});

// The students to enter marks for: those registered for the unit, plus anyone who already has a mark
router.get('/roster', (req, res) => {
  const examId = toId(req.query.exam_id);
  const subjectId = toId(req.query.subject_id);
  const exam = examId && db.prepare('SELECT * FROM exams WHERE id = ?').get(examId);
  const unit = subjectId && db.prepare('SELECT * FROM subjects WHERE id = ?').get(subjectId);
  if (!exam || !unit) return fail(res, 'Choose an assessment and a unit.');
  if (!canManageSubject(req, subjectId)) return fail(res, 'You are not assigned to assess this unit.', 403);

  const label = `${exam.term} ${exam.year}`;
  const ids = new Set();
  db.prepare('SELECT student_id FROM unit_registrations WHERE subject_id = ? AND term = ?')
    .all(subjectId, label).forEach((r) => ids.add(r.student_id));
  const scores = new Map();
  db.prepare('SELECT student_id, score FROM grades WHERE exam_id = ? AND subject_id = ?')
    .all(examId, subjectId).forEach((g) => { ids.add(g.student_id); scores.set(g.student_id, g.score); });

  // Never broaden an empty unit roster to every active student. An empty roster
  // means registrations need to be corrected by the authorized academic office.
  const fallback = false;

  const students = db.prepare(`
    SELECT s.id AS student_id, s.name, s.adm_no, c.name || ' ' || c.stream AS class_name
    FROM students s LEFT JOIN classes c ON c.id = s.class_id
    WHERE s.id IN (${[...ids].map(() => '?').join(',') || 'NULL'})
    ORDER BY s.name
  `).all(...ids).map((s) => ({ ...s, score: scores.has(s.student_id) ? scores.get(s.student_id) : null }));

  res.json({ exam, unit, fallback, students });
});

// Save marks. A blank score clears an existing mark.
// Teaching assistants and lab technicians may only enter assessment (CAT / practical) marks,
// never final exam marks.
function assistantMarksGuard(req, res, next) {
  const actual = req.user.actual_role;
  if (actual === 'teaching_assistant' || actual === 'lab_technician') {
    const exam = db.prepare('SELECT kind FROM exams WHERE id = ?').get(toId(req.body.exam_id));
    if (exam && exam.kind === 'Exam') {
      return res.status(403).json({ error: 'Teaching assistants and lab technicians cannot submit or change final exam marks.' });
    }
  }
  next();
}

router.put('/marks', gradeLockGuard, assistantMarksGuard, (req, res) => {
  const examId = toId(req.body.exam_id);
  const subjectId = toId(req.body.subject_id);
  const marks = Array.isArray(req.body.marks) ? req.body.marks : [];
  if (!examId || !subjectId) return fail(res, 'Choose an assessment and a unit.');
  if (!db.prepare('SELECT id FROM exams WHERE id = ?').get(examId)) return fail(res, 'Assessment not found.', 404);
  if (!db.prepare('SELECT id FROM subjects WHERE id = ?').get(subjectId)) return fail(res, 'Unit not found.', 404);

  // Check everything first so a typo does not leave half the marks saved
  const entries = [];
  for (const mark of marks) {
    const studentId = toId(mark.student_id);
    if (!studentId) continue;
    if (mark.score === '' || mark.score === null || mark.score === undefined) {
      entries.push({ studentId, score: null });
      continue;
    }
    const score = Number(mark.score);
    if (!Number.isFinite(score) || score < 0 || score > 100) {
      return fail(res, 'Marks must be numbers from 0 to 100.');
    }
    const alreadyMarked = db.prepare('SELECT id FROM grades WHERE exam_id=? AND subject_id=? AND student_id=?').get(examId, subjectId, studentId);
    const registered = db.prepare('SELECT id FROM unit_registrations WHERE student_id=? AND subject_id=? AND term=?').get(studentId, subjectId, `${db.prepare('SELECT term FROM exams WHERE id=?').get(examId).term} ${db.prepare('SELECT year FROM exams WHERE id=?').get(examId).year}`);
    if (!registered && !alreadyMarked) return fail(res, `Student ${studentId} is not registered for this unit and assessment period.`, 403);
    entries.push({ studentId, score });
  }

  let saved = 0;
  let cleared = 0;
  db.exec('BEGIN');
  try {
    entries.forEach(({ studentId, score }) => {
      const existing = db.prepare(
        'SELECT id FROM grades WHERE exam_id = ? AND student_id = ? AND subject_id = ?'
      ).get(examId, studentId, subjectId);

      if (score === null) {
        if (existing) { db.prepare('DELETE FROM grades WHERE id = ?').run(existing.id); cleared += 1; }
      } else if (existing) {
        db.prepare('UPDATE grades SET score = ? WHERE id = ?').run(score, existing.id);
        saved += 1;
      } else {
        db.prepare('INSERT INTO grades (exam_id, student_id, subject_id, score) VALUES (?, ?, ?, ?)')
          .run(examId, studentId, subjectId, score);
        saved += 1;
      }
    });
    db.exec('COMMIT');
  } catch (err) {
    db.exec('ROLLBACK');
    console.error(err);
    return fail(res, 'Could not save the marks.', 500);
  }

  audit(req, 'enter_marks', examId, `Saved ${saved} mark(s), cleared ${cleared}, unit ${subjectId}`);
  res.json({ saved, cleared });
});

// ---------- supplementary applications ----------

router.get('/supplementary', (req, res) => {
  if (!BROAD_ASSESSMENT_ROLES.has(String(req.user.role || '').toLowerCase())) return fail(res, 'Examination-office access required.', 403);
  res.json(db.prepare(`
    SELECT sr.id, sr.reason, sr.status, sr.staff_comment, sr.created_at, sr.decided_at,
      s.name AS student_name, s.adm_no, c.name || ' ' || c.stream AS class_name,
      sub.name AS unit_name, sub.code, e.name AS exam_name, e.kind, e.term, e.year, g.score
    FROM supplementary_requests sr
    JOIN students s ON s.id = sr.student_id
    LEFT JOIN classes c ON c.id = s.class_id
    JOIN subjects sub ON sub.id = sr.subject_id
    JOIN exams e ON e.id = sr.exam_id
    LEFT JOIN grades g ON g.student_id = sr.student_id AND g.subject_id = sr.subject_id AND g.exam_id = sr.exam_id
    ORDER BY CASE sr.status WHEN 'pending' THEN 0 ELSE 1 END, sr.created_at DESC
  `).all());
});

router.put('/supplementary/:id', (req, res) => {
  if (!BROAD_ASSESSMENT_ROLES.has(String(req.user.role || '').toLowerCase())) return fail(res, 'Examination-office access required.', 403);
  const id = toId(req.params.id);
  const status = req.body.status;
  if (!['approved', 'rejected'].includes(status)) return fail(res, 'Choose approve or reject.');

  const application = db.prepare('SELECT id, status FROM supplementary_requests WHERE id = ?').get(id);
  if (!application) return fail(res, 'Application not found.', 404);
  if (application.status !== 'pending') return fail(res, 'This application has already been decided.');

  const comment = String(req.body.comment || '').trim() || null;
  db.prepare(`
    UPDATE supplementary_requests
    SET status = ?, staff_comment = ?, decided_at = datetime('now'), decided_by = ?
    WHERE id = ?
  `).run(status, comment, req.user.id, id);

  audit(req, `supplementary_${status}`, id, `Supplementary application ${id} ${status}`);
  res.json({ success: true });
});

module.exports = router;
