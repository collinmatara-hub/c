'use strict';

// Shared ERP-backed LMS workflows. These endpoints use the existing users,
// teachers, students, classes, subjects, registrations and assessment tables.
const express = require('express');
const { db } = require('../db');
const { currentTerm } = require('../lib/academic');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();
router.use(requireAuth);

const LECTURER_ROLES = new Set(['teacher', 'lecturer', 'senior_lecturer', 'professor', 'academic_staff']);
const idOf = (v) => Number.isSafeInteger(Number(v)) && Number(v) > 0 ? Number(v) : null;
const clean = (v, max = 5000) => String(v ?? '').trim().slice(0, max);
const sendError = (res, status, error) => res.status(status).json({ error });

function lecturerFor(req) {
  if (!LECTURER_ROLES.has(String(req.user.role || '').toLowerCase())) return null;
  return db.prepare('SELECT id, user_id, staff_no, name FROM teachers WHERE user_id = ?').get(req.user.id) || null;
}
function studentFor(req) {
  if (String(req.user.role || '').toLowerCase() !== 'student') return null;
  return db.prepare("SELECT id, user_id, adm_no, name, class_id, status FROM students WHERE user_id = ? AND lower(COALESCE(status,'active')) = 'active'").get(req.user.id) || null;
}
function audit(req, action, entity, entityId, details = '') {
  db.prepare('INSERT INTO audit_logs(user_id,action,entity,entity_id,details) VALUES(?,?,?,?,?)')
    .run(req.user.id, action, entity, entityId || null, details.slice(0, 1000));
}
function lecturerOwnsAssignment(teacherId, assignmentId) {
  return db.prepare('SELECT * FROM assignments WHERE id = ? AND teacher_id = ?').get(assignmentId, teacherId) || null;
}
function studentCanAccessAssignment(student, assignment) {
  if (assignment.class_id && Number(assignment.class_id) === Number(student.class_id)) return true;
  if (!assignment.subject_id) return false;
  return Boolean(db.prepare('SELECT id FROM unit_registrations WHERE student_id = ? AND subject_id = ? LIMIT 1')
    .get(student.id, assignment.subject_id));
}

router.get('/lecturer/dashboard', (req, res) => {
  const teacher = lecturerFor(req);
  if (!teacher) return sendError(res, 403, 'An authorized lecturer account linked to a teaching record is required.');
  try {
    const classes = db.prepare(`
      SELECT c.*, COUNT(DISTINCT s.id) AS student_count
      FROM classes c LEFT JOIN students s ON s.class_id = c.id
      WHERE c.class_teacher_id = ? OR c.id IN (
        SELECT class_id FROM timetables WHERE teacher_id = ?
        UNION SELECT class_id FROM assignments WHERE teacher_id = ?
      ) GROUP BY c.id ORDER BY c.name, c.stream
    `).all(teacher.id, teacher.id, teacher.id);
    const students = db.prepare(`
      SELECT DISTINCT s.id, s.name, s.adm_no, c.name AS class_name, c.stream
      FROM students s LEFT JOIN classes c ON c.id = s.class_id
      WHERE c.class_teacher_id = ? OR c.id IN (
        SELECT class_id FROM timetables WHERE teacher_id = ?
        UNION SELECT class_id FROM assignments WHERE teacher_id = ?
      ) OR s.id IN (
        SELECT r.student_id FROM unit_registrations r WHERE r.subject_id IN (
          SELECT subject_id FROM timetables WHERE teacher_id = ?
          UNION SELECT subject_id FROM assignments WHERE teacher_id = ?
        )
      ) ORDER BY s.name
    `).all(teacher.id, teacher.id, teacher.id, teacher.id, teacher.id);
    const timetable = db.prepare(`SELECT t.*, c.name AS class_name, c.stream, s.name AS subject_name, s.code AS subject_code, r.name AS room_name
      FROM timetables t LEFT JOIN classes c ON c.id=t.class_id LEFT JOIN subjects s ON s.id=t.subject_id LEFT JOIN rooms r ON r.name=t.room
      WHERE t.teacher_id=? ORDER BY CASE t.day WHEN 'Monday' THEN 1 WHEN 'Tuesday' THEN 2 WHEN 'Wednesday' THEN 3 WHEN 'Thursday' THEN 4 WHEN 'Friday' THEN 5 ELSE 6 END,t.start_time`).all(teacher.id);
    const assignments = db.prepare(`SELECT a.*, c.name AS class_name, c.stream, s.name AS subject_name, s.code AS subject_code,
        (SELECT COUNT(*) FROM assignment_submissions sub WHERE sub.assignment_id=a.id) AS submission_count,
        (SELECT COUNT(*) FROM assignment_submissions sub WHERE sub.assignment_id=a.id AND sub.marks IS NULL) AS pending_marking
      FROM assignments a LEFT JOIN classes c ON c.id=a.class_id LEFT JOIN subjects s ON s.id=a.subject_id
      WHERE a.teacher_id=? ORDER BY a.due_date`).all(teacher.id);
    res.json({ teacher, classes, students, timetable, assignments,
      pendingGrading: assignments.reduce((n, a) => n + Number(a.pending_marking || 0), 0) });
  } catch (error) {
    console.error('[lms:lecturer-dashboard]', error.message);
    sendError(res, 500, 'Could not load lecturer LMS data.');
  }
});

router.get('/lecturer/assignments', (req, res) => {
  const teacher = lecturerFor(req);
  if (!teacher) return sendError(res, 403, 'Lecturer access required.');
  const rows = db.prepare(`SELECT a.*,c.name AS class_name,c.stream,s.name AS subject_name,s.code AS subject_code,
      (SELECT COUNT(*) FROM assignment_submissions x WHERE x.assignment_id=a.id) AS submission_count,
      (SELECT COUNT(*) FROM assignment_submissions x WHERE x.assignment_id=a.id AND x.marks IS NULL) AS pending_marking
    FROM assignments a LEFT JOIN classes c ON c.id=a.class_id LEFT JOIN subjects s ON s.id=a.subject_id
    WHERE a.teacher_id=? ORDER BY a.due_date,a.id DESC`).all(teacher.id);
  res.json({ items: rows });
});

router.post('/lecturer/assignments', (req, res) => {
  const teacher = lecturerFor(req);
  if (!teacher) return sendError(res, 403, 'Lecturer access required.');
  const title = clean(req.body.title, 180), description = clean(req.body.description, 10000);
  const classId = idOf(req.body.class_id), subjectId = idOf(req.body.subject_id);
  const maxMarks = Number(req.body.max_marks ?? 100);
  const dueDate = req.body.due_date ? clean(req.body.due_date, 40) : null;
  if (!title || !classId || !subjectId) return sendError(res, 400, 'Title, assigned class and subject are required.');
  if (!Number.isFinite(maxMarks) || maxMarks <= 0 || maxMarks > 10000) return sendError(res, 400, 'Maximum marks must be greater than zero and no more than 10,000.');
  if (dueDate && Number.isNaN(Date.parse(dueDate))) return sendError(res, 400, 'Due date must be a valid date/time.');
  const authorized = db.prepare(`SELECT c.id FROM classes c WHERE c.id=? AND (
      EXISTS(SELECT 1 FROM timetables t WHERE t.teacher_id=? AND t.class_id=c.id AND t.subject_id=?)
      OR EXISTS(SELECT 1 FROM assignments a WHERE a.teacher_id=? AND a.class_id=c.id AND a.subject_id=?)
      OR (c.class_teacher_id=? AND EXISTS(SELECT 1 FROM timetables t WHERE t.teacher_id=? AND t.subject_id=?))
    )`).get(classId, teacher.id, subjectId, teacher.id, subjectId, teacher.id, teacher.id, subjectId);
  if (!authorized || !db.prepare('SELECT id FROM subjects WHERE id=?').get(subjectId)) return sendError(res, 403, 'You may create assignments only for a class and subject you are assigned to teach.');
  try {
    const create = db.transaction(() => {
      const result = db.prepare('INSERT INTO assignments(teacher_id,class_id,subject_id,title,description,due_date,max_marks) VALUES(?,?,?,?,?,?,?)')
        .run(teacher.id, classId, subjectId, title, description || null, dueDate, maxMarks);
      const id = Number(result.lastInsertRowid);
      audit(req, 'lms_assignment_created', 'assignments', id, `class=${classId}; subject=${subjectId}`);
      return id;
    });
    const id = create();
    res.status(201).json({ id, status: 'created' });
  } catch (error) {
    console.error('[lms:create-assignment]', error.message);
    sendError(res, 400, 'Assignment could not be created with the supplied class and subject.');
  }
});

router.get('/lecturer/assignments/:id/submissions', (req, res) => {
  const teacher = lecturerFor(req), assignmentId = idOf(req.params.id);
  if (!teacher) return sendError(res, 403, 'Lecturer access required.');
  const assignment = assignmentId && lecturerOwnsAssignment(teacher.id, assignmentId);
  if (!assignment) return sendError(res, 404, 'Assignment not found in your teaching allocation.');
  const rows = db.prepare(`SELECT sub.id,sub.assignment_id,sub.student_id,sub.content,sub.file_path,sub.submitted_at,sub.marks,sub.feedback,sub.status,
      s.name AS student_name,s.adm_no FROM assignment_submissions sub JOIN students s ON s.id=sub.student_id
      WHERE sub.assignment_id=? ORDER BY sub.submitted_at DESC,sub.id DESC`).all(assignment.id);
  res.json({ assignment, items: rows });
});

router.put('/lecturer/submissions/:id/mark', (req, res) => {
  const teacher = lecturerFor(req), submissionId = idOf(req.params.id);
  if (!teacher) return sendError(res, 403, 'Lecturer access required.');
  const submission = submissionId && db.prepare(`SELECT sub.*,a.teacher_id,a.max_marks FROM assignment_submissions sub JOIN assignments a ON a.id=sub.assignment_id WHERE sub.id=?`).get(submissionId);
  if (!submission || Number(submission.teacher_id) !== Number(teacher.id)) return sendError(res, 404, 'Submission not found in your teaching allocation.');
  const marks = Number(req.body.marks), feedback = clean(req.body.feedback, 10000);
  if (!Number.isFinite(marks) || marks < 0 || marks > Number(submission.max_marks || 100)) return sendError(res, 400, `Marks must be between 0 and ${Number(submission.max_marks || 100)}.`);
  try {
    const tx = db.transaction(() => {
      db.prepare(`INSERT INTO assignment_submission_history(submission_id,assignment_id,student_id,content,file_path,submitted_at,marks,feedback,status,changed_by,change_type)
        VALUES(?,?,?,?,?,?,?,?,?,?,?)`).run(submission.id, submission.assignment_id, submission.student_id, submission.content, submission.file_path,
        submission.submitted_at, submission.marks, submission.feedback, submission.status, req.user.id, 'marked');
      db.prepare("UPDATE assignment_submissions SET marks=?,feedback=?,status='graded' WHERE id=?").run(marks, feedback || null, submission.id);
      audit(req, 'lms_submission_marked', 'assignment_submissions', submission.id, `assignment=${submission.assignment_id}; marks=${marks}`);
    });
    tx();
    res.json({ success: true, status: 'graded' });
  } catch (error) {
    console.error('[lms:mark-submission]', error.message);
    sendError(res, 500, 'Could not save marking. No changes were committed.');
  }
});

router.put('/lecturer/submissions/:id/release', (req, res) => {
  const teacher = lecturerFor(req), submissionId = idOf(req.params.id);
  if (!teacher) return sendError(res, 403, 'Lecturer access required.');
  const submission = submissionId && db.prepare(`SELECT sub.id,sub.assignment_id,sub.marks,sub.status,a.teacher_id FROM assignment_submissions sub JOIN assignments a ON a.id=sub.assignment_id WHERE sub.id=?`).get(submissionId);
  if (!submission || Number(submission.teacher_id) !== Number(teacher.id)) return sendError(res, 404, 'Submission not found in your teaching allocation.');
  if (submission.marks === null || submission.marks === undefined || !['graded','released'].includes(String(submission.status))) return sendError(res, 409, 'Save valid marks before releasing feedback.');
  if (submission.status === 'released') return res.json({ success: true, status: 'released' });
  try {
    const tx = db.transaction(() => {
      db.prepare("UPDATE assignment_submissions SET status='released' WHERE id=?").run(submission.id);
      audit(req, 'lms_feedback_released', 'assignment_submissions', submission.id, `assignment=${submission.assignment_id}`);
    });
    tx();
    res.json({ success: true, status: 'released' });
  } catch (error) {
    console.error('[lms:release-feedback]', error.message);
    sendError(res, 500, 'Feedback could not be released.');
  }
});

router.get('/student/dashboard', (req, res) => {
  const student = studentFor(req);
  if (!student) return sendError(res, 403, 'An active student account linked to a student record is required.');
  const term = currentTerm();
  const units = db.prepare(`SELECT DISTINCT sub.id AS unit_id,sub.name AS unit_name,sub.code AS unit_code,te.name AS lecturer
    FROM unit_registrations r JOIN subjects sub ON sub.id=r.subject_id
    LEFT JOIN timetables t ON t.subject_id=sub.id LEFT JOIN teachers te ON te.id=t.teacher_id
    WHERE r.student_id=? AND (? IS NULL OR r.term=?) ORDER BY sub.name`).all(student.id, term, term);
  const assignments = db.prepare(`SELECT DISTINCT a.id,a.title,a.description,a.due_date,a.max_marks,s.name AS unit_name,s.code AS unit_code,
      x.id AS submission_id,x.submitted_at,CASE WHEN x.status='released' THEN x.marks ELSE NULL END AS marks,CASE WHEN x.status='released' THEN x.feedback ELSE NULL END AS feedback,x.status AS submission_status
    FROM assignments a LEFT JOIN subjects s ON s.id=a.subject_id
    LEFT JOIN assignment_submissions x ON x.assignment_id=a.id AND x.student_id=?
    WHERE (a.class_id=? OR a.subject_id IN (SELECT subject_id FROM unit_registrations WHERE student_id=?))
    ORDER BY a.due_date,a.id DESC`).all(student.id, student.class_id || 0, student.id);
  const upcoming = assignments.filter(a => a.due_date && Date.parse(a.due_date) >= Date.now() && !a.submission_id).length;
  const releasedResults = db.prepare(`SELECT ur.total_mark,ur.grade,ur.grade_points,ur.credits,ur.status FROM university_results ur WHERE ur.student_id=? AND ur.status='published'`).all(student.id);
  const credits = releasedResults.reduce((n, r) => n + Number(r.credits || 0), 0);
  const gpa = credits ? Number((releasedResults.reduce((n, r) => n + Number(r.grade_points || 0) * Number(r.credits || 0), 0) / credits).toFixed(2)) : null;
  const deadlines = assignments.filter(a => a.due_date && !a.submission_id).map(a => ({ ...a, type: 'assignment', date: a.due_date }));
  res.json({ student: { id: student.id, name: student.name, adm_no: student.adm_no }, term, units, unitsRegistered: units.length,
    assignments, pendingAssignments: upcoming, gpa, deadlines, upcomingExams: null,
    note: 'GPA uses published university results only; exam counts are unavailable where no linked examination schedule exists.' });
});

router.get('/student/assignments', (req, res) => {
  const student = studentFor(req);
  if (!student) return sendError(res, 403, 'Student access required.');
  const items = db.prepare(`SELECT a.id,a.title,a.description,a.due_date,a.max_marks,s.name AS unit_name,s.code AS unit_code,
      x.id AS submission_id,x.content AS submitted_content,x.file_path,x.submitted_at,CASE WHEN x.status='released' THEN x.marks ELSE NULL END AS marks,CASE WHEN x.status='released' THEN x.feedback ELSE NULL END AS feedback,x.status AS submission_status
    FROM assignments a LEFT JOIN subjects s ON s.id=a.subject_id
    LEFT JOIN assignment_submissions x ON x.assignment_id=a.id AND x.student_id=?
    WHERE (a.class_id=? OR a.subject_id IN (SELECT subject_id FROM unit_registrations WHERE student_id=?))
    ORDER BY a.due_date,a.id DESC`).all(student.id, student.class_id || 0, student.id);
  res.json({ items });
});

router.post('/student/assignments/:id/submit', (req, res) => {
  const student = studentFor(req), assignmentId = idOf(req.params.id), content = clean(req.body.content, 50000);
  if (!student) return sendError(res, 403, 'Student access required.');
  if (!assignmentId || !content) return sendError(res, 400, 'Assignment and submission text are required.');
  const assignment = db.prepare('SELECT * FROM assignments WHERE id=?').get(assignmentId);
  if (!assignment || !studentCanAccessAssignment(student, assignment)) return sendError(res, 404, 'Assignment not found for your registered classes or units.');
  if (assignment.due_date && Date.parse(assignment.due_date) < Date.now()) return sendError(res, 409, 'The submission deadline has passed. Contact the lecturer if an extension is approved.');
  const existing = db.prepare('SELECT * FROM assignment_submissions WHERE assignment_id=? AND student_id=?').get(assignmentId, student.id);
  try {
    const tx = db.transaction(() => {
      if (existing) db.prepare(`INSERT INTO assignment_submission_history(submission_id,assignment_id,student_id,content,file_path,submitted_at,marks,feedback,status,changed_by,change_type)
        VALUES(?,?,?,?,?,?,?,?,?,?,?)`).run(existing.id, existing.assignment_id, existing.student_id, existing.content, existing.file_path, existing.submitted_at,
          existing.marks, existing.feedback, existing.status, req.user.id, 'resubmitted');
      if (existing) db.prepare("UPDATE assignment_submissions SET content=?,submitted_at=datetime('now'),marks=NULL,feedback=NULL,status='submitted' WHERE id=?").run(content, existing.id);
      else db.prepare("INSERT INTO assignment_submissions(assignment_id,student_id,content,status) VALUES(?,?,?,'submitted')").run(assignmentId, student.id, content);
      audit(req, existing ? 'lms_assignment_resubmitted' : 'lms_assignment_submitted', 'assignments', assignmentId, `student_id=${student.id}`);
    });
    tx();
    res.status(existing ? 200 : 201).json({ success: true, status: 'submitted', submitted_at: new Date().toISOString() });
  } catch (error) {
    console.error('[lms:student-submit]', error.message);
    sendError(res, 500, 'Submission could not be saved. Please try again.');
  }
});

module.exports = router;
