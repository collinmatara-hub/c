const express = require('express');
const { db } = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');
const multer = require('multer');
const fs = require('fs');
const path = require('path');

const router = express.Router();
router.use(requireAuth);

const adminOnly = requireRole('admin');
const staffRoles = requireRole('admin','vice_chancellor','deputy_vc','registrar','deputy_registrar','dean','deputy_dean','hod','lecturer','senior_lecturer','professor','academic_staff','non_academic_staff','admissions_officer','examination_officer','exam_board','finance_director','finance_officer','hr_director','hr_officer','procurement_officer','stores_officer','asset_officer','facilities_officer','transport_officer','security_officer','medical_officer','counselor','research_officer','student_affairs_officer','accommodation_officer','auditor','teacher','accounts','librarian','nurse','ict','staff');
const uploadDir=path.join(__dirname,'..','uploads');fs.mkdirSync(uploadDir,{recursive:true});
const storage=multer.diskStorage({destination:uploadDir,filename:(req,file,cb)=>{const safe=path.basename(file.originalname).replace(/[^a-zA-Z0-9._-]/g,'_');cb(null,`${Date.now()}-${safe}`)}});
const upload=multer({storage,limits:{fileSize:5*1024*1024},fileFilter:(req,file,cb)=>{const allowed=['application/pdf','image/png','image/jpeg','image/webp','application/vnd.openxmlformats-officedocument.wordprocessingml.document','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','text/csv'];cb(null,allowed.includes(file.mimetype));}});


function safe(fn, res) {
  try { return res.json(fn()); }
  catch (e) { console.error(e); return res.status(400).json({ error: e.message }); }
}
function audit(req, action, entity, entityId, details='') {
  try { db.prepare('INSERT INTO audit_logs(user_id,action,entity,entity_id,details) VALUES(?,?,?,?,?)').run(req.user.id, action, entity, entityId || null, details); } catch (_) {}
}
function ownStudentId(req) {
  return db.prepare('SELECT id FROM students WHERE user_id=?').get(req.user.id)?.id || null;
}
function parentStudentIds(req) {
  const parent = db.prepare('SELECT id FROM parents WHERE user_id=?').get(req.user.id);
  if (!parent) return [];
  return db.prepare('SELECT student_id FROM parent_students WHERE parent_id=?').all(parent.id).map(x=>x.student_id);
}
const UNIVERSITY_STUDENT_VIEW_ROLES = new Set([
  'admin','vice_chancellor','deputy_vc','registrar','deputy_registrar',
  'finance_director','finance_officer','hr_director','hr_officer',
  'dean','deputy_dean','hod','lecturer','senior_lecturer','professor','academic_staff',
  'non_academic_staff','admissions_officer','examination_officer','exam_board',
  'procurement_officer','stores_officer','asset_officer','facilities_officer',
  'transport_officer','security_officer','medical_officer','counselor',
  'research_officer','student_affairs_officer','accommodation_officer','auditor',
  'teacher','accounts','librarian','nurse','ict','staff'
]);
function canViewStudent(req, studentId) {
  if (UNIVERSITY_STUDENT_VIEW_ROLES.has(req.user.role)) return true;
  if (req.user.role === 'student') return ownStudentId(req) === Number(studentId);
  if (req.user.role === 'parent') return parentStudentIds(req).includes(Number(studentId));
  return false;
}

function buildStudentProfile(id) {

    const student=db.prepare(`SELECT s.*, c.name class_name,c.stream class_stream, t.name class_teacher,
      sp.nationality,sp.previous_school,sp.admission_date,sp.nemis_upi,sp.house_name,sp.residence,sp.photo_url,sp.religion,sp.birth_certificate_no,sp.special_needs
      FROM students s LEFT JOIN classes c ON c.id=s.class_id LEFT JOIN teachers t ON t.id=c.class_teacher_id
      LEFT JOIN student_profiles sp ON sp.student_id=s.id WHERE s.id=?`).get(id);
    if(!student) throw Error('Student not found');
    const guardians=db.prepare('SELECT * FROM student_contacts WHERE student_id=? ORDER BY is_primary DESC,id').all(id);
    const medical=db.prepare('SELECT * FROM medical_profiles WHERE student_id=?').get(id)||{};
    const visits=db.prepare('SELECT * FROM medical_visits WHERE student_id=? ORDER BY visit_date DESC,id DESC').all(id);
    const fees=db.prepare(`SELECT f.*, COALESCE((SELECT SUM(p.amount) FROM fee_payments p WHERE p.fee_id=f.id AND p.status='posted'),0) allocated_paid
      FROM fees f WHERE f.student_id=? ORDER BY f.term DESC,f.id DESC`).all(id);
    const payments=db.prepare("SELECT * FROM fee_payments WHERE student_id=? AND status='posted' ORDER BY payment_date DESC,id DESC").all(id);
    const grades=db.prepare(`SELECT g.*,e.name exam_name,e.term,e.year,e.kind,s.name subject_name,s.code subject_code
      FROM grades g JOIN exams e ON e.id=g.exam_id JOIN subjects s ON s.id=g.subject_id WHERE g.student_id=? ORDER BY e.year DESC,e.term DESC,e.id DESC,s.name`).all(id);
    const attendance=db.prepare('SELECT * FROM attendance WHERE student_id=? ORDER BY date DESC LIMIT 300').all(id);
    const discipline=db.prepare('SELECT * FROM discipline_incidents WHERE student_id=? ORDER BY incident_date DESC,id DESC').all(id);
    const assignments=db.prepare(`SELECT a.*,s.name subject_name,asub.marks submission_marks,asub.status submission_status,asub.submitted_at
      FROM assignments a LEFT JOIN subjects s ON s.id=a.subject_id LEFT JOIN assignment_submissions asub ON asub.assignment_id=a.id AND asub.student_id=? WHERE a.class_id=? ORDER BY a.due_date DESC`).all(id,student.class_id||0);
    const books=db.prepare(`SELECT b.title,b.author,br.borrowed_at,br.due_date,br.returned_at,br.fine FROM borrowings br JOIN books b ON b.id=br.book_id WHERE br.student_id=? ORDER BY br.borrowed_at DESC`).all(id);
    const transport=db.prepare(`SELECT ta.*,r.name route_name,v.registration vehicle_registration,d.name driver_name,d.phone driver_phone FROM transport_assignments ta LEFT JOIN routes r ON r.id=ta.route_id LEFT JOIN vehicles v ON v.id=ta.vehicle_id LEFT JOIN drivers d ON d.id=ta.driver_id WHERE ta.student_id=?`).all(id);
    const boarding=db.prepare(`SELECT ba.*,h.name house_name,d.name dormitory_name FROM boarding_assignments ba LEFT JOIN houses h ON h.id=ba.house_id LEFT JOIN dormitories d ON d.id=ba.dormitory_id WHERE ba.student_id=?`).get(id)||null;
    const documents=db.prepare('SELECT * FROM student_documents WHERE student_id=? ORDER BY created_at DESC,id DESC').all(id);
    const timeline=db.prepare('SELECT * FROM student_timeline WHERE student_id=? ORDER BY event_date DESC,id DESC LIMIT 500').all(id);
    const transfers=db.prepare('SELECT * FROM student_transfers WHERE student_id=? ORDER BY transfer_date DESC,id DESC').all(id);
    const leaves=db.prepare('SELECT * FROM student_leaves WHERE student_id=? ORDER BY start_date DESC,id DESC').all(id);
    const scholarships=db.prepare('SELECT * FROM scholarships WHERE student_id=? ORDER BY id DESC').all(id);
    const examinations=db.prepare(`SELECT os.title,os.duration_minutes,es.score,es.status,es.submitted_at,es.started_at FROM exam_submissions es JOIN online_exams os ON os.id=es.exam_id WHERE es.student_id=? ORDER BY es.id DESC`).all(id);
    const communications=db.prepare(`SELECT m.*,u.name sender_name FROM messages m LEFT JOIN users u ON u.id=m.sender_id WHERE m.recipient_id=? ORDER BY m.created_at DESC LIMIT 100`).all(student.user_id||0);
    const totalDue=fees.reduce((a,x)=>a+Number(x.amount_due||0),0);
    const totalPaid=fees.reduce((a,x)=>a+Number(x.allocated_paid||x.amount_paid||0),0);
    const present=attendance.filter(x=>x.status==='present').length, absent=attendance.filter(x=>x.status==='absent').length, late=attendance.filter(x=>x.status==='late').length;
    return {student,guardians,medical,visits,fees,payments,grades,attendance,discipline,assignments,books,transport,boarding,documents,timeline,transfers,leaves,scholarships,examinations,communications,summary:{totalDue,totalPaid,balance:totalDue-totalPaid,attendance:{present,absent,late,total:attendance.length,percentage:attendance.length?Math.round(present/attendance.length*10000)/100:0}}};

}

router.put('/students/:id/profile',adminOnly,(req,res)=>{
  const id=Number(req.params.id); const allowed=['nationality','previous_school','admission_date','nemis_upi','house_name','residence','photo_url','religion','birth_certificate_no','special_needs'];
  const baseFields=['name','gender','dob','class_id','guardian_name','guardian_phone','status'];
  const base=baseFields.filter(k=>req.body[k]!==undefined); const prof=allowed.filter(k=>req.body[k]!==undefined);
  try { const tx=db.transaction(()=>{if(base.length)db.prepare(`UPDATE students SET ${base.map(k=>`${k}=?`).join(',')} WHERE id=?`).run(...base.map(k=>req.body[k]),id); if(prof.length){const existing=db.prepare('SELECT student_id FROM student_profiles WHERE student_id=?').get(id);if(existing)db.prepare(`UPDATE student_profiles SET ${prof.map(k=>`${k}=?`).join(',')},updated_at=datetime('now') WHERE student_id=?`).run(...prof.map(k=>req.body[k]),id);else db.prepare(`INSERT INTO student_profiles(student_id,${prof.join(',')}) VALUES(?,${prof.map(()=>'?').join(',')})`).run(id,...prof.map(k=>req.body[k]));}});tx();audit(req,'UPDATE_STUDENT_PROFILE','students',id);res.json({success:true}); } catch(e){res.status(400).json({error:e.message});}
});
router.post('/students/:id/contacts',adminOnly,(req,res)=>safe(()=>{const f=['contact_type','relationship','name','phone','email','address','is_primary','emergency_priority'];if(!req.body.name)throw Error('Contact name is required');const x=db.prepare(`INSERT INTO student_contacts(student_id,${f.join(',')}) VALUES(?,${f.map(()=>'?').join(',')})`).run(req.params.id,...f.map(k=>req.body[k]??(k==='is_primary'||k==='emergency_priority'?0:'')));return {id:x.lastInsertRowid};},res));
router.post('/students/:id/documents',adminOnly,(req,res)=>safe(()=>{if(!req.body.title)throw Error('Document title is required');const x=db.prepare('INSERT INTO student_documents(student_id,title,category,file_path,document_no,issue_date,expiry_date,notes) VALUES(?,?,?,?,?,?,?,?)').run(req.params.id,req.body.title,req.body.category||'',req.body.file_path||'',req.body.document_no||'',req.body.issue_date||null,req.body.expiry_date||null,req.body.notes||'');return {id:x.lastInsertRowid};},res));
router.post('/students/:id/timeline',adminOnly,(req,res)=>safe(()=>{const x=db.prepare('INSERT INTO student_timeline(student_id,event_date,event_type,title,details,actor_id) VALUES(?,?,?,?,?,?)').run(req.params.id,req.body.event_date||new Date().toISOString().slice(0,10),req.body.event_type||'General',req.body.title||'Timeline event',req.body.details||'',req.user.id);return {id:x.lastInsertRowid};},res));
router.post('/students/:id/withdraw',adminOnly,(req,res)=>safe(()=>{db.prepare("UPDATE students SET status='withdrawn',withdrawal_date=?,withdrawal_reason=? WHERE id=?").run(req.body.date||new Date().toISOString().slice(0,10),req.body.reason||'',req.params.id);db.prepare('INSERT INTO student_status_history(student_id,status,effective_date,reason,changed_by) VALUES(?,?,?,?,?)').run(req.params.id,'withdrawn',req.body.date||new Date().toISOString().slice(0,10),req.body.reason||'',req.user.id);return {success:true};},res));
router.post('/students/:id/graduate',adminOnly,(req,res)=>safe(()=>{const date=req.body.date||new Date().toISOString().slice(0,10);db.prepare("UPDATE students SET status='graduated',graduation_date=? WHERE id=?").run(date,req.params.id);db.prepare('INSERT INTO student_status_history(student_id,status,effective_date,reason,changed_by) VALUES(?,?,?,?,?)').run(req.params.id,'graduated',date,req.body.reason||'Graduation',req.user.id);const x=db.prepare('INSERT INTO student_certificates(student_id,certificate_type,certificate_no,issue_date,issued_by,notes) VALUES(?,?,?,?,?,?)').run(req.params.id,'Graduation',req.body.certificate_no||'',date,req.user.id,req.body.notes||'');return {success:true,certificate_id:x.lastInsertRowid};},res));
router.post('/students/:id/transfer',adminOnly,(req,res)=>safe(()=>{const date=req.body.transfer_date||new Date().toISOString().slice(0,10);const x=db.prepare('INSERT INTO student_transfers(student_id,transfer_date,from_school,to_school,from_class,to_class,reason,status) VALUES(?,?,?,?,?,?,?,?)').run(req.params.id,date,req.body.from_school||'Matara University',req.body.to_school||'',req.body.from_class||'',req.body.to_class||'',req.body.reason||'','completed');db.prepare("UPDATE students SET status='transferred',withdrawal_date=?,withdrawal_reason=? WHERE id=?").run(date,`Transferred to ${req.body.to_school||'another institution'}`,req.params.id);return {id:x.lastInsertRowid};},res));

router.post('/files/upload',requireRole('admin','teacher','accounts','librarian','nurse','ict','staff'),upload.single('file'),(req,res)=>{if(!req.file)return res.status(400).json({error:'A supported file is required.'});audit(req,'UPLOAD_FILE','documents',null,req.file.filename);res.status(201).json({success:true,filename:req.file.filename,path:`/uploads/${req.file.filename}`,size:req.file.size,mime:req.file.mimetype});});
router.get('/files/:filename',requireRole('admin','teacher','accounts','librarian','nurse','ict','staff'),(req,res)=>{const filename=path.basename(req.params.filename);const file=path.join(uploadDir,filename);if(filename!==req.params.filename||!fs.existsSync(file))return res.status(404).json({error:'File not found'});res.sendFile(file);});

router.get('/students/:id/profile',staffRoles,(req,res)=>{
  const id=Number(req.params.id);
  if(!canViewStudent(req,id)) return res.status(403).json({error:'You are not authorised to view this student profile.'});
  try { const result=buildStudentProfile(id); if(req.user.role==='teacher'){result.medical={};result.visits=[];result.discipline=[];} if(req.user.role==='accounts'){result.medical={};result.visits=[];result.discipline=[];result.assignments=[];} res.json(result); } catch(e) { console.error(e); res.status(400).json({error:e.message}); }
});

router.get('/student/me/profile',(req,res)=>{
  const id=ownStudentId(req);
  if(!id) return res.status(404).json({error:'No student record is linked to this account.'});
  try { res.json(buildStudentProfile(id)); } catch(e) { console.error(e); res.status(400).json({error:e.message}); }
});

router.get('/teacher/me/dashboard',(req,res)=>{
  if(!['teacher','lecturer','senior_lecturer','professor','academic_staff','admin'].includes(req.user.role))return res.status(403).json({error:'Lecturer access required'});
  safe(()=>{const t=req.user.role==='admin'?db.prepare('SELECT * FROM teachers ORDER BY id LIMIT 1').get():db.prepare('SELECT * FROM teachers WHERE user_id=?').get(req.user.id);if(!t)return {teacher:null,classes:[],students:[],timetable:[],assignments:[],exams:[]};const classes=db.prepare(`SELECT c.*,COUNT(s.id) student_count FROM classes c LEFT JOIN students s ON s.class_id=c.id WHERE c.class_teacher_id=? GROUP BY c.id`).all(t.id);const students=db.prepare(`SELECT s.id,s.name,s.adm_no,c.name class_name,c.stream FROM students s LEFT JOIN classes c ON c.id=s.class_id WHERE c.class_teacher_id=? ORDER BY s.name`).all(t.id);const timetable=db.prepare(`SELECT tt.*,c.name class_name,c.stream,sub.name subject_name,sub.code subject_code,r.name room_name FROM timetables tt LEFT JOIN classes c ON c.id=tt.class_id LEFT JOIN subjects sub ON sub.id=tt.subject_id LEFT JOIN rooms r ON r.name=tt.room WHERE tt.teacher_id=? ORDER BY CASE tt.day WHEN 'Monday' THEN 1 WHEN 'Tuesday' THEN 2 WHEN 'Wednesday' THEN 3 WHEN 'Thursday' THEN 4 WHEN 'Friday' THEN 5 ELSE 6 END,tt.start_time`).all(t.id);const assignments=db.prepare(`SELECT a.*,c.name class_name,sub.name subject_name FROM assignments a LEFT JOIN classes c ON c.id=a.class_id LEFT JOIN subjects sub ON sub.id=a.subject_id WHERE a.teacher_id=? ORDER BY a.due_date DESC`).all(t.id);return {teacher:t,classes,students,timetable,assignments};},res);
});
router.get('/timetable/conflicts',adminOnly,(req,res)=>safe(()=>{const rows=db.prepare(`SELECT a.id a_id,b.id b_id,a.teacher_id,a.class_id,a.room,a.day,a.start_time,a.end_time FROM timetables a JOIN timetables b ON b.id>a.id AND b.day=a.day AND a.start_time<b.end_time AND b.start_time<a.end_time WHERE a.teacher_id=b.teacher_id OR a.class_id=b.class_id OR (a.room IS NOT NULL AND a.room<>'' AND a.room=b.room) ORDER BY a.day,a.start_time`).all();return rows;},res));
router.post('/timetable',adminOnly,(req,res)=>safe(()=>{const {class_id,subject_id,teacher_id,day,start_time,end_time,room}=req.body;if(!class_id||!subject_id||!teacher_id||!day||!start_time||!end_time)throw Error('Class, subject, teacher, day and time are required');const conflict=db.prepare(`SELECT id FROM timetables WHERE day=? AND start_time<? AND end_time>? AND (teacher_id=? OR class_id=? OR (?<>'' AND room=?)) LIMIT 1`).get(day,end_time,start_time,teacher_id,class_id,room||'',room||'');if(conflict)throw Error('Timetable conflict detected for the teacher, class or room.');const x=db.prepare('INSERT INTO timetables(class_id,subject_id,teacher_id,day,start_time,end_time,room) VALUES(?,?,?,?,?,?,?)').run(class_id,subject_id,teacher_id,day,start_time,end_time,room||'');return {id:x.lastInsertRowid};},res));

router.get('/parent/me/family',(req,res)=>{
  if(req.user.role!=='parent'&&req.user.role!=='admin')return res.status(403).json({error:'Parent access required'});
  safe(()=>{
    const p=req.user.role==='admin' ? null : db.prepare('SELECT * FROM parents WHERE user_id=?').get(req.user.id);
    const ids=p?parentStudentIds(req):db.prepare('SELECT id FROM students ORDER BY id LIMIT 20').all().map(x=>x.id);
    return ids.map(id=>{const profile=buildStudentProfile(id);return {student:profile.student,summary:profile.summary,grades:profile.grades.slice(0,12),attendance:profile.summary.attendance,fees:profile.fees.slice(0,12),assignments:profile.assignments.slice(0,10),examinations:profile.examinations.slice(0,10),timeline:profile.timeline.slice(0,10)}});
  },res);
});

router.get('/student/me/fee-statement',(req,res)=>{
  const id=ownStudentId(req); if(!id) return res.status(404).json({error:'No student record is linked to this account.'});
  safe(()=>{
    const student=db.prepare(`SELECT s.*,c.name class_name,c.stream class_stream FROM students s LEFT JOIN classes c ON c.id=s.class_id WHERE s.id=?`).get(id);
    const rows=db.prepare(`SELECT f.id,f.term,f.amount_due,f.amount_paid,f.due_date,COALESCE(SUM(CASE WHEN p.status='posted' THEN p.amount ELSE 0 END),0) allocated_paid
      FROM fees f LEFT JOIN fee_payments p ON p.fee_id=f.id WHERE f.student_id=? GROUP BY f.id ORDER BY f.id`).all(id);
    const payments=db.prepare("SELECT * FROM fee_payments WHERE student_id=? AND status='posted' ORDER BY payment_date DESC,id DESC").all(id);
    const totalDue=rows.reduce((a,r)=>a+Number(r.amount_due||0),0), totalPaid=rows.reduce((a,r)=>a+Number(r.allocated_paid||r.amount_paid||0),0);
    return {student,rows,payments,totalDue,totalPaid,balance:totalDue-totalPaid,currency:'KES'};
  },res);
});

router.get('/student/me/report-card',(req,res)=>{
  const id=ownStudentId(req); if(!id) return res.status(404).json({error:'No student record is linked to this account.'});
  safe(()=>buildReportCard(id,req.query.exam_id),res);
});

router.post('/admissions/:id/enroll',adminOnly,(req,res)=>safe(()=>{
  const a=db.prepare('SELECT * FROM admissions WHERE id=?').get(req.params.id);
  if(!a)throw Error('Admission application not found');
  if(a.status==='enrolled')throw Error('Application is already enrolled');
  const classId=req.body.class_id||null; const admNo=req.body.adm_no||a.application_no||`MU-${Date.now()}`;
  const tx=db.transaction(()=>{
    const s=db.prepare(`INSERT INTO students(adm_no,name,class_id,guardian_name,guardian_phone,status,enrolled_on,admission_date) VALUES(?,?,?,?,?,?,date('now'),date('now'))`).run(admNo,a.applicant_name,classId,a.guardian_name,a.guardian_phone,'active');
    db.prepare('INSERT INTO student_profiles(student_id,admission_date,previous_school) VALUES(?,?,?)').run(s.lastInsertRowid,new Date().toISOString().slice(0,10),req.body.previous_school||'');
    db.prepare("UPDATE admissions SET status='enrolled' WHERE id=?").run(a.id);
    db.prepare('INSERT INTO student_timeline(student_id,event_date,event_type,title,details,actor_id) VALUES(?,?,?,?,?,?)').run(s.lastInsertRowid,new Date().toISOString().slice(0,10),'Admission','Enrollment completed',`Application ${a.application_no||a.id}`,req.user.id);
    return s.lastInsertRowid;
  });
  return {student_id:tx(),success:true};
},res));
router.put('/report-card-comments',requireRole('admin','teacher'),(req,res)=>safe(()=>{const x=db.prepare(`INSERT INTO report_card_comments(student_id,exam_id,teacher_comment,class_teacher_comment,principal_comment,promotion_status,updated_by) VALUES(?,?,?,?,?,?,?) ON CONFLICT(student_id,exam_id) DO UPDATE SET teacher_comment=excluded.teacher_comment,class_teacher_comment=excluded.class_teacher_comment,principal_comment=excluded.principal_comment,promotion_status=excluded.promotion_status,updated_by=excluded.updated_by,updated_at=datetime('now')`).run(req.body.student_id,req.body.exam_id||null,req.body.teacher_comment||'',req.body.class_teacher_comment||'',req.body.principal_comment||'',req.body.promotion_status||'',req.user.id);return {id:x.lastInsertRowid};},res));

router.get('/gradebook/config',adminOnly,(req,res)=>safe(()=>({components:db.prepare('SELECT * FROM assessment_components WHERE active=1 ORDER BY id').all(),scales:db.prepare('SELECT * FROM grading_scales ORDER BY min_score DESC').all()}),res));
router.post('/gradebook/components',adminOnly,(req,res)=>safe(()=>{if(!req.body.name||req.body.weight==null)throw Error('Name and weight are required');const x=db.prepare('INSERT INTO assessment_components(name,kind,weight,term,academic_year,max_marks) VALUES(?,?,?,?,?,?)').run(req.body.name,req.body.kind||req.body.name,Number(req.body.weight),req.body.term||'',req.body.academic_year||'',Number(req.body.max_marks||100));return {id:x.lastInsertRowid};},res));
router.post('/gradebook/entry',requireRole('admin','teacher'),(req,res)=>safe(()=>{const x=db.prepare(`INSERT INTO gradebook_entries(student_id,subject_id,component_id,exam_id,marks,comment,entered_by) VALUES(?,?,?,?,?,?,?) ON CONFLICT(student_id,subject_id,component_id,exam_id) DO UPDATE SET marks=excluded.marks,comment=excluded.comment,entered_by=excluded.entered_by,entered_at=datetime('now')`).run(req.body.student_id,req.body.subject_id,req.body.component_id,req.body.exam_id||null,req.body.marks===''?null:Number(req.body.marks),req.body.comment||'',req.user.id);return {id:x.lastInsertRowid};},res));
router.get('/gradebook/:studentId',requireAuth,(req,res)=>safe(()=>db.prepare(`SELECT ge.*,s.name subject_name,ac.name component_name,ac.kind,ac.weight,e.name exam_name FROM gradebook_entries ge JOIN subjects s ON s.id=ge.subject_id JOIN assessment_components ac ON ac.id=ge.component_id LEFT JOIN exams e ON e.id=ge.exam_id WHERE ge.student_id=? ORDER BY ge.id DESC`).all(req.params.studentId),res));

router.get('/report-cards/bulk',adminOnly,(req,res)=>safe(()=>{const students=db.prepare(`SELECT s.id,s.name,s.adm_no,c.name class_name,c.stream FROM students s LEFT JOIN classes c ON c.id=s.class_id WHERE s.status='active' ORDER BY c.name,c.stream,s.name`).all();return students.map(st=>buildReportCard(st.id,req.query.exam_id));},res));

router.get('/reports/:type', adminOnly, (req,res)=>safe(()=>buildReport(req.params.type,req.query),res));
router.get('/reports/:type/csv', adminOnly, (req,res)=>{
  try { const data=buildReport(req.params.type,req.query); const rows=data.rows||[]; const headers=rows.length?Object.keys(rows[0]):[]; const esc=v=>`"${String(v??'').replaceAll('"','""')}"`; const csv=[headers.map(esc).join(','),...rows.map(r=>headers.map(h=>esc(r[h])).join(','))].join('\n'); audit(req,'REPORT_EXPORT_CSV',req.params.type,null,`${rows.length} rows`); res.setHeader('Content-Type','text/csv'); res.setHeader('Content-Disposition',`attachment; filename=matara-${req.params.type}-report.csv`); res.send(csv); } catch(e){res.status(400).json({error:e.message});}
});

router.get('/search', staffRoles, (req,res)=>safe(()=>{
  const q=String(req.query.q||'').trim(); if(q.length<2)return {students:[],parents:[],teachers:[],staff:[],programs:[],classes:[],books:[],receipts:[]}; const like=`%${q}%`;
  return {
    students:db.prepare('SELECT id,adm_no,name,status FROM students WHERE name LIKE ? OR adm_no LIKE ? ORDER BY name LIMIT 20').all(like,like),
    parents:db.prepare('SELECT id,name,phone,email FROM parents WHERE name LIKE ? OR phone LIKE ? OR email LIKE ? ORDER BY name LIMIT 20').all(like,like,like),
    teachers:db.prepare('SELECT id,staff_no,name,phone FROM teachers WHERE name LIKE ? OR staff_no LIKE ? ORDER BY name LIMIT 20').all(like,like),
    staff:db.prepare(`SELECT id,name,email,position,employee_no,status FROM staff WHERE name LIKE ? OR email LIKE ? OR position LIKE ? OR employee_no LIKE ? ORDER BY name LIMIT 20`).all(like,like,like,like),
    programs:db.prepare(`SELECT p.id,p.name,p.code,p.award,ud.name department FROM programs p LEFT JOIN university_departments ud ON ud.id=p.department_id WHERE p.name LIKE ? OR p.code LIKE ? OR p.award LIKE ? ORDER BY p.name LIMIT 20`).all(like,like,like),
    classes:db.prepare('SELECT id,name,stream FROM classes WHERE name LIKE ? OR stream LIKE ? ORDER BY name LIMIT 20').all(like,like),
    books:db.prepare('SELECT id,title,author,isbn FROM books WHERE title LIKE ? OR author LIKE ? OR isbn LIKE ? ORDER BY title LIMIT 20').all(like,like,like),
    receipts:db.prepare('SELECT id,receipt_no,student_id,amount,method,reference FROM receipts WHERE receipt_no LIKE ? OR reference LIKE ? ORDER BY id DESC LIMIT 20').all(like,like)
  };
},res));

router.get('/settings', adminOnly, (req,res)=>safe(()=>db.prepare('SELECT * FROM system_settings ORDER BY key').all(),res));
router.put('/settings', adminOnly, (req,res)=>safe(()=>{
  const entries=Array.isArray(req.body)?req.body:Object.entries(req.body||{}).map(([key,value])=>({key,value}));
  for(const x of entries){if(!x.key)continue;db.prepare('INSERT INTO system_settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').run(x.key,String(x.value??''));}
  audit(req,'UPDATE_SCHOOL_SETTINGS','system_settings',null,`${entries.length} settings`);return {success:true};
},res));

function buildReport(type, query) {
  const from=query.from||'2000-01-01', to=query.to||'2999-12-31';
  if(type==='finance'){
    const rows=db.prepare(`SELECT s.adm_no,s.name,COALESCE(SUM(f.amount_due),0) billed,COALESCE(SUM(f.amount_paid),0) legacy_paid,COALESCE((SELECT SUM(p.amount) FROM fee_payments p WHERE p.student_id=s.id AND p.status='posted'),0) paid FROM students s LEFT JOIN fees f ON f.student_id=s.id GROUP BY s.id ORDER BY s.name`).all();
    rows.forEach(r=>{r.balance=Number(r.billed)-Math.max(Number(r.paid),Number(r.legacy_paid));});
    return {title:'Finance Report',columns:['adm_no','name','billed','paid','balance'],rows};
  }
  if(type==='academic'){
    const rows=db.prepare(`SELECT s.adm_no,s.name,sub.name subject,e.name exam,e.term,e.year,e.kind,g.score FROM grades g JOIN students s ON s.id=g.student_id JOIN subjects sub ON sub.id=g.subject_id JOIN exams e ON e.id=g.exam_id WHERE COALESCE(e.year,'') BETWEEN ? AND ? ORDER BY s.name,sub.name,e.id DESC`).all(String(query.from||'0000'),String(query.to||'9999'));
    return {title:'Academic Report',columns:['adm_no','name','subject','exam','term','year','kind','score'],rows};
  }
  if(type==='attendance'){
    const rows=db.prepare(`SELECT s.adm_no,s.name,COUNT(a.id) total,SUM(CASE WHEN a.status='present' THEN 1 ELSE 0 END) present,SUM(CASE WHEN a.status='absent' THEN 1 ELSE 0 END) absent,SUM(CASE WHEN a.status='late' THEN 1 ELSE 0 END) late FROM students s LEFT JOIN attendance a ON a.student_id=s.id AND a.date BETWEEN ? AND ? GROUP BY s.id ORDER BY s.name`).all(from,to);
    rows.forEach(r=>r.percentage=r.total?Math.round(Number(r.present)/Number(r.total)*10000)/100:0); return {title:'Attendance Report',columns:['adm_no','name','total','present','absent','late','percentage'],rows};
  }
  if(type==='admissions') return {title:'Admissions Report',columns:['application_no','applicant_name','guardian_name','guardian_phone','class_applied','status','created_at'],rows:db.prepare('SELECT application_no,applicant_name,guardian_name,guardian_phone,class_applied,status,created_at FROM admissions ORDER BY id DESC').all()};
  if(type==='discipline') return {title:'Discipline Report',columns:['adm_no','name','incident_date','type','description','action_taken','reported_by','resolved'],rows:db.prepare(`SELECT s.adm_no,s.name,d.incident_date,d.type,d.description,d.action_taken,d.reported_by,d.resolved FROM discipline_incidents d JOIN students s ON s.id=d.student_id ORDER BY d.incident_date DESC`).all()};
  if(type==='library') return {title:'Library Report',columns:['title','student','borrowed_at','due_date','returned_at','fine'],rows:db.prepare(`SELECT b.title,s.name student,br.borrowed_at,br.due_date,br.returned_at,br.fine FROM borrowings br JOIN books b ON b.id=br.book_id JOIN students s ON s.id=br.student_id ORDER BY br.borrowed_at DESC`).all()};
  if(type==='payroll') return {title:'Payroll Report',columns:['employee_no','name','month','basic','allowances','deductions','net','status'],rows:db.prepare(`SELECT st.employee_no,st.name,p.month,p.basic,p.allowances,p.deductions,p.net,p.status FROM payroll p JOIN staff st ON st.id=p.staff_id ORDER BY p.month DESC,st.name`).all()};
  if(type==='inventory') return {title:'Inventory Report',columns:['name','category','quantity','reorder_level','unit','location','supplier'],rows:db.prepare('SELECT name,category,quantity,reorder_level,unit,location,supplier FROM inventory_items ORDER BY name').all()};
  if(type==='transport') return {title:'Transport Report',columns:['student','route','vehicle','driver'],rows:db.prepare(`SELECT s.name student,r.name route,v.registration vehicle,d.name driver FROM transport_assignments ta JOIN students s ON s.id=ta.student_id LEFT JOIN routes r ON r.id=ta.route_id LEFT JOIN vehicles v ON v.id=ta.vehicle_id LEFT JOIN drivers d ON d.id=ta.driver_id ORDER BY s.name`).all()};
  if(type==='boarding') return {title:'Boarding Report',columns:['student','house','dormitory','room','bed'],rows:db.prepare(`SELECT s.name student,h.name house,d.name dormitory,ba.room,ba.bed FROM boarding_assignments ba JOIN students s ON s.id=ba.student_id LEFT JOIN houses h ON h.id=ba.house_id LEFT JOIN dormitories d ON d.id=ba.dormitory_id ORDER BY s.name`).all()};
  if(type==='staff') return {title:'Staff Report',columns:['employee_no','name','position','department','phone','email','employment_date','status'],rows:db.prepare(`SELECT st.employee_no,st.name,st.position,d.name department,st.phone,st.email,st.employment_date,st.status FROM staff st LEFT JOIN departments d ON d.id=st.department_id ORDER BY st.name`).all()};
  throw Error('Unknown report type');
}

function buildReportCard(studentId, examId) {
  const student=db.prepare(`SELECT s.*,c.name class_name,c.stream class_stream FROM students s LEFT JOIN classes c ON c.id=s.class_id WHERE s.id=?`).get(studentId);
  const rows=db.prepare(`SELECT sub.name subject,sub.code,e.name exam,e.term,e.year,e.kind,g.score FROM grades g JOIN subjects sub ON sub.id=g.subject_id JOIN exams e ON e.id=g.exam_id WHERE g.student_id=? ${examId?'AND e.id=?':''} ORDER BY e.year DESC,e.term DESC,sub.name`).all(...(examId?[studentId,examId]:[studentId]));
  const scales=db.prepare('SELECT * FROM grading_scales ORDER BY min_score DESC').all();
  rows.forEach(r=>{const s=Number(r.score);const x=scales.find(g=>s>=Number(g.min_score)&&s<=Number(g.max_score));r.grade=x?.grade||'';r.points=x?.points??'';r.comment=x?.comment||'';});
  const att=db.prepare(`SELECT COUNT(*) total,SUM(status='present') present,SUM(status='absent') absent,SUM(status='late') late FROM attendance WHERE student_id=?`).get(studentId)||{};
  const comment=db.prepare('SELECT * FROM report_card_comments WHERE student_id=? AND (? IS NULL OR exam_id=?) ORDER BY id DESC LIMIT 1').get(studentId,examId||null,examId||null)||{};
  return {student,rows,attendance:{...att,percentage:att.total?Math.round(Number(att.present)/Number(att.total)*10000)/100:0},grading_scales:scales,teacher_comment:comment.teacher_comment||'',class_teacher_comment:comment.class_teacher_comment||'',principal_comment:comment.principal_comment||'',promotion_status:comment.promotion_status||''};
}

module.exports = router;
