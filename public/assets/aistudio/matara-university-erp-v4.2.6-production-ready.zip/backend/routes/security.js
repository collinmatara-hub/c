const express = require('express');
const crypto = require('crypto');
const { db } = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');

const router = express.Router();
const SECURITY_ROLES = ['admin','vice_chancellor','deputy_vc','registrar','deputy_registrar','security_officer','auditor','student_affairs_officer','accommodation_officer','medical_officer'];
router.use(requireAuth, requireRole(...SECURITY_ROLES));

const tables = {
  incidents: 'security_incidents', reports: 'security_reports', visitors: 'security_visitors',
  access: 'security_access_records', lost_found: 'security_lost_found', emergencies: 'security_emergencies',
  alerts: 'security_alerts', investigations: 'security_investigations', personnel: 'security_personnel', workflows: 'security_workflows'
};
function table(name){ if(!tables[name]) { const e=new Error('Unknown security resource.'); e.status=404; throw e; } return tables[name]; }
function clean(v){ if(v===undefined||v===null) return null; const x=String(v).trim(); return x||null; }
function id(v){ const n=Number(v); return Number.isInteger(n)?n:null; }
function nextNo(prefix, t, col){ const rows=db.prepare(`SELECT ${col} value FROM ${t}`).all(); let max=0; for(const r of rows){ const m=String(r.value||'').match(/(\d+)$/); if(m) max=Math.max(max,Number(m[1])); } return prefix+String(max+1).padStart(5,'0'); }
function audit(req, action, entity, entityId, details){ db.prepare('INSERT INTO university_audit_logs(user_id,module,action,entity,entity_id,reason,ip) VALUES(?,?,?,?,?,?,?)').run(req.user.id,'security',action,entity,entityId,details||'',req.ip||''); }

router.post('/2fa/reset/:id',(req,res)=>{ const uid=id(req.params.id); if(!uid)return res.status(400).json({error:'Invalid user.'}); db.prepare('UPDATE users SET two_factor_enabled=0,two_factor_secret=NULL,two_factor_backup_hashes=NULL,session_version=session_version+1 WHERE id=?').run(uid); audit(req,'reset_2fa',uid,'Administrator reset two-factor authentication'); res.json({success:true}); });

router.get('/overview',(req,res)=>{
  const count=(t,w='1=1')=>db.prepare(`SELECT COUNT(*) n FROM ${t} WHERE ${w}`).get().n;
  res.json({
    incidents:count('security_incidents'), open_incidents:count('security_incidents',"status IN ('open','investigating')"),
    active_visitors:count('security_visitors',"status='inside'"), access_today:db.prepare("SELECT COUNT(*) n FROM security_access_records WHERE date(access_time)=date('now')").get().n,
    lost_found_open:count('security_lost_found',"status IN ('stored','claimed')"), active_emergencies:count('security_emergencies',"status='active'"),
    active_alerts:count('security_alerts',"status='active'"), open_investigations:count('security_investigations',"status='open'"),
    personnel:count('security_personnel',"status='active'"), pending_workflows:count('security_workflows',"status='pending'")
  });
});

router.get('/dashboard',(req,res)=>{
  const recent = db.prepare("SELECT i.*, u.name reporter_name, a.name assignee_name FROM security_incidents i LEFT JOIN users u ON u.id=i.reported_by LEFT JOIN users a ON a.id=i.assigned_to ORDER BY i.id DESC LIMIT 15").all();
  const alerts=db.prepare("SELECT * FROM security_alerts WHERE status='active' ORDER BY id DESC LIMIT 10").all();
  const visitors=db.prepare("SELECT v.*, u.name host_name FROM security_visitors v LEFT JOIN users u ON u.id=v.host_user_id WHERE v.status='inside' ORDER BY v.id DESC LIMIT 10").all();
  res.json({recent,alerts,visitors});
});

router.get('/:resource',(req,res)=>{ try { const t=table(req.params.resource); const rows=db.prepare(`SELECT * FROM ${t} ORDER BY id DESC LIMIT 500`).all(); res.json(rows); } catch(e){ res.status(e.status||500).json({error:e.message}); } });
router.get('/:resource/:id',(req,res)=>{ try { const t=table(req.params.resource); const row=db.prepare(`SELECT * FROM ${t} WHERE id=?`).get(id(req.params.id)); if(!row)return res.status(404).json({error:'Record not found.'}); res.json(row); } catch(e){ res.status(e.status||500).json({error:e.message}); } });

router.post('/incidents',(req,res)=>{ const b=req.body; const no=clean(b.incident_no)||nextNo('INC-', 'security_incidents','incident_no'); const r=db.prepare(`INSERT INTO security_incidents(incident_no,title,category,severity,status,location,occurred_at,description,reported_by,assigned_to) VALUES(?,?,?,?,?,?,?,?,?,?)`).run(no,clean(b.title)||'Security incident',clean(b.category),clean(b.severity)||'medium',clean(b.status)||'open',clean(b.location),clean(b.occurred_at),clean(b.description),req.user.id,id(b.assigned_to)); audit(req,'create','security_incident',r.lastInsertRowid,no); res.status(201).json({id:Number(r.lastInsertRowid),incident_no:no}); });
router.post('/reports',(req,res)=>{ const b=req.body; const r=db.prepare(`INSERT INTO security_reports(incident_id,report_type,title,body,status,submitted_by,submitted_at) VALUES(?,?,?,?,?,?,CASE WHEN ?='submitted' THEN datetime('now') END)`).run(id(b.incident_id),clean(b.report_type)||'Incident Report',clean(b.title),clean(b.body),clean(b.status)||'draft',req.user.id,clean(b.status)||'draft'); audit(req,'create','security_report',r.lastInsertRowid,'Security report'); res.status(201).json({id:Number(r.lastInsertRowid)}); });
router.post('/visitors',(req,res)=>{ const b=req.body; const no=clean(b.visitor_no)||nextNo('VIS-', 'security_visitors','visitor_no'); const r=db.prepare(`INSERT INTO security_visitors(visitor_no,full_name,organization,phone,id_type,id_reference,host_user_id,purpose,vehicle_no,status,notes) VALUES(?,?,?,?,?,?,?,?,?,?,?)`).run(no,clean(b.full_name)||'Visitor',clean(b.organization),clean(b.phone),clean(b.id_type),clean(b.id_reference),id(b.host_user_id),clean(b.purpose),clean(b.vehicle_no),clean(b.status)||'inside',clean(b.notes)); audit(req,'create','security_visitor',r.lastInsertRowid,no); res.status(201).json({id:Number(r.lastInsertRowid),visitor_no:no}); });
router.post('/access',(req,res)=>{ const b=req.body; const r=db.prepare(`INSERT INTO security_access_records(person_name,user_id,access_point,direction,method,badge_no,authorized_by,notes) VALUES(?,?,?,?,?,?,?,?)`).run(clean(b.person_name),id(b.user_id),clean(b.access_point),clean(b.direction)||'in',clean(b.method)||'manual',clean(b.badge_no),id(b.authorized_by)||req.user.id,clean(b.notes)); audit(req,'create','security_access',r.lastInsertRowid,'Access record'); res.status(201).json({id:Number(r.lastInsertRowid)}); });
router.post('/lost_found',(req,res)=>{ const b=req.body; const no=clean(b.item_no)||nextNo('LF-', 'security_lost_found','item_no'); const r=db.prepare(`INSERT INTO security_lost_found(item_no,item_type,title,description,location,found_at,reported_by,status,notes) VALUES(?,?,?,?,?,?,?, ?,?)`).run(no,clean(b.item_type)||'Other',clean(b.title)||'Item',clean(b.description),clean(b.location),clean(b.found_at),req.user.id,clean(b.status)||'stored',clean(b.notes)); audit(req,'create','security_lost_found',r.lastInsertRowid,no); res.status(201).json({id:Number(r.lastInsertRowid),item_no:no}); });
router.post('/emergencies',(req,res)=>{ const b=req.body; const no=clean(b.event_no)||nextNo('EMG-', 'security_emergencies','event_no'); const r=db.prepare(`INSERT INTO security_emergencies(event_no,event_type,title,severity,status,location,description,declared_by,lead_officer,response_plan) VALUES(?,?,?,?,?,?,?,?,?,?)`).run(no,clean(b.event_type)||'Emergency',clean(b.title)||'Emergency event',clean(b.severity)||'high',clean(b.status)||'active',clean(b.location),clean(b.description),req.user.id,id(b.lead_officer),clean(b.response_plan)); audit(req,'create','security_emergency',r.lastInsertRowid,no); res.status(201).json({id:Number(r.lastInsertRowid),event_no:no}); });
router.post('/alerts',(req,res)=>{ const b=req.body; const no=clean(b.alert_no)||nextNo('ALT-', 'security_alerts','alert_no'); const r=db.prepare(`INSERT INTO security_alerts(alert_no,title,message,severity,audience,status,ends_at,created_by) VALUES(?,?,?,?,?,?,?,?)`).run(no,clean(b.title)||'Security alert',clean(b.message)||'',clean(b.severity)||'medium',clean(b.audience)||'all',clean(b.status)||'active',clean(b.ends_at),req.user.id); audit(req,'create','security_alert',r.lastInsertRowid,no); res.status(201).json({id:Number(r.lastInsertRowid),alert_no:no}); });
router.post('/investigations',(req,res)=>{ const b=req.body; const no=clean(b.investigation_no)||nextNo('INV-', 'security_investigations','investigation_no'); const r=db.prepare(`INSERT INTO security_investigations(investigation_no,incident_id,title,lead_investigator,status,findings,actions,confidential) VALUES(?,?,?,?,?,?,?,?)`).run(no,id(b.incident_id),clean(b.title)||'Investigation',id(b.lead_investigator)||req.user.id,clean(b.status)||'open',clean(b.findings),clean(b.actions),b.confidential===0?0:1); audit(req,'create','security_investigation',r.lastInsertRowid,no); res.status(201).json({id:Number(r.lastInsertRowid),investigation_no:no}); });
router.post('/personnel',(req,res)=>{ const b=req.body; const uid=id(b.user_id); if(!uid)return res.status(400).json({error:'Security personnel must be linked to a user account.'}); const r=db.prepare(`INSERT INTO security_personnel(user_id,badge_no,rank,shift,status,assigned_zone,phone,hired_at) VALUES(?,?,?,?,?,?,?,?)`).run(uid,clean(b.badge_no),clean(b.rank),clean(b.shift),clean(b.status)||'active',clean(b.assigned_zone),clean(b.phone),clean(b.hired_at)); audit(req,'create','security_personnel',r.lastInsertRowid,'Security personnel'); res.status(201).json({id:Number(r.lastInsertRowid)}); });
router.post('/workflows',(req,res)=>{ const b=req.body; const r=db.prepare(`INSERT INTO security_workflows(incident_id,workflow_type,step_no,action_required,assigned_to,status,due_at,notes) VALUES(?,?,?,?,?,?,?,?)`).run(id(b.incident_id),clean(b.workflow_type)||'incident',Number(b.step_no)||1,clean(b.action_required)||'Review incident',id(b.assigned_to),clean(b.status)||'pending',clean(b.due_at),clean(b.notes)); audit(req,'create','security_workflow',r.lastInsertRowid,'Incident workflow'); res.status(201).json({id:Number(r.lastInsertRowid)}); });

const EDITABLE = {
 incidents:['title','category','severity','status','location','occurred_at','description','assigned_to','resolution','closed_at'],
 reports:['incident_id','report_type','title','body','status','submitted_at'], visitors:['organization','phone','purpose','vehicle_no','check_out','status','notes'],
 access:['person_name','user_id','access_point','direction','method','badge_no','authorized_by','notes'], lost_found:['item_type','title','description','location','found_at','status','claimant_name','claimant_user_id','released_at','released_by','notes'],
 emergencies:['event_type','title','severity','status','location','ended_at','description','lead_officer','response_plan'], alerts:['title','message','severity','audience','status','starts_at','ends_at'],
 investigations:['incident_id','title','lead_investigator','status','closed_at','findings','actions','confidential'], personnel:['badge_no','rank','shift','status','assigned_zone','phone','hired_at'],
 workflows:['incident_id','workflow_type','step_no','action_required','assigned_to','status','due_at','completed_at','completed_by','notes']
};
router.put('/:resource/:id',(req,res)=>{ try { const t=table(req.params.resource); const allowed=(EDITABLE[req.params.resource]||[]).filter(k=>Object.prototype.hasOwnProperty.call(req.body,k)); if(!allowed.length)return res.status(400).json({error:'No editable fields supplied.'}); const sets=allowed.map(k=>`${k}=?`).join(', '); const vals=allowed.map(k=>req.body[k]); vals.push(id(req.params.id)); const r=db.prepare(`UPDATE ${t} SET ${sets} WHERE id=?`).run(...vals); if(!r.changes)return res.status(404).json({error:'Record not found.'}); audit(req,'update',`security_${req.params.resource}`,id(req.params.id),`Updated ${req.params.resource}`); res.json({success:true}); } catch(e){ res.status(400).json({error:e.message}); } });

module.exports=router;
