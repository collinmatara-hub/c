const express = require('express');
const crypto = require('crypto');
const { db } = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');
const router = express.Router();

const HELPDESK = ['helpdesk_l1','helpdesk_l2'];
const UNIVERSITY = ['admin','vice_chancellor','deputy_vc','registrar','deputy_registrar','dean','deputy_dean','hod','lecturer','senior_lecturer','professor','academic_staff','examination_officer','exam_board','admissions_officer','finance_director','finance_officer','hr_director','hr_officer','research_officer','student_affairs_officer','accommodation_officer','librarian','accounts','ict','auditor'];
const ADMIN = ['admin','vice_chancellor','registrar','deputy_registrar','dean','deputy_dean','hod','examination_officer','exam_board','finance_director','finance_officer','auditor'];
const ref = () => `MU-HLP-${Date.now()}-${crypto.randomBytes(2).toString('hex').toUpperCase()}`;
const roles = (r) => requireRole(...r);
const audit = (u,a,e,id,d='') => { try { db.prepare('INSERT INTO audit_logs(user_id,action,entity,entity_id,details) VALUES(?,?,?,?,?)').run(u?.id||null,a,e,id||null,d); } catch {} };

router.get('/lifecycle', requireAuth, roles(UNIVERSITY), (req,res) => {
  const stages = [
    ['Applicants', `SELECT COUNT(*) c FROM applicants WHERE status NOT IN ('rejected','withdrawn')`],
    ['Admitted', `SELECT COUNT(*) c FROM applicants WHERE status IN ('offered','accepted','registered')`],
    ['Active Students', `SELECT COUNT(*) c FROM students WHERE status='active'`],
    ['Graduation Candidates', `SELECT COUNT(*) c FROM graduation_clearance WHERE academic_status='ready'`],
    ['Graduated', `SELECT COUNT(*) c FROM alumni WHERE graduation_year IS NOT NULL`],
  ].map(([label,sql])=>({label,value:Number(db.prepare(sql).get()?.c||0)}));
  const alerts = [];
  const outstanding = Number(db.prepare(`SELECT COALESCE(SUM(total-paid),0) n FROM university_invoices WHERE status NOT IN ('paid','cancelled')`).get()?.n||0);
  if(outstanding>0) alerts.push({type:'finance',label:'Outstanding student balances',value:`KES ${outstanding.toLocaleString('en-KE')}`});
  const unpublished = Number(db.prepare(`SELECT COUNT(*) c FROM university_results WHERE status='approved' AND published_at IS NULL`).get()?.c||0);
  if(unpublished) alerts.push({type:'academic',label:'Approved results awaiting publication',value:unpublished});
  const openTickets = Number(db.prepare(`SELECT COUNT(*) c FROM helpdesk_tickets WHERE status NOT IN ('resolved','closed')`).get()?.c||0);
  if(openTickets) alerts.push({type:'service',label:'Open support tickets',value:openTickets});
  res.json({stages,alerts});
});

router.get('/degree-audit/:studentId', requireAuth, roles(UNIVERSITY.concat(['student'])), (req,res) => {
  const studentId = Number(req.params.studentId);
  if(req.user.role==='student') { const own=db.prepare('SELECT id FROM students WHERE user_id=?').get(req.user.id); if(!own || own.id!==studentId) return res.status(403).json({error:'You can only view your own degree audit.'}); }
  const student = db.prepare(`SELECT s.id,s.adm_no,s.name,p.name program_name,p.id program_id,ue.curriculum_id,ue.expected_completion FROM students s LEFT JOIN university_enrollments ue ON ue.student_id=s.id AND ue.status='active' LEFT JOIN programs p ON p.id=ue.program_id WHERE s.id=?`).get(studentId);
  if(!student) return res.status(404).json({error:'Student not found.'});
  let rows=[];
  if(student.curriculum_id) rows=db.prepare(`SELECT uc.id,uc.code,uc.name,uc.credits,uc.course_type,cc.semester_no,cc.required,cc.prerequisite_course_id,
      ur.total_mark,ur.grade,ur.grade_points,ur.status FROM curriculum_courses cc JOIN university_courses uc ON uc.id=cc.course_id
      LEFT JOIN course_offerings co ON co.course_id=uc.id LEFT JOIN university_results ur ON ur.offering_id=co.id AND ur.student_id=?
      WHERE cc.curriculum_id=? GROUP BY uc.id ORDER BY cc.semester_no,uc.code`).all(studentId,student.curriculum_id);
  else rows=db.prepare(`SELECT uc.id,uc.code,uc.name,uc.credits,uc.course_type,NULL semester_no,1 required,NULL prerequisite_course_id,NULL total_mark,NULL grade,NULL grade_points,NULL status FROM university_courses uc WHERE uc.status='active' ORDER BY uc.code`).all();
  const passed = rows.filter(r=>Number(r.grade_points||0)>0 && !['F','E','FAIL'].includes(String(r.grade||'').toUpperCase()));
  const creditsCompleted = passed.reduce((n,r)=>n+Number(r.credits||0),0);
  const creditsRequired = rows.reduce((n,r)=>n+((Number(r.required)!==0)?Number(r.credits||0):0),0);
  const requiredRemaining = rows.filter(r=>Number(r.required)!==0 && !passed.some(p=>p.id===r.id));
  const totalPoints = passed.reduce((n,r)=>n+Number(r.grade_points||0)*Number(r.credits||0),0);
  const gpa = creditsCompleted ? totalPoints/creditsCompleted : 0;
  res.json({student,summary:{creditsRequired,creditsCompleted,creditsRemaining:Math.max(creditsRequired-creditsCompleted,0),completionPercent:creditsRequired?Math.round(creditsCompleted/creditsRequired*100):0,gpa:Number(gpa.toFixed(2)),graduationReady:requiredRemaining.length===0 && creditsCompleted>=creditsRequired},rows,remaining:requiredRemaining});
});

router.get('/advising', requireAuth, roles(UNIVERSITY.concat(['student'])), (req,res) => {
  const studentId = req.query.student_id ? Number(req.query.student_id) : null;
  const scope = req.user.role==='student' ? db.prepare('SELECT id FROM students WHERE user_id=?').get(req.user.id)?.id : studentId;
  const where = scope ? 'WHERE aa.student_id=?' : '';
  const advisors=db.prepare(`SELECT aa.*,s.name student_name,s.adm_no,u.name advisor_name,u.email advisor_email FROM academic_advisors aa JOIN students s ON s.id=aa.student_id JOIN users u ON u.id=aa.advisor_id ${where} ORDER BY aa.assigned_at DESC`).all(...(scope?[scope]:[]));
  const notes=db.prepare(`SELECT an.*,s.name student_name,u.name advisor_name FROM advising_notes an JOIN students s ON s.id=an.student_id JOIN users u ON u.id=an.advisor_id ${scope?'WHERE an.student_id=?':''} ORDER BY an.created_at DESC LIMIT 100`).all(...(scope?[scope]:[]));
  res.json({advisors,notes});
});
router.post('/advising/notes', requireAuth, roles(UNIVERSITY), (req,res)=>{ const b=req.body||{}; if(!b.student_id||!b.title||!b.note)return res.status(400).json({error:'Student, title and note are required.'}); const r=db.prepare('INSERT INTO advising_notes(student_id,advisor_id,title,note,risk_level,follow_up_date) VALUES(?,?,?,?,?,?)').run(b.student_id,req.user.id,b.title,b.note,b.risk_level||'normal',b.follow_up_date||null); audit(req.user,'CREATE','advising_note',r.lastInsertRowid,b.title); res.status(201).json({id:r.lastInsertRowid}); });

router.get('/graduation', requireAuth, roles(ADMIN), (req,res)=>{
  const rows=db.prepare(`SELECT s.id,s.adm_no,s.name,p.name program_name,ue.expected_completion,
    (SELECT COUNT(*) FROM university_results ur WHERE ur.student_id=s.id AND ur.grade_points>0) passed_courses,
    COALESCE((SELECT SUM(ur.credits) FROM university_results ur WHERE ur.student_id=s.id AND ur.grade_points>0),0) earned_credits,
    COALESCE((SELECT SUM(cc2.required*uc2.credits) FROM curriculum_courses cc2 JOIN university_courses uc2 ON uc2.id=cc2.course_id WHERE cc2.curriculum_id=ue.curriculum_id),0) required_credits
    FROM students s JOIN university_enrollments ue ON ue.student_id=s.id AND ue.status='active' LEFT JOIN programs p ON p.id=ue.program_id ORDER BY s.name LIMIT 500`).all();
  res.json(rows.map(r=>({...r,percent:r.required_credits?Math.min(100,Math.round(r.earned_credits/r.required_credits*100)):0,ready:r.required_credits>0&&r.earned_credits>=r.required_credits}))); 
});

const HELP_DESK_VIEWERS = ['admin','ict','helpdesk_l1','helpdesk_l2'];
const VIP_ROLES = ['vice_chancellor','deputy_vc','registrar','deputy_registrar','dean','deputy_dean','hod','finance_director','hr_director'];
const isHelpDeskViewer = (user) => HELP_DESK_VIEWERS.includes(String(user?.role || '').toLowerCase());
const requesterRankSql = `CASE lower(COALESCE(u.role,''))
  WHEN 'vice_chancellor' THEN 0 WHEN 'deputy_vc' THEN 1 WHEN 'registrar' THEN 2
  WHEN 'deputy_registrar' THEN 3 WHEN 'dean' THEN 4 WHEN 'deputy_dean' THEN 5
  WHEN 'hod' THEN 6 WHEN 'finance_director' THEN 7 WHEN 'hr_director' THEN 8 ELSE 20 END`;
function chooseLeastLoadedHelpDesk() {
  const agents = db.prepare(`SELECT id, role FROM users WHERE lower(role) IN ('helpdesk_l1','helpdesk_l2') AND COALESCE(status,'active')='active' ORDER BY
    (SELECT COUNT(*) FROM helpdesk_tickets t WHERE t.assigned_to=users.id AND t.status NOT IN ('resolved','closed')) ASC,
    CASE lower(role) WHEN 'helpdesk_l1' THEN 0 ELSE 1 END, id ASC`).all();
  return agents[0]?.id ?? null;
}
router.get('/helpdesk', requireAuth, (req,res)=>{
  if (isHelpDeskViewer(req.user)) {
    const rows=db.prepare(`SELECT t.*,u.name requester_name,u.role requester_role,a.name assignee_name
      FROM helpdesk_tickets t LEFT JOIN users u ON u.id=t.requester_id LEFT JOIN users a ON a.id=t.assigned_to
      ORDER BY ${requesterRankSql}, CASE lower(COALESCE(t.priority,'normal')) WHEN 'urgent' THEN 0 WHEN 'high' THEN 1 WHEN 'normal' THEN 2 ELSE 3 END,
      CASE WHEN t.status IN ('resolved','closed') THEN 1 ELSE 0 END, t.created_at ASC LIMIT 1000`).all();
    return res.json({access:'helpdesk_queue',tickets:rows});
  }
  // Ordinary users can retrieve only their own ticket numbers. No subject, description,
  // requester identity, priority, status, assignment, or other ticket metadata is exposed.
  const rows=db.prepare('SELECT id,ticket_no FROM helpdesk_tickets WHERE requester_id=? ORDER BY created_at DESC LIMIT 100').all(req.user.id);
  return res.json({access:'ticket_numbers_only',tickets:rows});
});
router.post('/helpdesk', requireAuth, (req,res)=>{
  const b=req.body||{};
  if(!b.category||!b.subject||!b.description)return res.status(400).json({error:'Category, subject and description are required.'});
  const no=ref();
  const priority=VIP_ROLES.includes(String(req.user.role||'').toLowerCase()) ? 'urgent' : (['low','normal','high','urgent'].includes(String(b.priority||'normal').toLowerCase())?String(b.priority||'normal').toLowerCase():'normal');
  const assignedTo=chooseLeastLoadedHelpDesk();
  const r=db.prepare('INSERT INTO helpdesk_tickets(ticket_no,requester_id,category,subject,description,priority,assigned_to) VALUES(?,?,?,?,?,?,?)').run(no,req.user.id,b.category,b.subject,b.description,priority,assignedTo);
  audit(req.user,'CREATE','helpdesk_ticket',r.lastInsertRowid,JSON.stringify({ticket_no:no,assigned_to:assignedTo,priority}));
  res.status(201).json({id:r.lastInsertRowid,ticket_no:no,assigned:!!assignedTo});
});
router.patch('/helpdesk/:id', requireAuth, (req,res)=>{
  if(!isHelpDeskViewer(req.user)) return res.status(403).json({error:'Only Help Desk Level 1, Help Desk Level 2, ICT Officer, or Super Administrator can manage tickets.'});
  const b=req.body||{}; const fields=[]; const vals=[];
  for(const k of ['status','priority','assigned_to']) if(b[k]!==undefined){
    if(k==='status'&&!['open','in_progress','resolved','closed'].includes(String(b[k]))) return res.status(400).json({error:'Invalid ticket status.'});
    if(k==='priority'&&!['low','normal','high','urgent'].includes(String(b[k]))) return res.status(400).json({error:'Invalid ticket priority.'});
    if(k==='assigned_to'&&b[k]!==null&&!db.prepare("SELECT id FROM users WHERE id=? AND lower(role) IN ('helpdesk_l1','helpdesk_l2')").get(Number(b[k]))) return res.status(400).json({error:'Tickets may only be assigned to Help Desk Level 1 or Level 2.'});
    fields.push(`${k}=?`); vals.push(b[k]===null?null:b[k]);
  }
  if(!fields.length)return res.status(400).json({error:'No changes supplied.'});
  fields.push("updated_at=datetime('now')"); vals.push(req.params.id);
  const result=db.prepare(`UPDATE helpdesk_tickets SET ${fields.join(',')} WHERE id=?`).run(...vals);
  if(!result.changes)return res.status(404).json({error:'Ticket not found.'});
  audit(req.user,'UPDATE','helpdesk_ticket',req.params.id,JSON.stringify(b)); res.json({success:true});
});

router.get('/data-quality', requireAuth, roles(ADMIN), (req,res)=>{
  const checks=[];
  const add=(label,count,severity='warning',detail='')=>checks.push({label,count:Number(count||0),severity,detail});
  add('Students without email',db.prepare("SELECT COUNT(*) c FROM students WHERE email IS NULL OR TRIM(email)='' ").get()?.c,'warning','Add an institutional or personal email.');
  add('Students without programme',db.prepare(`SELECT COUNT(*) c FROM students s LEFT JOIN university_enrollments ue ON ue.student_id=s.id AND ue.status='active' WHERE s.status='active' AND ue.id IS NULL`).get()?.c,'warning','Assign an active university programme.');
  add('Duplicate student admission numbers',db.prepare(`SELECT COUNT(*) c FROM (SELECT adm_no FROM students WHERE adm_no IS NOT NULL AND adm_no<>'' GROUP BY adm_no HAVING COUNT(*)>1)`).get()?.c,'critical','Admission numbers should be unique.');
  add('Active staff without department',db.prepare(`SELECT COUNT(*) c FROM staff WHERE status='active' AND (department_id IS NULL OR department_id=0)`).get()?.c,'warning','Assign each active staff member to an academic or administrative unit.');
  add('Approved results not published',db.prepare("SELECT COUNT(*) c FROM university_results WHERE status='approved' AND published_at IS NULL").get()?.c,'warning','Publish or return for correction.');
  add('Open helpdesk tickets',db.prepare("SELECT COUNT(*) c FROM helpdesk_tickets WHERE status NOT IN ('resolved','closed')").get()?.c,'info','Operational queue.');
  res.json({generated_at:new Date().toISOString(),checks,score:Math.max(0,100-checks.filter(x=>x.severity==='critical').reduce((n,x)=>n+Math.min(25,x.count),0)-checks.filter(x=>x.severity==='warning').reduce((n,x)=>n+Math.min(10,x.count),0))});
});

router.get('/calendar', requireAuth, roles(UNIVERSITY.concat(['student'])), (req,res)=>{
  const events=db.prepare(`SELECT id,title,event_type,start_at,end_at,location,audience,reminder_minutes,description FROM calendar_events ORDER BY start_at LIMIT 500`).all();
  const legacy=db.prepare(`SELECT id,title,description,event_date,start_time,end_time,audience FROM events ORDER BY event_date,start_time LIMIT 500`).all();
  res.json({events,legacy});
});

module.exports=router;
