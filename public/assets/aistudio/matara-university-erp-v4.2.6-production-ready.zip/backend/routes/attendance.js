const express = require('express');
const { db } = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');

const router = express.Router();

// Get attendance for a specific date (defaults to today), optionally filtered by class
router.get('/', requireAuth, requireRole('admin','vice_chancellor','deputy_vc','registrar','deputy_registrar','dean','deputy_dean','hod','lecturer','senior_lecturer','professor','academic_staff','examination_officer','exam_board','auditor'), (req, res) => {
  const date = req.query.date || new Date().toISOString().slice(0, 10);
  const classId = req.query.class_id;

  let query = `
    SELECT s.id as student_id, s.name, s.adm_no, c.name as class_name, c.stream,
      a.status, a.id as attendance_id
    FROM students s
    LEFT JOIN classes c ON c.id = s.class_id
    LEFT JOIN attendance a ON a.student_id = s.id AND a.date = ?
    WHERE s.status = 'active'
  `;
  const params = [date];
  if (classId) {
    query += ' AND s.class_id = ?';
    params.push(classId);
  }
  query += ' ORDER BY s.name ASC';

  const rows = db.prepare(query).all(...params);
  res.json({ date, records: rows });
});

// Mark/update attendance for one student on one date
router.post('/', requireAuth, requireRole('admin', 'teacher'), (req, res) => {
  const { student_id, date, status } = req.body;
  if (!student_id || !date || !status) {
    return res.status(400).json({ error: 'student_id, date and status are required.' });
  }
  db.prepare(`
    INSERT INTO attendance (student_id, date, status) VALUES (?, ?, ?)
    ON CONFLICT(student_id, date) DO UPDATE SET status = excluded.status
  `).run(student_id, date, status);
  res.json({ success: true });
});

// Bulk mark a whole class in one request
router.post('/bulk', requireAuth, requireRole('admin', 'teacher'), (req, res) => {
  const { date, records } = req.body; // records: [{student_id, status}]
  if (!date || !Array.isArray(records)) {
    return res.status(400).json({ error: 'date and records[] are required.' });
  }
  const stmt = db.prepare(`
    INSERT INTO attendance (student_id, date, status) VALUES (?, ?, ?)
    ON CONFLICT(student_id, date) DO UPDATE SET status = excluded.status
  `);
  db.exec('BEGIN');
  try {
    for (const r of records) stmt.run(r.student_id, date, r.status);
    db.exec('COMMIT');
  } catch (err) {
    db.exec('ROLLBACK');
    throw err;
  }
  res.json({ success: true, count: records.length });
});

module.exports = router;
