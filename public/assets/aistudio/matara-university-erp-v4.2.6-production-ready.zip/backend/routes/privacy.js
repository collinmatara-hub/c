const express=require('express');
const {db}=require('../db');
const {requireAuth,requireRole}=require('../middleware/auth');
const router=express.Router();
router.use(requireAuth);
router.get('/notice',(req,res)=>res.json({institution:'Matara University',version:'1.0',purposes:['student administration','academic delivery','finance','security','legal and regulatory compliance'],rights:['access','correction','erasure where applicable','objection','withdrawal of consent'],contact:'University Data Protection Office'}));
router.get('/me/export',(req,res)=>{
 const blocked={users:new Set(['password','two_factor_secret','two_factor_backup_hashes']),password_reset_tokens:new Set(['token_hash']),account_recovery:new Set(['recovery_code_hash']),api_keys:new Set(['key_hash'])};
 const tables=['users','students','student_profiles','university_enrollments','course_registrations','university_results','privacy_consents','privacy_requests']; const out={exported_at:new Date().toISOString(),user_id:req.user.id,tables:{}};
 for(const table of tables){if(!db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name=?").get(table))continue; const cols=db.prepare(`PRAGMA table_info(${table})`).all().map(c=>c.name).filter(c=>!(blocked[table]||new Set()).has(c)); let rows=[]; if(table==='users') rows=db.prepare(`SELECT ${cols.map(c=>'\"'+c+'\"').join(',')} FROM users WHERE id=?`).all(req.user.id); else if(['students','student_profiles','university_enrollments','course_registrations','university_results'].includes(table)){const col=table==='students'?'id':'student_id'; const student=db.prepare('SELECT id FROM students WHERE user_id=?').get(req.user.id); rows=student?db.prepare(`SELECT ${cols.map(c=>'\"'+c+'\"').join(',')} FROM ${table} WHERE ${col}=?`).all(student.id):[];} else if(table==='privacy_consents'||table==='privacy_requests') rows=db.prepare(`SELECT ${cols.map(c=>'\"'+c+'\"').join(',')} FROM ${table} WHERE user_id=?`).all(req.user.id); out.tables[table]={columns:cols,rows};}
 res.setHeader('Content-Type','application/json');res.setHeader('Content-Disposition',`attachment; filename=matara-university-my-data-${new Date().toISOString().slice(0,10)}.json`);res.json(out);
});
router.post('/breaches',requireRole('admin','vice_chancellor','auditor'),(req,res)=>{const ref=`BREACH-${Date.now()}`;const x=db.prepare('INSERT INTO data_breaches(reference_no,severity,description,affected_records,containment,reported_by) VALUES(?,?,?,?,?,?)').run(ref,req.body.severity||'medium',String(req.body.description||''),Number(req.body.affected_records||0),String(req.body.containment||''),req.user.id);res.status(201).json({id:x.lastInsertRowid,reference_no:ref});});
router.get('/breaches',requireRole('admin','vice_chancellor','auditor'),(req,res)=>res.json(db.prepare('SELECT b.*,u.name reported_by_name FROM data_breaches b LEFT JOIN users u ON u.id=b.reported_by ORDER BY b.detected_at DESC').all()));
router.get('/requests',requireRole('admin','vice_chancellor','auditor'),(req,res)=>res.json(db.prepare('SELECT r.*,u.name,u.email FROM privacy_requests r JOIN users u ON u.id=r.user_id ORDER BY r.requested_at DESC').all()));
router.get('/retention',requireRole('admin','vice_chancellor','auditor'),(req,res)=>res.json(db.prepare('SELECT * FROM retention_policies ORDER BY data_category').all()));
module.exports=router;
