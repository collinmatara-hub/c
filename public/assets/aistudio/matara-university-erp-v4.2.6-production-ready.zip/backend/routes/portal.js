// routes/portal.js
// Everything a signed-in student can do for themselves: register units, read CAT results,
// apply for supplementary exams, see the class timetable and open e-content.

const express = require('express');
const { db } = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');
const { activeHold } = require('../lib/holds');
const { currentTerm, passMark, gradeFor, studentFor, lecturerNames, dayKey } = require('../lib/academic');

const router = express.Router();
router.use(requireAuth, requireRole('student'));

// Every route below needs the student record that belongs to this login
router.use((req, res, next) => {
  const student = studentFor(req.user.id);
  if (!student) {
    return res.status(404).json({ error: 'Your login is not linked to a student record. Please contact the school office.' });
  }
  req.student = student;
  next();
});

function toId(value) {
  const number = parseInt(value, 10);
  return Number.isNaN(number) ? null : number;
}

function registeredUnits(studentId, term) {
  return db.prepare(`
    SELECT r.id, r.subject_id, r.registered_at, sub.name, sub.code
    FROM unit_registrations r JOIN subjects sub ON sub.id = r.subject_id
    WHERE r.student_id = ? AND r.term = ?
    ORDER BY sub.name
  `).all(studentId, term);
}

// All of this student's results, newest assessment first
function resultsFor(studentId) {
  const limit = passMark();
  return db.prepare(`
    SELECT g.exam_id, g.subject_id, g.score,
      e.name AS exam_name, e.kind, e.term, e.year,
      sub.name AS unit_name, sub.code,
      (SELECT ROUND(AVG(g2.score), 1) FROM grades g2 WHERE g2.exam_id = g.exam_id AND g2.subject_id = g.subject_id) AS class_average,
      (SELECT sr.status FROM supplementary_requests sr
        WHERE sr.student_id = g.student_id AND sr.subject_id = g.subject_id AND sr.exam_id = g.exam_id) AS supplementary_status
    FROM grades g
    JOIN exams e ON e.id = g.exam_id
    JOIN subjects sub ON sub.id = g.subject_id
    WHERE g.student_id = ?
    ORDER BY e.id DESC, sub.name
  `).all(studentId).map((row) => {
    const grade = gradeFor(row.score);
    return { ...row, grade: grade.grade, remark: grade.comment, passed: row.score >= limit };
  });
}


router.get('/university-results', (req,res) => {
  const rows = db.prepare(`
    SELECT ur.id, ur.total_mark, ur.grade, ur.grade_points, ur.credits, ur.status, ur.approval_stage,
           c.code AS unit_code, c.name AS unit_name, p.name AS semester, p.start_date, p.end_date
    FROM university_results ur
    JOIN course_offerings o ON o.id=ur.offering_id
    JOIN university_courses c ON c.id=o.course_id
    JOIN academic_periods p ON p.id=o.period_id
    WHERE ur.student_id=?
    ORDER BY p.start_date DESC, c.code
  `).all(req.student.id);
  const graded=rows.filter(r=>r.grade_points!==null && r.credits!==null && ['approved','published'].includes(r.status));
  const credits=graded.reduce((a,r)=>a+Number(r.credits||0),0);
  const points=graded.reduce((a,r)=>a+(Number(r.grade_points||0)*Number(r.credits||0)),0);
  const gpa=credits?Number((points/credits).toFixed(2)):null;
  const bySemester={};
  graded.forEach(r=>{const key=r.semester||'Unassigned semester'; if(!bySemester[key])bySemester[key]={semester:key,credits:0,points:0}; bySemester[key].credits+=Number(r.credits||0); bySemester[key].points+=Number(r.grade_points||0)*Number(r.credits||0);});
  Object.values(bySemester).forEach(x=>x.gpa=x.credits?Number((x.points/x.credits).toFixed(2)):null);
  res.json({student:{name:req.student.name,registration_no:req.student.adm_no},gpa,credits_attempted:credits,results:rows,semesters:Object.values(bySemester)});
});

router.get('/privacy/consents', (req,res)=>res.json({consents:db.prepare('SELECT consent_type,purpose,granted,granted_at,revoked_at FROM privacy_consents WHERE user_id=? ORDER BY consent_type').all(req.user.id)}));
router.post('/privacy/consents', (req,res)=>{
  const type=String(req.body.consent_type||'').trim(); const purpose=String(req.body.purpose||'').trim(); const granted=Boolean(req.body.granted);
  if(!type||!purpose)return res.status(400).json({error:'Consent type and purpose are required.'});
  db.prepare(`INSERT INTO privacy_consents(user_id,consent_type,purpose,granted,granted_at,revoked_at) VALUES(?,?,?,?,CASE WHEN ?=1 THEN datetime('now') ELSE NULL END,CASE WHEN ?=0 THEN datetime('now') ELSE NULL END) ON CONFLICT(user_id,consent_type) DO UPDATE SET purpose=excluded.purpose,granted=excluded.granted,granted_at=CASE WHEN excluded.granted=1 THEN datetime('now') ELSE privacy_consents.granted_at END,revoked_at=CASE WHEN excluded.granted=0 THEN datetime('now') ELSE NULL END`).run(req.user.id,type,purpose,granted?1:0,granted?1:0,granted?1:0);
  res.json({success:true});
});
router.post('/privacy/request', (req,res)=>{
  const type=String(req.body.request_type||'access').trim(); if(!['access','correction','erasure','objection'].includes(type))return res.status(400).json({error:'Unsupported privacy request type.'});
  const x=db.prepare('INSERT INTO privacy_requests(user_id,request_type,notes) VALUES(?,?,?)').run(req.user.id,type,String(req.body.notes||''));
  res.status(201).json({id:x.lastInsertRowid,status:'submitted'});
});

// ---------- dashboard summary ----------

router.get('/overview', (req, res) => {
  const student = req.student;
  const term = currentTerm();
  const results = resultsFor(student.id);

  // Average of the most recent assessment that has marks
  const latest = results.length > 0 ? results.filter((r) => r.exam_id === results[0].exam_id) : [];
  const latestAverage = latest.length > 0
    ? Math.round(latest.reduce((sum, r) => sum + r.score, 0) / latest.length)
    : null;

  const todayKey = dayKey(new Date().toLocaleDateString('en-US', { weekday: 'long' }));
  const today = db.prepare(`
    SELECT t.day, t.start_time, t.end_time, t.room, sub.name AS unit_name, te.name AS lecturer
    FROM timetables t
    LEFT JOIN subjects sub ON sub.id = t.subject_id
    LEFT JOIN teachers te ON te.id = t.teacher_id
    WHERE t.class_id = ? ORDER BY t.start_time
  `).all(student.class_id || 0).filter((slot) => dayKey(slot.day) === todayKey);

  res.json({
    student: { id: student.id, name: student.name, adm_no: student.adm_no, class_name: student.class_name, class_stream: student.class_stream },
    term,
    unitsRegistered: registeredUnits(student.id, term).length,
    latestAverage,
    latestAssessment: latest.length > 0 ? latest[0].exam_name : null,
    pendingSupplementary: db.prepare(
      "SELECT COUNT(*) c FROM supplementary_requests WHERE student_id = ? AND status = 'pending'"
    ).get(student.id).c,
    unreadMessages: db.prepare(
      'SELECT COUNT(*) c FROM messages WHERE recipient_id = ? AND read_at IS NULL'
    ).get(req.user.id).c,
    failedUnits: results.filter((r) => !r.passed && !r.supplementary_status).length,
    feeBalance: db.prepare('SELECT COALESCE(SUM(amount_due - amount_paid), 0) AS balance FROM fees WHERE student_id = ?').get(student.id).balance,
    today,
    recentResults: results.slice(0, 5),
  });
});

// ---------- unit registration ----------

router.get('/units', (req, res) => {
  const student = req.student;
  const term = currentTerm();
  const registered = registeredUnits(student.id, term).map((unit) => ({
    ...unit, lecturer: lecturerNames(student.class_id, unit.subject_id),
  }));
  const taken = new Set(registered.map((u) => u.subject_id));
  const available = db.prepare('SELECT id AS subject_id, name, code FROM subjects ORDER BY name').all()
    .filter((unit) => !taken.has(unit.subject_id))
    .map((unit) => ({ ...unit, lecturer: lecturerNames(student.class_id, unit.subject_id) }));

  res.json({ term, registered, available });
});

router.post('/units/register', (req, res) => {
  // A financial hold placed by the Collections Officer blocks unit registration.
  const hold = activeHold(req.student.id);
  if (hold) return res.status(403).json({ error: 'You have a financial hold on your account. Please contact Student Accounts.', hold: { reason: hold.reason, amount: hold.amount } });
  const subjectId = toId(req.body.subject_id);
  const subject = subjectId && db.prepare('SELECT id FROM subjects WHERE id = ?').get(subjectId);
  if (!subject) return res.status(400).json({ error: 'That unit does not exist.' });

  const term = currentTerm();
  const exists = db.prepare(
    'SELECT id FROM unit_registrations WHERE student_id = ? AND subject_id = ? AND term = ?'
  ).get(req.student.id, subjectId, term);
  if (exists) return res.status(400).json({ error: 'You have already registered this unit.' });

  db.prepare('INSERT INTO unit_registrations (student_id, subject_id, term) VALUES (?, ?, ?)')
    .run(req.student.id, subjectId, term);
  res.status(201).json({ success: true, term });
});

router.delete('/units/:subjectId', (req, res) => {
  const subjectId = toId(req.params.subjectId);
  const term = currentTerm();

  const hasResults = db.prepare(`
    SELECT 1 AS found FROM grades g JOIN exams e ON e.id = g.exam_id
    WHERE g.student_id = ? AND g.subject_id = ? AND (e.term || ' ' || e.year) = ?
  `).get(req.student.id, subjectId, term);
  if (hasResults) {
    return res.status(400).json({ error: 'You already have results for this unit this term, so it cannot be dropped.' });
  }

  const removed = db.prepare(
    'DELETE FROM unit_registrations WHERE student_id = ? AND subject_id = ? AND term = ?'
  ).run(req.student.id, subjectId, term);
  if (removed.changes === 0) return res.status(404).json({ error: 'You are not registered for that unit.' });
  res.json({ success: true });
});

// ---------- results ----------

router.get('/results', (req, res) => {
  res.json({ passMark: passMark(), results: resultsFor(req.student.id) });
});

// ---------- supplementary exams ----------

router.get('/supplementary', (req, res) => {
  const results = resultsFor(req.student.id);
  // A rejected application can be sent again, so only pending and approved ones hide a result
  const eligible = results.filter((r) => !r.passed && (!r.supplementary_status || r.supplementary_status === 'rejected'));

  const applications = db.prepare(`
    SELECT sr.id, sr.reason, sr.status, sr.staff_comment, sr.created_at, sr.decided_at,
      sub.name AS unit_name, sub.code, e.name AS exam_name, e.kind, e.term, e.year, g.score
    FROM supplementary_requests sr
    JOIN subjects sub ON sub.id = sr.subject_id
    JOIN exams e ON e.id = sr.exam_id
    LEFT JOIN grades g ON g.student_id = sr.student_id AND g.subject_id = sr.subject_id AND g.exam_id = sr.exam_id
    WHERE sr.student_id = ?
    ORDER BY sr.created_at DESC, sr.id DESC
  `).all(req.student.id);

  res.json({ passMark: passMark(), eligible, applications });
});

router.post('/supplementary', (req, res) => {
  const examId = toId(req.body.exam_id);
  const subjectId = toId(req.body.subject_id);
  const reason = String(req.body.reason || '').trim();
  if (!examId || !subjectId) return res.status(400).json({ error: 'Choose the unit you want to apply for.' });
  if (reason.length < 5) return res.status(400).json({ error: 'Please give a reason for your application.' });

  const grade = db.prepare(
    'SELECT score FROM grades WHERE student_id = ? AND exam_id = ? AND subject_id = ?'
  ).get(req.student.id, examId, subjectId);
  if (!grade) return res.status(400).json({ error: 'You have no result for that unit.' });
  if (grade.score >= passMark()) {
    return res.status(400).json({ error: `You passed this unit, so no supplementary is needed (pass mark is ${passMark()}).` });
  }

  const existing = db.prepare(
    'SELECT id, status FROM supplementary_requests WHERE student_id = ? AND exam_id = ? AND subject_id = ?'
  ).get(req.student.id, examId, subjectId);

  if (existing && existing.status !== 'rejected') {
    return res.status(400).json({ error: 'You have already applied for this unit.' });
  }
  if (existing) {
    db.prepare(`
      UPDATE supplementary_requests
      SET reason = ?, status = 'pending', staff_comment = NULL, decided_at = NULL, decided_by = NULL, created_at = datetime('now')
      WHERE id = ?
    `).run(reason, existing.id);
  } else {
    db.prepare(
      'INSERT INTO supplementary_requests (student_id, subject_id, exam_id, reason) VALUES (?, ?, ?, ?)'
    ).run(req.student.id, subjectId, examId, reason);
  }
  res.status(201).json({ success: true });
});

router.delete('/supplementary/:id', (req, res) => {
  const removed = db.prepare(
    "DELETE FROM supplementary_requests WHERE id = ? AND student_id = ? AND status = 'pending'"
  ).run(toId(req.params.id), req.student.id);
  if (removed.changes === 0) {
    return res.status(400).json({ error: 'Only your own pending applications can be withdrawn.' });
  }
  res.json({ success: true });
});

// ---------- timetable ----------

router.get('/timetable', (req, res) => {
  const student = req.student;
  const mine = new Set(registeredUnits(student.id, currentTerm()).map((u) => u.subject_id));

  const slots = db.prepare(`
    SELECT t.id, t.day, t.start_time, t.end_time, t.room,
      sub.id AS subject_id, sub.name AS unit_name, sub.code, te.name AS lecturer
    FROM timetables t
    LEFT JOIN subjects sub ON sub.id = t.subject_id
    LEFT JOIN teachers te ON te.id = t.teacher_id
    WHERE t.class_id = ?
    ORDER BY t.start_time
  `).all(student.class_id || 0).map((slot) => ({ ...slot, registered: mine.has(slot.subject_id) }));

  res.json({
    class_name: student.class_name ? `${student.class_name} ${student.class_stream}` : null,
    slots,
  });
});

// ---------- e-content ----------

router.get('/content', (req, res) => {
  const student = req.student;
  const mine = new Set(registeredUnits(student.id, currentTerm()).map((u) => u.subject_id));

  // Material with no class (or a blank one) is for everybody
  const items = db.prepare(`
    SELECT m.id, m.title, m.description, m.url, m.file_path, m.created_at,
      sub.id AS subject_id, sub.name AS unit_name, sub.code, te.name AS lecturer
    FROM learning_materials m
    LEFT JOIN subjects sub ON sub.id = m.subject_id
    LEFT JOIN teachers te ON te.id = m.teacher_id
    WHERE m.class_id IS NULL OR m.class_id = '' OR m.class_id = ?
    ORDER BY m.created_at DESC, m.id DESC
  `).all(student.class_id || 0).map((item) => ({ ...item, registered: mine.has(item.subject_id) }));

  res.json({ items });
});

module.exports = router;
