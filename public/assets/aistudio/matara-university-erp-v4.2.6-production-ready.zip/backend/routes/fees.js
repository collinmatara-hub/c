const express = require('express');
const { db } = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');
const router = express.Router();

router.get('/', requireAuth, requireRole('admin','vice_chancellor','deputy_vc','registrar','finance_director','finance_officer','auditor','accounts'), (req, res) => {
  const rows = db.prepare(`SELECT f.*, s.name student_name,s.adm_no,c.name class_name,
    COALESCE((SELECT SUM(p.amount) FROM fee_payments p WHERE p.fee_id=f.id AND p.status='posted'),0) allocated_paid
    FROM fees f JOIN students s ON s.id=f.student_id LEFT JOIN classes c ON c.id=s.class_id ORDER BY f.due_date ASC,f.id DESC`).all();
  res.json(rows);
});

router.get('/student/:studentId', requireAuth, (req,res)=>{
  const id=Number(req.params.studentId);
  if(req.user.role==='student') { const own=db.prepare('SELECT id FROM students WHERE user_id=?').get(req.user.id)?.id; if(own!==id)return res.status(403).json({error:'Not authorised'}); }
  if(req.user.role==='parent') { const p=db.prepare('SELECT id FROM parents WHERE user_id=?').get(req.user.id); const ok=p&&db.prepare('SELECT 1 FROM parent_students WHERE parent_id=? AND student_id=?').get(p.id,id); if(!ok)return res.status(403).json({error:'Not authorised'}); }
  const fees=db.prepare(`SELECT f.*,COALESCE((SELECT SUM(p.amount) FROM fee_payments p WHERE p.fee_id=f.id AND p.status='posted'),0) paid_allocated FROM fees f WHERE f.student_id=? ORDER BY f.id`).all(id);
  const payments=db.prepare('SELECT * FROM fee_payments WHERE student_id=? ORDER BY payment_date DESC,id DESC').all(id);
  res.json({fees,payments});
});

router.post('/', requireAuth, requireRole('admin','accounts'), (req,res) => {
  const { student_id, term, amount_due, amount_paid, due_date } = req.body;
  if (!student_id || !term || amount_due == null) return res.status(400).json({ error: 'student_id, term and amount_due are required.' });
  const result = db.prepare('INSERT INTO fees(student_id,term,amount_due,amount_paid,due_date) VALUES(?,?,?,?,?)').run(student_id,term,Number(amount_due),Number(amount_paid||0),due_date||null);
  if(Number(amount_paid||0)>0) db.prepare('INSERT INTO fee_payments(student_id,fee_id,amount,method,reference,received_by) VALUES(?,?,?,?,?,?)').run(student_id,result.lastInsertRowid,Number(amount_paid),'Opening Balance/Allocation','',req.user.id);
  res.status(201).json({ id: result.lastInsertRowid });
});

router.post('/payments', requireAuth, requireRole('admin','accounts'), (req,res)=>{
  const {student_id,fee_id,amount,method='Cash',reference='',payment_date,notes=''}=req.body;
  if(!student_id||!amount||Number(amount)<=0)return res.status(400).json({error:'student_id and a positive amount are required.'});
  const tx=db.transaction(()=>{
    const p=db.prepare('INSERT INTO fee_payments(student_id,fee_id,amount,method,reference,payment_date,notes,received_by) VALUES(?,?,?,?,?,?,?,?)').run(student_id,fee_id||null,Number(amount),method,reference,payment_date||new Date().toISOString().slice(0,10),notes,req.user.id);
    if(fee_id) db.prepare('UPDATE fees SET amount_paid=amount_paid+? WHERE id=?').run(Number(amount),fee_id);
    const receiptNo='MU-'+new Date().getFullYear()+'-'+String(Date.now()).slice(-6);
    const r=db.prepare('INSERT INTO receipts(receipt_no,student_id,payment_id,amount,method,reference) VALUES(?,?,?,?,?,?)').run(receiptNo,student_id,p.lastInsertRowid,Number(amount),method,reference);
    return {payment_id:p.lastInsertRowid,receipt_id:r.lastInsertRowid,receipt_no:receiptNo};
  });
  try{res.status(201).json({success:true,...tx()});}catch(e){res.status(400).json({error:e.message});}
});

router.put('/:id/pay', requireAuth, requireRole('admin','accounts'), (req, res) => {
  const { amount, method='Cash', reference='' } = req.body;
  const fee = db.prepare('SELECT * FROM fees WHERE id=?').get(req.params.id);
  if (!fee) return res.status(404).json({ error: 'Fee record not found.' });
  if (!amount || Number(amount) <= 0) return res.status(400).json({ error: 'Enter a valid payment amount.' });
  const result=db.prepare('INSERT INTO fee_payments(student_id,fee_id,amount,method,reference,received_by) VALUES(?,?,?,?,?,?)').run(fee.student_id,fee.id,Number(amount),method,reference,req.user.id);
  db.prepare('UPDATE fees SET amount_paid=amount_paid+? WHERE id=?').run(Number(amount),fee.id);
  const receiptNo='MU-'+new Date().getFullYear()+'-'+String(Date.now()).slice(-6);
  const r=db.prepare('INSERT INTO receipts(receipt_no,student_id,payment_id,amount,method,reference) VALUES(?,?,?,?,?,?)').run(receiptNo,fee.student_id,result.lastInsertRowid,Number(amount),method,reference);
  res.json({success:true,receipt:{id:r.lastInsertRowid,receipt_no:receiptNo,amount:Number(amount),student_id:fee.student_id}});
});

router.post('/payments/:id/reverse', requireAuth, requireRole('admin'), (req,res)=>{
  const p=db.prepare('SELECT * FROM fee_payments WHERE id=?').get(req.params.id); if(!p)return res.status(404).json({error:'Payment not found'}); if(p.status==='reversed')return res.status(400).json({error:'Payment already reversed'});
  const tx=db.transaction(()=>{db.prepare("UPDATE fee_payments SET status='reversed',reversed_at=datetime('now'),reversal_reason=? WHERE id=?").run(req.body.reason||'Admin reversal',p.id); if(p.fee_id)db.prepare('UPDATE fees SET amount_paid=MAX(0,amount_paid-?) WHERE id=?').run(p.amount,p.fee_id);}); tx(); res.json({success:true});
});

module.exports = router;
