const express = require('express');
const { db } = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');

const router = express.Router();

router.get('/', requireAuth, (req, res) => {
  const audience = req.user.role;
  const rows = db.prepare(`
    SELECT * FROM announcements
    WHERE audience = 'all' OR audience = ?
    ORDER BY created_at DESC
  `).all(audience);
  res.json(rows);
});

router.post('/', requireAuth, requireRole('admin', 'teacher'), (req, res) => {
  const { title, body, audience } = req.body;
  if (!title || !body) return res.status(400).json({ error: 'Title and body are required.' });
  const result = db.prepare(`
    INSERT INTO announcements (title, body, audience, author) VALUES (?, ?, ?, ?)
  `).run(title, body, audience || 'all', req.user.name);
  res.status(201).json({ id: result.lastInsertRowid });
});

router.delete('/:id', requireAuth, requireRole('admin', 'teacher'), (req, res) => {
  db.prepare('DELETE FROM announcements WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

module.exports = router;
