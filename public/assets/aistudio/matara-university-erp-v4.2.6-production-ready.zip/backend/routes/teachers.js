const express = require('express');
const bcrypt = require('bcryptjs');
const { db } = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');

const router = express.Router();

router.get('/', requireAuth, (req, res) => {
  const rows = db.prepare('SELECT * FROM teachers ORDER BY name ASC').all();
  res.json(rows);
});

router.post('/', requireAuth, requireRole('admin'), (req, res) => {
  const { name, staff_no, phone, specialty, email, password } = req.body;
  if (!name || !staff_no) return res.status(400).json({ error: 'Name and staff number are required.' });
  try {
    let userId = null;
    if (email && password) {
      const u = db.prepare(`INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, 'teacher')`)
        .run(name, email.toLowerCase().trim(), bcrypt.hashSync(password, 10));
      userId = u.lastInsertRowid;
    }
    const result = db.prepare(`
      INSERT INTO teachers (user_id, staff_no, name, phone, specialty) VALUES (?, ?, ?, ?, ?)
    `).run(userId, staff_no, name, phone || null, specialty || null);
    res.status(201).json({ id: result.lastInsertRowid });
  } catch (err) {
    res.status(400).json({ error: 'That staff number or email is already in use.' });
  }
});

router.put('/:id', requireAuth, requireRole('admin'), (req, res) => {
  const existing = db.prepare('SELECT * FROM teachers WHERE id = ?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'Teacher not found.' });
  const { name, phone, specialty } = req.body;
  db.prepare('UPDATE teachers SET name=?, phone=?, specialty=? WHERE id=?').run(
    name ?? existing.name, phone ?? existing.phone, specialty ?? existing.specialty, req.params.id
  );
  res.json({ success: true });
});

router.delete('/:id', requireAuth, requireRole('admin'), (req, res) => {
  db.prepare('DELETE FROM teachers WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

module.exports = router;
