// Reset local demo-account passwords without deleting university data.
// Run: node backend/reset-demo.js
const { db, init } = require('./db');
const bcrypt = require('bcryptjs');
init();
const password = process.env.DEMO_PASSWORD || 'MU-Demo-2026';
const emails = [
  'admin@matara.ac.ke',
  'otieno@matara.ac.ke',
  'achieng@matara.ac.ke',
  'kiptoo@matara.ac.ke',
  'amani@matara.ac.ke',
];
const update = db.prepare("UPDATE users SET password=?, session_version=session_version+1, password_changed_at=datetime('now') WHERE email=?");
let changed = 0;
for (const email of emails) {
  const r = update.run(bcrypt.hashSync(password, 10), email);
  changed += Number(r.changes || 0);
}
console.log(`Reset ${changed} demo account(s).`);
console.log(`Demo password: ${password}`);
db.close();
