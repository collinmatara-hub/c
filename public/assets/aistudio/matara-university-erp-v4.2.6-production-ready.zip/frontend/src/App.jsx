import { lazy, Suspense } from 'react';
import { Routes, Route, Navigate, useParams } from 'react-router-dom';
import { useAuth } from './context/AuthContext.jsx';
import { homeFor, STAFF_ROLES, ACADEMIC_ROLES, STUDENT_VIEW_ROLES } from './config/roles.js';
import ProtectedRoute from './components/ProtectedRoute.jsx';

// Keep the initial bundle small and prevent a problem in an unused module from
// stopping the login screen from rendering.
const Login = lazy(() => import('./pages/Login.jsx'));
const ForgotPassword = lazy(() => import('./pages/ForgotPassword.jsx'));
const Profile = lazy(() => import('./pages/Profile.jsx'));
const Attendance = lazy(() => import('./pages/Attendance.jsx'));
const Announcements = lazy(() => import('./pages/Announcements.jsx'));
const Messages = lazy(() => import('./pages/Messages.jsx'));
const Management = lazy(() => import('./pages/Management.jsx'));
const OnlineExamManager = lazy(() => import('./pages/OnlineExamManager.jsx'));

const AdminDashboard = lazy(() => import('./pages/admin/Dashboard.jsx'));
const Students = lazy(() => import('./pages/admin/Students.jsx'));
const Teachers = lazy(() => import('./pages/admin/Teachers.jsx'));
const Classes = lazy(() => import('./pages/admin/Classes.jsx'));
const Fees = lazy(() => import('./pages/admin/Fees.jsx'));
const Accounts = lazy(() => import('./pages/admin/Accounts.jsx'));
const Departments = lazy(() => import('./pages/admin/Departments.jsx'));
const Users = lazy(() => import('./pages/admin/Users.jsx'));
const ControlCenter = lazy(() => import('./pages/admin/ControlCenter.jsx'));
const Editors = lazy(() => import('./pages/admin/Editors.jsx'));
const Creatives = lazy(() => import('./pages/admin/Creatives.jsx'));
const Marks = lazy(() => import('./pages/academics/Marks.jsx'));
const SupplementaryReview = lazy(() => import('./pages/academics/SupplementaryReview.jsx'));
const StudentProfile = lazy(() => import('./pages/admin/StudentProfile.jsx'));
const StudentCards = lazy(() => import('./pages/admin/StudentCards.jsx'));
const V3Admin = lazy(() => import('./pages/V3Admin.jsx'));
const V3Documents = lazy(() => import('./pages/V3Documents.jsx'));
const VerifyDocument = lazy(() => import('./pages/VerifyDocument.jsx'));
const Reports = lazy(() => import('./pages/admin/Reports.jsx'));
const TimetableManagement = lazy(() => import('./pages/admin/TimetableManagement.jsx'));
const TimetableMaker = lazy(() => import('./pages/timetable/TimetableMaker.jsx'));
const MyTimetable = lazy(() => import('./pages/timetable/MyTimetable.jsx'));
const FeeStatement = lazy(() => import('./pages/student/FeeStatement.jsx'));

const TeacherDashboard = lazy(() => import('./pages/teacher/Dashboard.jsx'));
const TeacherExams = lazy(() => import('./pages/teacher/Exams.jsx'));
const Grading = lazy(() => import('./pages/teacher/Grading.jsx'));

const StudentDashboard = lazy(() => import('./pages/student/Dashboard.jsx'));
const LMSDashboard = lazy(() => import('./pages/student/LMSDashboard.jsx'));
const LecturerLMSDashboard = lazy(() => import('./pages/teacher/LMSDashboard.jsx'));
const LMSLiveClasses = lazy(() => import('./pages/LMSLiveClasses.jsx'));
const LMSConference = lazy(() => import('./pages/LMSConference.jsx'));
const LMSAssignments = lazy(() => import('./pages/LMSAssignments.jsx'));
const StudentExams = lazy(() => import('./pages/student/Exams.jsx'));
const Units = lazy(() => import('./pages/student/Units.jsx'));
const Results = lazy(() => import('./pages/student/Results.jsx'));
const Supplementary = lazy(() => import('./pages/student/Supplementary.jsx'));
const Timetable = lazy(() => import('./pages/student/Timetable.jsx'));
const EContent = lazy(() => import('./pages/student/EContent.jsx'));
const StudentDegreeAudit = lazy(() => import('./pages/student/DegreeAudit.jsx'));

const StaffDashboard = lazy(() => import('./pages/staff/Dashboard.jsx'));
const StaffOperations = lazy(() => import('./pages/staff/Operations.jsx'));
const UniversityCommandCenter = lazy(() => import('./pages/UniversityCommandCenter.jsx'));
const SecurityCenter = lazy(() => import('./pages/SecurityCenter.jsx'));
const DegreeAudit = lazy(() => import('./pages/university/DegreeAudit.jsx'));
const Graduation = lazy(() => import('./pages/university/Graduation.jsx'));
const HelpDesk = lazy(() => import('./pages/university/HelpDesk.jsx'));
const DataQuality = lazy(() => import('./pages/university/DataQuality.jsx'));
const UniversityCalendar = lazy(() => import('./pages/university/Calendar.jsx'));
const Advising = lazy(() => import('./pages/university/Advising.jsx'));
const VCDashboard = lazy(() => import('./pages/executive/VCDashboard.jsx'));
const RoleDesk = lazy(() => import('./pages/RoleDesk.jsx'));

function LoadingScreen() {
  return (
    <div className="grid min-h-screen place-items-center bg-paper px-6 text-ink">
      <div className="text-center">
        <div className="mx-auto mb-4 h-10 w-10 animate-spin rounded-full border-4 border-sage border-t-forest" />
        <p className="text-sm font-semibold">Loading Matara University ERP…</p>
      </div>
    </div>
  );
}

export default function App() {
  const { user } = useAuth();

  return (
    <Suspense fallback={<LoadingScreen />}>
      <Routes>
        <Route path="/profile" element={<ProtectedRoute roles={['admin','teacher','student',...STAFF_ROLES,...ACADEMIC_ROLES]}><Profile /></ProtectedRoute>} />
        <Route path="/vc" element={<ProtectedRoute roles={['admin','vice_chancellor','deputy_vc']}><VCDashboard /></ProtectedRoute>} />
        <Route path="/desk" element={<ProtectedRoute><RoleDesk /></ProtectedRoute>} />
        <Route path="/login" element={user ? <Navigate to={homeFor(user.role)} replace /> : <Login />} />
        <Route path="/forgot-password" element={user ? <Navigate to={homeFor(user.role)} replace /> : <ForgotPassword />} />

        <Route path="/admin" element={<ProtectedRoute roles={['admin']}><AdminDashboard /></ProtectedRoute>} />
        <Route path="/admin/v3/admissions" element={<ProtectedRoute roles={['admin','registrar','deputy_registrar','admissions_officer','vice_chancellor','deputy_vc']}><V3Admin type="admissions" /></ProtectedRoute>} />
        <Route path="/admin/v3/payroll" element={<ProtectedRoute roles={['admin','hr_director','hr_officer']}><V3Admin type="payroll" /></ProtectedRoute>} />
        <Route path="/admin/v3/payments" element={<ProtectedRoute roles={['admin','finance_director','finance_officer','auditor']}><V3Admin type="payments" /></ProtectedRoute>} />
        <Route path="/admin/v3/documents" element={<ProtectedRoute roles={['admin','registrar','examination_officer','exam_board']}><V3Documents /></ProtectedRoute>} />
        <Route path="/verify/:code" element={<VerifyDocument />} />
        <Route path="/admin/v3/lms" element={<ProtectedRoute roles={['admin','ict','vice_chancellor','registrar']}><V3Admin type="lms" /></ProtectedRoute>} />
        <Route path="/admin/degree-audit" element={<ProtectedRoute roles={['admin','vice_chancellor','registrar','deputy_registrar','dean','deputy_dean','hod','examination_officer','exam_board','lecturer','senior_lecturer','professor','academic_staff']}><DegreeAudit /></ProtectedRoute>} />
        <Route path="/admin/advising" element={<ProtectedRoute roles={ACADEMIC_ROLES.concat(['admin','vice_chancellor','registrar','dean','deputy_dean','hod','student_affairs_officer'])}><Advising /></ProtectedRoute>} />
        <Route path="/admin/graduation" element={<ProtectedRoute roles={['admin','vice_chancellor','registrar','deputy_registrar','dean','deputy_dean','hod','examination_officer','exam_board','auditor']}><Graduation /></ProtectedRoute>} />
        <Route path="/admin/data-quality" element={<ProtectedRoute roles={['admin','vice_chancellor','registrar','auditor','ict']}><DataQuality /></ProtectedRoute>} />
        <Route path="/help-desk" element={<ProtectedRoute roles={['admin','student','staff','accounts','librarian','nurse','ict','helpdesk_l1','helpdesk_l2',...STAFF_ROLES,...ACADEMIC_ROLES]}><HelpDesk /></ProtectedRoute>} />
        <Route path="/calendar" element={<ProtectedRoute roles={['admin','student',...STAFF_ROLES,...ACADEMIC_ROLES]}><UniversityCalendar /></ProtectedRoute>} />
        <Route path="/admin/v3/backups" element={<ProtectedRoute roles={['admin','ict','auditor']}><V3Admin type="backups" /></ProtectedRoute>} />

        <Route path="/admin/control-center" element={<ProtectedRoute roles={['admin']}><ControlCenter /></ProtectedRoute>} />
        <Route path="/admin/editors" element={<ProtectedRoute roles={['admin','super_admin']}><Editors /></ProtectedRoute>} />
        <Route path="/admin/creatives" element={<ProtectedRoute><Creatives /></ProtectedRoute>} />
        <Route path="/admin/users" element={<ProtectedRoute roles={['admin']}><Users /></ProtectedRoute>} />
        <Route path="/admin/students" element={<ProtectedRoute roles={STUDENT_VIEW_ROLES}><Students /></ProtectedRoute>} />
        <Route path="/admin/students/:id" element={<ProtectedRoute roles={STUDENT_VIEW_ROLES}><StudentProfile /></ProtectedRoute>} />
        <Route path="/admin/student-cards" element={<ProtectedRoute roles={['admin','super_admin','ict','registrar','deputy_registrar','admissions_officer','security','security_officer','gate_security']}><StudentCards /></ProtectedRoute>} />
        <Route path="/student/exam-card" element={<ProtectedRoute roles={['student']}><StudentExams /></ProtectedRoute>} />
        <Route path="/admin/teachers" element={<ProtectedRoute roles={['admin','dean','deputy_dean','hod','registrar','deputy_registrar','finance_director','finance_officer','hr_director','hr_officer']}><Teachers /></ProtectedRoute>} />
        <Route path="/admin/classes" element={<ProtectedRoute roles={['admin','dean','deputy_dean','hod','registrar','deputy_registrar']}><Classes /></ProtectedRoute>} />
        <Route path="/admin/attendance" element={<ProtectedRoute roles={['admin']}><Attendance /></ProtectedRoute>} />
        <Route path="/admin/fees" element={<ProtectedRoute roles={['admin','finance_director','finance_officer','accounts']}><Fees /></ProtectedRoute>} />
        <Route path="/admin/accounts" element={<ProtectedRoute roles={['admin','finance_director','finance_officer','accounts']}><Accounts /></ProtectedRoute>} />
        <Route path="/admin/departments" element={<ProtectedRoute roles={['admin','registrar','deputy_registrar','dean','deputy_dean','hod']}><Departments /></ProtectedRoute>} />
        <Route path="/admin/announcements" element={<ProtectedRoute roles={['admin']}><Announcements /></ProtectedRoute>} />
        <Route path="/admin/marks" element={<ProtectedRoute roles={['admin']}><Marks /></ProtectedRoute>} />
        <Route path="/admin/supplementary" element={<ProtectedRoute roles={['admin']}><SupplementaryReview /></ProtectedRoute>} />
        <Route path="/admin/messages" element={<ProtectedRoute roles={['admin']}><Messages /></ProtectedRoute>} />
        <Route path="/admin/online-exams" element={<ProtectedRoute roles={['admin']}><OnlineExamManager /></ProtectedRoute>} />
        <Route path="/timetable-maker" element={<ProtectedRoute roles={['admin','timetabling_officer','registrar','deputy_registrar','dean','deputy_dean','hod']}><TimetableMaker /></ProtectedRoute>} />
        <Route path="/my-timetable" element={<ProtectedRoute roles={['student','teacher','lecturer','senior_lecturer','professor','academic_staff']}><MyTimetable /></ProtectedRoute>} />
        <Route path="/admin/timetable" element={<ProtectedRoute roles={['admin','registrar','deputy_registrar','dean','deputy_dean','hod','timetabling_officer']}><TimetableManagement /></ProtectedRoute>} />
        <Route path="/admin/reports" element={<ProtectedRoute roles={['admin','finance_director','finance_officer','hr_director','hr_officer','registrar','deputy_registrar','dean','deputy_dean','hod','examination_officer','exam_board','auditor']}><Reports /></ProtectedRoute>} />
        <Route path="/admin/reports/:report" element={<ProtectedRoute roles={['admin','finance_director','finance_officer','hr_director','hr_officer','registrar','deputy_registrar','dean','deputy_dean','hod','examination_officer','exam_board','auditor']}><Reports /></ProtectedRoute>} />
        <Route path="/admin/:resource" element={<ProtectedRoute roles={['admin']}><AdminManagementRoute /></ProtectedRoute>} />

        <Route path="/teacher" element={<ProtectedRoute roles={ACADEMIC_ROLES}><TeacherDashboard /></ProtectedRoute>} />
        <Route path="/lecturer/lms" element={<ProtectedRoute roles={ACADEMIC_ROLES}><LecturerLMSDashboard /></ProtectedRoute>} />
        <Route path="/lecturer/lms/online-classes" element={<ProtectedRoute roles={ACADEMIC_ROLES}><LMSLiveClasses /></ProtectedRoute>} />
        <Route path="/lecturer/lms/classroom/:id" element={<ProtectedRoute roles={ACADEMIC_ROLES}><LMSConference /></ProtectedRoute>} />
        <Route path="/student/lms/online-classes" element={<ProtectedRoute roles={['student']}><LMSLiveClasses /></ProtectedRoute>} />
        <Route path="/student/lms/classroom/:id" element={<ProtectedRoute roles={['student']}><LMSConference /></ProtectedRoute>} />
        <Route path="/lecturer/lms/assignments" element={<ProtectedRoute roles={ACADEMIC_ROLES}><LMSAssignments /></ProtectedRoute>} />
        <Route path="/teacher/attendance" element={<ProtectedRoute roles={ACADEMIC_ROLES}><Attendance /></ProtectedRoute>} />
        <Route path="/teacher/announcements" element={<ProtectedRoute roles={ACADEMIC_ROLES}><Announcements /></ProtectedRoute>} />
        <Route path="/teacher/exams" element={<ProtectedRoute roles={ACADEMIC_ROLES}><TeacherExams /></ProtectedRoute>} />
        <Route path="/teacher/grading" element={<ProtectedRoute roles={ACADEMIC_ROLES}><Grading /></ProtectedRoute>} />
        <Route path="/teacher/marks" element={<ProtectedRoute roles={ACADEMIC_ROLES}><Marks /></ProtectedRoute>} />
        <Route path="/teacher/supplementary" element={<ProtectedRoute roles={ACADEMIC_ROLES}><SupplementaryReview /></ProtectedRoute>} />
        <Route path="/teacher/messages" element={<ProtectedRoute roles={ACADEMIC_ROLES}><Messages /></ProtectedRoute>} />
        <Route path="/teacher/materials" element={<ProtectedRoute roles={ACADEMIC_ROLES}><Management resource="materials" /></ProtectedRoute>} />
        <Route path="/teacher/online-exams" element={<ProtectedRoute roles={ACADEMIC_ROLES}><OnlineExamManager /></ProtectedRoute>} />

        <Route path="/staff" element={<ProtectedRoute roles={STAFF_ROLES}><StaffDashboard /></ProtectedRoute>} />
        <Route path="/staff/announcements" element={<ProtectedRoute roles={STAFF_ROLES}><Announcements /></ProtectedRoute>} />
        <Route path="/staff/messages" element={<ProtectedRoute roles={STAFF_ROLES}><Messages /></ProtectedRoute>} />
        <Route path="/staff/finance" element={<ProtectedRoute roles={['accounts']}><StaffOperations type="accounts" /></ProtectedRoute>} />
        <Route path="/staff/library" element={<ProtectedRoute roles={['librarian']}><StaffOperations type="librarian" /></ProtectedRoute>} />
        <Route path="/staff/medical" element={<ProtectedRoute roles={['nurse']}><StaffOperations type="nurse" /></ProtectedRoute>} />
        <Route path="/staff/system" element={<ProtectedRoute roles={['ict']}><StaffOperations type="ict" /></ProtectedRoute>} />

        <Route path="/security" element={<ProtectedRoute roles={['admin','vice_chancellor','deputy_vc','registrar','deputy_registrar','security_officer','auditor','student_affairs_officer','accommodation_officer','medical_officer']}><SecurityCenter /></ProtectedRoute>} />
        <Route path="/university" element={<ProtectedRoute roles={['admin',...STAFF_ROLES,'vice_chancellor','deputy_vc','registrar','deputy_registrar','finance_director','finance_officer','hr_director','hr_officer','dean','deputy_dean','hod','lecturer','senior_lecturer','professor','academic_staff','non_academic_staff','admissions_officer','examination_officer','exam_board','procurement_officer','stores_officer','asset_officer','facilities_officer','transport_officer','security_officer','medical_officer','counselor','research_officer','student_affairs_officer','accommodation_officer','auditor','applicant','alumni']}><UniversityCommandCenter /></ProtectedRoute>} />

        <Route path="/student" element={<ProtectedRoute roles={['student']}><StudentDashboard /></ProtectedRoute>} />
        <Route path="/student/lms" element={<ProtectedRoute roles={['student']}><LMSDashboard /></ProtectedRoute>} />
        <Route path="/student/lms/assignments" element={<ProtectedRoute roles={['student']}><LMSAssignments /></ProtectedRoute>} />
        <Route path="/student/announcements" element={<ProtectedRoute roles={['student']}><Announcements /></ProtectedRoute>} />
        <Route path="/student/units" element={<ProtectedRoute roles={['student']}><Units /></ProtectedRoute>} />
        <Route path="/student/timetable" element={<ProtectedRoute roles={['student']}><Timetable /></ProtectedRoute>} />
        <Route path="/student/content" element={<ProtectedRoute roles={['student']}><EContent /></ProtectedRoute>} />
        <Route path="/student/degree-audit" element={<ProtectedRoute roles={['student']}><StudentDegreeAudit /></ProtectedRoute>} />
        <Route path="/student/results" element={<ProtectedRoute roles={['student']}><Results /></ProtectedRoute>} />
        <Route path="/student/fees" element={<ProtectedRoute roles={['student']}><FeeStatement /></ProtectedRoute>} />
        <Route path="/student/supplementary" element={<ProtectedRoute roles={['student']}><Supplementary /></ProtectedRoute>} />
        <Route path="/student/messages" element={<ProtectedRoute roles={['student']}><Messages /></ProtectedRoute>} />
        <Route path="/student/exams" element={<ProtectedRoute roles={['student']}><OnlineExamManager student={user?.role==='student'} readonly={false} /></ProtectedRoute>} />

        <Route path="/" element={<Navigate to={user ? homeFor(user.role) : '/login'} replace />} />
        <Route path="*" element={<Navigate to={user ? homeFor(user.role) : '/login'} replace />} />
      </Routes>
    </Suspense>
  );
}

function AdminManagementRoute({ reportMode = false }) {
  const params = useParams();
  const resource = params.resource;
  const known = resource && ['departments','units','staff','years','terms','timetable','assignments','materials','books','medical','transport','boarding','vehicles','drivers','routes','houses','dormitories','discipline','events','expenses','income','grading','admissions','alumni','curriculum','lessonplans','examschedules','studentleave','feestructures','scholarships','staffleave','payroll','appraisals','inventory','assets','vendors','procurement','templates','documents','branches'].includes(resource);
  if (!reportMode && !known) return <Navigate to="/admin" replace />;
  return <Management {...(reportMode ? { report: params.report } : { resource })} />;
}
