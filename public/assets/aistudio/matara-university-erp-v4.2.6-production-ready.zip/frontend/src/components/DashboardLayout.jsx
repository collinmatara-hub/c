import Sidebar from './Sidebar.jsx';
import Topbar from './Topbar.jsx';
import { useAuth } from '../context/AuthContext.jsx';
import { homeFor } from '../config/roles.js';

export default function DashboardLayout({ title, subtitle, hideTitle = false, children }) {
  const { user, exitView } = useAuth();
  async function stop() {
    try { const admin = await exitView(); window.location.assign(homeFor(admin.role)); } catch (_) { /* stays in view mode */ }
  }
  return <div className="min-h-screen bg-paper">
    {user?.imp && (
      <div role="status" className="sticky top-0 z-50 flex flex-wrap items-center justify-center gap-3 bg-gold px-4 py-2 text-sm font-semibold text-ink">
        <span>You are viewing as {user.name}. This view is read-only.</span>
        <button type="button" className="btn-secondary !py-1" onClick={stop}>Return to my account</button>
      </div>
    )}
    <Sidebar />
    <div className="dashboard-shell">
      <Topbar />
      <main className="dashboard-main">
        {!hideTitle && title && <div className="mb-6"><h1 className="font-display text-2xl font-bold text-ink">{title}</h1>{subtitle && <p className="mt-1 text-sm text-ink/55">{subtitle}</p>}</div>}
        <div className="animate-fade-up">{children}</div>
      </main>
    </div>
  </div>;
}
