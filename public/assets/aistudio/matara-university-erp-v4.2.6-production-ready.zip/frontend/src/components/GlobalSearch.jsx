import { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search } from 'lucide-react';
import api from '../api/axios.js';
import useClickOutside from '../hooks/useClickOutside.js';
import { useAuth } from '../context/AuthContext.jsx';
import { navFor, flattenNav } from '../config/nav.js';

const MAX_RESULTS = 8;

// Search box in the top bar. Finds pages for everyone.
// Admins can also find students, staff, programs and university pages. Press Ctrl+K (or Cmd+K) to jump to it.
export default function GlobalSearch() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [query, setQuery] = useState('');
  const [open, setOpen] = useState(false);
  const [people, setPeople] = useState(null);
  const [searching, setSearching] = useState(false);
  const inputRef = useRef(null);
  const boxRef = useRef(null);
  useClickOutside(boxRef, () => setOpen(false));

  const pages = useMemo(() => flattenNav(navFor(user?.role)), [user?.role]);
  const isAdmin = user?.role === 'admin';

  useEffect(() => {
    function onKey(event) {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') {
        event.preventDefault();
        inputRef.current?.focus();
      }
    }
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  useEffect(()=>{
    const text=query.trim(); if(text.length<2||!isAdmin){setPeople(null);return;}
    let active=true; const timer=setTimeout(async()=>{try{setSearching(true);const r=await api.get('/erp/search',{params:{q:text}});if(active)setPeople(r.data)}catch(_){if(active)setPeople({students:[],teachers:[],classes:[],books:[],receipts:[]})}finally{if(active)setSearching(false)}},220);
    return()=>{active=false;clearTimeout(timer)};
  },[query,isAdmin]);

  const results = useMemo(() => {
    const text=query.trim().toLowerCase(); if(!text)return []; const found=[];
    pages.forEach(page=>{if(`${page.label} ${page.group||''}`.toLowerCase().includes(text))found.push({key:`page-${page.to}`,label:page.label,hint:page.group?`Page · ${page.group}`:'Page',to:page.to});});
    if(people){
      people.students?.forEach(s=>{if(`${s.name} ${s.adm_no}`.toLowerCase().includes(text))found.push({key:`student-${s.id}`,label:s.name,hint:`Student · ${s.adm_no}`,to:`/admin/students/${s.id}`})});
      people.teachers?.forEach(t=>{if(`${t.name} ${t.staff_no}`.toLowerCase().includes(text))found.push({key:`teacher-${t.id}`,label:t.name,hint:`Lecturer · ${t.staff_no}`,to:'/admin/teachers'})});
      people.staff?.forEach(st=>{if(`${st.name} ${st.email||''} ${st.position||''} ${st.employee_no||''}`.toLowerCase().includes(text))found.push({key:`staff-${st.id}`,label:st.name,hint:`Staff · ${st.position||'University staff'}`,to:'/admin/users'})});
      people.programs?.forEach(p=>{if(`${p.name} ${p.code||''} ${p.award||''}`.toLowerCase().includes(text))found.push({key:`program-${p.id}`,label:p.name,hint:`Program · ${p.code||''}`,to:'/university'})});
      people.classes?.forEach(c=>{if(`${c.name} ${c.stream}`.toLowerCase().includes(text))found.push({key:`class-${c.id}`,label:`${c.name} ${c.stream}`,hint:'Class',to:'/admin/classes'})});
      
      people.books?.forEach(b=>{if(`${b.title} ${b.author||''} ${b.isbn||''}`.toLowerCase().includes(text))found.push({key:`book-${b.id}`,label:b.title,hint:'Library book',to:'/admin/books'})});
    }
    return found.slice(0,MAX_RESULTS);
  },[query,pages,people]);

  function go(result) {
    navigate(result.to);
    setQuery('');
    setOpen(false);
    inputRef.current?.blur();
  }

  function onKeyDown(event) {
    if (event.key === 'Enter' && results.length > 0) go(results[0]);
    if (event.key === 'Escape') {
      setOpen(false);
      inputRef.current?.blur();
    }
  }

  return (
    <div className="relative w-full" ref={boxRef}>
      <Search size={18} className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-forest" />
      <input
        ref={inputRef}
        type="search"
        value={query}
        onChange={(e) => { setQuery(e.target.value); setOpen(true); }}
        onFocus={() => setOpen(true)}
        onKeyDown={onKeyDown}
        placeholder={isAdmin ? 'Search students, staff, programs, pages…' : 'Search pages…'}
        aria-label="Search"
        className="h-12 w-full rounded-full border border-sage bg-surface pl-11 pr-16 text-sm text-ink shadow-sm outline-none transition placeholder:text-ink/40 focus:border-forest focus:ring-2 focus:ring-forest/15 [&::-webkit-search-cancel-button]:hidden"
      />
      <kbd className="pointer-events-none absolute right-4 top-1/2 hidden -translate-y-1/2 rounded-md border border-sage bg-paper px-1.5 py-0.5 text-[11px] font-medium text-ink/50 sm:block">
        Ctrl K
      </kbd>

      {open && query.trim() && (
        <div className="card absolute left-0 right-0 top-full z-50 mt-2 max-h-96 overflow-y-auto p-2">
          {searching ? <p className="px-3 py-6 text-center text-sm text-ink/45">Searching…</p> : results.length === 0 ? (
            <p className="px-3 py-6 text-center text-sm text-ink/45">Nothing found for "{query.trim()}".</p>
          ) : (
            <ul>
              {results.map((result) => (
                <li key={result.key}>
                  <button
                    type="button"
                    onClick={() => go(result)}
                    className="flex w-full items-center justify-between gap-3 rounded-xl px-3 py-2.5 text-left hover:bg-forest/10"
                  >
                    <span className="truncate text-sm font-medium text-ink">{result.label}</span>
                    <span className="shrink-0 text-xs text-ink/45">{result.hint}</span>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}
