export default function PageHeader({ eyebrow, title, subtitle, actions }) {
  return (
    <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
      <div>
        {eyebrow && <p className="page-eyebrow">{eyebrow}</p>}
        <h2 className="mt-1 font-display text-xl font-semibold text-ink">{title}</h2>
        {subtitle && <p className="mt-1 max-w-3xl text-sm text-ink/55">{subtitle}</p>}
      </div>
      {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
    </div>
  );
}
