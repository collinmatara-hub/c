import { ROLE_CATEGORIES, ROLE_OPTIONS } from '../config/roles.js';

// A role drop-down grouped under the university's role categories.
export default function RoleSelect({ value, onChange, className = 'input', allLabel, ariaLabel }) {
  return (
    <select className={className} value={value} onChange={(e) => onChange(e.target.value)} aria-label={ariaLabel}>
      {allLabel && <option value="all">{allLabel}</option>}
      {ROLE_CATEGORIES.map((category) => {
        const roles = ROLE_OPTIONS.filter((r) => r.category === category.key);
        if (!roles.length) return null;
        return (
          <optgroup key={category.key} label={category.label}>
            {roles.map((r) => <option key={r.value} value={r.value}>{r.label}</option>)}
          </optgroup>
        );
      })}
    </select>
  );
}
