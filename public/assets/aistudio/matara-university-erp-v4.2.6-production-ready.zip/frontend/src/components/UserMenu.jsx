import { useRef, useState } from 'react';
import { ChevronDown, LogOut, UserRound } from 'lucide-react';
import useClickOutside from '../hooks/useClickOutside.js';
import { useAuth } from '../context/AuthContext.jsx';
import { roleLabel } from '../config/roles.js';
import { firstName } from '../utils/format.js';
import { useNavigate } from 'react-router-dom';

export default function UserMenu() {
  const { user, logout } = useAuth();
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();
  const ref = useRef(null);
  useClickOutside(ref, () => setOpen(false));

  const initials = user?.name?.split(' ').map((n) => n[0]).slice(0, 2).join('').toUpperCase() || 'MG';

  return (
    <div className="relative" ref={ref}>
      <button
        type="button"
        onClick={() => setOpen(!open)}
        aria-haspopup="menu"
        aria-expanded={open}
        className="flex items-center gap-2.5 rounded-2xl p-1.5 transition hover:bg-forest/10 lg:pr-2.5"
      >
        {user?.profile_image_url ? <img src={user.profile_image_url} alt="" className="h-10 w-10 rounded-full object-cover"/> : <span className="flex h-10 w-10 items-center justify-center rounded-full bg-forest text-sm font-bold text-on-forest">{initials}</span>}
        <span className="hidden text-left leading-tight lg:block">
          <span className="block text-sm font-semibold text-ink">{firstName(user?.name)}</span>
          <span className="block text-[11px] text-ink/55">{roleLabel(user?.role)}</span>
        </span>
        <ChevronDown size={16} className="hidden text-ink/50 lg:block" />
      </button>

      {open && (
        <div role="menu" className="card absolute right-0 top-full z-50 mt-2 w-64 p-2">
          <div className="border-b border-sage/70 px-3 pb-3 pt-2">
            <p className="truncate text-sm font-semibold text-ink">{user?.name}</p>
            <p className="truncate text-xs text-ink/50">{user?.email}</p>
          </div>
          <button type="button" role="menuitem" onClick={() => { setOpen(false); navigate('/profile'); }} className="nav-link mt-2">
            <UserRound size={17} /> My profile & security
          </button>
          <button type="button" role="menuitem" onClick={logout} className="nav-link mt-1">
            <LogOut size={17} /> Sign out
          </button>
        </div>
      )}
    </div>
  );
}
