import { createPortal } from 'react-dom';

// Renders a popup on top of the whole app (above the sidebar and top bar).
// It is attached to document.body so page animations cannot resize or hide it.
export default function ModalOverlay({ onClose, children }) {
  return createPortal(
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center overflow-y-auto bg-navy/50 px-4 py-6"
      onMouseDown={(e) => { if (e.target === e.currentTarget && onClose) onClose(); }}
    >
      {children}
    </div>,
    document.body
  );
}
