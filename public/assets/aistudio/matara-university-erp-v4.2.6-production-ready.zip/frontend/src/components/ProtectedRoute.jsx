import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import { homeFor, effectiveRole } from '../config/roles.js';

export default function ProtectedRoute({ roles, children }) {
  const { user } = useAuth();

  if (!user) return <Navigate to="/login" replace />;
  // A role may open the pages of the older role it inherits from (for example a Helpdesk
  // Level 1 account uses the General Staff pages).
  if (roles && !roles.includes(user.role) && !roles.includes(effectiveRole(user.role))) {
    return <Navigate to={homeFor(user.role)} replace />;
  }
  return children;
}
