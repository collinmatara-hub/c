import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { MessageSquare } from 'lucide-react';
import api from '../api/axios.js';
import { useAuth } from '../context/AuthContext.jsx';

// Envelope icon in the top bar. The red number is how many messages have not been read yet.
export default function MessageBell() {
  const { user } = useAuth();
  const [count, setCount] = useState(0);
  const canMessage = ['admin', 'teacher', 'student'].includes(user?.role);

  useEffect(() => {
    if (!canMessage) return undefined;
    function check() {
      api.get('/messages/unread-count').then((res) => setCount(res.data.count)).catch(() => {});
    }
    check();
    const timer = setInterval(check, 60000);
    window.addEventListener('matara:messages-changed', check);
    return () => {
      clearInterval(timer);
      window.removeEventListener('matara:messages-changed', check);
    };
  }, [canMessage]);

  if (!canMessage) return null;

  return (
    <Link
      to={`/${user.role}/messages`}
      className="icon-btn"
      aria-label={count > 0 ? `Messages, ${count} unread` : 'Messages'}
      title="Messages"
    >
      <MessageSquare size={19} />
      {count > 0 && (
        <span className="absolute -right-0.5 -top-0.5 flex h-5 min-w-5 items-center justify-center rounded-full bg-clay px-1 text-[11px] font-bold text-white">
          {count}
        </span>
      )}
    </Link>
  );
}
