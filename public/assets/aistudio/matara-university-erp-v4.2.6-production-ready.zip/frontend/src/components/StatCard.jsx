export default function StatCard({ label, value, hint, icon: Icon, tone = 'green' }) {
  const tones = {
    green: 'bg-forest/10 text-forest',
    gold: 'bg-gold/15 text-gold-dark',
    clay: 'bg-clay/10 text-clay',
  };
  return (
    <div className="card group relative overflow-hidden p-5">
      <div className="pointer-events-none absolute -right-8 -top-8 h-24 w-24 rounded-full bg-forest/[0.035] transition-transform duration-300 group-hover:scale-125" />
      <div className="relative flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-[11px] font-bold uppercase tracking-[.08em] text-ink/45">{label}</p>
          <p className="mt-2 font-display text-3xl font-semibold tracking-tight text-ink">{value}</p>
          {hint && <p className="mt-1.5 truncate text-xs text-ink/45">{hint}</p>}
        </div>
        {Icon && (
          <div className={`rounded-xl p-3 ${tones[tone]} transition-transform duration-200 group-hover:scale-105`}>
            <Icon size={20} strokeWidth={2} />
          </div>
        )}
      </div>
    </div>
  );
}
