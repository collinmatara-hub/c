const STYLES = {
  pending: { className: 'badge-gold', label: 'Pending' },
  approved: { className: 'badge-green', label: 'Approved' },
  rejected: { className: 'badge-red', label: 'Rejected' },
};

// Pending / Approved / Rejected pill for supplementary applications
export default function StatusBadge({ status }) {
  const style = STYLES[status] || STYLES.pending;
  return <span className={`badge ${style.className}`}>{style.label}</span>;
}
