import { Moon, Sun } from 'lucide-react';
import { useTheme } from '../context/ThemeContext.jsx';

// Round sun/moon button for the top bar
export function ThemeIconButton() {
  const { theme, toggleTheme } = useTheme();
  const dark = theme === 'dark';
  return (
    <button
      type="button"
      className="icon-btn"
      onClick={toggleTheme}
      aria-label={dark ? 'Switch to light mode' : 'Switch to dark mode'}
      title={dark ? 'Light mode' : 'Dark mode'}
    >
      {dark ? <Sun size={19} /> : <Moon size={19} />}
    </button>
  );
}

// "Dark Mode" row with a switch, for the bottom of the sidebar
export function ThemeSwitch() {
  const { theme, toggleTheme } = useTheme();
  const dark = theme === 'dark';
  return (
    <div className="flex items-center justify-between rounded-xl px-2 py-1">
      <span className="flex items-center gap-3 text-sm font-medium text-ink/70">
        {dark ? <Sun size={18} /> : <Moon size={18} />} Dark Mode
      </span>
      <button
        type="button"
        role="switch"
        aria-checked={dark}
        aria-label="Dark mode"
        onClick={toggleTheme}
        className={`relative h-6 w-11 rounded-full transition-colors ${dark ? 'bg-forest' : 'bg-sage'}`}
      >
        <span
          className={`absolute left-0.5 top-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform ${dark ? 'translate-x-5' : ''}`}
        />
      </button>
    </div>
  );
}
