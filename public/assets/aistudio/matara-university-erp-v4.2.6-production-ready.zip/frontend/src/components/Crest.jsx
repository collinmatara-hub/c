import logo from '../assets/matara-logo.png';

// The Matara University logo. "size" is the width and height in pixels.
export default function Crest({ size = 44, className = '' }) {
  return (
    <img
      src={logo}
      width={size}
      height={size}
      alt="Matara University logo"
      className={`shrink-0 object-contain ${className}`}
    />
  );
}
