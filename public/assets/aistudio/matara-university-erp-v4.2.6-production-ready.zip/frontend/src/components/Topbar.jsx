import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X, Sun, Moon } from 'lucide-react';
import GlobalSearch from './GlobalSearch.jsx';
import MessageBell from './MessageBell.jsx';
import NotificationBell from './NotificationBell.jsx';
import UserMenu from './UserMenu.jsx';
import { SidebarNav } from './Sidebar.jsx';
import { useAuth } from '../context/AuthContext.jsx';
import { homeFor } from '../config/roles.js';
import { useTheme } from '../context/ThemeContext.jsx';

export default function Topbar() {
  const [menuOpen, setMenuOpen] = useState(false);
  const { user } = useAuth();
  const { theme, toggleTheme } = useTheme();
  return <header className="topbar-shell">
    <div className="flex h-[68px] items-center gap-3 px-4 md:px-7">
      <button type="button" className="topbar-mobile-menu md:hidden" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle menu">{menuOpen ? <X size={20}/> : <Menu size={20}/>}</button>
      <Link to={homeFor(user?.role)} className="flex items-center gap-2 md:hidden"><span className="text-sm font-extrabold text-navy dark:text-ink">MATARA UNIVERSITY</span></Link>
      <div className="hidden w-full max-w-[560px] md:block"><GlobalSearch /></div>
      <div className="ml-auto flex items-center gap-1.5">
        <MessageBell />
        <NotificationBell />
        <button type="button" className="topbar-icon" onClick={toggleTheme} title="Toggle theme" aria-label="Toggle theme">{theme === 'dark' ? <Sun size={18}/> : <span className="text-lg">☼</span>}</button>
        <UserMenu />
      </div>
    </div>
    {menuOpen && <div className="mobile-nav md:hidden"><GlobalSearch/><SidebarNav onNavigate={() => setMenuOpen(false)}/></div>}
  </header>;
}
