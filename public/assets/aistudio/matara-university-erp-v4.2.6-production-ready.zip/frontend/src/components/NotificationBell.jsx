import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { Bell, Megaphone } from 'lucide-react';
import api from '../api/axios.js';
import useClickOutside from '../hooks/useClickOutside.js';
import { useAuth } from '../context/AuthContext.jsx';
import { STAFF_ROLES, effectiveRole } from '../config/roles.js';
import { timeAgo } from '../utils/format.js';

// Where each university role reads announcements.
function announcementsPath(realRole) {
  const role = effectiveRole(realRole);
  if (['admin', 'teacher', 'student'].includes(role)) return `/${role}/announcements`;
  if (STAFF_ROLES.includes(role)) return '/staff/announcements';
  return null;
}

// Shows the latest announcements. The red number counts the ones this person has not opened yet.
export default function NotificationBell() {
  const { user } = useAuth();
  const [items, setItems] = useState([]);
  const [open, setOpen] = useState(false);
  const seenKey = `matara_seen_announcements_${user?.id}`;
  const [seenAt, setSeenAt] = useState(() => localStorage.getItem(seenKey) || '');
  const ref = useRef(null);
  useClickOutside(ref, () => setOpen(false));

  useEffect(() => {
    api.get('/announcements')
      .then((res) => setItems(res.data.slice(0, 5)))
      .catch(() => {});
  }, []);

  const unread = items.filter((a) => a.created_at > seenAt).length;
  const allLink = announcementsPath(user?.role);

  function toggle() {
    const next = !open;
    setOpen(next);
    if (next && items.length > 0) {
      const latest = items[0].created_at;
      localStorage.setItem(seenKey, latest);
      setSeenAt(latest);
    }
  }

  return (
    <div className="relative" ref={ref}>
      <button
        type="button"
        className="icon-btn"
        onClick={toggle}
        aria-label={unread > 0 ? `Notifications, ${unread} new` : 'Notifications'}
        aria-haspopup="true"
        aria-expanded={open}
      >
        <Bell size={19} />
        {unread > 0 && (
          <span className="absolute -right-0.5 -top-0.5 flex h-5 min-w-5 items-center justify-center rounded-full bg-clay px-1 text-[11px] font-bold text-white">
            {unread}
          </span>
        )}
      </button>

      {open && (
        <div className="card absolute right-0 top-full z-50 mt-2 w-[min(22rem,calc(100vw-2rem))] p-3">
          <p className="px-2 pb-2 text-sm font-semibold text-ink">Notifications</p>
          {items.length === 0 ? (
            <p className="px-2 py-6 text-center text-sm text-ink/45">You're all caught up.</p>
          ) : (
            <ul className="max-h-80 space-y-1 overflow-y-auto">
              {items.map((a) => (
                <li key={a.id} className="flex gap-3 rounded-xl px-2 py-2.5 hover:bg-forest/10">
                  <span className="icon-bubble h-9 w-9"><Megaphone size={16} /></span>
                  <div className="min-w-0">
                    <p className="truncate text-sm font-semibold text-ink">{a.title}</p>
                    <p className="line-clamp-2 text-xs text-ink/55">{a.body}</p>
                    <p className="mt-0.5 text-[11px] text-ink/40">{timeAgo(a.created_at)}</p>
                  </div>
                </li>
              ))}
            </ul>
          )}
          {allLink && (
            <Link to={allLink} onClick={() => setOpen(false)} className="mt-2 block rounded-xl px-2 py-2 text-center text-sm font-semibold text-forest hover:bg-forest/10">
              View all announcements
            </Link>
          )}
        </div>
      )}
    </div>
  );
}
