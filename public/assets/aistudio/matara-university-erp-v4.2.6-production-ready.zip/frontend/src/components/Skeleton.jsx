export function Skeleton({ className = '' }) {
  return <div className={`animate-pulse rounded-xl bg-sage/60 ${className}`} />;
}

export function StatCardSkeleton() {
  return (
    <div className="card p-5">
      <Skeleton className="h-3 w-20" />
      <Skeleton className="mt-3 h-7 w-16" />
      <Skeleton className="mt-2 h-3 w-24" />
    </div>
  );
}

export function DashboardSkeleton({ cards = 4 }) {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {Array.from({ length: cards }).map((_, i) => <StatCardSkeleton key={i} />)}
      </div>
      <div className="card p-5">
        <Skeleton className="h-4 w-40" />
        <Skeleton className="mt-4 h-48 w-full" />
      </div>
    </div>
  );
}

export function EmptyState({ icon: Icon, title, hint }) {
  return (
    <div className="flex flex-col items-center justify-center gap-2 rounded-2xl border border-dashed border-sage py-12 text-center">
      {Icon && (
        <div className="rounded-full bg-paper p-3 text-ink/35">
          <Icon size={22} />
        </div>
      )}
      <p className="text-sm font-semibold text-ink/70">{title}</p>
      {hint && <p className="max-w-xs text-xs text-ink/45">{hint}</p>}
    </div>
  );
}
