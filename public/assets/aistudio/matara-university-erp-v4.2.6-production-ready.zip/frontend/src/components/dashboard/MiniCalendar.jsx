import { useState } from 'react';
import { Link } from 'react-router-dom';
import { CalendarDays, ChevronLeft, ChevronRight } from 'lucide-react';
import Panel from './Panel.jsx';

const WEEKDAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

function pad(number) {
  return String(number).padStart(2, '0');
}

// Month view. Today is filled in, and a dot marks days that have a school event.
export default function MiniCalendar({ events = [], embedded = false, title = null }) {
  const today = new Date();
  const todayIso = `${today.getFullYear()}-${pad(today.getMonth() + 1)}-${pad(today.getDate())}`;
  const [shown, setShown] = useState(new Date(today.getFullYear(), today.getMonth(), 1));

  const year = shown.getFullYear();
  const month = shown.getMonth();
  const firstWeekday = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const daysInPreviousMonth = new Date(year, month, 0).getDate();
  const eventDays = new Set(events.map((e) => e.event_date));

  // Always 6 rows of 7 days, so the card does not change height between months
  const cells = [];
  for (let i = 0; i < 42; i++) {
    const day = i - firstWeekday + 1;
    if (day < 1) cells.push({ label: daysInPreviousMonth + day, current: false });
    else if (day > daysInMonth) cells.push({ label: day - daysInMonth, current: false });
    else cells.push({ label: day, current: true, iso: `${year}-${pad(month + 1)}-${pad(day)}` });
  }

  function move(step) {
    setShown(new Date(year, month + step, 1));
  }

  const content = (
      <div>
      <div className="mb-3 flex items-center justify-between">
        <button type="button" className="icon-btn !h-9 !w-9" onClick={() => move(-1)} aria-label="Previous month">
          <ChevronLeft size={17} />
        </button>
        <p className="text-base font-bold text-ink">
          {shown.toLocaleDateString('en-GB', { month: 'long', year: 'numeric' })}
        </p>
        <button type="button" className="icon-btn !h-9 !w-9" onClick={() => move(1)} aria-label="Next month">
          <ChevronRight size={17} />
        </button>
      </div>

      <div className="grid grid-cols-7 gap-y-1 text-center">
        {WEEKDAYS.map((d) => (
          <span key={d} className="pb-2 text-xs font-medium text-ink/55">{d}</span>
        ))}
        {cells.map((cell, index) => {
          const isToday = cell.iso === todayIso;
          return (
            <span key={index} className="flex flex-col items-center">
              <span
                className={`flex h-8 w-8 items-center justify-center rounded-full text-sm ${
                  isToday
                    ? 'bg-forest font-bold text-on-forest'
                    : cell.current ? 'text-ink' : 'text-ink/30'
                }`}
                aria-current={isToday ? 'date' : undefined}
              >
                {cell.label}
              </span>
              <span className={`mt-0.5 h-1 w-1 rounded-full ${cell.current && eventDays.has(cell.iso) ? 'bg-gold' : 'bg-transparent'}`} />
            </span>
          );
        })}
      </div>
      </div>
    );

  return embedded ? content : (
    <Panel icon={CalendarDays} title={title || 'Academic Calendar'} action={<Link to="/admin/events" className="pill hover:bg-forest/10">Full calendar</Link>}>
      {content}
    </Panel>
  );
}
