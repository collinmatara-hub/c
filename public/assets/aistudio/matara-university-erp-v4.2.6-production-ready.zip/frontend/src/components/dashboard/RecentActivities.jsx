import { ClipboardList, Mail, Megaphone, ShieldCheck, Wallet, Activity } from 'lucide-react';
import Panel from './Panel.jsx';
import { timeAgo } from '../../utils/format.js';

const ICONS = {
  payment: Wallet,
  announcement: Megaphone,
  assignment: ClipboardList,
  message: Mail,
  account: ShieldCheck,
};

export default function RecentActivities({ items = [], embedded = false }) {
  const content = items.length === 0 ? (
        <p className="py-6 text-center text-sm text-ink/45">Nothing has happened yet. New activity will show up here.</p>
      ) : (
        <ul className="divide-y divide-sage/60">
          {items.map((item, index) => {
            const Icon = ICONS[item.type] || Activity;
            return (
              <li key={index} className="flex items-center gap-3 py-3 first:pt-0 last:pb-0">
                <span className="icon-bubble h-11 w-11"><Icon size={19} /></span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-semibold text-ink">{item.title}</p>
                  {item.detail && <p className="truncate text-xs text-ink/55">{item.detail}</p>}
                </div>
                <span className="shrink-0 text-xs text-ink/45">{timeAgo(item.at)}</span>
              </li>
            );
          })}
        </ul>
      );
  return embedded ? content : <Panel icon={Activity} title="Recent Activities">{content}</Panel>;
}
