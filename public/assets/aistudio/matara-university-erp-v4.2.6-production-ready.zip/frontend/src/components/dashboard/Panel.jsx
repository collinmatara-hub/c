// A white card with a round icon and a title, used for each block on the dashboard
export default function Panel({ icon: Icon, title, subtitle, action, className = '', children }) {
  return (
    <section className={`card p-5 ${className}`}>
      <div className="mb-4 flex items-start justify-between gap-3">
        <div className="flex items-center gap-3">
          {Icon && (
            <span className="icon-bubble h-11 w-11">
              <Icon size={20} />
            </span>
          )}
          <div>
            <h3 className="text-base font-bold text-ink">{title}</h3>
            {subtitle && <p className="text-xs text-ink/50">{subtitle}</p>}
          </div>
        </div>
        {action}
      </div>
      {children}
    </section>
  );
}
