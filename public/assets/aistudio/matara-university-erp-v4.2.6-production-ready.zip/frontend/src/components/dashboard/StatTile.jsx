import { ArrowUp } from 'lucide-react';

// One number at the top of the dashboard. "up" adds a green arrow before the hint.
export default function StatTile({ icon: Icon, label, value, hint, up = false }) {
  return (
    <div className="card flex items-center gap-3 p-4">
      <span className="icon-bubble h-12 w-12">
        <Icon size={23} strokeWidth={1.8} />
      </span>
      <div className="min-w-0">
        <p className="truncate text-xs font-semibold text-ink/70">{label}</p>
        <p className="font-display text-2xl font-extrabold leading-tight text-ink">{value}</p>
        <p className="mt-0.5 flex items-center gap-1 truncate text-[11px] text-ink/50">
          {up && <ArrowUp size={14} className="shrink-0 text-emerald-600 dark:text-emerald-400" />}
          <span className={up ? 'font-semibold text-emerald-600 dark:text-emerald-400' : ''}>{hint}</span>
        </p>
      </div>
    </div>
  );
}
