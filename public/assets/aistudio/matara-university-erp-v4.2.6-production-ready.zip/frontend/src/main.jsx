import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import App from './App.jsx';
import { AuthProvider } from './context/AuthContext.jsx';
import { ThemeProvider } from './context/ThemeContext.jsx';
import './index.css';

class AppErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { error: null };
  }
  static getDerivedStateFromError(error) {
    return { error };
  }
  componentDidCatch(error, info) {
    console.error('Matara University frontend error:', error, info);
  }
  render() {
    if (this.state.error) {
      return (
        <div style={{ minHeight: '100vh', display: 'grid', placeItems: 'center', padding: 24, background: '#f0f7f9', fontFamily: 'Inter, sans-serif', color: '#102a3a' }}>
          <div style={{ maxWidth: 720, width: '100%', background: '#fff', border: '1px solid #d6e5ea', borderRadius: 20, padding: 28, boxShadow: '0 12px 32px rgba(16,42,58,.12)' }}>
            <h1 style={{ margin: 0, fontSize: 24 }}>Matara University ERP could not start</h1>
            <p style={{ marginTop: 10, color: '#6b7280' }}>The application hit a frontend error. The exact error is shown below so it can be fixed instead of displaying a blank page.</p>
            <pre style={{ marginTop: 18, padding: 16, borderRadius: 12, background: '#f8fafb', overflow: 'auto', whiteSpace: 'pre-wrap' }}>{String(this.state.error?.stack || this.state.error)}</pre>
            <button onClick={() => window.location.reload()} style={{ marginTop: 16, border: 0, borderRadius: 10, padding: '10px 16px', background: '#0b8797', color: '#fff', fontWeight: 700, cursor: 'pointer' }}>Reload application</button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <AppErrorBoundary>
      <BrowserRouter>
        <ThemeProvider>
          <AuthProvider>
            <App />
          </AuthProvider>
        </ThemeProvider>
      </BrowserRouter>
    </AppErrorBoundary>
  </React.StrictMode>
);
