const TITLES = ['mr', 'mrs', 'ms', 'miss', 'dr', 'prof', 'director', 'eng', 'hon', 'rev'];

// "Director Wanjiru Kamau" -> "Wanjiru"
export function firstName(fullName) {
  const words = String(fullName || '').split(/\s+/).filter(Boolean);
  const real = words.find((word) => !TITLES.includes(word.toLowerCase().replace('.', '')));
  return real || words[0] || 'there';
}

export function greeting(date = new Date()) {
  const hour = date.getHours();
  if (hour < 12) return 'Good morning';
  if (hour < 17) return 'Good afternoon';
  return 'Good evening';
}

// "Monday, 21 September 2026"
export function longDate(date = new Date()) {
  const weekday = date.toLocaleDateString('en-GB', { weekday: 'long' });
  const rest = date.toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' });
  return `${weekday}, ${rest}`;
}

// The database stores UTC times like "2026-09-21 05:38:25"
export function parseDbTime(text) {
  return new Date(String(text).replace(' ', 'T') + 'Z');
}

// "5m ago", "3h ago", "2d ago", or a date for anything older than a month
export function timeAgo(text) {
  const seconds = Math.round((Date.now() - parseDbTime(text).getTime()) / 1000);
  if (seconds < 60) return 'Just now';
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  if (days < 7) return `${days}d ago`;
  if (days < 31) return `${Math.floor(days / 7)}w ago`;
  return parseDbTime(text).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
}

export function kes(amount) {
  return `KES ${Number(amount || 0).toLocaleString('en-KE')}`;
}

// "08:00" -> "08:00 AM"
export function clockTime(text) {
  if (!text) return '';
  const [h, m] = text.split(':').map(Number);
  if (Number.isNaN(h)) return text;
  const suffix = h >= 12 ? 'PM' : 'AM';
  const hour12 = h % 12 === 0 ? 12 : h % 12;
  return `${String(hour12).padStart(2, '0')}:${String(m || 0).padStart(2, '0')} ${suffix}`;
}

// "21 Sep 2026" from a database time
export function shortDate(text) {
  if (!text) return '';
  return parseDbTime(text).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
}
