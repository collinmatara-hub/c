import { jsPDF } from 'jspdf';
import { LOGO_DATA_URL } from '../assets/logoData.js';

async function photoAsDataUrl(src) {
  if (!src) return null; if (/^data:image\/(png|jpeg|jpg|webp);base64,/i.test(src)) return src;
  try { const configuredBase = import.meta.env?.VITE_API_BASE_URL || '/api'; const base = configuredBase.replace(/\/api\/?$/, ''); const url = /^https?:\/\//i.test(src) ? src : `${base}${src.startsWith('/') ? '' : '/'}${src}`; const response = await fetch(url, { credentials: 'include' }); if (!response.ok) return null; const blob = await response.blob(); return await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=reject;reader.readAsDataURL(blob);}); } catch (_) { return null; }
}

function addLogo(doc, x, y, size) { try { doc.addImage(LOGO_DATA_URL, 'PNG', x, y, size, size); } catch (_) {} }
function creativeConfig(key='general_pdf') { try { return {primary:'#123b69',secondary:'#eaf4fb',accent:'#d4af37',heading:'MATARA UNIVERSITY',footer:'Official University Document',showLogo:true,showStamp:true,...JSON.parse(localStorage.getItem(`matara_creative_${key}`)||'{}')}; } catch (_) { return {primary:'#123b69',secondary:'#eaf4fb',accent:'#d4af37',heading:'MATARA UNIVERSITY',footer:'Official University Document',showLogo:true,showStamp:true}; } }
function rgb(hex) { const h=String(hex||'#123b69').replace('#',''); return [parseInt(h.slice(0,2),16)||18,parseInt(h.slice(2,4),16)||59,parseInt(h.slice(4,6),16)||105]; }
function templateKey(title='') { const t=String(title).toLowerCase(); if(t.includes('fee'))return 'fee_statement'; if(t.includes('report card')||t.includes('academic report'))return 'results_slip'; if(t.includes('certificate'))return 'certificate'; if(t.includes('profile'))return 'student_profile'; return 'general_pdf'; }

function header(doc, title, subtitle='') {
  const cfg=creativeConfig(templateKey(title)); const c=rgb(cfg.primary); doc.setDrawColor(...c); doc.setTextColor(...c);
  if(cfg.showLogo!==false) addLogo(doc, 14, 8, 24);
  doc.setFont('helvetica','bold'); doc.setFontSize(16); doc.text(String(cfg.heading||'MATARA UNIVERSITY'), 42, 18);
  doc.setFontSize(12); doc.text(title, 42, 26);
  if (subtitle) { doc.setFont('helvetica','normal'); doc.setFontSize(9); doc.text(subtitle, 42, 32); }
  doc.line(14, 36, 196, 36); doc.setTextColor(0);
}
function footer(doc) { const pages=doc.getNumberOfPages(); for(let i=1;i<=pages;i++){doc.setPage(i);doc.setFontSize(8);doc.setTextColor(100);doc.text(`Matara University • Page ${i} of ${pages}`,14,289);doc.setTextColor(0);} }
function table(doc, headers, rows, y, widths) {
  const x=14, rowH=7; let yy=y; doc.setFontSize(8); doc.setFont('helvetica','bold');
  let xx=x; headers.forEach((h,i)=>{doc.rect(xx,yy,widths[i],rowH);doc.text(String(h).slice(0,22),xx+1,yy+5);xx+=widths[i];}); yy+=rowH; doc.setFont('helvetica','normal');
  for(const row of rows){ if(yy>278){doc.addPage();header(doc,'Continued');yy=44;} xx=x; row.forEach((v,i)=>{const text=doc.splitTextToSize(String(v??''),widths[i]-2)[0]||'';doc.rect(xx,yy,widths[i],rowH);doc.text(text,xx+1,yy+5);xx+=widths[i];});yy+=rowH; }
  return yy+4;
}
function section(doc,title,items,y){ doc.setFont('helvetica','bold');doc.setFontSize(10);doc.text(title,14,y);y+=6;doc.setFont('helvetica','normal');doc.setFontSize(9);for(const [k,v] of items){doc.text(`${k}: ${v??'—'}`,16,y);y+=5;if(y>278){doc.addPage();header(doc,'Continued');y=44;}}return y+3; }

export function downloadStudentProfile(p){
  const doc=new jsPDF(); header(doc,'Confidential Student Profile',`${p.student.name} • ${p.student.adm_no}`); let y=44;
  y=section(doc,'Student Information',[["Admission No.",p.student.adm_no],["University Reference",p.student.nemis_upi],["Gender",p.student.gender],["Date of Birth",p.student.dob],["Nationality",p.student.nationality],["Previous School",p.student.previous_school],["Admission Date",p.student.admission_date],["Class",`${p.student.class_name||''} ${p.student.class_stream||''}`],["House",p.student.house_name],["Residence",p.student.residence],["Status",p.student.status],["Special Needs",p.student.special_needs]],y);
  y=section(doc,'Contacts',p.guardians.map(g=>[g.relationship||g.contact_type,g.name+` • ${g.phone||''}`]),y);
  y=section(doc,'Finance Summary',[["Total billed",`KES ${Number(p.summary.totalDue||0).toLocaleString()}`],["Total paid",`KES ${Number(p.summary.totalPaid||0).toLocaleString()}`],["Balance",`KES ${Number(p.summary.balance||0).toLocaleString()}`]],y);
  y=section(doc,'Attendance Summary',[["Present",p.summary.attendance.present],["Absent",p.summary.attendance.absent],["Late",p.summary.attendance.late],["Attendance %",`${p.summary.attendance.percentage}%`]],y);
  if(y>245){doc.addPage();header(doc,'Academic & Welfare Record');y=44;}
  y=table(doc,['University Unit','Exam','Kind','Score','Grade','Points'],p.grades.map(r=>[r.subject_name,r.exam_name,r.kind,r.score,r.grade||'',r.points||'']),y,[35,42,22,20,25,20]);
  if(y>250){doc.addPage();header(doc,'Student Profile — Welfare');y=44;}
  y=table(doc,['Date','Type','Description','Action','Resolved'],p.discipline.map(r=>[r.incident_date,r.type,r.description,r.action_taken,r.resolved?'Yes':'No']),y,[22,25,65,50,20]);
  y=table(doc,['Date','Complaint','Treatment','Officer'],p.visits.map(r=>[r.visit_date,r.complaint,r.treatment,r.officer]),y,[25,55,65,35]);
  y=table(doc,['Book','Borrowed','Due','Returned','Fine'],p.books.map(r=>[r.title,r.borrowed_at,r.due_date,r.returned_at||'—',`KES ${Number(r.fine||0).toLocaleString()}`]),y,[60,30,30,30,30]);
  y=table(doc,['Event Date','Type','Title','Details'],p.timeline.map(r=>[r.event_date,r.event_type,r.title,r.details]),y,[25,30,45,82]);
  footer(doc);doc.save(`matara-student-profile-${p.student.adm_no}.pdf`);
}

export function downloadFeeStatement(d){
  const doc=new jsPDF(); header(doc,'Student Fee Statement',`${d.student.name} • ${d.student.adm_no}`); let y=44;
  y=section(doc,'Account Summary',[["Cohort",`${d.student.class_name||''} ${d.student.class_stream||''}`],["Total Due",`KES ${Number(d.totalDue).toLocaleString()}`],["Total Paid",`KES ${Number(d.totalPaid).toLocaleString()}`],["Balance",`KES ${Number(d.balance).toLocaleString()}`]],y);
  y=table(doc,['Term','Due','Paid','Balance','Due Date'],d.rows.map(r=>[r.term,`KES ${Number(r.amount_due||0).toLocaleString()}`,`KES ${Number(r.allocated_paid||r.amount_paid||0).toLocaleString()}`,`KES ${(Number(r.amount_due||0)-Number(r.allocated_paid||r.amount_paid||0)).toLocaleString()}`,r.due_date||'—']),y,[35,35,35,40,37]);
  y=table(doc,['Date','Amount','Method','Reference','Status'],d.payments.map(r=>[r.payment_date,`KES ${Number(r.amount).toLocaleString()}`,r.method,r.reference,r.status]),y,[28,35,35,50,30]); footer(doc);doc.save(`matara-fee-statement-${d.student.adm_no}.pdf`);
}

export function downloadReportCard(d){
  const doc=new jsPDF(); header(doc,'Academic Report Card',`${d.student.name} • ${d.student.adm_no} • Cohort: ${d.student.class_name||'Unassigned'} ${d.student.class_stream||''} • Period: Semesters and Cohorts`); let y=44;
  y=section(doc,'Attendance',[["Present",d.attendance.present],["Absent",d.attendance.absent],["Late",d.attendance.late],["Attendance %",`${d.attendance.percentage}%`]],y);
  y=table(doc,['University Unit','Assessment','Semester','Assessment Type','Score','Grade','Grade Points'],d.rows.map(r=>[r.subject,r.exam,r.semester||r.term,r.kind,r.score,r.grade,r.points]),y,[34,40,25,22,18,22,21]);
  if(y>235){doc.addPage();header(doc,'Report Card — Academic Review');y=45;}
  y=section(doc,'Academic Review',[["Review status",d.review_status||'Pending authorized academic review'],["Semester",d.semester||d.term||'As recorded in results'],["Cohort",`${d.student.class_name||'Unassigned'} ${d.student.class_stream||''}`]],y);
  doc.line(18,255,75,255);doc.line(120,255,177,255);doc.setFontSize(8);doc.text('Lecturer / Academic Officer',46,261,{align:'center'});doc.text('Authorized University Officer',148,261,{align:'center'});
  footer(doc);doc.save(`matara-report-card-${d.student.adm_no}.pdf`);
}

export function downloadTabularReport(title, columns, rows){
  const doc=new jsPDF('landscape'); header(doc,title,'Generated from Matara University'); let y=44; const usable=270; const widths=columns.map(()=>usable/Math.max(columns.length,1));
  y=table(doc,columns,rows.map(r=>columns.map(c=>r[c])),y,widths); footer(doc); doc.save(`matara-${title.toLowerCase().replace(/[^a-z0-9]+/g,'-')}.pdf`);
}

export async function downloadXlsx(filename, columns, rows) {
  // Dependency-free spreadsheet export. Excel opens CSV directly, and this avoids the vulnerable xlsx package.
  const esc = (v) => `"${String(v ?? '').replaceAll('\"','\"\"')}"`;
  const csv = [columns.map(esc).join(','), ...rows.map(r => columns.map(c => esc(r[c])).join(','))].join('\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename.replace(/\.xlsx$/i, '.csv');
  a.click();
  URL.revokeObjectURL(a.href);
}

export async function downloadStudentIdCard(student) {
  const QR = await import('qrcode');
  const doc = new jsPDF({orientation:'landscape',unit:'mm',format:[86,54]});
  // Front face
  const cfg=creativeConfig('id_card'), primary=rgb(cfg.primary), secondary=rgb(cfg.secondary), accent=rgb(cfg.accent);
  doc.setFillColor(...secondary); doc.rect(0,0,86,54,'F');
  doc.setDrawColor(...primary); doc.setLineWidth(0.7); doc.roundedRect(1,1,84,52,2,2,'S');
  if(cfg.showLogo!==false)addLogo(doc,3,2.5,12);
  doc.setTextColor(...primary); doc.setFont('helvetica','bold'); doc.setFontSize(9); doc.text(String(cfg.heading||'MATARA UNIVERSITY').slice(0,26),17,8);
  doc.setFontSize(5.8); doc.setFont('helvetica','normal'); doc.text('OFFICIAL STUDENT IDENTIFICATION',17,12);
  doc.setFont('helvetica','bold'); doc.setFontSize(8); doc.text(String(student.name||'').slice(0,32),4,20);
  doc.setFont('helvetica','normal'); doc.setFontSize(6); doc.text(`Admission: ${student.adm_no||''}`,4,25); doc.text(`Programme: ${String(student.programme_name||student.program_name||student.programme||'—').slice(0,28)}`,4,29); doc.text(`Faculty: ${String(student.faculty_name||'—').slice(0,28)}`,4,33);
  if(student.photo_url){try{const photo=await photoAsDataUrl(student.photo_url);if(photo)doc.addImage(photo,photo.startsWith('data:image/png')?'PNG':'JPEG',4,36,14,15);}catch(_){} }
  const cardNumber=String(student.card_number||student.cardNumber||`MU-ID-${student.adm_no||'STUDENT'}`);
  const qr=await QR.toDataURL(`MATARA-UNIVERSITY|CARD=${cardNumber}|ADM=${student.adm_no||''}`,{margin:1,width:180,errorCorrectionLevel:'M'});doc.addImage(qr,'PNG',64,17,17,17);
  doc.setFont('helvetica','bold');doc.setFontSize(5.5);doc.text(cardNumber.slice(0,26),72.5,36,{align:'center'});
  doc.setFontSize(4.8);doc.setFont('helvetica','normal');doc.text('Property of Matara University',43,50,{align:'center'});
  // Reverse face: official contact information and gate-use code.
  doc.addPage([86,54],'landscape');doc.setFillColor(248,251,255);doc.rect(0,0,86,54,'F');doc.setDrawColor(18,59,105);doc.setLineWidth(0.7);doc.roundedRect(1,1,84,52,2,2,'S');
  addLogo(doc,3,3,9);doc.setTextColor(10,42,70);doc.setFont('helvetica','bold');doc.setFontSize(7.2);doc.text('MATARA UNIVERSITY',15,8);doc.setFontSize(5.2);doc.setFont('helvetica','normal');doc.text('STUDENT SERVICES • OFFICIAL IDENTIFICATION',15,12);doc.line(4,15,82,15);
  doc.setFont('helvetica','bold');doc.setFontSize(5.8);doc.text('UNIVERSITY DETAILS',4,20);doc.setFont('helvetica','normal');doc.setFontSize(5.2);
  const backLines=[`Campus: ${student.campus||'Matara University Campus'}`,`Faculty: ${student.faculty_name||'See student record'}`,`Department: ${student.department_name||'See student record'}`,`Contact: ${student.university_phone||'Contact University Registry'}`,`Email: ${student.university_email||'Contact University Registry'}`];
  backLines.forEach((line,i)=>doc.text(line.slice(0,47),4,25+i*4));
  const backQr=await QR.toDataURL(`MATARA-UNIVERSITY-GATE|${cardNumber}`,{margin:1,width:180,errorCorrectionLevel:'H'});doc.addImage(backQr,'PNG',64,23,17,17);
  doc.setFont('helvetica','bold');doc.setTextColor(...accent);doc.setFontSize(4.7);doc.text('GATE SCAN',72.5,42,{align:'center'});doc.setTextColor(...primary);doc.setFont('helvetica','normal');doc.setFontSize(4.2);doc.text(String(cfg.footer||'Validity is checked by University Security.').slice(0,60),4,49);doc.text('Lost cards must be reported to ICT / Registry.',4,52);
  doc.save(`matara-id-card-${student.adm_no||'student'}.pdf`);
}


export async function downloadExamCard(student, details = {}) {
  const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a5' });
  const cfg=creativeConfig('exam_card'), primary=rgb(cfg.primary), secondary=rgb(cfg.secondary);
  doc.setFillColor(...secondary); doc.rect(0, 0, 210, 148, 'F');
  doc.setDrawColor(...primary); doc.setLineWidth(0.8); doc.roundedRect(6, 6, 198, 136, 3, 3, 'S');
  if(cfg.showLogo!==false)addLogo(doc, 12, 12, 22);
  doc.setTextColor(...primary); doc.setFont('helvetica', 'bold'); doc.setFontSize(17); doc.text(String(cfg.heading||'MATARA UNIVERSITY'), 39, 20);
  doc.setFontSize(12); doc.text('OFFICIAL EXAMINATION CARD', 39, 28);
  doc.setFont('helvetica', 'normal'); doc.setFontSize(8); doc.text('Knowledge • Innovation • Service', 39, 34);
  doc.setDrawColor(190, 210, 232); doc.line(12, 40, 198, 40);
  const fields = [
    ['Full Name', student.name], ['Admission Number', student.adm_no],
    ['Programme', student.program_name || student.programme || 'As recorded by the University'],
    ['Faculty / Department', [student.faculty_name, student.department_name].filter(Boolean).join(' / ') || 'As recorded by the University'],
    ['Cohort', [student.class_name, student.class_stream].filter(Boolean).join(' ') || student.cohort || 'As recorded by the University'],
    ['Academic Year', details.academicYear || new Date().getFullYear() + '/' + (new Date().getFullYear() + 1)],
    ['Semester', details.semester || 'As announced by the University'],
  ];
  let y = 51; doc.setFontSize(9);
  for (const [label, value] of fields) { doc.setFont('helvetica', 'bold'); doc.text(label + ':', 14, y); doc.setFont('helvetica', 'normal'); doc.text(doc.splitTextToSize(String(value || '—'), 105)[0], 48, y); y += 10; }
  if (student.photo_url) { try { const photo = await photoAsDataUrl(student.photo_url); if(photo) doc.addImage(photo, photo.startsWith('data:image/png') ? 'PNG' : 'JPEG', 158, 48, 30, 36); else throw new Error('Photo unavailable'); } catch (_) { doc.setDrawColor(150); doc.rect(158, 48, 30, 36); doc.setFontSize(7); doc.text('PHOTO UNAVAILABLE', 173, 68, { align: 'center' }); } } else { doc.setDrawColor(150); doc.rect(158, 48, 30, 36); doc.setFontSize(7); doc.text('STUDENT PHOTO', 173, 68, { align: 'center' }); }
  doc.setFontSize(8); doc.setTextColor(45, 70, 100); doc.text('Carry this card with your valid university identification. Follow the examination rules.', 14, 126);
  doc.text(`${cfg.footer||'Official University Document'} • Generated: ${new Date().toLocaleString('en-KE', { timeZone: 'Africa/Nairobi' })} EAT`, 14, 134);
  doc.save(`matara-exam-card-${student.adm_no || 'student'}.pdf`);
}

export function downloadCertificate(student,type='Certificate of Enrolment') {
  const doc=new jsPDF('landscape');doc.setDrawColor(10,42,70);doc.rect(8,8,281,194);addLogo(doc,133.5,12,30);doc.setFont('helvetica','bold');doc.setFontSize(24);doc.text('MATARA UNIVERSITY',148,52,{align:'center'});doc.setFontSize(18);doc.text(type.toUpperCase(),148,66,{align:'center'});doc.setFont('helvetica','normal');doc.setFontSize(12);doc.text('This is to certify that',148,86,{align:'center'});doc.setFont('helvetica','bold');doc.setFontSize(22);doc.text(String(student.name||''),148,98,{align:'center'});doc.setFont('helvetica','normal');doc.setFontSize(12);doc.text(`Admission Number: ${student.adm_no||'—'}`,148,113,{align:'center'});doc.text(`University Reference: ${student.nemis_upi||'—'}`,148,124,{align:'center'});doc.text(`Cohort: ${student.class_name||''} ${student.class_stream||''}`,148,135,{align:'center'});doc.text(`Issued on ${new Date().toLocaleDateString()}`,148,155,{align:'center'});doc.line(35,177,100,177);doc.line(190,177,255,177);doc.setFontSize(9);doc.text('Authorized University Officer',67,184,{align:'center'});doc.text('University Stamp',222,184,{align:'center'});doc.save(`matara-${type.toLowerCase().replace(/[^a-z0-9]+/g,'-')}-${student.adm_no}.pdf`);
}

export function downloadBulkReportCards(items) {
  const doc = new jsPDF();
  items.forEach((d,index)=>{
    if(index>0) doc.addPage();
    header(doc,'Academic Report Card',`${d.student.name} • ${d.student.adm_no} • Cohort: ${d.student.class_name||'Unassigned'} ${d.student.class_stream||''} • Period: Semesters and Cohorts`);
    let y=44;
    y=section(doc,'Attendance',[["Present",d.attendance.present],["Absent",d.attendance.absent],["Late",d.attendance.late],["Attendance %",`${d.attendance.percentage}%`]],y);
    table(doc,['University Unit','Assessment','Semester','Assessment Type','Score','Grade','Grade Points'],d.rows.map(r=>[r.subject,r.exam,r.semester||r.term,r.kind,r.score,r.grade,r.points]),y,[34,40,25,22,18,22,21]);
    doc.setFontSize(8);doc.text(`Cohort: ${d.student.class_name||'Unassigned'} ${d.student.class_stream||''}`,14,270);doc.text('Academic review: Subject to the university results approval process',14,276);
  });
  footer(doc);doc.save(`matara-bulk-report-cards-${new Date().toISOString().slice(0,10)}.pdf`);
}
