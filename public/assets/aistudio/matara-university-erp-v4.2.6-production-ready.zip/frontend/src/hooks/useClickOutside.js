import { useEffect } from 'react';

// Calls onOutside() when the user clicks or taps anywhere outside the element in ref.
export default function useClickOutside(ref, onOutside) {
  useEffect(() => {
    function handle(event) {
      if (ref.current && !ref.current.contains(event.target)) onOutside();
    }
    document.addEventListener('mousedown', handle);
    return () => document.removeEventListener('mousedown', handle);
  }, [ref, onOutside]);
}
