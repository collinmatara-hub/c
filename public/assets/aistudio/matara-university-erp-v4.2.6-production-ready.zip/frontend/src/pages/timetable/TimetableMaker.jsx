import { useCallback, useEffect, useMemo, useState } from 'react';
import DashboardLayout from '../../components/DashboardLayout.jsx';
import api from '../../api/axios.js';

const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
const HOURS = ['08:00', '09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00'];
const STATUS_LABEL = { draft: 'Draft', pending: 'Waiting for approval', approved: 'Approved', published: 'Published', archived: 'Archived' };
const STATUS_CLASS = { draft: 'badge-gold', pending: 'badge-gold', approved: 'badge-green', published: 'badge-green', archived: 'badge' };

function errorText(e, fallback) {
  const d = e.response?.data;
  if (d?.issues?.length) return `${d.error} ${d.issues.slice(0, 3).map((i) => i.message).join(' ')}`;
  return d?.error || fallback;
}

function Field({ label, children }) {
  return <label className="block"><span className="label mb-1 block text-xs uppercase text-ink/55">{label}</span>{children}</label>;
}

export default function TimetableMaker() {
  const [me, setMe] = useState(null);
  const [tab, setTab] = useState('timetables');
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  useEffect(() => {
    api.get('/timetable-maker/me').then((r) => setMe(r.data)).catch((e) => setError(errorText(e, 'Could not load your permissions.')));
  }, []);

  const tabs = [['timetables', 'Timetables'], ['units', 'Units'], ['rooms', 'Rooms'], ['availability', 'Availability'], ['history', 'History']];
  const props = { me, setError, setNotice };

  return (
    <DashboardLayout title="Timetable Maker" subtitle="Plan, check, approve and publish the university timetable.">
      {error && <p className="mb-4 rounded-lg bg-clay/10 px-3 py-2 text-sm text-clay" role="alert">{error}</p>}
      {notice && <p className="mb-4 rounded-lg bg-forest/10 px-3 py-2 text-sm text-forest-dark" role="status">{notice}</p>}
      {!me ? <p className="text-sm text-ink/45">Loading…</p> : !me.can.view ? (
        <p className="card p-6 text-sm text-ink/70">Your role does not have access to the timetable maker.</p>
      ) : (
        <>
          <div className="mb-5 flex flex-wrap gap-2">
            {tabs.map(([key, label]) => (
              <button key={key} type="button" onClick={() => { setTab(key); setError(''); setNotice(''); }}
                className={tab === key ? 'btn-primary' : 'btn-ghost'}>{label}</button>
            ))}
          </div>
          {tab === 'timetables' && <Timetables {...props} />}
          {tab === 'units' && <Units {...props} />}
          {tab === 'rooms' && <Rooms {...props} />}
          {tab === 'availability' && <Availability {...props} />}
          {tab === 'history' && <History />}
        </>
      )}
    </DashboardLayout>
  );
}

// ---------------- Timetables: generate, review, approve, publish ----------------
function Timetables({ me, setError, setNotice }) {
  const [versions, setVersions] = useState([]);
  const [selected, setSelected] = useState(null);
  const [detail, setDetail] = useState(null);
  const [rooms, setRooms] = useState([]);
  const [gen, setGen] = useState({ term: '2026/2027 Semester 1', name: '', seed: '' });
  const [filterKind, setFilterKind] = useState('cohort');
  const [filterValue, setFilterValue] = useState('');
  const [busy, setBusy] = useState(false);
  const [editing, setEditing] = useState(null);

  const loadList = useCallback(() => api.get('/timetable-maker/versions').then((r) => setVersions(r.data)).catch((e) => setError(errorText(e, 'Could not load timetables.'))), [setError]);
  const loadDetail = useCallback((id) => api.get(`/timetable-maker/versions/${id}`).then((r) => setDetail(r.data)).catch((e) => setError(errorText(e, 'Could not load this timetable.'))), [setError]);
  useEffect(() => { loadList(); api.get('/timetable-maker/rooms').then((r) => setRooms(r.data)).catch(() => {}); }, [loadList]);
  useEffect(() => { if (selected) loadDetail(selected); else setDetail(null); }, [selected, loadDetail]);

  const roomName = (id) => rooms.find((r) => r.id === id)?.name || '—';

  async function run(fn, success) {
    setBusy(true); setError(''); setNotice('');
    try { const r = await fn(); if (success) setNotice(typeof success === 'function' ? success(r) : success); await loadList(); if (selected) await loadDetail(selected); return r; }
    catch (e) { setError(errorText(e, 'That did not work.')); return null; }
    finally { setBusy(false); }
  }

  async function generate(e) {
    e.preventDefault();
    const r = await run(() => api.post('/timetable-maker/versions/generate', { term: gen.term, name: gen.name, seed: gen.seed ? Number(gen.seed) : undefined }),
      (res) => `Draft created: ${res.data.placed} of ${res.data.totalSessions} sessions placed. ${res.data.unscheduled.length ? `${res.data.unscheduled.length} unit(s) need attention.` : 'Nothing is published until it is approved.'}`);
    if (r) setSelected(r.data.id);
  }

  const slots = detail?.slots || [];
  const options = useMemo(() => {
    const pick = { cohort: (s) => s.cohort, lecturer: (s) => s.lecturer_name, room: (s) => roomName(s.room_id) };
    return [...new Set(slots.map(pick[filterKind]).filter(Boolean))].sort();
  }, [slots, filterKind, rooms]); // eslint-disable-line react-hooks/exhaustive-deps
  const shown = slots.filter((s) => {
    if (!filterValue) return true;
    if (filterKind === 'cohort') return s.cohort === filterValue;
    if (filterKind === 'lecturer') return s.lecturer_name === filterValue;
    return roomName(s.room_id) === filterValue;
  });

  const v = detail?.version;
  const draft = v?.status === 'draft';

  return (
    <div className="grid gap-6 lg:grid-cols-[320px_1fr]">
      <div className="space-y-4">
        {me.can.generate && (
          <form onSubmit={generate} className="card space-y-3 p-4">
            <h3 className="font-display font-semibold text-ink">Generate a draft</h3>
            <Field label="Term"><input className="input w-full" value={gen.term} onChange={(e) => setGen({ ...gen, term: e.target.value })} required /></Field>
            <Field label="Name (optional)"><input className="input w-full" value={gen.name} onChange={(e) => setGen({ ...gen, name: e.target.value })} /></Field>
            <Field label="Seed (optional, repeats a result)"><input className="input w-full" type="number" value={gen.seed} onChange={(e) => setGen({ ...gen, seed: e.target.value })} /></Field>
            <button className="btn-primary w-full" disabled={busy}>{busy ? 'Working…' : 'Generate draft'}</button>
            <p className="text-xs text-ink/55">Uses the units, rooms and availability you have entered. It never invents data and never publishes.</p>
          </form>
        )}
        <div className="card p-4">
          <h3 className="mb-3 font-display font-semibold text-ink">Versions</h3>
          {versions.length === 0 && <p className="text-sm text-ink/55">No timetables yet.</p>}
          <ul className="space-y-2">
            {versions.map((x) => (
              <li key={x.id}>
                <button type="button" onClick={() => { setSelected(x.id); setFilterValue(''); }}
                  className={`w-full rounded-xl border p-3 text-left text-sm ${selected === x.id ? 'border-forest bg-forest/5' : 'border-sage'}`}>
                  <span className="block font-semibold text-ink">{x.name}</span>
                  <span className="block text-xs text-ink/55">{x.term} · {x.slot_count} sessions</span>
                  <span className={`badge mt-1 ${STATUS_CLASS[x.status]}`}>{STATUS_LABEL[x.status]}</span>
                </button>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="space-y-4">
        {!v ? <p className="card p-6 text-sm text-ink/55">Choose a version, or generate a draft, to review it.</p> : (
          <>
            <div className="card p-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h3 className="font-display text-lg font-semibold text-ink">{v.name}</h3>
                  <p className="text-xs text-ink/55">{v.term} · prepared by {v.created_by_name || 'unknown'}{v.approved_by_name ? ` · approved by ${v.approved_by_name}` : ''}</p>
                </div>
                <span className={`badge ${STATUS_CLASS[v.status]}`}>{STATUS_LABEL[v.status]}</span>
              </div>
              {v.review_note && <p className="mt-3 rounded-lg bg-gold/10 px-3 py-2 text-sm">Returned for changes: {v.review_note}</p>}
              <div className="mt-4 flex flex-wrap gap-2">
                {me.can.manage && draft && <button className="btn-primary" disabled={busy} onClick={() => run(() => api.post(`/timetable-maker/versions/${v.id}/submit`), 'Submitted for approval.')}>Submit for approval</button>}
                {me.can.approve && v.status === 'pending' && <button className="btn-primary" disabled={busy} onClick={() => run(() => api.post(`/timetable-maker/versions/${v.id}/approve`), 'Approved.')}>Approve</button>}
                {me.can.approve && v.status === 'pending' && <button className="btn-ghost" disabled={busy} onClick={() => { const note = window.prompt('What must be changed?'); if (note) run(() => api.post(`/timetable-maker/versions/${v.id}/reject`, { note }), 'Returned to the timetabling officer.'); }}>Return for changes</button>}
                {me.can.publish && v.status === 'approved' && <button className="btn-primary" disabled={busy} onClick={() => { if (window.confirm('Publish this timetable? Lecturers and students will see it.')) run(() => api.post(`/timetable-maker/versions/${v.id}/publish`), 'Published.'); }}>Publish</button>}
                {me.can.manage && <button className="btn-ghost" disabled={busy} onClick={() => run(() => api.post(`/timetable-maker/versions/${v.id}/restore`), 'Copied into a new draft.')}>Restore as new draft</button>}
                <a className="btn-ghost" href={`/api/timetable-maker/versions/${v.id}/export.csv`}>Export CSV</a>
                {me.can.manage && draft && <button className="btn-ghost" disabled={busy} onClick={() => { if (window.confirm('Delete this draft?')) run(() => api.delete(`/timetable-maker/versions/${v.id}`), 'Draft deleted.').then(() => setSelected(null)); }}>Delete draft</button>}
              </div>
            </div>

            {detail.issues.length > 0 && (
              <div className="card border-clay/40 p-4">
                <h4 className="font-semibold text-clay">{detail.issues.length} conflict(s) to fix</h4>
                <ul className="mt-2 list-disc pl-5 text-sm text-ink/80">{detail.issues.slice(0, 10).map((i, k) => <li key={k}>{i.message}</li>)}</ul>
              </div>
            )}
            {v.unscheduled.length > 0 && (
              <div className="card border-gold/50 p-4">
                <h4 className="font-semibold text-gold-dark">Not fully scheduled</h4>
                <ul className="mt-2 list-disc pl-5 text-sm text-ink/80">{v.unscheduled.map((u, k) => <li key={k}>{u.reason}</li>)}</ul>
              </div>
            )}

            <div className="card p-4">
              <div className="mb-3 flex flex-wrap items-end gap-3">
                <Field label="View by">
                  <select className="input" value={filterKind} onChange={(e) => { setFilterKind(e.target.value); setFilterValue(''); }}>
                    <option value="cohort">Cohort</option><option value="lecturer">Lecturer</option><option value="room">Room</option>
                  </select>
                </Field>
                <Field label="Show">
                  <select className="input" value={filterValue} onChange={(e) => setFilterValue(e.target.value)}>
                    <option value="">Everything</option>{options.map((o) => <option key={o}>{o}</option>)}
                  </select>
                </Field>
              </div>
              <Grid slots={shown} roomName={roomName} />
            </div>

            <div className="card overflow-x-auto p-4">
              <h4 className="mb-2 font-semibold text-ink">Sessions</h4>
              <table className="w-full text-left text-sm">
                <thead><tr className="text-xs uppercase text-ink/50"><th className="py-1">Unit</th><th>Cohort</th><th>Lecturer</th><th>When</th><th>Room</th><th /></tr></thead>
                <tbody>
                  {shown.map((s) => (
                    <tr key={s.id} className="border-t border-sage/60">
                      <td className="py-2 font-medium">{s.unit_code}</td><td>{s.cohort}</td><td>{s.lecturer_name || '—'}</td>
                      <td>{s.day} {s.start_time}–{s.end_time}{s.locked ? ' 🔒' : ''}</td><td>{roomName(s.room_id)}</td>
                      <td className="text-right">{me.can.manage && draft && <button className="btn-ghost !min-h-0 !py-1" onClick={() => setEditing({ ...s })}>Move</button>}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {shown.length === 0 && <p className="py-3 text-sm text-ink/55">No sessions to show.</p>}
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <div className="card p-4"><h4 className="mb-2 font-semibold text-ink">Room use</h4>
                {detail.stats.room_utilisation.map((r) => <p key={r.name} className="text-sm">{r.name}: {r.hours} h ({r.percent}%)</p>)}</div>
              <div className="card p-4"><h4 className="mb-2 font-semibold text-ink">Lecturer teaching hours</h4>
                {detail.stats.lecturer_load.map((r) => <p key={r.name} className="text-sm">{r.name}: {r.hours} h</p>)}</div>
            </div>
          </>
        )}
      </div>

      {editing && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" role="dialog" aria-modal="true">
          <div className="card w-full max-w-md space-y-3 p-5">
            <h3 className="font-display font-semibold">Move {editing.unit_code} ({editing.cohort})</h3>
            <Field label="Day"><select className="input w-full" value={editing.day} onChange={(e) => setEditing({ ...editing, day: e.target.value })}>{DAYS.map((d) => <option key={d}>{d}</option>)}</select></Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Start"><input className="input w-full" type="time" value={editing.start_time} onChange={(e) => setEditing({ ...editing, start_time: e.target.value })} /></Field>
              <Field label="End"><input className="input w-full" type="time" value={editing.end_time} onChange={(e) => setEditing({ ...editing, end_time: e.target.value })} /></Field>
            </div>
            <Field label="Room"><select className="input w-full" value={editing.room_id || ''} onChange={(e) => setEditing({ ...editing, room_id: Number(e.target.value) })}>{rooms.filter((r) => r.active).map((r) => <option key={r.id} value={r.id}>{r.name} ({r.capacity})</option>)}</select></Field>
            <p className="text-xs text-ink/55">A move that creates a clash is refused. A moved session is locked so regeneration keeps it.</p>
            <div className="flex justify-end gap-2">
              <button className="btn-ghost" onClick={() => setEditing(null)}>Cancel</button>
              <button className="btn-primary" disabled={busy} onClick={async () => { const ok = await run(() => api.patch(`/timetable-maker/versions/${v.id}/slots/${editing.id}`, { day: editing.day, start_time: editing.start_time, end_time: editing.end_time, room_id: editing.room_id }), 'Session moved.'); if (ok) setEditing(null); }}>Save move</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function Grid({ slots, roomName }) {
  const days = DAYS.filter((d, i) => i < 5 || slots.some((s) => s.day === d));
  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[640px] border-collapse text-xs">
        <thead><tr><th className="w-16 p-1" />{days.map((d) => <th key={d} className="p-1 text-left font-semibold text-ink">{d}</th>)}</tr></thead>
        <tbody>
          {HOURS.map((h) => (
            <tr key={h} className="border-t border-sage/60 align-top">
              <td className="p-1 text-ink/50">{h}</td>
              {days.map((d) => (
                <td key={d} className="p-1">
                  {slots.filter((s) => s.day === d && s.start_time.slice(0, 2) === h.slice(0, 2)).map((s) => (
                    <div key={s.id} className="mb-1 rounded-lg bg-forest/10 p-1.5">
                      <div className="font-semibold text-ink">{s.unit_code} <span className="font-normal text-ink/60">{s.cohort}</span></div>
                      <div className="text-ink/60">{s.start_time}–{s.end_time} · {roomName(s.room_id)}</div>
                      <div className="text-ink/60">{s.lecturer_name}</div>
                    </div>
                  ))}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ---------------- Units ----------------
const EMPTY_UNIT = { term: '2026/2027 Semester 1', unit_code: '', unit_name: '', department: '', programme: '', cohort: '', lecturer_user_id: '', sessions_per_week: 2, session_minutes: 120, class_size: 30, room_type_required: '', shared_group: '' };
function Units({ me, setError, setNotice }) {
  const [rows, setRows] = useState([]);
  const [lecturers, setLecturers] = useState([]);
  const [form, setForm] = useState(EMPTY_UNIT);
  const load = useCallback(() => api.get('/timetable-maker/units').then((r) => setRows(r.data)).catch((e) => setError(errorText(e, 'Could not load units.'))), [setError]);
  useEffect(() => { load(); api.get('/timetable-maker/lecturers').then((r) => setLecturers(r.data)).catch(() => {}); }, [load]);
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });
  async function add(e) {
    e.preventDefault(); setError(''); setNotice('');
    const lecturer = lecturers.find((l) => String(l.id) === String(form.lecturer_user_id));
    try { await api.post('/timetable-maker/units', { ...form, lecturer_name: lecturer?.name || '', lecturer_user_id: lecturer?.id || null }); setForm({ ...EMPTY_UNIT, term: form.term }); setNotice('Unit added.'); load(); }
    catch (err) { setError(errorText(err, 'Could not add the unit.')); }
  }
  async function remove(id) { if (!window.confirm('Remove this unit?')) return; try { await api.delete(`/timetable-maker/units/${id}`); load(); } catch (err) { setError(errorText(err, 'Could not remove the unit.')); } }
  return (
    <div className="space-y-5">
      {me.can.manage && (
        <form onSubmit={add} className="card grid gap-3 p-4 md:grid-cols-4">
          <Field label="Term"><input className="input w-full" value={form.term} onChange={set('term')} required /></Field>
          <Field label="Unit code"><input className="input w-full" value={form.unit_code} onChange={set('unit_code')} required /></Field>
          <Field label="Unit name"><input className="input w-full" value={form.unit_name} onChange={set('unit_name')} required /></Field>
          <Field label="Cohort"><input className="input w-full" value={form.cohort} onChange={set('cohort')} placeholder="e.g. BBIT Y2S1" required /></Field>
          <Field label="Department"><input className="input w-full" value={form.department} onChange={set('department')} /></Field>
          <Field label="Lecturer">
            <select className="input w-full" value={form.lecturer_user_id} onChange={set('lecturer_user_id')}><option value="">Not assigned</option>{lecturers.map((l) => <option key={l.id} value={l.id}>{l.name}</option>)}</select>
          </Field>
          <Field label="Sessions a week"><input className="input w-full" type="number" min="1" max="5" value={form.sessions_per_week} onChange={set('sessions_per_week')} /></Field>
          <Field label="Session length (min)"><select className="input w-full" value={form.session_minutes} onChange={set('session_minutes')}>{[60, 120, 180, 240].map((m) => <option key={m}>{m}</option>)}</select></Field>
          <Field label="Class size"><input className="input w-full" type="number" min="1" value={form.class_size} onChange={set('class_size')} /></Field>
          <Field label="Room type needed"><select className="input w-full" value={form.room_type_required} onChange={set('room_type_required')}><option value="">Any teaching room</option><option>Lecture hall</option><option>Laboratory</option><option>Seminar room</option></select></Field>
          <Field label="Shared class group"><input className="input w-full" value={form.shared_group} onChange={set('shared_group')} placeholder="same name = taught together" /></Field>
          <div className="flex items-end"><button className="btn-primary w-full">Add unit</button></div>
        </form>
      )}
      <div className="card overflow-x-auto p-4">
        <table className="w-full text-left text-sm">
          <thead><tr className="text-xs uppercase text-ink/50"><th className="py-1">Unit</th><th>Cohort</th><th>Lecturer</th><th>Sessions</th><th>Size</th><th>Term</th><th /></tr></thead>
          <tbody>{rows.map((u) => (
            <tr key={u.id} className="border-t border-sage/60"><td className="py-2 font-medium">{u.unit_code} <span className="font-normal text-ink/60">{u.unit_name}</span></td><td>{u.cohort}</td><td>{u.lecturer_name || '—'}</td>
              <td>{u.sessions_per_week} × {u.session_minutes / 60} h</td><td>{u.class_size}</td><td>{u.term}</td>
              <td className="text-right">{me.can.manage && <button className="btn-ghost !min-h-0 !py-1" onClick={() => remove(u.id)}>Remove</button>}</td></tr>
          ))}</tbody>
        </table>
        {rows.length === 0 && <p className="py-3 text-sm text-ink/55">No units yet. Add the real teaching requirements for the term.</p>}
      </div>
    </div>
  );
}

// ---------------- Rooms ----------------
function Rooms({ me, setError, setNotice }) {
  const [rooms, setRooms] = useState([]);
  const [blocks, setBlocks] = useState([]);
  const [form, setForm] = useState({ name: '', building: '', capacity: 60, room_type: 'Lecture hall' });
  const [block, setBlock] = useState({ room_id: '', day: 'Monday', start_time: '08:00', end_time: '10:00', reason: '' });
  const load = useCallback(() => {
    api.get('/timetable-maker/rooms').then((r) => setRooms(r.data)).catch((e) => setError(errorText(e, 'Could not load rooms.')));
    api.get('/timetable-maker/room-blocks').then((r) => setBlocks(r.data)).catch(() => {});
  }, [setError]);
  useEffect(() => { load(); }, [load]);
  async function post(url, body, ok, reset) { setError(''); setNotice(''); try { await api.post(url, body); setNotice(ok); reset(); load(); } catch (e) { setError(errorText(e, 'That did not work.')); } }
  return (
    <div className="space-y-5">
      {me.can.manage && (
        <div className="grid gap-4 lg:grid-cols-2">
          <form className="card grid gap-3 p-4 md:grid-cols-2" onSubmit={(e) => { e.preventDefault(); post('/timetable-maker/rooms', form, 'Room added.', () => setForm({ ...form, name: '' })); }}>
            <Field label="Room name"><input className="input w-full" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required /></Field>
            <Field label="Building"><input className="input w-full" value={form.building} onChange={(e) => setForm({ ...form, building: e.target.value })} /></Field>
            <Field label="Capacity"><input className="input w-full" type="number" min="1" value={form.capacity} onChange={(e) => setForm({ ...form, capacity: e.target.value })} /></Field>
            <Field label="Type"><select className="input w-full" value={form.room_type} onChange={(e) => setForm({ ...form, room_type: e.target.value })}><option>Lecture hall</option><option>Laboratory</option><option>Seminar room</option></select></Field>
            <button className="btn-primary md:col-span-2">Add room</button>
          </form>
          <form className="card grid gap-3 p-4 md:grid-cols-2" onSubmit={(e) => { e.preventDefault(); post('/timetable-maker/room-blocks', block, 'Maintenance period saved.', () => setBlock({ ...block, reason: '' })); }}>
            <Field label="Room under maintenance"><select className="input w-full" value={block.room_id} onChange={(e) => setBlock({ ...block, room_id: e.target.value })} required><option value="">Choose…</option>{rooms.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}</select></Field>
            <Field label="Day"><select className="input w-full" value={block.day} onChange={(e) => setBlock({ ...block, day: e.target.value })}>{DAYS.map((d) => <option key={d}>{d}</option>)}</select></Field>
            <Field label="From"><input className="input w-full" type="time" value={block.start_time} onChange={(e) => setBlock({ ...block, start_time: e.target.value })} /></Field>
            <Field label="To"><input className="input w-full" type="time" value={block.end_time} onChange={(e) => setBlock({ ...block, end_time: e.target.value })} /></Field>
            <button className="btn-ghost md:col-span-2">Block this period</button>
          </form>
        </div>
      )}
      <div className="card overflow-x-auto p-4">
        <table className="w-full text-left text-sm">
          <thead><tr className="text-xs uppercase text-ink/50"><th className="py-1">Room</th><th>Building</th><th>Type</th><th>Seats</th><th>Status</th></tr></thead>
          <tbody>{rooms.map((r) => <tr key={r.id} className="border-t border-sage/60"><td className="py-2 font-medium">{r.name}</td><td>{r.building || '—'}</td><td>{r.room_type}</td><td>{r.capacity}</td><td>{r.active ? 'In use' : 'Inactive'}</td></tr>)}</tbody>
        </table>
        {blocks.length > 0 && <div className="mt-4 border-t border-sage/60 pt-3 text-sm"><h4 className="mb-1 font-semibold">Maintenance periods</h4>
          {blocks.map((b) => (
            <p key={b.id}>{b.room_name}: {b.day} {b.start_time}–{b.end_time}
              {me.can.manage && <button className="ml-2 text-clay underline" onClick={async () => { await api.delete(`/timetable-maker/room-blocks/${b.id}`); load(); }}>remove</button>}</p>
          ))}</div>}
      </div>
    </div>
  );
}

// ---------------- Lecturer availability ----------------
function Availability({ me, setError, setNotice }) {
  const [rows, setRows] = useState([]);
  const [lecturers, setLecturers] = useState([]);
  const [form, setForm] = useState({ lecturer_user_id: '', day: 'Monday', start_time: '08:00', end_time: '10:00', reason: '' });
  const load = useCallback(() => api.get('/timetable-maker/availability').then((r) => setRows(r.data)).catch((e) => setError(errorText(e, 'Could not load availability.'))), [setError]);
  useEffect(() => { load(); if (me.can.manage) api.get('/timetable-maker/lecturers').then((r) => setLecturers(r.data)).catch(() => {}); }, [load, me]);
  async function add(e) {
    e.preventDefault(); setError(''); setNotice('');
    try { await api.post('/timetable-maker/availability', form); setNotice('Unavailable period saved.'); load(); } catch (err) { setError(errorText(err, 'Could not save.')); }
  }
  return (
    <div className="space-y-5">
      <form onSubmit={add} className="card grid gap-3 p-4 md:grid-cols-5">
        {me.can.manage && <Field label="Lecturer"><select className="input w-full" value={form.lecturer_user_id} onChange={(e) => setForm({ ...form, lecturer_user_id: e.target.value })} required><option value="">Choose…</option>{lecturers.map((l) => <option key={l.id} value={l.id}>{l.name}</option>)}</select></Field>}
        <Field label="Day"><select className="input w-full" value={form.day} onChange={(e) => setForm({ ...form, day: e.target.value })}>{DAYS.map((d) => <option key={d}>{d}</option>)}</select></Field>
        <Field label="From"><input className="input w-full" type="time" value={form.start_time} onChange={(e) => setForm({ ...form, start_time: e.target.value })} /></Field>
        <Field label="To"><input className="input w-full" type="time" value={form.end_time} onChange={(e) => setForm({ ...form, end_time: e.target.value })} /></Field>
        <Field label="Reason (optional)"><input className="input w-full" value={form.reason} onChange={(e) => setForm({ ...form, reason: e.target.value })} /></Field>
        <button className="btn-primary md:col-span-5">Mark as unavailable</button>
      </form>
      <div className="card p-4 text-sm">
        {rows.length === 0 && <p className="text-ink/55">No unavailable periods recorded.</p>}
        {rows.map((r) => (
          <p key={r.id} className="border-t border-sage/60 py-2 first:border-0">{r.lecturer_name}: {r.day} {r.start_time}–{r.end_time}{r.reason ? ` (${r.reason})` : ''}
            <button className="ml-2 text-clay underline" onClick={async () => { try { await api.delete(`/timetable-maker/availability/${r.id}`); load(); } catch (e) { setError(errorText(e, 'Could not remove.')); } }}>remove</button></p>
        ))}
      </div>
    </div>
  );
}

// ---------------- Change history ----------------
function History() {
  const [rows, setRows] = useState([]);
  useEffect(() => { api.get('/timetable-maker/audit').then((r) => setRows(r.data)).catch(() => {}); }, []);
  return (
    <div className="card overflow-x-auto p-4">
      <table className="w-full text-left text-sm">
        <thead><tr className="text-xs uppercase text-ink/50"><th className="py-1">When</th><th>Who</th><th>Action</th><th>Details</th></tr></thead>
        <tbody>{rows.map((r) => <tr key={r.id} className="border-t border-sage/60"><td className="py-2">{r.created_at}</td><td>{r.actor_name} <span className="text-ink/50">({r.actor_role})</span></td><td>{r.action.replaceAll('_', ' ')}</td><td>{r.details}</td></tr>)}</tbody>
      </table>
      {rows.length === 0 && <p className="py-3 text-sm text-ink/55">No changes recorded yet.</p>}
    </div>
  );
}
