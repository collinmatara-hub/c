import { useEffect, useState } from 'react';
import { CalendarDays } from 'lucide-react';
import DashboardLayout from '../../components/DashboardLayout.jsx';
import { EmptyState } from '../../components/Skeleton.jsx';
import api from '../../api/axios.js';

const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

// Lecturers see the sessions they teach; students see the units they registered for.
// Only a published timetable is ever shown here.
export default function MyTimetable() {
  const [data, setData] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    api.get('/timetable-maker/mine').then((r) => setData(r.data)).catch((e) => setError(e.response?.data?.error || 'Could not load your timetable.'));
  }, []);

  const days = DAYS.filter((d) => data?.slots.some((s) => s.day === d));
  return (
    <DashboardLayout title="My Timetable" subtitle="Your official weekly timetable.">
      {error && <p className="mb-4 rounded-lg bg-clay/10 px-3 py-2 text-sm text-clay" role="alert">{error}</p>}
      {!data ? (!error && <p className="text-sm text-ink/45">Loading…</p>) : !data.published ? (
        <EmptyState icon={CalendarDays} title="No published timetable yet" hint="The timetable will appear here once it has been approved and published." />
      ) : data.slots.length === 0 ? (
        <EmptyState icon={CalendarDays} title="No sessions for you" hint="Register for your units, or ask the timetabling office if a unit is missing." />
      ) : (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {days.map((d) => (
            <div key={d} className="card p-4">
              <h3 className="mb-3 font-display font-semibold text-ink">{d}</h3>
              <ul className="space-y-2">
                {data.slots.filter((s) => s.day === d).map((s, i) => (
                  <li key={i} className="rounded-xl bg-forest/10 p-3 text-sm">
                    <p className="font-semibold text-ink">{s.unit_code} · {s.unit_name}</p>
                    <p className="text-ink/65">{s.start_time}–{s.end_time} · {s.room || 'Room to be confirmed'}{s.building ? `, ${s.building}` : ''}</p>
                    {s.lecturer && <p className="text-ink/65">{s.lecturer}</p>}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      )}
    </DashboardLayout>
  );
}
