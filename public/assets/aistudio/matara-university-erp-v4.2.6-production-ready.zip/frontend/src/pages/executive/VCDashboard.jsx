import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  ResponsiveContainer, AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, PieChart, Pie, Cell,
} from 'recharts';
import { Wallet, Users, GraduationCap, TrendingUp, Landmark, Building2, Gavel, ClipboardList, ShieldAlert, Banknote } from 'lucide-react';
import DashboardLayout from '../../components/DashboardLayout.jsx';
import { DashboardSkeleton } from '../../components/Skeleton.jsx';
import Panel from '../../components/dashboard/Panel.jsx';
import StatTile from '../../components/dashboard/StatTile.jsx';
import api from '../../api/axios.js';
import { useAuth } from '../../context/AuthContext.jsx';
import { useTheme } from '../../context/ThemeContext.jsx';
import { firstName, greeting, kes } from '../../utils/format.js';

const COLORS = {
  light: { grid: '#DCE7F0', text: '#61768A', line: '#2F86E6', fill: '#5AA7F0', tipBg: '#fff', tipBorder: '#D7E3EC', tipText: '#102A43' },
  dark: { grid: '#263B4D', text: '#9DB1C0', line: '#5AA7F0', fill: '#2F86E6', tipBg: '#102334', tipBorder: '#294257', tipText: '#E6EEF5' },
};
const SLICES = ['#3B8EF3', '#32C89B', '#F1B33C', '#F27667', '#8A67E8', '#2DC4C8', '#B58BEA', '#45C89A'];

function Tip({ colors, formatter }) {
  return <Tooltip formatter={formatter} contentStyle={{ background: colors.tipBg, border: `1px solid ${colors.tipBorder}`, borderRadius: 12, color: colors.tipText, fontSize: 12 }} />;
}

function Bar100({ label, value, total }) {
  const pct = total > 0 ? Math.min(100, Math.round((value / total) * 100)) : 0;
  return (
    <div>
      <div className="mb-1 flex justify-between text-xs"><span className="text-ink/70">{label}</span><span className="font-semibold text-ink">{value.toLocaleString('en-KE')}</span></div>
      <div className="h-2 overflow-hidden rounded-full bg-sage/50"><div className="h-full rounded-full bg-forest" style={{ width: `${pct}%` }} /></div>
    </div>
  );
}

export default function VCDashboard() {
  const { user } = useAuth();
  const { theme } = useTheme();
  const colors = COLORS[theme === 'dark' ? 'dark' : 'light'];
  const [data, setData] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    api.get('/dashboard/executive').then((r) => setData(r.data)).catch((e) => setError(e.response?.data?.error || 'Could not load the dashboard.'));
  }, []);

  if (error) return <DashboardLayout title="Executive Dashboard"><div className="rounded-xl bg-clay/10 p-4 text-sm text-clay">{error}</div></DashboardLayout>;
  if (!data) return <DashboardLayout title="Executive Dashboard"><DashboardSkeleton /></DashboardLayout>;

  const { revenue, revenue_trend: revTrend, enrolment, graduation, people, attention } = data;
  const net = revenue.total_revenue - revenue.expenses;

  return (
    <DashboardLayout title={`${greeting()}, ${firstName(user?.name)}`} subtitle={`${data.institution}: executive overview. View-only.`}>
      <div className="space-y-4">
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <StatTile icon={Wallet} label="Total Revenue" value={kes(revenue.total_revenue)} hint={`${revenue.collection_rate}% of billed fees collected`} up={revenue.collection_rate >= 70} />
          <StatTile icon={Users} label="Total Enrolment" value={enrolment.active.toLocaleString('en-KE')} hint={`${enrolment.total.toLocaleString('en-KE')} students on record`} />
          <StatTile icon={GraduationCap} label="Graduation Rate" value={`${graduation.rate}%`} hint={`${graduation.cleared} of ${graduation.candidates} candidates cleared`} up={graduation.rate >= 70} />
          <StatTile icon={Banknote} label="Outstanding Fees" value={kes(revenue.outstanding)} hint={`${kes(revenue.billed)} billed`} />
        </div>

        <div className="grid gap-4 xl:grid-cols-2">
          <Panel icon={TrendingUp} title="Revenue Received" subtitle="Last 6 months">
            <ResponsiveContainer width="100%" height={230}>
              <AreaChart data={revTrend} margin={{ top: 10, right: 8, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke={colors.grid} vertical={false} />
                <XAxis dataKey="month" tick={{ fontSize: 11, fill: colors.text }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 10, fill: colors.text }} axisLine={false} tickLine={false} width={52} tickFormatter={(v) => (v >= 1000 ? `${Math.round(v / 1000)}k` : v)} />
                <Tip colors={colors} formatter={(v) => [kes(v), 'Revenue']} />
                <Area type="monotone" dataKey="revenue" stroke={colors.line} fill={colors.fill} fillOpacity={0.25} strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
            <div className="mt-3 grid grid-cols-3 gap-3 text-center text-xs">
              <div><p className="text-ink/50">Collected</p><p className="font-bold text-ink">{kes(revenue.collected)}</p></div>
              <div><p className="text-ink/50">Other income</p><p className="font-bold text-ink">{kes(revenue.other_income)}</p></div>
              <div><p className="text-ink/50">Net of expenses</p><p className={`font-bold ${net < 0 ? 'text-clay' : 'text-ink'}`}>{kes(net)}</p></div>
            </div>
          </Panel>

          <Panel icon={Users} title="Enrolment Trend" subtitle="Active students, last 6 months">
            <ResponsiveContainer width="100%" height={230}>
              <AreaChart data={enrolment.trend} margin={{ top: 10, right: 8, left: -10, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke={colors.grid} vertical={false} />
                <XAxis dataKey="month" tick={{ fontSize: 11, fill: colors.text }} axisLine={false} tickLine={false} />
                <YAxis allowDecimals={false} tick={{ fontSize: 10, fill: colors.text }} axisLine={false} tickLine={false} />
                <Tip colors={colors} formatter={(v) => [v, 'Students']} />
                <Area type="monotone" dataKey="students" stroke={colors.line} fill={colors.fill} fillOpacity={0.25} strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </Panel>
        </div>

        <div className="grid gap-4 xl:grid-cols-3">
          <Panel icon={Building2} title="Enrolment by Faculty">
            {enrolment.by_faculty.length === 0 ? <p className="text-sm text-ink/55">No programme enrolments recorded yet.</p> : (
              <div className="flex items-center gap-4">
                <ResponsiveContainer width={150} height={150}>
                  <PieChart><Pie data={enrolment.by_faculty} dataKey="count" nameKey="name" innerRadius={42} outerRadius={68} paddingAngle={2}>
                    {enrolment.by_faculty.map((_, i) => <Cell key={i} fill={SLICES[i % SLICES.length]} />)}
                  </Pie><Tip colors={colors} formatter={(v, n) => [v, n]} /></PieChart>
                </ResponsiveContainer>
                <ul className="min-w-0 flex-1 space-y-1.5 text-xs">
                  {enrolment.by_faculty.map((f, i) => <li key={f.name} className="flex items-center gap-2"><i className="h-2.5 w-2.5 shrink-0 rounded-full" style={{ background: SLICES[i % SLICES.length] }} /><span className="truncate text-ink/70">{f.name}</span><b className="ml-auto text-ink">{f.count}</b></li>)}
                </ul>
              </div>
            )}
          </Panel>

          <Panel icon={ClipboardList} title="Top Programmes" subtitle="Active enrolments">
            {enrolment.by_programme.length === 0 ? <p className="text-sm text-ink/55">No programme enrolments recorded yet.</p> : (
              <div className="space-y-3">{enrolment.by_programme.map((p) => <Bar100 key={p.name} label={p.name} value={p.count} total={enrolment.by_programme[0].count} />)}</div>
            )}
          </Panel>

          <Panel icon={GraduationCap} title="Graduation Pipeline">
            <div className="space-y-3">
              <Bar100 label="Candidates" value={graduation.candidates} total={graduation.candidates} />
              <Bar100 label="Academically ready" value={graduation.ready} total={graduation.candidates} />
              <Bar100 label="Senate approved" value={graduation.senate} total={graduation.candidates} />
              <Bar100 label="Cleared to graduate" value={graduation.cleared} total={graduation.candidates} />
            </div>
            {graduation.years.length > 0 && (
              <ResponsiveContainer width="100%" height={110}>
                <BarChart data={[...graduation.years].reverse()} margin={{ top: 14, right: 4, left: -26, bottom: 0 }}>
                  <XAxis dataKey="academic_year" tick={{ fontSize: 10, fill: colors.text }} axisLine={false} tickLine={false} />
                  <YAxis domain={[0, 100]} tick={{ fontSize: 9, fill: colors.text }} axisLine={false} tickLine={false} />
                  <Tip colors={colors} formatter={(v) => [`${v}%`, 'Graduation rate']} />
                  <Bar dataKey="rate" fill={colors.fill} radius={[6, 6, 0, 0]} maxBarSize={30} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </Panel>
        </div>

        <div className="grid gap-4 xl:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
          <Panel icon={Landmark} title="University at a Glance">
            <div className="grid grid-cols-3 gap-3 text-center">
              {[['Staff', people.staff], ['Programmes', people.programmes], ['Faculties', people.faculties]].map(([l, v]) => (
                <div key={l} className="quick-stat justify-center"><div><p className="text-xl font-extrabold text-ink">{v}</p><p className="text-[11px] text-ink/55">{l}</p></div></div>
              ))}
            </div>
            <div className="mt-4 flex flex-wrap gap-2 text-xs font-semibold">
              <Link to="/university" className="btn-secondary">University Overview</Link>
              <Link to="/admin/graduation" className="btn-secondary">Graduation &amp; Clearance</Link>
              <Link to="/admin/degree-audit" className="btn-secondary">Degree Audit</Link>
            </div>
          </Panel>

          <Panel icon={ShieldAlert} title="Needs Your Attention" subtitle="Counts only. Decisions are made by the offices that own them.">
            <ul className="space-y-2 text-sm">
              {[[Gavel, 'Senate motions open for voting', attention.open_motions], [ClipboardList, 'Workflow requests pending', attention.pending_workflows], [ShieldAlert, 'Open disciplinary cases', attention.open_suspensions], [Wallet, 'Active financial holds', attention.active_holds]].map(([Icon, label, v]) => (
                <li key={label} className="flex items-center gap-3"><Icon size={16} className="text-ink/45" /><span className="text-ink/75">{label}</span><b className="ml-auto text-ink">{v}</b></li>
              ))}
            </ul>
          </Panel>
        </div>
      </div>
    </DashboardLayout>
  );
}
