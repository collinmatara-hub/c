import { useEffect, useRef, useState } from 'react';
import { ArrowLeft, MessageSquare, Plus, Send } from 'lucide-react';
import DashboardLayout from '../components/DashboardLayout.jsx';
import api from '../api/axios.js';
import { useAuth } from '../context/AuthContext.jsx';
import { timeAgo, parseDbTime } from '../utils/format.js';

const ROLE_NAMES = { teacher: 'Lecturer', student: 'Student', admin: 'Administrator', parent: 'Parent' };

// Messages for students, lecturers and admins.
// Students write to their lecturers. Lecturers and admins reply and can write to students.
export default function Messages() {
  const { user } = useAuth();
  const [threads, setThreads] = useState([]);
  const [contacts, setContacts] = useState([]);
  const [openId, setOpenId] = useState(null);
  const [thread, setThread] = useState(null);
  const [composing, setComposing] = useState(false);
  const [form, setForm] = useState({ recipient_id: '', subject: '', body: '' });
  const [reply, setReply] = useState('');
  const [error, setError] = useState('');
  const [sending, setSending] = useState(false);
  const bottomRef = useRef(null);

  async function loadThreads() {
    try {
      const res = await api.get('/messages/threads');
      setThreads(res.data);
    } catch (err) {
      setError(err.response?.data?.error || 'Could not load your messages.');
    }
  }

  async function loadThread(id) {
    try {
      const res = await api.get(`/messages/threads/${id}`);
      setThread(res.data);
      loadThreads();
      // Opening a conversation marks it read, so refresh the count in the top bar
      window.dispatchEvent(new Event('matara:messages-changed'));
    } catch (err) {
      setError(err.response?.data?.error || 'Could not open that conversation.');
    }
  }

  useEffect(() => {
    loadThreads();
    api.get('/messages/contacts').then((res) => setContacts(res.data)).catch(() => {});
    // Check for new messages every 30 seconds
    const timer = setInterval(() => {
      loadThreads();
      setOpenId((id) => { if (id) loadThread(id); return id; });
    }, 30000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    bottomRef.current?.scrollIntoView?.({ block: 'end' });
  }, [thread]);

  function open(id) {
    setError('');
    setComposing(false);
    setOpenId(id);
    setThread(null);
    loadThread(id);
  }

  async function send(payload, done) {
    setSending(true);
    setError('');
    try {
      await api.post('/messages', payload);
      done();
    } catch (err) {
      setError(err.response?.data?.error || 'Could not send your message.');
    } finally {
      setSending(false);
    }
  }

  function sendNew(e) {
    e.preventDefault();
    if (!form.recipient_id) { setError('Choose who to write to.'); return; }
    send(form, () => {
      const id = Number(form.recipient_id);
      setForm({ recipient_id: '', subject: '', body: '' });
      open(id);
    });
  }

  function sendReply(e) {
    e.preventDefault();
    if (!reply.trim()) return;
    send({ recipient_id: openId, body: reply }, () => {
      setReply('');
      loadThread(openId);
    });
  }

  const contactLabel = user?.role === 'student' ? 'Lecturer' : 'Person';
  const showList = !openId && !composing;

  return (
    <DashboardLayout
      title={user?.role === 'student' ? 'Contact Lecturer' : 'Messages'}
      subtitle={user?.role === 'student' ? 'Send a message to your lecturers and read their replies' : 'Read and reply to messages'}
    >
      {error && <p className="mb-4 rounded-lg bg-clay/10 px-3 py-2 text-sm text-clay" role="alert">{error}</p>}

      <div className="grid gap-6 lg:grid-cols-[minmax(0,320px)_minmax(0,1fr)]">
        {/* Conversations */}
        <section className={`card flex max-h-[70vh] flex-col p-3 ${showList ? '' : 'hidden lg:flex'}`}>
          <button className="btn-primary mb-3" onClick={() => { setComposing(true); setOpenId(null); setThread(null); setError(''); }}>
            <Plus size={16} /> New message
          </button>
          {threads.length === 0 ? (
            <p className="px-3 py-8 text-center text-sm text-ink/45">No conversations yet.</p>
          ) : (
            <ul className="min-h-0 flex-1 space-y-1 overflow-y-auto">
              {threads.map((t) => (
                <li key={t.user_id}>
                  <button
                    onClick={() => open(t.user_id)}
                    className={`w-full rounded-xl px-3 py-3 text-left transition hover:bg-forest/10 ${openId === t.user_id ? 'bg-forest/15' : ''}`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <p className="truncate text-sm font-semibold text-ink">{t.name}</p>
                      <span className="shrink-0 text-[11px] text-ink/45">{timeAgo(t.last_at)}</span>
                    </div>
                    <div className="flex items-center justify-between gap-2">
                      <p className="truncate text-xs text-ink/55">{t.last_from_me ? 'You: ' : ''}{t.last_message}</p>
                      {t.unread > 0 && (
                        <span className="flex h-5 min-w-5 shrink-0 items-center justify-center rounded-full bg-clay px-1 text-[11px] font-bold text-white">{t.unread}</span>
                      )}
                    </div>
                    <p className="text-[11px] text-forest">{ROLE_NAMES[t.role] || t.role}</p>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </section>

        {/* Thread or new message */}
        <section className={`card flex min-h-[420px] flex-col p-5 ${showList ? 'hidden lg:flex' : ''}`}>
          {composing ? (
            <form onSubmit={sendNew} className="space-y-4">
              <div className="flex items-center gap-3">
                <button type="button" className="icon-btn !h-9 !w-9 lg:hidden" onClick={() => setComposing(false)} aria-label="Back"><ArrowLeft size={16} /></button>
                <h3 className="text-base font-bold text-ink">New message</h3>
              </div>
              <label className="block">
                <span className="label">{contactLabel}</span>
                <select className="input" value={form.recipient_id} onChange={(e) => setForm({ ...form, recipient_id: e.target.value })}>
                  <option value="">Choose…</option>
                  {contacts.map((c) => (
                    <option key={c.user_id} value={c.user_id}>{c.name}{c.detail ? ` — ${c.detail}` : ''}</option>
                  ))}
                </select>
              </label>
              <label className="block">
                <span className="label">Subject (optional)</span>
                <input className="input" value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })} placeholder="For example: CAT 1 marks" />
              </label>
              <label className="block">
                <span className="label">Message</span>
                <textarea className="input min-h-[140px]" value={form.body} onChange={(e) => setForm({ ...form, body: e.target.value })} />
              </label>
              <button type="submit" className="btn-primary" disabled={sending}><Send size={15} /> {sending ? 'Sending…' : 'Send message'}</button>
            </form>
          ) : !openId ? (
            <div className="m-auto text-center text-ink/45">
              <MessageSquare className="mx-auto mb-2" size={28} />
              <p className="text-sm">Choose a conversation, or start a new message.</p>
            </div>
          ) : !thread ? (
            <p className="text-sm text-ink/45">Loading…</p>
          ) : (
            <>
              <div className="mb-4 flex items-center gap-3 border-b border-sage/60 pb-3">
                <button className="icon-btn !h-9 !w-9 lg:hidden" onClick={() => { setOpenId(null); setThread(null); }} aria-label="Back to conversations"><ArrowLeft size={16} /></button>
                <div>
                  <h3 className="text-base font-bold text-ink">{thread.person.name}</h3>
                  <p className="text-xs text-forest">{ROLE_NAMES[thread.person.role] || thread.person.role}</p>
                </div>
              </div>

              <ul className="mb-4 max-h-[46vh] flex-1 space-y-3 overflow-y-auto pr-1">
                {thread.messages.map((m) => (
                  <li key={m.id} className={`flex ${m.mine ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[85%] rounded-2xl px-4 py-2.5 text-sm ${m.mine ? 'bg-forest text-on-forest' : 'bg-paper text-ink'}`}>
                      {m.subject && <p className="mb-0.5 text-xs font-bold opacity-80">{m.subject}</p>}
                      <p className="whitespace-pre-wrap">{m.body}</p>
                      <p className={`mt-1 text-[11px] ${m.mine ? 'text-on-forest/70' : 'text-ink/45'}`}>
                        {parseDbTime(m.created_at).toLocaleString('en-GB', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
                      </p>
                    </div>
                  </li>
                ))}
                <li ref={bottomRef} />
              </ul>

              <form onSubmit={sendReply} className="flex gap-2">
                <input className="input" value={reply} onChange={(e) => setReply(e.target.value)} placeholder="Write a reply…" aria-label="Reply" />
                <button type="submit" className="btn-primary" disabled={sending || !reply.trim()}><Send size={15} /> Send</button>
              </form>
            </>
          )}
        </section>
      </div>
    </DashboardLayout>
  );
}
