import { useCallback, useEffect, useMemo, useState } from 'react';
import { ChevronLeft, ChevronRight, MapPin } from 'lucide-react';
import DashboardLayout from '../../components/DashboardLayout.jsx';
import api from '../../api/axios.js';

const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const WEEKDAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
const STATUS = { draft: 'Draft', pending: 'Waiting for approval', published: 'Published', cancelled: 'Cancelled' };
const AUDIENCE = { all: 'Everyone', students: 'Students', staff: 'Staff', lecturers: 'Lecturers' };
const EMPTY = { title: '', category: '', event_type: 'Event', start_date: '', end_date: '', start_time: '', end_time: '', location: '', audience: 'all', academic_year: '', description: '' };

const pad = (n) => String(n).padStart(2, '0');
const iso = (y, m, d) => `${y}-${pad(m + 1)}-${pad(d)}`;
const errorText = (e, fallback) => e.response?.data?.error || fallback;

function Field({ label, children }) {
  return <label className="block"><span className="label mb-1 block text-xs uppercase text-ink/55">{label}</span>{children}</label>;
}

export default function Calendar() {
  const today = new Date();
  const [me, setMe] = useState(null);
  const [events, setEvents] = useState([]);
  const [tab, setTab] = useState('calendar');
  const [year, setYear] = useState(today.getFullYear());
  const [month, setMonth] = useState(today.getMonth());
  const [category, setCategory] = useState('');
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  const load = useCallback(() => api.get('/calendar/events').then((r) => setEvents(r.data)).catch((e) => setError(errorText(e, 'Could not load the calendar.'))), []);
  useEffect(() => { api.get('/calendar/me').then((r) => setMe(r.data)).catch(() => {}); load(); }, [load]);

  const label = (key) => me?.categories.find((c) => c.key === key)?.label.split(' (')[0] || key;
  const visible = events.filter((e) => ['published', 'cancelled'].includes(e.status) && (!category || e.category === category));

  const cells = useMemo(() => {
    const first = new Date(year, month, 1);
    const offset = (first.getDay() + 6) % 7; // Monday first
    const days = new Date(year, month + 1, 0).getDate();
    return [...Array(offset).fill(null), ...Array.from({ length: days }, (_, i) => i + 1)];
  }, [year, month]);
  const onDay = (d) => { const key = iso(year, month, d); return visible.filter((e) => e.start_date <= key && e.end_date >= key); };
  const shift = (step) => { const d = new Date(year, month + step, 1); setYear(d.getFullYear()); setMonth(d.getMonth()); };
  const monthEvents = visible.filter((e) => e.end_date >= iso(year, month, 1) && e.start_date <= iso(year, month, 31));

  return (
    <DashboardLayout title="University Calendar" subtitle="Official dates for the academic year, examinations, holidays, meetings and events.">
      {error && <p className="mb-4 rounded-lg bg-clay/10 px-3 py-2 text-sm text-clay" role="alert">{error}</p>}
      {notice && <p className="mb-4 rounded-lg bg-forest/10 px-3 py-2 text-sm text-forest-dark" role="status">{notice}</p>}
      <div className="mb-5 flex flex-wrap items-center gap-2">
        <button type="button" className={tab === 'calendar' ? 'btn-primary' : 'btn-ghost'} onClick={() => setTab('calendar')}>Calendar</button>
        {me?.manages && <button type="button" className={tab === 'manage' ? 'btn-primary' : 'btn-ghost'} onClick={() => setTab('manage')}>Manage events</button>}
        <a className="btn-ghost ml-auto" href="/api/calendar/export.ics">Add to my phone or Outlook (.ics)</a>
      </div>

      {tab === 'calendar' && (
        <div className="space-y-4">
          <div className="card flex flex-wrap items-center gap-3 p-4">
            <button type="button" className="btn-ghost !px-3" aria-label="Previous month" onClick={() => shift(-1)}><ChevronLeft size={18} /></button>
            <h2 className="font-display text-lg font-semibold text-ink">{MONTHS[month]} {year}</h2>
            <button type="button" className="btn-ghost !px-3" aria-label="Next month" onClick={() => shift(1)}><ChevronRight size={18} /></button>
            <button type="button" className="btn-ghost" onClick={() => { setYear(today.getFullYear()); setMonth(today.getMonth()); }}>Today</button>
            <select className="input ml-auto" aria-label="Filter by category" value={category} onChange={(e) => setCategory(e.target.value)}>
              <option value="">All categories</option>{me?.categories.map((c) => <option key={c.key} value={c.key}>{label(c.key)}</option>)}
            </select>
          </div>
          <div className="card overflow-x-auto p-3">
            <div className="grid min-w-[640px] grid-cols-7 gap-1 text-xs">
              {WEEKDAYS.map((d) => <div key={d} className="p-1 font-semibold text-ink/55">{d}</div>)}
              {cells.map((d, i) => (
                <div key={i} className={`min-h-[84px] rounded-lg border p-1 ${d ? 'border-sage/60' : 'border-transparent'} ${d && iso(year, month, d) === iso(today.getFullYear(), today.getMonth(), today.getDate()) ? 'bg-forest/5' : ''}`}>
                  {d && <div className="mb-1 text-ink/60">{d}</div>}
                  {d && onDay(d).slice(0, 3).map((e) => (
                    <div key={e.id} title={e.title} className={`mb-1 truncate rounded px-1 py-0.5 ${e.status === 'cancelled' ? 'bg-clay/10 text-clay line-through' : 'bg-forest/15 text-ink'}`}>{e.title}</div>
                  ))}
                  {d && onDay(d).length > 3 && <div className="text-ink/50">+{onDay(d).length - 3} more</div>}
                </div>
              ))}
            </div>
          </div>
          <div className="card divide-y divide-sage/50">
            {monthEvents.length === 0 && <p className="p-6 text-center text-sm text-ink/50">Nothing scheduled this month.</p>}
            {monthEvents.map((e) => <EventRow key={e.id} e={e} label={label(e.category)} />)}
          </div>
        </div>
      )}

      {tab === 'manage' && me && <Manage me={me} events={events} reload={load} setError={setError} setNotice={setNotice} label={label} />}
    </DashboardLayout>
  );
}

function EventRow({ e, label, children }) {
  const when = e.start_date === e.end_date ? e.start_date : `${e.start_date} to ${e.end_date}`;
  return (
    <div className="flex flex-wrap items-start gap-3 p-4">
      <div className="min-w-0 flex-1">
        <h3 className={`font-semibold text-ink ${e.status === 'cancelled' ? 'line-through' : ''}`}>{e.title}</h3>
        <p className="mt-1 text-sm text-ink/60">{when}{e.start_time ? ` · ${e.start_time}${e.end_time ? `–${e.end_time}` : ''}` : ''}
          {e.location && <> · <MapPin size={13} className="inline" /> {e.location}</>}</p>
        {e.description && <p className="mt-1 text-sm text-ink/55">{e.description}</p>}
        {e.review_note && <p className="mt-1 text-sm text-gold-dark">{e.status === 'cancelled' ? 'Cancelled' : 'Returned'}: {e.review_note}</p>}
        {children}
      </div>
      <div className="flex flex-col items-end gap-1">
        <span className="badge">{label}</span>
        <span className="text-xs text-ink/50">{AUDIENCE[e.audience]} · {STATUS[e.status]}</span>
      </div>
    </div>
  );
}

function Manage({ me, events, reload, setError, setNotice, label }) {
  const mine = me.categories.filter((c) => c.canAuthor || c.canPublish);
  const authorCats = mine.filter((c) => c.canAuthor);
  const [form, setForm] = useState({ ...EMPTY, category: authorCats[0]?.key || '' });
  const [editingId, setEditingId] = useState(null);
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });
  const cat = (key) => me.categories.find((c) => c.key === key);
  const owned = events.filter((e) => cat(e.category)?.canAuthor || cat(e.category)?.canPublish);

  async function act(fn, ok) {
    setBusy(true); setError(''); setNotice('');
    try { await fn(); setNotice(ok); await reload(); return true; } catch (e) { setError(errorText(e, 'That did not work.')); return false; } finally { setBusy(false); }
  }
  async function save(e) {
    e.preventDefault();
    const ok = await act(() => (editingId ? api.put(`/calendar/events/${editingId}`, form) : api.post('/calendar/events', form)), editingId ? 'Event updated.' : 'Saved as a draft. Submit it when it is ready.');
    if (ok) { setForm({ ...EMPTY, category: form.category }); setEditingId(null); }
  }
  const ask = (text) => window.prompt(text);

  const groups = [
    ['Waiting for your approval', (e) => e.status === 'pending' && cat(e.category)?.canPublish],
    ['Drafts', (e) => e.status === 'draft'],
    ['Waiting for approval by others', (e) => e.status === 'pending' && !cat(e.category)?.canPublish],
    ['Published and cancelled', (e) => ['published', 'cancelled'].includes(e.status)],
  ];

  return (
    <div className="space-y-5">
      <div className="card p-4 text-sm text-ink/70">
        <p className="mb-1 font-semibold text-ink">What you manage</p>
        <ul className="list-disc pl-5">
          {mine.map((c) => (
            <li key={c.key}>{c.label}: {c.canAuthor && c.canPublish ? 'you create and publish' : c.canPublish ? 'you approve and publish' : 'you propose; approved by a senior officer'}</li>
          ))}
        </ul>
      </div>

      {authorCats.length > 0 && (
        <form onSubmit={save} className="card grid gap-3 p-4 md:grid-cols-4">
          <Field label="Category"><select className="input w-full" value={form.category} onChange={set('category')} disabled={!!editingId}>{authorCats.map((c) => <option key={c.key} value={c.key}>{label(c.key)}</option>)}</select></Field>
          <Field label="Title"><input className="input w-full" value={form.title} onChange={set('title')} required /></Field>
          <Field label="Type"><select className="input w-full" value={form.event_type} onChange={set('event_type')}>{me.eventTypes.map((t) => <option key={t}>{t}</option>)}</select></Field>
          <Field label="Who it is for"><select className="input w-full" value={form.audience} onChange={set('audience')}>{me.audiences.map((a) => <option key={a} value={a}>{AUDIENCE[a]}</option>)}</select></Field>
          <Field label="Start date"><input className="input w-full" type="date" value={form.start_date} onChange={set('start_date')} required /></Field>
          <Field label="End date"><input className="input w-full" type="date" value={form.end_date} onChange={set('end_date')} /></Field>
          <Field label="From (optional)"><input className="input w-full" type="time" value={form.start_time} onChange={set('start_time')} /></Field>
          <Field label="To (optional)"><input className="input w-full" type="time" value={form.end_time} onChange={set('end_time')} /></Field>
          <Field label="Location"><input className="input w-full" value={form.location} onChange={set('location')} /></Field>
          <Field label="Academic year (e.g. 2026/2027)"><input className="input w-full" value={form.academic_year} onChange={set('academic_year')} /></Field>
          <div className="md:col-span-2"><Field label="Details"><input className="input w-full" value={form.description} onChange={set('description')} /></Field></div>
          <div className="flex gap-2 md:col-span-4">
            <button className="btn-primary" disabled={busy}>{editingId ? 'Save changes' : 'Save draft'}</button>
            {editingId && <button type="button" className="btn-ghost" onClick={() => { setEditingId(null); setForm({ ...EMPTY, category: authorCats[0].key }); }}>Cancel</button>}
          </div>
        </form>
      )}

      {groups.map(([title, test]) => {
        const rows = owned.filter(test);
        if (!rows.length) return null;
        return (
          <div key={title} className="card">
            <h3 className="border-b border-sage/50 p-4 font-display font-semibold text-ink">{title}</h3>
            <div className="divide-y divide-sage/50">
              {rows.map((e) => {
                const c = cat(e.category);
                return (
                  <EventRow key={e.id} e={e} label={label(e.category)}>
                    <div className="mt-2 flex flex-wrap gap-2">
                      {e.status === 'draft' && c.canAuthor && <button className="btn-primary !min-h-0 !py-1" disabled={busy} onClick={() => act(() => api.post(`/calendar/events/${e.id}/submit`), c.canPublish ? 'Published.' : 'Sent for approval.')}>{c.canPublish ? 'Publish' : 'Submit for approval'}</button>}
                      {e.status === 'pending' && c.canPublish && <button className="btn-primary !min-h-0 !py-1" disabled={busy} onClick={() => act(() => api.post(`/calendar/events/${e.id}/approve`), 'Approved and published.')}>Approve and publish</button>}
                      {e.status === 'pending' && c.canPublish && <button className="btn-ghost !min-h-0 !py-1" disabled={busy} onClick={() => { const note = ask('What must be changed?'); if (note) act(() => api.post(`/calendar/events/${e.id}/return`, { note }), 'Returned to the author.'); }}>Return</button>}
                      {((['draft', 'pending'].includes(e.status) && c.canAuthor) || (e.status === 'published' && c.canPublish)) && <button className="btn-ghost !min-h-0 !py-1" onClick={() => { setEditingId(e.id); setForm({ ...EMPTY, ...e }); window.scrollTo({ top: 0, behavior: 'smooth' }); }}>Edit</button>}
                      {e.status === 'published' && c.canPublish && <button className="btn-ghost !min-h-0 !py-1" disabled={busy} onClick={() => { const note = ask('Reason for cancelling?'); if (note) act(() => api.post(`/calendar/events/${e.id}/cancel`, { note }), 'Event cancelled and the audience notified.'); }}>Cancel event</button>}
                      {['draft', 'pending'].includes(e.status) && c.canAuthor && <button className="btn-ghost !min-h-0 !py-1" disabled={busy} onClick={() => { if (window.confirm('Delete this event?')) act(() => api.delete(`/calendar/events/${e.id}`), 'Deleted.'); }}>Delete</button>}
                    </div>
                  </EventRow>
                );
              })}
            </div>
          </div>
        );
      })}
    </div>
  );
}
