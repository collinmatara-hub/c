import { useCallback, useEffect, useState } from 'react';
import { LifeBuoy, Plus, RefreshCw, Search, TicketCheck } from 'lucide-react';
import DashboardLayout from '../../components/DashboardLayout.jsx';
import PageHeader from '../../components/PageHeader.jsx';
import api from '../../api/axios.js';

const INITIAL_FORM = { category: 'Academic', subject: '', description: '', priority: 'normal' };
const CATEGORIES = ['Academic', 'Finance', 'ICT', 'Admissions', 'HR', 'Library', 'Accommodation', 'Facilities', 'Other'];
const PRIORITIES = ['low', 'normal', 'high', 'urgent'];

function statusClass(status) {
  const value = String(status || '').toLowerCase();
  if (value === 'resolved' || value === 'closed') return 'bg-emerald-500/10 text-emerald-700';
  if (value === 'in_progress' || value === 'in progress') return 'bg-blue-500/10 text-blue-700';
  return 'bg-amber-500/10 text-amber-700';
}

function priorityClass(priority) {
  const value = String(priority || '').toLowerCase();
  if (value === 'urgent' || value === 'high') return 'bg-rose-500/10 text-rose-700';
  if (value === 'low') return 'bg-emerald-500/10 text-emerald-700';
  return 'bg-amber-500/10 text-amber-700';
}

export default function HelpDesk() {
  const [rows, setRows] = useState([]);
  const [queueAccess, setQueueAccess] = useState(false);
  const [form, setForm] = useState(INITIAL_FORM);
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [msg, setMsg] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    try {
      const response = await api.get('/university-experience/helpdesk');
      const payload = response.data || {};
      setQueueAccess(payload.access === 'helpdesk_queue');
      setRows(Array.isArray(payload.tickets) ? payload.tickets : (Array.isArray(payload) ? payload : []));
      setErr('');
    } catch (error) {
      setErr(error.response?.data?.error || 'Could not load tickets. Please try again.');
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const create = async (event) => {
    event.preventDefault();
    setBusy(true);
    setErr('');
    setMsg('');
    try {
      await api.post('/university-experience/helpdesk', form);
      setMsg('Ticket created successfully.');
      setForm(INITIAL_FORM);
      setOpen(false);
      await load();
    } catch (error) {
      setErr(error.response?.data?.error || 'Could not create ticket. Please try again.');
    } finally {
      setBusy(false);
    }
  };

  const update = async (id, status) => {
    setErr('');
    try {
      await api.patch(`/university-experience/helpdesk/${id}`, { status });
      setMsg(`Ticket marked ${status}.`);
      await load();
    } catch (error) {
      setErr(error.response?.data?.error || 'Could not update ticket.');
    }
  };

  const filteredRows = rows.filter((row) => {
    const query = search.trim().toLowerCase();
    const matchesSearch = !query || [row.ticket_no, row.subject, row.category, row.requester_name]
      .some((value) => String(value || '').toLowerCase().includes(query));
    const normalizedStatus = String(row.status || '').toLowerCase().replaceAll(' ', '_');
    const matchesStatus = statusFilter === 'all' || normalizedStatus === statusFilter;
    return matchesSearch && matchesStatus;
  });
  const openCount = rows.filter((row) => !['resolved', 'closed'].includes(String(row.status || '').toLowerCase())).length;
  const resolvedCount = rows.length - openCount;

  return (
    <DashboardLayout>
      {/* Keep the Help Desk inside the normal dashboard content area, not viewport-wide. */}
      <div className="mx-auto w-full max-w-7xl min-w-0 space-y-5">
        <PageHeader
          eyebrow="Service Desk"
          title="University Help Desk"
          subtitle="Create, track and resolve academic, finance, ICT, facilities and student-service requests."
          actions={<button type="button" className="btn-primary" onClick={() => { setOpen(true); setMsg(''); setErr(''); }}><Plus size={16} /> New ticket</button>}
        />

        {msg && <div role="status" className="rounded-xl border border-emerald-500/20 bg-emerald-500/10 p-3 text-sm text-emerald-800">{msg}</div>}
        {err && <div role="alert" className="rounded-xl border border-clay/20 bg-clay/10 p-3 text-sm text-clay">{err}</div>}

        {queueAccess && <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          <div className="card flex items-center gap-4 p-4 sm:p-5"><div className="rounded-xl bg-blue-500/10 p-3 text-blue-700"><LifeBuoy size={21} /></div><div><p className="text-sm text-ink/55">Total tickets</p><p className="mt-1 text-2xl font-bold text-ink">{rows.length}</p></div></div>
          <div className="card flex items-center gap-4 p-4 sm:p-5"><div className="rounded-xl bg-amber-500/10 p-3 text-amber-700"><TicketCheck size={21} /></div><div><p className="text-sm text-ink/55">Awaiting resolution</p><p className="mt-1 text-2xl font-bold text-ink">{openCount}</p></div></div>
          <div className="card flex items-center gap-4 p-4 sm:p-5"><div className="rounded-xl bg-emerald-500/10 p-3 text-emerald-700"><TicketCheck size={21} /></div><div><p className="text-sm text-ink/55">Resolved / closed</p><p className="mt-1 text-2xl font-bold text-ink">{resolvedCount}</p></div></div>
        </div>}

        {open && (
          <form onSubmit={create} className="card grid min-w-0 grid-cols-1 gap-4 p-4 sm:p-5 md:grid-cols-2">
            <div className="md:col-span-2 flex items-center justify-between gap-3"><h2 className="font-display text-lg font-semibold">Create a support ticket</h2><button type="button" className="btn-ghost !px-3 !py-1.5" onClick={() => setOpen(false)}>Cancel</button></div>
            <label><span className="label">Category</span><select className="input mt-1" value={form.category} onChange={(event) => setForm({ ...form, category: event.target.value })}>{CATEGORIES.map((category) => <option key={category} value={category}>{category}</option>)}</select></label>
            <label><span className="label">Priority</span><select className="input mt-1" value={form.priority} onChange={(event) => setForm({ ...form, priority: event.target.value })}>{PRIORITIES.map((priority) => <option key={priority} value={priority}>{priority.charAt(0).toUpperCase() + priority.slice(1)}</option>)}</select></label>
            <label className="md:col-span-2"><span className="label">Subject</span><input className="input mt-1" required maxLength={180} value={form.subject} onChange={(event) => setForm({ ...form, subject: event.target.value })} placeholder="Briefly describe the issue" /></label>
            <label className="md:col-span-2"><span className="label">Description</span><textarea className="input mt-1 min-h-28 resize-y" required maxLength={5000} value={form.description} onChange={(event) => setForm({ ...form, description: event.target.value })} placeholder="Include the details needed to help resolve your request." /></label>
            <div className="md:col-span-2"><button className="btn-primary" disabled={busy}>{busy ? 'Submitting…' : 'Submit ticket'}</button></div>
          </form>
        )}

        {!queueAccess ? (
          <section className="card min-w-0 overflow-hidden p-5">
            <div className="flex items-center gap-2"><TicketCheck size={19} className="text-forest" /><h2 className="font-display text-lg font-semibold">Your ticket numbers</h2></div>
            <p className="mt-2 text-sm text-ink/60">For privacy, this panel displays only the ticket numbers assigned to your requests. Help Desk staff will handle the ticket details.</p>
            {rows.length ? <ul className="mt-4 divide-y divide-sage/60">{rows.map((row) => <li key={row.id} className="py-3 font-semibold tracking-wide">{row.ticket_no}</li>)}</ul> : <p className="mt-4 text-sm text-ink/50">You have no ticket numbers yet. Submit a new ticket to receive one.</p>}
          </section>
        ) : (
        <section className="card min-w-0 overflow-hidden">
          <div className="flex flex-col gap-3 border-b border-sage/60 p-4 sm:flex-row sm:items-center sm:justify-between sm:p-5">
            <div className="flex items-center gap-2"><LifeBuoy size={19} className="text-forest" /><h2 className="font-display text-lg font-semibold">Ticket queue</h2><span className="rounded-full bg-paper px-2.5 py-1 text-xs font-semibold text-ink/60">{filteredRows.length}</span></div>
            <button type="button" className="btn-ghost self-start !py-2 sm:self-auto" onClick={load}><RefreshCw size={15} /> Refresh</button>
          </div>
          <div className="grid grid-cols-1 gap-3 p-4 sm:grid-cols-[minmax(0,1fr)_190px] sm:p-5">
            <label className="relative block min-w-0"><span className="sr-only">Search tickets</span><Search size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-ink/40" /><input className="input pl-9" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search ticket, subject, category or requester…" /></label>
            <label><span className="sr-only">Filter by status</span><select className="input" value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)}><option value="all">All statuses</option><option value="open">Open</option><option value="in_progress">In progress</option><option value="resolved">Resolved</option><option value="closed">Closed</option></select></label>
          </div>
          <div className="w-full overflow-x-auto">
            <table className="ledger-table min-w-[760px]">
              <thead><tr><th>Ticket</th><th>Subject</th><th>Category</th><th>Priority</th><th>Status</th><th>Requester</th><th>Action</th></tr></thead>
              <tbody>
                {filteredRows.map((row) => {
                  const closed = ['resolved', 'closed'].includes(String(row.status || '').toLowerCase());
                  return <tr key={row.id}>
                    <td className="whitespace-nowrap font-semibold">{row.ticket_no || `#${row.id}`}</td>
                    <td className="max-w-[260px] whitespace-normal"><span className="font-medium text-ink">{row.subject}</span></td>
                    <td>{row.category || '—'}</td>
                    <td><span className={`inline-flex rounded-full px-2.5 py-1 text-xs font-semibold capitalize ${priorityClass(row.priority)}`}>{row.priority || 'normal'}</span></td>
                    <td><span className={`inline-flex rounded-full px-2.5 py-1 text-xs font-semibold capitalize ${statusClass(row.status)}`}>{String(row.status || 'open').replaceAll('_', ' ')}</span></td>
                    <td>{row.requester_name || '—'}</td>
                    <td>{!closed ? <button type="button" className="btn-ghost !px-3 !py-1.5" onClick={() => update(row.id, 'resolved')}>Resolve</button> : <span className="text-xs text-ink/45">Closed</span>}</td>
                  </tr>;
                })}
                {!filteredRows.length && <tr><td colSpan={7} className="px-4 py-10 text-center text-sm text-ink/50">{rows.length ? 'No tickets match your search or filter.' : 'No support tickets have been created yet.'}</td></tr>}
              </tbody>
            </table>
          </div>
          <div className="flex flex-col gap-2 border-t border-sage/60 px-4 py-3 text-xs text-ink/50 sm:flex-row sm:items-center sm:justify-between sm:px-5"><span>Showing {filteredRows.length} of {rows.length} ticket(s)</span><span>Refresh the queue to see the latest updates.</span></div>
        </section>
        )}
      </div>
    </DashboardLayout>
  );
}
