import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { FileSpreadsheet, FileText, RefreshCw } from 'lucide-react';
import DashboardLayout from '../../components/DashboardLayout.jsx';
import PageHeader from '../../components/PageHeader.jsx';
import api from '../../api/axios.js';
import { downloadTabularReport, downloadXlsx, downloadBulkReportCards } from '../../utils/pdf.js';

const TYPES = [
  ['finance', 'Finance'],
  ['academic', 'Academic'],
  ['attendance', 'Attendance'],
  ['admissions', 'Admissions'],
  ['discipline', 'Discipline'],
  ['library', 'Library'],
  ['payroll', 'Payroll'],
  ['inventory', 'Inventory'],
  ['transport', 'Transport'],
  ['boarding', 'Boarding'],
  ['staff', 'Staff'],
];

function formatCell(value, column) {
  if (value === null || value === undefined || value === '') return '—';
  const moneyColumns = ['billed', 'paid', 'balance', 'amount', 'basic', 'allowances', 'deductions', 'net'];
  if (typeof value === 'number' && moneyColumns.includes(column)) {
    return `KES ${Number(value).toLocaleString()}`;
  }
  return String(value);
}

export default function Reports() {
  const { report } = useParams();
  const [type, setType] = useState(report || 'finance');
  const [data, setData] = useState({ title: '', columns: [], rows: [] });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  async function load() {
    try {
      setBusy(true);
      setError('');
      const response = await api.get(`/erp/reports/${type}`);
      const next = response.data || {};
      setData({
        title: next.title || `${type} report`,
        columns: Array.isArray(next.columns) ? next.columns : [],
        rows: Array.isArray(next.rows) ? next.rows : [],
      });
    } catch (e) {
      setError(e.response?.data?.error || 'Could not load report.');
      setData({ title: '', columns: [], rows: [] });
    } finally {
      setBusy(false);
    }
  }

  useEffect(() => {
    if (report) setType(report);
  }, [report]);

  useEffect(() => {
    load();
  }, [type]);

  async function csv() {
    try {
      const response = await api.get(`/erp/reports/${type}/csv`, { responseType: 'blob' });
      const url = URL.createObjectURL(response.data);
      const link = document.createElement('a');
      link.href = url;
      link.download = `matara-${type}-report.csv`;
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(url);
    } catch (e) {
      setError(e.response?.data?.error || 'Could not download CSV.');
    }
  }

  async function bulkReportCards() {
    try {
      const response = await api.get('/erp/report-cards/bulk');
      downloadBulkReportCards(response.data);
    } catch (e) {
      setError(e.response?.data?.error || 'Could not generate bulk report cards.');
    }
  }

  const hasRows = data.rows.length > 0;

  return (
    <DashboardLayout
      title="Reports & Analytics"
      subtitle="Live tabular reporting with export and print-ready PDF output"
    >
      <PageHeader eyebrow="Reports & Analytics" title="Reports & Analytics" />

      <div className="mb-5 flex flex-wrap gap-2">
        {TYPES.map(([key, label]) => (
          <button
            key={key}
            type="button"
            onClick={() => setType(key)}
            className={`rounded-lg px-3 py-2 text-sm font-semibold ${
              type === key ? 'bg-navy text-white' : 'bg-white text-ink/60 ring-1 ring-ink/10'
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      <div className="mb-4 flex flex-wrap gap-2">
        <button type="button" className="btn-primary" onClick={() => downloadTabularReport(data.title, data.columns, data.rows)}>
          <FileText size={16} /> Download PDF
        </button>
        <button type="button" className="btn-ghost" onClick={csv}>
          <FileSpreadsheet size={16} /> Download CSV
        </button>
        <button
          type="button"
          className="btn-ghost"
          onClick={() => downloadXlsx(`matara-${type}-report.xlsx`, data.columns, data.rows)}
        >
          <FileSpreadsheet size={16} /> Download Excel
        </button>
        <button type="button" className="btn-ghost" onClick={load}>
          <RefreshCw size={16} /> Refresh
        </button>
        {type === 'academic' && (
          <button type="button" className="btn-ghost" onClick={bulkReportCards}>
            <FileText size={16} /> Bulk report cards PDF
          </button>
        )}
      </div>

      {error && <div className="card mb-4 p-4 text-clay">{error}</div>}

      <div className="card overflow-x-auto">
        <table className="ledger-table">
          <thead>
            <tr>
              {data.columns.map((column) => (
                <th key={column}>{String(column).replaceAll('_', ' ')}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {busy ? (
              <tr>
                <td colSpan={Math.max(1, data.columns.length)} className="py-10 text-center">
                  Loading…
                </td>
              </tr>
            ) : hasRows ? (
              data.rows.map((row, index) => (
                <tr key={row.id ?? index}>
                  {data.columns.map((column) => (
                    <td key={column}>{formatCell(row[column], column)}</td>
                  ))}
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={Math.max(1, data.columns.length)} className="py-10 text-center text-ink/40">
                  No records found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </DashboardLayout>
  );
}
