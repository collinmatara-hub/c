import { useEffect, useState } from 'react';
import { Plus, X, Trash2, Users } from 'lucide-react';
import DashboardLayout from '../../components/DashboardLayout.jsx';
import api from '../../api/axios.js';
import ModalOverlay from '../../components/ModalOverlay.jsx';

export default function CohortsSections() {
  const [cohorts, setCohorts] = useState([]);
  const [teachers, setTeachers] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ name: '', stream: '', class_teacher_id: '', capacity: 40 });

  async function load() {
    const [c, t] = await Promise.all([api.get('/classes'), api.get('/teachers')]);
    setCohorts(c.data);
    setTeachers(t.data);
  }
  useEffect(() => { load(); }, []);

  async function handleSubmit(e) {
    e.preventDefault();
    setSaving(true);
    try {
      await api.post('/classes', form);
      setShowForm(false);
      setForm({ name: '', stream: '', class_teacher_id: '', capacity: 40 });
      load();
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(id) {
    if (!confirm('Delete this cohort?')) return;
    await api.delete(`/classes/${id}`);
    load();
  }

  return (
    <DashboardLayout title="Academic Cohorts / Sections" subtitle={`${cohorts.length} cohorts running`}>
      <div className="mb-5 flex justify-end">
        <button className="btn-primary" onClick={() => setShowForm(true)}>
          <Plus size={16} /> New cohort
        </button>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {cohorts.map((c) => (
          <div key={c.id} className="card p-5">
            <div className="flex items-start justify-between">
              <div>
                <p className="font-display text-lg font-semibold text-ink">{c.name} {c.stream}</p>
                <p className="text-xs text-ink/50">Academic coordinator: {c.teacher_name || 'Unassigned'}</p>
              </div>
              <button
                onClick={() => handleDelete(c.id)}
                className="rounded-md p-1.5 text-ink/40 hover:bg-clay/10 hover:text-clay"
              >
                <Trash2 size={15} />
              </button>
            </div>
            <div className="mt-4 flex items-center justify-between border-t border-sage/70 pt-3">
              <span className="flex items-center gap-2 text-sm text-ink/60">
                <Users size={15} /> {c.student_count} / {c.capacity} students
              </span>
              <div className="h-1.5 w-20 overflow-hidden rounded-full bg-sage">
                <div
                  className="h-full bg-gold"
                  style={{ width: `${Math.min(100, (c.student_count / c.capacity) * 100)}%` }}
                />
              </div>
            </div>
          </div>
        ))}
      </div>

      {showForm && (
        <ModalOverlay>
          <div className="card w-full max-w-md p-6">
            <div className="mb-5 flex items-center justify-between">
              <h3 className="font-display text-lg font-semibold">Create a cohort</h3>
              <button onClick={() => setShowForm(false)} className="text-ink/40 hover:text-ink">
                <X size={20} />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="label">Cohort name</label>
                <input required className="input" value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Year 1" />
              </div>
              <div>
                <label className="label">Stream</label>
                <input required className="input" value={form.stream}
                  onChange={(e) => setForm({ ...form, stream: e.target.value })} placeholder="Acacia" />
              </div>
              <div>
                <label className="label">Academic coordinator</label>
                <select className="input" value={form.class_teacher_id}
                  onChange={(e) => setForm({ ...form, class_teacher_id: e.target.value })}>
                  <option value="">Unassigned</option>
                  {teachers.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
                </select>
              </div>
              <div>
                <label className="label">Capacity</label>
                <input type="number" className="input" value={form.capacity}
                  onChange={(e) => setForm({ ...form, capacity: e.target.value })} />
              </div>
              <div className="mt-2 flex justify-end gap-3">
                <button type="button" className="btn-ghost" onClick={() => setShowForm(false)}>Cancel</button>
                <button type="submit" disabled={saving} className="btn-primary">
                  {saving ? 'Saving…' : 'Create cohort'}
                </button>
              </div>
            </form>
          </div>
        </ModalOverlay>
      )}
    </DashboardLayout>
  );
}
