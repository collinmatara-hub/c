import { useEffect, useMemo, useState } from 'react';
import { UserPlus, X, Search, KeyRound, Trash2, Pencil, Power, Copy, Check, RefreshCw, Plus, UsersRound, ShieldCheck, History, LogOut } from 'lucide-react';
import DashboardLayout from '../../components/DashboardLayout.jsx';
import api from '../../api/axios.js';
import { useAuth } from '../../context/AuthContext.jsx';
import { roleLabel, groupOf, isTemporary } from '../../config/roles.js';
import RoleSelect from '../../components/RoleSelect.jsx';

const EMPTY_FORM = {
  role: 'lecturer', existing_id: '', access_expires_at: '', name: '', username: '', password: '',
  phone: '', staff_no: '', specialty: '',
  adm_no: '', gender: '', dob: '', class_id: '', guardian_name: '', guardian_phone: '',
  address: '', children: [],
  employee_no: '', position: '', department_id: '', employment_date: '',
};

function formatDate(text) {
  if (!text) return '—';
  return new Date(text.replace(' ', 'T') + 'Z').toLocaleDateString();
}

// A label wrapped around its input, sized for the two-column form
function Field({ label, wide, children }) {
  return (
    <label className={wide ? 'col-span-2' : 'col-span-2 sm:col-span-1'}>
      <span className="label">{label}</span>
      {children}
    </label>
  );
}

export default function Users() {
  const { user: me } = useAuth();
  const [users, setUsers] = useState([]);
  const [options, setOptions] = useState({ domain: 'matara.ac.ke', classes: [], departments: [], students: [], unlinked: {} });
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState('');
  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState('all');

  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(EMPTY_FORM);
  const [usernameEdited, setUsernameEdited] = useState(false);
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState('');

  const [credentials, setCredentials] = useState(null);
  const [editing, setEditing] = useState(null);
  const [roleEditing, setRoleEditing] = useState(null);
  const [passwordEditing, setPasswordEditing] = useState(null);
  const [passwordValue, setPasswordValue] = useState('');
  const [passwordSaving, setPasswordSaving] = useState(false);
  const [editError, setEditError] = useState('');
  const [securityUser, setSecurityUser] = useState(null);
  const [securityData, setSecurityData] = useState(null);
  const [securityLoading, setSecurityLoading] = useState(false);

  async function load() {
    setLoading(true);
    setLoadError('');
    try {
      const [usersRes, optionsRes] = await Promise.all([api.get('/users'), api.get('/users/options')]);
      setUsers(usersRes.data);
      setOptions(optionsRes.data);
    } catch (err) {
      setLoadError(err.response?.data?.error || 'Could not load users. Check that the backend is running.');
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => { load(); }, []);

  const filtered = useMemo(() => {
    const text = search.toLowerCase();
    return users.filter((u) => {
      if (roleFilter !== 'all' && u.role !== roleFilter) return false;
      return `${u.name} ${u.email} ${u.reference_no || ''}`.toLowerCase().includes(text);
    });
  }, [users, search, roleFilter]);

  const activeCount = users.filter((u) => u.active === 1).length;

  // ---------- add user form ----------

  const group = groupOf(form.role);
  const unlinkedList = group ? options.unlinked[group] || [] : [];
  const linking = form.existing_id !== '';

  function setField(key, value) {
    setForm((current) => ({ ...current, [key]: value }));
  }

  function openForm() {
    setForm(EMPTY_FORM);
    setUsernameEdited(false);
    setFormError('');
    setShowForm(true);
  }

  function changeRole(role) {
    // A different role has a different list of people who still need a login
    const wasLinked = form.existing_id !== '';
    setForm({
      ...form,
      role,
      existing_id: '',
      name: wasLinked ? '' : form.name,
      username: wasLinked ? '' : form.username,
    });
    if (wasLinked) setUsernameEdited(false);
  }

  async function suggestUsername(name) {
    if (!name.trim()) return;
    try {
      const res = await api.get('/users/suggest-email', { params: { name } });
      setField('username', res.data.username);
      setUsernameEdited(false);
    } catch (err) {
      // The admin can still type the email by hand
    }
  }

  function pickExisting(id) {
    const person = unlinkedList.find((p) => String(p.id) === id);
    setForm({ ...form, existing_id: id, name: person ? person.name : '', username: '' });
    setUsernameEdited(false);
    if (person) suggestUsername(person.name);
  }

  function addChild() {
    setField('children', [...form.children, { student_id: '', relationship: 'Guardian' }]);
  }

  function changeChild(index, key, value) {
    setField('children', form.children.map((child, i) => (i === index ? { ...child, [key]: value } : child)));
  }

  function removeChild(index) {
    setField('children', form.children.filter((_, i) => i !== index));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setSaving(true);
    setFormError('');
    try {
      const res = await api.post('/users', form);
      setShowForm(false);
      setCredentials({ heading: 'Account created', ...res.data });
      load();
    } catch (err) {
      setFormError(err.response?.data?.error || 'Could not create the account.');
    } finally {
      setSaving(false);
    }
  }

  // ---------- actions on an existing account ----------

  function startEdit(u) {
    setEditError('');
    setEditing({ id: u.id, name: u.name, username: u.email.split('@')[0] });
  }

  async function saveEdit(e) {
    e.preventDefault();
    setEditError('');
    try {
      await api.put(`/users/${editing.id}`, { name: editing.name, username: editing.username });
      setEditing(null);
      load();
    } catch (err) {
      setEditError(err.response?.data?.error || 'Could not save the changes.');
    }
  }

  function resetPassword(u) {
    setPasswordEditing(u);
    setPasswordValue('');
  }

  async function savePasswordReset(e) {
    e.preventDefault();
    if (!passwordEditing) return;
    setPasswordSaving(true);
    try {
      const res = await api.put(`/users/${passwordEditing.id}/password`, { password: passwordValue || undefined });
      setPasswordEditing(null);
      setPasswordValue('');
      setCredentials({ heading: 'Password changed', ...res.data });
      load();
    } catch (err) {
      alert(err.response?.data?.error || 'Could not change the password.');
    } finally { setPasswordSaving(false); }
  }

  async function saveRole(e) {
    e.preventDefault();
    try {
      await api.put(`/users/${roleEditing.id}/role`, { role: roleEditing.role, access_expires_at: roleEditing.access_expires_at || undefined });
      setRoleEditing(null);
      load();
    } catch (err) {
      alert(err.response?.data?.error || 'Could not change the role.');
    }
  }

  async function openSecurity(u) {
    setSecurityUser(u); setSecurityData(null); setSecurityLoading(true);
    try { const res = await api.get(`/users/${u.id}/security`); setSecurityData(res.data); }
    catch (err) { alert(err.response?.data?.error || 'Could not load security history.'); setSecurityUser(null); }
    finally { setSecurityLoading(false); }
  }

  async function forceLogout(u) {
    if (!confirm(`Sign out all active sessions for ${u.name}?`)) return;
    try { await api.post(`/users/${u.id}/force-logout`); alert('All active sessions were invalidated.'); }
    catch (err) { alert(err.response?.data?.error || 'Could not invalidate sessions.'); }
  }

  async function regenerateRecovery(u) {
    if (!confirm(`Generate a new recovery code for ${u.name}? The old recovery code will stop working.`)) return;
    try { const res=await api.post(`/users/${u.id}/recovery-code`); setCredentials({heading:'Recovery code regenerated', ...res.data, password:res.data.recovery_code}); }
    catch (err) { alert(err.response?.data?.error || 'Could not generate recovery code.'); }
  }

  async function toggleActive(u) {
    const turningOff = u.active === 1;
    if (turningOff && !confirm(`Deactivate ${u.name}? They will be signed out and cannot log in until you activate the account again.`)) return;
    try {
      await api.put(`/users/${u.id}/status`, { active: !turningOff });
      load();
    } catch (err) {
      alert(err.response?.data?.error || 'Could not change the account status.');
    }
  }

  async function deleteUser(u) {
    if (!confirm(`Delete the login for ${u.name}? Their records stay in the system, but they will no longer be able to sign in.`)) return;
    try {
      await api.delete(`/users/${u.id}`);
      load();
    } catch (err) {
      alert(err.response?.data?.error || 'Could not delete the login.');
    }
  }

  // ---------- page ----------

  return (
    <DashboardLayout
      title="User Accounts"
      subtitle={`${users.length} accounts · ${activeCount} active`}
    >
      <div className="mb-5 flex flex-wrap gap-3">
        <div className="relative min-w-[220px] flex-1">
          <Search className="absolute left-3 top-2.5 text-ink/40" size={17} />
          <input
            className="input pl-9"
            placeholder="Search by name, email or ID number"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <RoleSelect className="input !w-auto" value={roleFilter} onChange={setRoleFilter} allLabel="All roles" ariaLabel="Filter by role" />
        <button className="btn-ghost" onClick={load}><RefreshCw size={16} /> Refresh</button>
        <button className="btn-primary" onClick={openForm}><UserPlus size={16} /> Add user</button>
      </div>

      {loadError && <p className="mb-4 rounded-lg bg-clay/10 px-3 py-2 text-sm text-clay">{loadError}</p>}

      <div className="card overflow-x-auto">
        <table className="ledger-table">
          <thead>
            <tr>
              <th>Person</th>
              <th>School email</th>
              <th>Role</th>
              <th>Status</th>
              <th>Added</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={6} className="py-10 text-center text-ink/45">Loading…</td></tr>
            ) : filtered.length === 0 ? (
              <tr>
                <td colSpan={6} className="py-10 text-center text-ink/45">
                  No users match. Try a different search, or add a new user.
                </td>
              </tr>
            ) : (
              filtered.map((u) => {
                const isMe = u.id === me?.id;
                return (
                  <tr key={u.id}>
                    <td>
                      <p className="font-semibold text-ink">{u.name}{isMe && <span className="ml-2 text-xs font-normal text-ink/40">(you)</span>}</p>
                      {u.reference_no && <p className="font-mono text-xs text-ink/45">{u.reference_no}</p>}
                    </td>
                    <td>{u.email}</td>
                    <td><span className="badge badge-gold">{roleLabel(u.role)}</span></td>
                    <td>
                      <span className={`badge ${u.active === 1 ? 'badge-green' : 'badge-red'}`}>
                        {u.active === 1 ? 'Active' : 'Inactive'}
                      </span>
                    </td>
                    <td className="whitespace-nowrap text-ink/60">{formatDate(u.created_at)}</td>
                    <td>
                      <div className="flex gap-2">
                        <button className="btn-ghost !p-2" title="Edit name or email" aria-label="Edit name or email" onClick={() => startEdit(u)}>
                          <Pencil size={14} />
                        </button>
                        <button className="btn-ghost !p-2 disabled:opacity-40" title="Change role" aria-label="Change role" disabled={isMe} onClick={() => setRoleEditing({ id: u.id, name: u.name, role: u.role })}>
                          <UsersRound size={14} />
                        </button>
                        <button className="btn-ghost !p-2" title="Reset password" aria-label="Reset password" onClick={() => resetPassword(u)}>
                          <KeyRound size={14} />
                        </button>
                        <button className="btn-ghost !p-2" title="Security history" aria-label="Security history" onClick={() => openSecurity(u)}>
                          <ShieldCheck size={14} />
                        </button>
                        <button className="btn-ghost !p-2 disabled:opacity-40" title="Force logout" aria-label="Force logout" disabled={isMe} onClick={() => forceLogout(u)}>
                          <LogOut size={14} />
                        </button>
                        <button
                          className="btn-ghost !p-2 disabled:cursor-not-allowed disabled:opacity-40"
                          title={u.active === 1 ? 'Deactivate account' : 'Activate account'}
                          aria-label={u.active === 1 ? 'Deactivate account' : 'Activate account'}
                          disabled={isMe}
                          onClick={() => toggleActive(u)}
                        >
                          <Power size={14} />
                        </button>
                        <button
                          className="btn-ghost !p-2 disabled:cursor-not-allowed disabled:opacity-40"
                          title="Delete login"
                          aria-label="Delete login"
                          disabled={isMe}
                          onClick={() => deleteUser(u)}
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {passwordEditing && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-navy/50 px-4">
          <form onSubmit={savePasswordReset} className="card w-full max-w-md p-6">
            <h3 className="font-display text-lg font-semibold">Change user password</h3>
            <p className="mt-1 text-sm text-ink/55">{passwordEditing.name} · {passwordEditing.email}</p>
            <label className="mt-5 block"><span className="label">New password</span>
              <input className="input" type="text" minLength="8" value={passwordValue} onChange={e=>setPasswordValue(e.target.value)} placeholder="Leave blank to generate a secure password" autoComplete="off" />
            </label>
            <p className="mt-3 rounded-xl bg-gold/10 p-3 text-xs text-ink/60">For security, the system cannot display an existing password because passwords are stored as one-way bcrypt hashes. If you set or generate a new password, it will be shown once after saving.</p>
            <div className="mt-5 flex justify-end gap-2"><button type="button" className="btn-ghost" onClick={()=>setPasswordEditing(null)}>Cancel</button><button className="btn-primary" disabled={passwordSaving}>{passwordSaving ? 'Saving…' : 'Set password'}</button></div>
          </form>
        </div>
      )}

      {securityUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-navy/50 px-4">
          <div className="card max-h-[85vh] w-full max-w-3xl overflow-y-auto p-6">
            <div className="flex items-start justify-between gap-4"><div><h3 className="font-display text-lg font-semibold">Account security</h3><p className="mt-1 text-sm text-ink/55">{securityUser.name} · {securityUser.email}</p></div><button className="text-ink/40 hover:text-ink" onClick={()=>setSecurityUser(null)}><X size={20}/></button></div>
            {securityLoading ? <p className="py-10 text-center text-ink/45">Loading security history…</p> : securityData && <>
              <div className="mt-5 grid gap-3 sm:grid-cols-4">
                <div className="rounded-xl bg-paper p-3"><p className="text-xs text-ink/45">Password status</p><p className="mt-1 font-semibold">Set</p></div>
                <div className="rounded-xl bg-paper p-3"><p className="text-xs text-ink/45">Last changed</p><p className="mt-1 text-sm font-semibold">{securityData.password.changed_at ? formatDate(securityData.password.changed_at) : 'Not recorded'}</p></div>
                <div className="rounded-xl bg-paper p-3"><p className="text-xs text-ink/45">Password events</p><p className="mt-1 font-semibold">{securityData.password.events}</p></div>
                <div className="rounded-xl bg-paper p-3"><p className="text-xs text-ink/45">Recovery</p><p className="mt-1 font-semibold">{securityData.recovery_configured?'Configured':'Not configured'}</p></div>
              </div>
              <div className="mt-5 flex flex-wrap gap-2"><button className="btn-ghost" onClick={()=>regenerateRecovery(securityUser)}><KeyRound size={15}/> Regenerate recovery code</button><button className="btn-ghost" onClick={()=>forceLogout(securityUser)}><LogOut size={15}/> Force logout</button><button className="btn-primary" onClick={()=>{setSecurityUser(null);resetPassword(securityUser)}}><KeyRound size={15}/> Reset password</button></div>
              <div className="mt-6"><div className="flex items-center gap-2 font-semibold"><History size={16}/> Password history</div><div className="mt-2 overflow-x-auto"><table className="ledger-table"><thead><tr><th>Action</th><th>Date</th><th>Changed by</th><th>Reason</th></tr></thead><tbody>{securityData.history.length?securityData.history.map(h=><tr key={h.id}><td>{h.action.replaceAll('_',' ')}</td><td>{formatDate(h.changed_at)}</td><td>{h.changed_by_name}</td><td>{h.reason||'—'}</td></tr>):<tr><td colSpan={4} className="py-6 text-center text-ink/45">No password events recorded.</td></tr>}</tbody></table></div></div>
              <div className="mt-6"><div className="font-semibold">Account activity</div><div className="mt-2 max-h-56 overflow-y-auto rounded-xl border border-sage">{securityData.audit.length?securityData.audit.map(a=><div key={a.id} className="border-b border-sage p-3 last:border-0"><div className="flex justify-between gap-3 text-sm"><span className="font-semibold">{a.action.replaceAll('_',' ')}</span><span className="text-xs text-ink/45">{formatDate(a.created_at)}</span></div><p className="mt-1 text-xs text-ink/55">{a.details} · by {a.actor_name}</p></div>):<p className="p-4 text-sm text-ink/45">No activity recorded.</p>}</div></div>
              <p className="mt-5 rounded-xl bg-gold/10 p-3 text-xs text-ink/60">For security, administrators can never view an existing password. The system stores only one-way password hashes. Administrators can reset a password, invalidate sessions, issue a new recovery code, and review password/security history.</p>
            </>}
          </div>
        </div>
      )}

      {roleEditing && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-navy/50 px-4">
          <form onSubmit={saveRole} className="card w-full max-w-md p-6">
            <h3 className="font-display text-lg font-semibold">Change account role</h3>
            <p className="mt-1 text-sm text-ink/55">{roleEditing.name}</p>
            <label className="mt-5 block"><span className="label">New role</span>
              <RoleSelect value={roleEditing.role} onChange={(role)=>setRoleEditing({...roleEditing,role})} ariaLabel="New role" />
            </label>
            {isTemporary(roleEditing.role) && (
              <label className="mt-4 block"><span className="label">Access ends on</span>
                <input type="date" className="input" required value={roleEditing.access_expires_at || ''} onChange={e=>setRoleEditing({...roleEditing,access_expires_at:e.target.value})} />
              </label>
            )}
            <p className="mt-3 rounded-xl bg-gold/10 p-3 text-xs text-ink/60">Changing a role updates the login permissions and creates/links the appropriate profile record. The previous profile remains on file without this login.</p>
            <div className="mt-5 flex justify-end gap-2"><button type="button" className="btn-ghost" onClick={()=>setRoleEditing(null)}>Cancel</button><button className="btn-primary">Save role</button></div>
          </form>
        </div>
      )}

      {/* ---------- Add user ---------- */}
      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-navy/50 px-4">
          <div className="card max-h-[90vh] w-full max-w-2xl overflow-y-auto p-6">
            <div className="mb-5 flex items-center justify-between">
              <h3 className="font-display text-lg font-semibold">Add a user</h3>
              <button onClick={() => setShowForm(false)} className="text-ink/40 hover:text-ink" aria-label="Close">
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="grid grid-cols-2 gap-4">
              <Field label="Account type" wide>
                <RoleSelect value={form.role} onChange={changeRole} ariaLabel="Account type" />
              </Field>

              {isTemporary(form.role) && (
                <Field label="Access ends on (temporary role)" wide>
                  <input type="date" className="input" required value={form.access_expires_at} onChange={(e) => setField('access_expires_at', e.target.value)} />
                </Field>
              )}

              {unlinkedList.length > 0 && (
                <Field label="Who is this for?" wide>
                  <select className="input" value={form.existing_id} onChange={(e) => pickExisting(e.target.value)}>
                    <option value="">A new person</option>
                    {unlinkedList.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.name}{p.ref ? ` (${p.ref})` : ''} — already on record, no login yet
                      </option>
                    ))}
                  </select>
                </Field>
              )}

              <Field label="Full name" wide>
                <input
                  required
                  className="input"
                  value={form.name}
                  disabled={linking}
                  onChange={(e) => setField('name', e.target.value)}
                  onBlur={() => { if (!usernameEdited && !linking) suggestUsername(form.name); }}
                  placeholder="e.g. Faith Wambui"
                />
              </Field>

              <div className="col-span-2 border-t border-sage pt-4">
                <p className="text-sm font-semibold text-ink">Login details</p>
              </div>

              <div className="col-span-2">
                <span className="label">School email</span>
                <div className="flex gap-2">
                  <div className="flex min-w-0 flex-1">
                    <input
                      className="input min-w-0 rounded-r-none"
                      aria-label="School email name"
                      value={form.username}
                      onChange={(e) => { setField('username', e.target.value); setUsernameEdited(true); }}
                      placeholder="first.last"
                    />
                    <span className="flex items-center whitespace-nowrap rounded-r-xl border border-l-0 border-sage bg-paper px-3 text-sm text-ink/60">
                      @{options.domain}
                    </span>
                  </div>
                  <button
                    type="button"
                    className="btn-ghost disabled:cursor-not-allowed disabled:opacity-50"
                    disabled={!form.name.trim()}
                    onClick={() => suggestUsername(form.name)}
                  >
                    Suggest
                  </button>
                </div>
                <p className="mt-1.5 text-xs text-ink/45">
                  Created from the name. Change it if you prefer, or leave it blank and one is made for you.
                </p>
              </div>

              <Field label="Password" wide>
                <input
                  className="input"
                  value={form.password}
                  onChange={(e) => setField('password', e.target.value)}
                  placeholder="Leave blank to create a temporary password"
                />
              </Field>

              {group && !linking && (
                <div className="col-span-2 border-t border-sage pt-4">
                  <p className="text-sm font-semibold text-ink">{roleLabel(form.role)} details</p>
                </div>
              )}
              {group && linking && (
                <p className="col-span-2 rounded-lg bg-paper px-3 py-2 text-sm text-ink/60">
                  The existing record stays as it is. This adds a login to it.
                </p>
              )}

              {group === 'teacher' && !linking && (
                <>
                  <Field label="Staff number">
                    <input className="input" value={form.staff_no} onChange={(e) => setField('staff_no', e.target.value)} placeholder="Automatic, e.g. T004" />
                  </Field>
                  <Field label="Phone">
                    <input className="input" value={form.phone} onChange={(e) => setField('phone', e.target.value)} placeholder="07XX XXX XXX" />
                  </Field>
                  <Field label="University unit specialty" wide>
                    <input className="input" value={form.specialty} onChange={(e) => setField('specialty', e.target.value)} placeholder="Chemistry" />
                  </Field>
                </>
              )}

              {group === 'student' && !linking && (
                <>
                  <Field label="Admission number">
                    <input className="input" value={form.adm_no} onChange={(e) => setField('adm_no', e.target.value)} placeholder="Automatic, e.g. MU-1007" />
                  </Field>
                  <Field label="Class">
                    <select className="input" value={form.class_id} onChange={(e) => setField('class_id', e.target.value)}>
                      <option value="">No class yet</option>
                      {options.classes.map((c) => (
                        <option key={c.id} value={c.id}>{c.name} {c.stream}</option>
                      ))}
                    </select>
                  </Field>
                  <Field label="Gender">
                    <select className="input" value={form.gender} onChange={(e) => setField('gender', e.target.value)}>
                      <option value="">Not stated</option>
                      <option value="M">Male</option>
                      <option value="F">Female</option>
                    </select>
                  </Field>
                  <Field label="Date of birth">
                    <input type="date" className="input" value={form.dob} onChange={(e) => setField('dob', e.target.value)} />
                  </Field>
                  <Field label="Guardian name">
                    <input className="input" value={form.guardian_name} onChange={(e) => setField('guardian_name', e.target.value)} />
                  </Field>
                  <Field label="Guardian phone">
                    <input className="input" value={form.guardian_phone} onChange={(e) => setField('guardian_phone', e.target.value)} placeholder="07XX XXX XXX" />
                  </Field>
                </>
              )}

              {group === 'parent' && !linking && (
                <>
                  <Field label="Phone">
                    <input className="input" value={form.phone} onChange={(e) => setField('phone', e.target.value)} placeholder="07XX XXX XXX" />
                  </Field>
                  <Field label="Address">
                    <input className="input" value={form.address} onChange={(e) => setField('address', e.target.value)} />
                  </Field>
                  <div className="col-span-2">
                    <span className="label">Children at the school</span>
                    <div className="space-y-2">
                      {form.children.map((child, index) => (
                        <div key={index} className="flex gap-2">
                          <select
                            className="input min-w-0 flex-1"
                            aria-label="Child"
                            value={child.student_id}
                            onChange={(e) => changeChild(index, 'student_id', e.target.value)}
                          >
                            <option value="">Choose a student</option>
                            {options.students.map((s) => (
                              <option key={s.id} value={s.id}>{s.name} ({s.adm_no})</option>
                            ))}
                          </select>
                          <input
                            className="input !w-36"
                            aria-label="Relationship"
                            value={child.relationship}
                            onChange={(e) => changeChild(index, 'relationship', e.target.value)}
                            placeholder="Mother"
                          />
                          <button type="button" className="btn-ghost !p-2" aria-label="Remove child" onClick={() => removeChild(index)}>
                            <X size={14} />
                          </button>
                        </div>
                      ))}
                    </div>
                    <button type="button" className="btn-ghost mt-2" onClick={addChild}>
                      <Plus size={14} /> Add a child
                    </button>
                  </div>
                </>
              )}

              {group === 'staff' && !linking && (
                <>
                  <Field label="Employee number">
                    <input className="input" value={form.employee_no} onChange={(e) => setField('employee_no', e.target.value)} placeholder="Automatic, e.g. E001" />
                  </Field>
                  <Field label="Position">
                    <input className="input" value={form.position} onChange={(e) => setField('position', e.target.value)} placeholder={roleLabel(form.role)} />
                  </Field>
                  <Field label="Department">
                    <select className="input" value={form.department_id} onChange={(e) => setField('department_id', e.target.value)}>
                      <option value="">No department</option>
                      {options.departments.map((d) => (
                        <option key={d.id} value={d.id}>{d.name}</option>
                      ))}
                    </select>
                  </Field>
                  <Field label="Phone">
                    <input className="input" value={form.phone} onChange={(e) => setField('phone', e.target.value)} placeholder="07XX XXX XXX" />
                  </Field>
                  <Field label="Date employed" wide>
                    <input type="date" className="input" value={form.employment_date} onChange={(e) => setField('employment_date', e.target.value)} />
                  </Field>
                </>
              )}

              {formError && <p className="col-span-2 rounded-lg bg-clay/10 px-3 py-2 text-sm text-clay">{formError}</p>}

              <div className="col-span-2 mt-2 flex justify-end gap-3">
                <button type="button" className="btn-ghost" onClick={() => setShowForm(false)}>Cancel</button>
                <button type="submit" disabled={saving} className="btn-primary">
                  {saving ? 'Creating…' : 'Create account'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ---------- Edit user ---------- */}
      {editing && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-navy/50 px-4">
          <div className="card w-full max-w-md p-6">
            <div className="mb-5 flex items-center justify-between">
              <h3 className="font-display text-lg font-semibold">Edit account</h3>
              <button onClick={() => setEditing(null)} className="text-ink/40 hover:text-ink" aria-label="Close">
                <X size={20} />
              </button>
            </div>
            <form onSubmit={saveEdit} className="space-y-4">
              <label className="block">
                <span className="label">Full name</span>
                <input required className="input" value={editing.name} onChange={(e) => setEditing({ ...editing, name: e.target.value })} />
              </label>
              <div>
                <span className="label">School email</span>
                <div className="flex">
                  <input
                    required
                    className="input min-w-0 rounded-r-none"
                    aria-label="School email name"
                    value={editing.username}
                    onChange={(e) => setEditing({ ...editing, username: e.target.value })}
                  />
                  <span className="flex items-center whitespace-nowrap rounded-r-xl border border-l-0 border-sage bg-paper px-3 text-sm text-ink/60">
                    @{options.domain}
                  </span>
                </div>
                <p className="mt-1.5 text-xs text-ink/45">
                  Administrators can change this account's role from the User Accounts table. Changing a role updates its permissions and profile linkage.
                </p>
              </div>
              {editError && <p className="rounded-lg bg-clay/10 px-3 py-2 text-sm text-clay">{editError}</p>}
              <div className="flex justify-end gap-3">
                <button type="button" className="btn-ghost" onClick={() => setEditing(null)}>Cancel</button>
                <button type="submit" className="btn-primary">Save changes</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ---------- Login details to hand over ---------- */}
      {credentials && (
        <CredentialsModal
          info={credentials}
          onClose={() => setCredentials(null)}
          onAddAnother={() => { setCredentials(null); openForm(); }}
        />
      )}
    </DashboardLayout>
  );
}

function CredentialsModal({ info, onClose, onAddAnother }) {
  const [copied, setCopied] = useState(false);

  async function copyDetails() {
    const text = `Matara University portal\nEmail: ${info.email}\nPassword: ${info.password}`;
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      alert('Could not copy automatically. Please select the details and copy them by hand.');
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-navy/50 px-4">
      <div className="card w-full max-w-md p-6">
        <h3 className="font-display text-lg font-semibold">{info.heading}</h3>
        <p className="mt-1 text-sm text-ink/60">
          Give these login details to {info.name}. The password is only shown now, so copy it before you close this window.
        </p>

        <div className="mt-5 space-y-3 rounded-2xl border border-sage bg-paper p-4">
          <div>
            <p className="label !mb-0.5">School email</p>
            <p className="break-all font-mono text-sm text-ink">{info.email}</p>
          </div>
          <div>
            <p className="label !mb-0.5">Password</p>
            <p className="break-all font-mono text-sm text-ink">{info.password}</p>
          </div>
        </div>

        <div className="mt-5 flex flex-wrap justify-end gap-3">
          <button className="btn-ghost" onClick={copyDetails}>
            {copied ? <Check size={16} /> : <Copy size={16} />} {copied ? 'Copied' : 'Copy details'}
          </button>
          {info.heading === 'Account created' && (
            <button className="btn-ghost" onClick={onAddAnother}><UserPlus size={16} /> Add another</button>
          )}
          <button className="btn-primary" onClick={onClose}>Done</button>
        </div>
      </div>
    </div>
  );
}
