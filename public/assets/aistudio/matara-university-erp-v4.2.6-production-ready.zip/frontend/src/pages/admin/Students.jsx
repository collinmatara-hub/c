import { useEffect, useState } from 'react';
import { Plus, Search, X, Trash2, Eye } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext.jsx';
import DashboardLayout from '../../components/DashboardLayout.jsx';
import api from '../../api/axios.js';

export default function Students() {
  const { user } = useAuth();
  const canManage = user?.role === 'admin';
  const [students, setStudents] = useState([]);
  const [classes, setClasses] = useState([]);
  const [query, setQuery] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState('');
  const [form, setForm] = useState({
    adm_no: '', name: '', gender: 'M', dob: '', class_id: '', guardian_name: '', guardian_phone: '',
  });

  async function load() {
    const [s, c] = await Promise.all([api.get('/students'), api.get('/classes')]);
    setStudents(s.data);
    setClasses(c.data);
  }

  useEffect(() => { load(); }, []);

  const filtered = students.filter((s) =>
    `${s.name} ${s.adm_no} ${s.program_name || ''} ${s.class_name || ''}`.toLowerCase().includes(query.toLowerCase())
  );

  async function handleSubmit(e) {
    e.preventDefault();
    setSaving(true);
    setFormError('');
    try {
      await api.post('/students', form);
      setShowForm(false);
      setForm({ adm_no: '', name: '', gender: 'M', dob: '', class_id: '', guardian_name: '', guardian_phone: '' });
      load();
    } catch (err) {
      setFormError(err.response?.data?.error || 'Could not save student.');
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(id) {
    if (!confirm('Remove this student from the register?')) return;
    await api.delete(`/students/${id}`);
    load();
  }

  return (
    <DashboardLayout title="Students" subtitle={`${students.length} on the active register`}>
      <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="relative w-full sm:max-w-xs">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink/40" />
          <input
            className="input pl-9"
            placeholder="Search by name, Reg. No. or programme"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
        {canManage && <button className="btn-primary" onClick={() => setShowForm(true)}>
          <Plus size={16} /> Admit student
        </button>}
      </div>

      <div className="card overflow-x-auto">
        <table className="ledger-table">
          <thead>
            <tr>
              <th>Reg. No.</th>
              <th>Name</th>
              <th>Programme / Year</th>
              <th>Gender</th>
              <th>Contact</th>
              <th>Status</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((s) => (
              <tr key={s.id}>
                <td className="font-mono text-xs text-ink/70">{s.adm_no}</td>
                <td className="font-medium">{s.name}</td>
                <td>{s.program_name ? `${s.program_name}${s.year_of_study ? ` · Year ${s.year_of_study}` : ''}` : (s.class_name ? `${s.class_name} ${s.class_stream || ''}` : '—')}</td>
                <td>{s.gender === 'F' ? 'Female' : s.gender === 'M' ? 'Male' : '—'}</td>
                <td className="text-ink/60">{s.email || s.guardian_phone || '—'}</td>
                <td>
                  <span className={`badge ${s.status === 'active' ? 'badge-green' : 'badge-red'} capitalize`}>
                    {s.status}
                  </span>
                </td>
                <td>
                  <div className="flex items-center gap-1"><Link to={`/admin/students/${s.id}`} className="rounded-md p-1.5 text-forest hover:bg-forest/10" title="Open full student profile"><Eye size={15}/></Link>{canManage && <button
                    onClick={() => handleDelete(s.id)}
                    className="rounded-md p-1.5 text-ink/40 hover:bg-clay/10 hover:text-clay"
                    aria-label={`Remove ${s.name}`}
                  >
                    <Trash2 size={15} />
                  </button>}</div>
                </td>
              </tr>
            ))}
            {filtered.length === 0 && (
              <tr><td colSpan={7} className="py-8 text-center text-ink/40">No students match your search.</td></tr>
            )}
          </tbody>
        </table>
      </div>

      {showForm && (
        <div className="fixed inset-0 z-30 flex items-center justify-center bg-navy/50 px-4">
          <div className="card w-full max-w-lg p-6">
            <div className="mb-5 flex items-center justify-between">
              <h3 className="font-display text-lg font-semibold">Admit a new student</h3>
              <button onClick={() => setShowForm(false)} className="text-ink/40 hover:text-ink">
                <X size={20} />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="grid grid-cols-2 gap-4">
              <div className="col-span-2 sm:col-span-1">
                <label className="label">Admission No.</label>
                <input required className="input" value={form.adm_no}
                  onChange={(e) => setForm({ ...form, adm_no: e.target.value })} placeholder="MU-1007" />
              </div>
              <div className="col-span-2 sm:col-span-1">
                <label className="label">Full name</label>
                <input required className="input" value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Jane Doe" />
              </div>
              <div>
                <label className="label">Gender</label>
                <select className="input" value={form.gender} onChange={(e) => setForm({ ...form, gender: e.target.value })}>
                  <option value="M">Male</option>
                  <option value="F">Female</option>
                </select>
              </div>
              <div>
                <label className="label">Date of birth</label>
                <input type="date" className="input" value={form.dob} onChange={(e) => setForm({ ...form, dob: e.target.value })} />
              </div>
              <div className="col-span-2">
                <label className="label">Cohort / Year of Study</label>
                <select className="input" value={form.class_id} onChange={(e) => setForm({ ...form, class_id: e.target.value })}>
                  <option value="">Unassigned</option>
                  {classes.map((c) => (
                    <option key={c.id} value={c.id}>{c.name} {c.stream}</option>
                  ))}
                </select>
              </div>
              <div className="col-span-2 sm:col-span-1">
                <label className="label">Emergency contact name</label>
                <input className="input" value={form.guardian_name}
                  onChange={(e) => setForm({ ...form, guardian_name: e.target.value })} />
              </div>
              <div className="col-span-2 sm:col-span-1">
                <label className="label">Emergency contact phone</label>
                <input className="input" value={form.guardian_phone}
                  onChange={(e) => setForm({ ...form, guardian_phone: e.target.value })} placeholder="07XX XXX XXX" />
              </div>

              {formError && <p className="col-span-2 rounded-lg bg-clay/10 px-3 py-2 text-sm text-clay">{formError}</p>}

              <div className="col-span-2 mt-2 flex justify-end gap-3">
                <button type="button" className="btn-ghost" onClick={() => setShowForm(false)}>Cancel</button>
                <button type="submit" disabled={saving} className="btn-primary">
                  {saving ? 'Saving…' : 'Admit student'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </DashboardLayout>
  );
}
