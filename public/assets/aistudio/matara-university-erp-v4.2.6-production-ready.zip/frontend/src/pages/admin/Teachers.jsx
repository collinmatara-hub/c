import { useEffect, useState } from 'react';
import { Plus, X, Trash2, Phone } from 'lucide-react';
import DashboardLayout from '../../components/DashboardLayout.jsx';
import api from '../../api/axios.js';
import ModalOverlay from '../../components/ModalOverlay.jsx';

export default function Teachers() {
  const [teachers, setTeachers] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState('');
  const [form, setForm] = useState({
    name: '', staff_no: '', phone: '', specialty: '', email: '', password: '',
  });

  const [loadError, setLoadError] = useState('');

  async function load() {
    try {
      const res = await api.get('/teachers');
      setTeachers(Array.isArray(res.data) ? res.data : []);
      setLoadError('');
    } catch (err) {
      setLoadError(err.response?.data?.error || 'Could not load lecturers.');
    }
  }
  useEffect(() => { load(); }, []);

  async function handleSubmit(e) {
    e.preventDefault();
    setSaving(true);
    setFormError('');
    try {
      await api.post('/teachers', form);
      setShowForm(false);
      setForm({ name: '', staff_no: '', phone: '', specialty: '', email: '', password: '' });
      load();
    } catch (err) {
      setFormError(err.response?.data?.error || 'Could not save lecturer.');
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(id) {
    if (!confirm('Remove this lecturer from staff records?')) return;
    await api.delete(`/teachers/${id}`);
    load();
  }

  return (
    <DashboardLayout title="Lecturers" subtitle={`${teachers.length} lecturers on record`}>
      <div className="mb-5 flex justify-end">
        <button className="btn-primary" onClick={() => setShowForm(true)}>
          <Plus size={16} /> Add lecturer
        </button>
      </div>

      {loadError && <p className="mb-4 rounded-lg bg-clay/10 px-3 py-2 text-sm text-clay">{loadError}</p>}

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {teachers.map((t) => (
          <div key={t.id} className="card p-5">
            <div className="flex items-start justify-between">
              <div className="crest" style={{ width: 40, height: 40, fontSize: 14 }}>
                {String(t.name || '?').split(' ').filter(Boolean).map((n) => n[0]).slice(0, 2).join('').toUpperCase()}
              </div>
              <button
                onClick={() => handleDelete(t.id)}
                className="rounded-md p-1.5 text-ink/40 hover:bg-clay/10 hover:text-clay"
              >
                <Trash2 size={15} />
              </button>
            </div>
            <p className="mt-3 font-display text-base font-semibold text-ink">{t.name}</p>
            <p className="font-mono text-xs text-ink/50">{t.staff_no}</p>
            <div className="mt-3 flex flex-wrap gap-2">
              <span className="badge badge-gold">{t.specialty || 'General'}</span>
            </div>
            {t.phone && (
              <p className="mt-3 flex items-center gap-2 text-sm text-ink/60">
                <Phone size={14} /> {t.phone}
              </p>
            )}
          </div>
        ))}
      </div>

      {showForm && (
        <ModalOverlay onClose={() => setShowForm(false)}>
          <div className="card w-full max-w-lg p-6">
            <div className="mb-5 flex items-center justify-between">
              <h3 className="font-display text-lg font-semibold">Add a lecturer</h3>
              <button onClick={() => setShowForm(false)} className="text-ink/40 hover:text-ink">
                <X size={20} />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="grid grid-cols-2 gap-4">
              <div className="col-span-2 sm:col-span-1">
                <label className="label">Full name</label>
                <input required className="input" value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })} />
              </div>
              <div className="col-span-2 sm:col-span-1">
                <label className="label">Staff number</label>
                <input required className="input" value={form.staff_no}
                  onChange={(e) => setForm({ ...form, staff_no: e.target.value })} placeholder="T004" />
              </div>
              <div className="col-span-2 sm:col-span-1">
                <label className="label">Phone</label>
                <input className="input" value={form.phone}
                  onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="07XX XXX XXX" />
              </div>
              <div className="col-span-2 sm:col-span-1">
                <label className="label">University unit specialty</label>
                <input className="input" value={form.specialty}
                  onChange={(e) => setForm({ ...form, specialty: e.target.value })} placeholder="Chemistry" />
              </div>
              <div className="col-span-2 border-t border-sage pt-4">
                <p className="mb-3 text-xs font-semibold uppercase tracking-wide text-ink/50">
                  Portal login (optional)
                </p>
              </div>
              <div className="col-span-2 sm:col-span-1">
                <label className="label">Email</label>
                <input type="email" className="input" value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="name@matara.ac.ke" />
              </div>
              <div className="col-span-2 sm:col-span-1">
                <label className="label">Password</label>
                <input type="text" className="input" value={form.password}
                  onChange={(e) => setForm({ ...form, password: e.target.value })} placeholder="Temporary password" />
              </div>

              {formError && <p className="col-span-2 rounded-lg bg-clay/10 px-3 py-2 text-sm text-clay">{formError}</p>}

              <div className="col-span-2 mt-2 flex justify-end gap-3">
                <button type="button" className="btn-ghost" onClick={() => setShowForm(false)}>Cancel</button>
                <button type="submit" disabled={saving} className="btn-primary">
                  {saving ? 'Saving…' : 'Add lecturer'}
                </button>
              </div>
            </form>
          </div>
        </ModalOverlay>
      )}
    </DashboardLayout>
  );
}
