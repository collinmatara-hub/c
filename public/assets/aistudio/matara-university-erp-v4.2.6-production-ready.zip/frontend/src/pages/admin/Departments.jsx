import { useState } from 'react';
import { Building2, Mail, Phone, Plus, Users } from 'lucide-react';
import DashboardLayout from '../../components/DashboardLayout.jsx';
import PageHeader from '../../components/PageHeader.jsx';

const seed = [
  { id: 1, name: 'Sciences', head: 'Dr. Grace Njeri', teachers: 12, subjects: 'Biology · Chemistry · Physics', color: 'green' },
  { id: 2, name: 'Languages', head: 'Ms. Faith Achieng', teachers: 9, subjects: 'English · Kiswahili · French', color: 'gold' },
  { id: 3, name: 'Mathematics', head: 'Mr. Daniel Otieno', teachers: 8, subjects: 'Mathematics · Statistics', color: 'clay' },
  { id: 4, name: 'Humanities', head: 'Mrs. Jane Wambui', teachers: 10, subjects: 'History · Geography · CRE', color: 'green' },
  { id: 5, name: 'ICT & Business', head: 'Mr. Peter Kamau', teachers: 7, subjects: 'Computer Studies · Business', color: 'gold' },
];

const TONE = {
  gold: 'bg-gold/15 text-gold-dark',
  clay: 'bg-clay/10 text-clay',
  green: 'bg-forest/10 text-forest',
};

export default function Departments() {
  const [departments, setDepartments] = useState(seed);
  const [open, setOpen] = useState(false);
  const [name, setName] = useState('');

  function add(e) {
    e.preventDefault();
    if (!name.trim()) return;
    setDepartments([
      ...departments,
      { id: Date.now(), name: name.trim(), head: 'Not assigned', teachers: 0, subjects: 'Add subjects', color: 'green' },
    ]);
    setName('');
    setOpen(false);
  }

  return (
    <DashboardLayout title="Departments" subtitle="Organise academic departments, heads of department and teaching teams">
      <PageHeader
        eyebrow="Academic structure"
        title="School departments"
        actions={
          <button className="btn-gold" onClick={() => setOpen(!open)}>
            <Plus size={17} /> Add department
          </button>
        }
      />

      {open && (
        <form onSubmit={add} className="card mb-6 flex flex-col gap-3 p-5 sm:flex-row">
          <div className="flex-1">
            <span className="label">Department name</span>
            <input autoFocus className="input" value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Creative Arts" />
          </div>
          <button className="btn-primary sm:mt-5" type="submit">Create department</button>
        </form>
      )}

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        {departments.map((d) => (
          <div className="card group p-5" key={d.id}>
            <div className="flex items-start justify-between gap-4">
              <div className={`flex h-12 w-12 items-center justify-center rounded-2xl ${TONE[d.color] || TONE.green}`}>
                <Building2 size={23} />
              </div>
              <span className="badge badge-green">Active</span>
            </div>
            <h3 className="mt-5 font-display text-xl font-semibold">{d.name}</h3>
            <p className="mt-1 text-sm text-ink/55">{d.subjects}</p>
            <div className="mt-5 flex flex-wrap gap-4 border-t border-sage pt-4 text-sm">
              <span className="flex items-center gap-2 text-ink/65"><Users size={16} /> {d.teachers} teachers</span>
              <span className="flex items-center gap-2 text-ink/65"><Mail size={16} /> {d.head}</span>
            </div>
            <div className="mt-4 flex gap-2">
              <button className="btn-ghost flex-1">View department</button>
              <button className="btn-ghost" aria-label="Call head of department"><Phone size={15} /></button>
            </div>
          </div>
        ))}
      </div>
    </DashboardLayout>
  );
}
