import { useEffect, useState } from 'react';
import { Wallet, X } from 'lucide-react';
import DashboardLayout from '../../components/DashboardLayout.jsx';
import api from '../../api/axios.js';
import ModalOverlay from '../../components/ModalOverlay.jsx';

export default function Fees() {
  const [fees, setFees] = useState([]);
  const [payFor, setPayFor] = useState(null);
  const [amount, setAmount] = useState('');
  const [saving, setSaving] = useState(false);

  async function load() {
    const res = await api.get('/fees');
    setFees(res.data);
  }
  useEffect(() => { load(); }, []);

  async function handlePay(e) {
    e.preventDefault();
    setSaving(true);
    try {
      await api.put(`/fees/${payFor.id}/pay`, { amount: Number(amount) });
      setPayFor(null);
      setAmount('');
      load();
    } finally {
      setSaving(false);
    }
  }

  const totalDue = fees.reduce((s, f) => s + f.amount_due, 0);
  const totalPaid = fees.reduce((s, f) => s + f.amount_paid, 0);

  return (
    <DashboardLayout title="Fee Ledger" subtitle="Term payments and outstanding balances">
      <div className="mb-5 grid grid-cols-1 gap-4 sm:grid-cols-3">
        <div className="card p-5">
          <p className="text-xs font-semibold uppercase tracking-wide text-ink/50">Total billed</p>
          <p className="mt-2 font-display text-2xl font-semibold">KES {totalDue.toLocaleString()}</p>
        </div>
        <div className="card p-5">
          <p className="text-xs font-semibold uppercase tracking-wide text-ink/50">Total collected</p>
          <p className="mt-2 font-display text-2xl font-semibold text-forest">KES {totalPaid.toLocaleString()}</p>
        </div>
        <div className="card p-5">
          <p className="text-xs font-semibold uppercase tracking-wide text-ink/50">Outstanding</p>
          <p className="mt-2 font-display text-2xl font-semibold text-clay">KES {(totalDue - totalPaid).toLocaleString()}</p>
        </div>
      </div>

      <div className="card overflow-x-auto">
        <table className="ledger-table">
          <thead>
            <tr>
              <th>Student</th>
              <th>Class</th>
              <th>Term</th>
              <th>Due</th>
              <th>Paid</th>
              <th>Balance</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {fees.map((f) => {
              const balance = f.amount_due - f.amount_paid;
              return (
                <tr key={f.id}>
                  <td className="font-medium">{f.student_name}</td>
                  <td className="text-ink/60">{f.class_name || '—'}</td>
                  <td className="text-ink/60">{f.term}</td>
                  <td className="font-mono text-xs">{f.amount_due.toLocaleString()}</td>
                  <td className="font-mono text-xs">{f.amount_paid.toLocaleString()}</td>
                  <td>
                    <span className={`badge ${balance <= 0 ? 'badge-green' : 'badge-red'}`}>
                      KES {balance.toLocaleString()}
                    </span>
                  </td>
                  <td>
                    {balance > 0 && (
                      <button className="btn-ghost !px-3 !py-1.5 text-xs" onClick={() => setPayFor(f)}>
                        <Wallet size={13} /> Record payment
                      </button>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {payFor && (
        <ModalOverlay>
          <div className="card w-full max-w-sm p-6">
            <div className="mb-4 flex items-center justify-between">
              <h3 className="font-display text-lg font-semibold">Record payment</h3>
              <button onClick={() => setPayFor(null)} className="text-ink/40 hover:text-ink"><X size={20} /></button>
            </div>
            <p className="mb-4 text-sm text-ink/60">
              For <span className="font-semibold text-ink">{payFor.student_name}</span> — {payFor.term}
            </p>
            <form onSubmit={handlePay} className="space-y-4">
              <div>
                <label className="label">Amount received (KES)</label>
                <input
                  type="number" required min="1" className="input"
                  value={amount} onChange={(e) => setAmount(e.target.value)}
                  placeholder={`Balance: ${(payFor.amount_due - payFor.amount_paid).toLocaleString()}`}
                />
              </div>
              <div className="flex justify-end gap-3">
                <button type="button" className="btn-ghost" onClick={() => setPayFor(null)}>Cancel</button>
                <button type="submit" disabled={saving} className="btn-primary">
                  {saving ? 'Saving…' : 'Record payment'}
                </button>
              </div>
            </form>
          </div>
        </ModalOverlay>
      )}
    </DashboardLayout>
  );
}
