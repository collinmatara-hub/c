import { useEffect, useState } from 'react';
import { Image, Palette, RefreshCw, Upload, RotateCcw } from 'lucide-react';
import DashboardLayout from '../../components/DashboardLayout.jsx';
import PageHeader from '../../components/PageHeader.jsx';
import api from '../../api/axios.js';

export default function Editors() {
  const [settings, setSettings] = useState([]);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [file, setFile] = useState(null);
  const load = async () => { setBusy(true); setError(''); try { const r=await api.get('/admin-control/settings'); setSettings(r.data); } catch(e){setError(e.response?.data?.error||'Could not load editor settings.');} finally{setBusy(false);} };
  useEffect(()=>{load();},[]);
  const value=(key)=>settings.find(x=>x.key===key)?.value||'';
  const save=async(key,val)=>{try{await api.put(`/admin-control/settings/${encodeURIComponent(key)}`,{value:val});setMessage(`${key.replaceAll('_',' ')} saved.`);load();}catch(e){setError(e.response?.data?.error||'Could not save setting.');}};
  const uploadDashboard=async(e)=>{e.preventDefault();if(!file)return;setBusy(true);setError('');try{const fd=new FormData();fd.append('image',file);const r=await api.post('/admin-control/branding/dashboard-image',fd,{headers:{'Content-Type':'multipart/form-data'}});setMessage('Dashboard image updated successfully.');setFile(null);setSettings(prev=>[...prev.filter(x=>x.key!=='dashboard_image_url'),{key:'dashboard_image_url',value:r.data.dashboard_image_url}]);}catch(e){setError(e.response?.data?.error||'Could not upload dashboard image.');}finally{setBusy(false);}};
  const resetDashboard=async()=>{if(!confirm('Reset the dashboard banner to the built-in university illustration?'))return;try{await api.delete('/admin-control/branding/dashboard-image');setMessage('Dashboard image reset.');load();}catch(e){setError(e.response?.data?.error||'Could not reset dashboard image.');}};
  return <DashboardLayout>
    <PageHeader eyebrow="Administration" title="Appearance & Branding" subtitle="Control university branding, dashboard presentation and global visual settings." />
    {message&&<div className="mb-4 rounded-xl bg-emerald-500/10 p-3 text-sm text-emerald-700 dark:text-emerald-300">{message}</div>}
    {error&&<div className="mb-4 rounded-xl bg-clay/10 p-3 text-sm text-clay">{error}</div>}
    <div className="grid gap-5 xl:grid-cols-2">
      <section className="card p-5"><div className="flex items-center gap-3"><div className="rounded-xl bg-forest/10 p-2 text-forest"><Image size={20}/></div><div><h2 className="font-display text-lg font-semibold">Dashboard image</h2><p className="text-xs text-ink/50">Replace the building/banner image shown on the main dashboard.</p></div></div>
        <div className="mt-5 overflow-hidden rounded-2xl border border-sage bg-paper">{value('dashboard_image_url')?<img src={value('dashboard_image_url')} alt="Dashboard banner" className="h-48 w-full object-cover"/>:<div className="grid h-48 place-items-center text-sm text-ink/45">Built-in university illustration is active.</div>}</div>
        <form onSubmit={uploadDashboard} className="mt-4 flex flex-wrap gap-3"><input type="file" accept="image/jpeg,image/png,image/webp" onChange={e=>setFile(e.target.files?.[0]||null)} className="input flex-1"/><button className="btn-primary" disabled={busy||!file}><Upload size={16}/> Upload image</button><button type="button" className="btn-secondary" onClick={resetDashboard}><RotateCcw size={16}/> Reset</button></form>
        <p className="mt-2 text-xs text-ink/45">JPG, PNG or WEBP, maximum 8 MB. Only Super Admin can change the shared dashboard image.</p>
      </section>
      <section className="card p-5"><div className="flex items-center gap-3"><div className="rounded-xl bg-gold/15 p-2 text-gold-dark"><Palette size={20}/></div><div><h2 className="font-display text-lg font-semibold">University branding</h2><p className="text-xs text-ink/50">Edit the text and colours used throughout the university interface.</p></div></div>
        <div className="mt-5 grid gap-4">{[['University Name','University Name'],['school_address','Address'],['school_phone','Phone'],['school_email','Email'],['brand_primary','Primary brand color'],['brand_secondary','Secondary brand color'],['currency','Currency'],['timezone','Timezone']].map(([key,label])=><label key={key}><span className="label">{label}</span><input className="input mt-1" defaultValue={value(key)} onBlur={e=>save(key,e.target.value)}/></label>)}</div>
      </section>
    </div>
    <section className="card mt-5 p-5"><div className="flex items-center justify-between"><div><h2 className="font-display text-lg font-semibold">Editor tools</h2><p className="text-sm text-ink/50">Changes are saved to the database and recorded in the audit log.</p></div><button className="btn-ghost" onClick={load}><RefreshCw size={16}/> Refresh</button></div></section>
  </DashboardLayout>;
}
