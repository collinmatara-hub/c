import { useEffect, useMemo, useState } from 'react';
import { Download, ShieldCheck } from 'lucide-react';
import { useAuth } from '../../context/AuthContext.jsx';
import api from '../../api/axios.js';
import { downloadExamCard } from '../../utils/pdf.js';
import { AlertCircle, CheckCircle2, Clock3, FileQuestion, Play, Send } from 'lucide-react';
import DashboardLayout from '../../components/DashboardLayout.jsx';
import PageHeader from '../../components/PageHeader.jsx';

const EXAMS = [
  {
    id: 1,
    title: 'Computer Networks CAT 1',
    subject: 'Data Communication',
    teacher: 'Mr. Peter Kamau',
    duration: 45,
    questions: 4,
    due: 'Today · 5:00 PM',
    status: 'Available',
    items: [
      { q: 'Which OSI layer handles logical addressing?', a: ['Physical', 'Data Link', 'Network', 'Application'], correct: 2 },
      { q: 'What does DHCP provide?', a: ['IP configuration', 'File encryption', 'Web hosting', 'Email'], correct: 0 },
      { q: 'Which device connects different networks?', a: ['Switch', 'Router', 'Hub', 'Repeater'], correct: 1 },
      { q: 'A VLAN primarily creates separate…', a: ['Broadcast domains', 'Power supplies', 'Hard disks', 'CPU cores'], correct: 0 },
    ],
  },
  {
    id: 2,
    title: 'Python Fundamentals',
    subject: 'Introduction to Python',
    teacher: 'Ms. Jane Wambui',
    duration: 60,
    questions: 3,
    due: 'Tomorrow · 11:00 AM',
    status: 'Upcoming',
    items: [],
  },
];

export default function StudentExams() {
  const { user } = useAuth();
  const [examCardError, setExamCardError] = useState('');
  const [cardConsent, setCardConsent] = useState(null);
  const [consentChecked, setConsentChecked] = useState(false);
  useEffect(() => { api.get('/student-cards/me').then(({data}) => setCardConsent(data.consent)).catch(() => {}); }, []);
  async function recordCardConsent() {
    setExamCardError('');
    try { const {data} = await api.post('/student-cards/me/consent', { consent: true, noticeVersion: '2026-01', purposes: ['student identity card', 'examination card generation', 'university student administration'] }); setCardConsent({consent_given: data.consent ? 1 : 0}); setConsentChecked(false); }
    catch (e) { setExamCardError(e.response?.data?.error || 'Could not record consent.'); }
  }
  async function generateMyExamCard() {
    setExamCardError('');
    try { const { data } = await api.get('/student-cards/me'); if (!data.consent || Number(data.consent.consent_given)!==1 || data.consent.withdrawn_at) { setExamCardError('Please review and record consent before generating your official examination card.'); return; } if (!data.student?.photo_url) { setExamCardError('Your student photograph is missing. Contact the ICT Office to register it.'); return; } downloadExamCard(data.student, { academicYear: data.student.academic_year, semester: data.student.current_semester }); }
    catch (e) { setExamCardError(e.response?.data?.error || 'Could not generate exam card. Please contact the ICT Office.'); }
  }
  const [active, setActive] = useState(null);
  const [answers, setAnswers] = useState({});
  const [submitted, setSubmitted] = useState(() => JSON.parse(localStorage.getItem('matara_exam_submissions') || '{}'));
  const [seconds, setSeconds] = useState(0);

  useEffect(() => {
    if (!active) return;
    setSeconds(active.duration * 60);
    const id = setInterval(() => {
      setSeconds((s) => {
        if (s <= 1) {
          clearInterval(id);
          return 0;
        }
        return s - 1;
      });
    }, 1000);
    return () => clearInterval(id);
  }, [active]);

  const score = useMemo(() => {
    if (!active) return 0;
    const correct = active.items.reduce((s, item, i) => s + (answers[i] === item.correct ? 1 : 0), 0);
    return Math.round((correct / active.items.length) * 100);
  }, [active, answers]);

  function submit() {
    const next = { ...submitted, [active.id]: { score, submittedAt: new Date().toLocaleString() } };
    setSubmitted(next);
    localStorage.setItem('matara_exam_submissions', JSON.stringify(next));
    setActive(null);
    setAnswers({});
  }

  if (active) {
    return (
      <DashboardLayout title={active.title} subtitle={`${active.subject} · ${active.questions} questions`}>
        <div className="mx-auto max-w-3xl">
          <div className="card mb-5 flex items-center justify-between p-4">
            <div className="flex items-center gap-3">
              <Clock3 className="text-forest" />
              <div>
                <p className="text-xs uppercase tracking-wide text-ink/40">Time remaining</p>
                <b className="text-lg">{Math.floor(seconds / 60)}:{String(seconds % 60).padStart(2, '0')}</b>
              </div>
            </div>
            <span className="badge badge-gold">Online examination</span>
          </div>

          <div className="space-y-4">
            {active.items.map((item, i) => (
              <div className="card p-5" key={item.q}>
                <p className="text-xs font-bold uppercase tracking-wide text-ink/40">Question {i + 1} of {active.questions}</p>
                <h3 className="mt-2 font-display text-lg font-semibold">{item.q}</h3>
                <div className="mt-4 grid gap-2">
                  {item.a.map((option, j) => (
                    <label
                      key={option}
                      className={`flex cursor-pointer items-center gap-3 rounded-xl border p-3 transition ${
                        answers[i] === j ? 'border-forest bg-forest/[.06]' : 'border-sage hover:bg-paper'
                      }`}
                    >
                      <input type="radio" name={`q-${i}`} checked={answers[i] === j} onChange={() => setAnswers({ ...answers, [i]: j })} />
                      <span>{option}</span>
                    </label>
                  ))}
                </div>
              </div>
            ))}
          </div>

          <button className="btn-primary mt-5" onClick={submit}><Send size={16} /> Submit examination</button>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout title="Online Examinations" subtitle="Take your scheduled tests and view submitted assessments">
      <PageHeader eyebrow="Student workspace" title="Exam centre" />
      <div className="card mb-5 p-4"><div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between"><div><h3 className="font-semibold">Examination card</h3><p className="text-sm text-ink/55">Generate your personal exam card using your university record and registered photograph.</p>{examCardError && <p role="alert" className="mt-2 text-sm text-clay">{examCardError}</p>}</div><button className="btn-primary shrink-0" onClick={generateMyExamCard}><Download size={16}/> Generate exam card PDF</button></div>{(!cardConsent || Number(cardConsent.consent_given)!==1 || cardConsent.withdrawn_at) && <div className="mt-4 rounded-xl border border-blue-200 bg-blue-50 p-3 text-sm"><b>Student data privacy notice</b><p className="mt-1">Your name, admission details, programme and student photograph will be used to create your identity and examination cards and support university administration. Access is restricted to authorized university personnel; data is handled under the applicable university privacy policy.</p><label className="mt-3 flex items-start gap-2"><input type="checkbox" checked={consentChecked} onChange={e=>setConsentChecked(e.target.checked)} className="mt-1"/><span>I have read this notice and consent to the stated use of my information for these purposes.</span></label><button className="btn-primary mt-3" disabled={!consentChecked} onClick={recordCardConsent}><ShieldCheck size={16}/> Record my consent</button></div>}</div>

      <div className="mb-6 rounded-2xl border border-forest/15 bg-forest/[.05] p-5">
        <div className="flex gap-3">
          <FileQuestion className="mt-0.5 text-forest" />
          <div>
            <h3 className="font-semibold">Exam centre</h3>
            <p className="mt-1 text-sm text-ink/55">
              Complete assessments before their deadlines. Your answers are submitted electronically for marking.
            </p>
          </div>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        {EXAMS.map((x) => {
          const done = submitted[x.id];
          return (
            <div className="card p-5" key={x.id}>
              <div className="flex items-start justify-between">
                <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-gold/15 text-gold-dark">
                  <FileQuestion size={22} />
                </div>
                {done ? (
                  <span className="badge badge-green"><CheckCircle2 size={13} /> Submitted</span>
                ) : (
                  <span className={`badge ${x.status === 'Available' ? 'badge-gold' : 'badge-green'}`}>{x.status}</span>
                )}
              </div>
              <h3 className="mt-4 font-display text-lg font-semibold">{x.title}</h3>
              <p className="text-sm text-ink/50">{x.subject} · {x.teacher}</p>
              <div className="mt-5 grid grid-cols-3 gap-2">
                <div className="rounded-xl bg-paper p-3"><p className="text-xs text-ink/45">Questions</p><b>{x.questions}</b></div>
                <div className="rounded-xl bg-paper p-3"><p className="text-xs text-ink/45">Duration</p><b>{x.duration} min</b></div>
                <div className="rounded-xl bg-paper p-3"><p className="text-xs text-ink/45">Due</p><b className="text-xs">{x.due}</b></div>
              </div>
              {done && (
                <div className="mt-4 rounded-xl bg-forest/5 p-3 text-sm">
                  <b>Latest submission: {done.score}%</b>
                  <p className="text-ink/50">Submitted {done.submittedAt}</p>
                </div>
              )}
              <button
                disabled={x.status !== 'Available' || done}
                onClick={() => setActive(x)}
                className="btn-primary mt-5 w-full disabled:opacity-40"
              >
                {done ? <><CheckCircle2 size={16} /> Completed</> : <><Play size={16} /> Start examination</>}
              </button>
              {x.status === 'Upcoming' && (
                <p className="mt-2 flex items-center justify-center gap-1 text-center text-xs text-ink/40">
                  <AlertCircle size={13} /> This exam is not open yet.
                </p>
              )}
            </div>
          );
        })}
      </div>
    </DashboardLayout>
  );
}
