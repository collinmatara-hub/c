import { useEffect, useMemo, useState } from 'react';
import { CalendarDays } from 'lucide-react';
import DashboardLayout from '../../components/DashboardLayout.jsx';
import { EmptyState } from '../../components/Skeleton.jsx';
import api from '../../api/axios.js';
import { clockTime } from '../../utils/format.js';

const DAYS = [
  { key: 'mon', label: 'Monday' },
  { key: 'tue', label: 'Tuesday' },
  { key: 'wed', label: 'Wednesday' },
  { key: 'thu', label: 'Thursday' },
  { key: 'fri', label: 'Friday' },
  { key: 'sat', label: 'Saturday' },
  { key: 'sun', label: 'Sunday' },
];

function dayKey(text) {
  return String(text || '').trim().toLowerCase().slice(0, 3);
}

export default function Timetable() {
  const [data, setData] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    api.get('/portal/timetable')
      .then((res) => setData(res.data))
      .catch((err) => setError(err.response?.data?.error || 'Could not load the timetable.'));
  }, []);

  const todayKey = dayKey(new Date().toLocaleDateString('en-US', { weekday: 'long' }));

  // Monday to Friday always show. Weekend days show only when they have classes.
  const { days, rows } = useMemo(() => {
    const slots = data?.slots || [];
    const used = new Set(slots.map((s) => dayKey(s.day)));
    const days = DAYS.filter((d, i) => i < 5 || used.has(d.key));
    const times = new Map();
    slots.forEach((s) => {
      const key = `${s.start_time}-${s.end_time}`;
      if (!times.has(key)) times.set(key, { key, start: s.start_time, end: s.end_time });
    });
    const rows = [...times.values()].sort((a, b) => a.start.localeCompare(b.start));
    return { days, rows };
  }, [data]);

  function cell(row, day) {
    return data.slots.filter((s) => dayKey(s.day) === day.key && s.start_time === row.start && s.end_time === row.end);
  }

  return (
    <DashboardLayout title="Timetable" subtitle={data?.class_name ? `Weekly lessons for ${data.class_name}` : 'Your weekly lessons'}>
      {error && <p className="mb-4 rounded-lg bg-clay/10 px-3 py-2 text-sm text-clay">{error}</p>}
      {!data ? (
        !error && <p className="text-sm text-ink/45">Loading…</p>
      ) : data.slots.length === 0 ? (
        <EmptyState icon={CalendarDays} title="No timetable yet" hint="Your timetable will show here once the school office has set it up." />
      ) : (
        <>
          <p className="mb-3 flex items-center gap-2 text-xs text-ink/55">
            <span className="inline-block h-3 w-3 rounded bg-forest/20 ring-1 ring-forest/40" /> Units you registered
          </p>
          <div className="card overflow-x-auto p-3">
            <table className="w-full min-w-[720px] border-separate border-spacing-2 text-sm">
              <thead>
                <tr>
                  <th className="w-28 text-left text-xs font-bold uppercase tracking-wide text-ink/45">Time</th>
                  {days.map((d) => (
                    <th
                      key={d.key}
                      className={`rounded-lg px-2 py-2 text-left text-xs font-bold uppercase tracking-wide ${
                        d.key === todayKey ? 'bg-forest text-on-forest' : 'bg-paper text-ink/55'
                      }`}
                    >
                      {d.label}{d.key === todayKey ? ' · Today' : ''}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {rows.map((row) => (
                  <tr key={row.key}>
                    <td className="whitespace-nowrap align-top text-xs font-semibold text-ink/60">
                      {clockTime(row.start)}<br />{clockTime(row.end)}
                    </td>
                    {days.map((d) => (
                      <td key={d.key} className="align-top">
                        {cell(row, d).map((slot) => (
                          <div
                            key={slot.id}
                            className={`mb-1 rounded-xl border p-2.5 ${
                              slot.registered ? 'border-forest/40 bg-forest/15' : 'border-sage bg-surface'
                            }`}
                          >
                            <p className="text-sm font-semibold text-ink">{slot.unit_name || 'Lesson'}</p>
                            {slot.lecturer && <p className="text-xs text-ink/60">{slot.lecturer}</p>}
                            {slot.room && <p className="text-xs text-ink/45">{slot.room}</p>}
                          </div>
                        ))}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
    </DashboardLayout>
  );
}
