import { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowLeft, ArrowRight, Bell, BookOpen, CalendarDays, CheckSquare, ChevronRight, CircleHelp, ClipboardList, FileText, GraduationCap, LayoutDashboard, LibraryBig, LogOut, Mail, Menu, MessageCircle, Moon, Search, Settings, Sun, UserRound, X, Megaphone, BookMarked, Clock3, Award, ExternalLink, Video } from 'lucide-react';
import api from '../../api/axios.js';
import { useAuth } from '../../context/AuthContext.jsx';
import '../../styles/lms.css';

const navItems = [
  { label: 'Dashboard', icon: LayoutDashboard, to: '/student/lms' },
  { label: 'Online Classes', icon: Video, to: '/student/lms/online-classes' },
  { label: 'My Courses', icon: BookOpen, to: '/student/units' },
  { label: 'Assignments', icon: ClipboardList, to: '/student/lms/assignments' },
  { label: 'Quizzes & Exams', icon: CheckSquare, to: '/student/exams' },
  { label: 'Grades', icon: Award, to: '/student/results' },
  { label: 'Announcements', icon: Megaphone, to: '/student/announcements' },
  { label: 'Academic Calendar', icon: CalendarDays, to: '/calendar' },
  { label: 'Learning Resources', icon: LibraryBig, to: '/student/content' },
  { label: 'Discussions', icon: MessageCircle, to: '/student/messages' },
  { label: 'Messages', icon: Mail, to: '/student/messages' },
  { label: 'My Profile', icon: UserRound, to: '/profile' },
  { label: 'Help & Support', icon: CircleHelp, to: '/help-desk' },
];
const dateLabel = (value) => { if (!value) return 'Date to be confirmed'; const d = new Date(value); return Number.isNaN(d.getTime()) ? String(value) : d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric', timeZone: 'Africa/Nairobi' }); };
const getGreeting = () => { const h = new Date().getHours(); return h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening'; };

export default function LMSDashboard() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [data, setData] = useState(null);
  const [error, setError] = useState('');
  const [collapsed, setCollapsed] = useState(false);
  const [dark, setDark] = useState(() => localStorage.getItem('matara_lms_theme') === 'dark');
  const [query, setQuery] = useState('');
  useEffect(() => { let active = true; api.get('/lms/student/dashboard').then(({ data: result }) => { if (active) setData(result); }).catch((e) => { if (active) setError(e.response?.data?.error || 'We could not load your learning data. Please try again.'); }); return () => { active = false; }; }, []);
  useEffect(() => { localStorage.setItem('matara_lms_theme', dark ? 'dark' : 'light'); }, [dark]);
  const student = data?.student || {};
  const courses = useMemo(() => (data?.units || data?.courses || []).filter((c) => `${c.unit_name || c.name || ''} ${c.unit_code || c.code || ''}`.toLowerCase().includes(query.toLowerCase())), [data, query]);
  const deadlines = useMemo(() => (data?.upcoming || data?.deadlines || []).slice().sort((a,b) => new Date(a.due_date || a.date || 0) - new Date(b.due_date || b.date || 0)).slice(0,5), [data]);
  return <div className={`lms-app ${dark ? 'lms-dark' : ''}`}>
    <aside className={`lms-sidebar ${collapsed ? 'lms-sidebar-collapsed' : ''}`}>
      <div className="lms-brand"><div className="lms-crest"><GraduationCap size={27}/></div>{!collapsed && <div><strong>MATARA<br/>UNIVERSITY</strong><small>Knowledge | Integrity | Impact</small></div>}</div>
      <nav className="lms-nav" aria-label="LMS navigation">{navItems.map(({label,icon:Icon,to}) => <Link key={label} to={to} title={collapsed ? label : undefined} className={`lms-nav-link ${to === '/student/lms' ? 'lms-active' : ''}`}><Icon size={19}/>{!collapsed && <span>{label}</span>}</Link>)}</nav>
      {!collapsed && <div className="lms-sidebar-campus"><div className="lms-campus-overlay"><strong>Matara University LMS</strong><span>Learn · Grow · Succeed</span></div></div>}
      <button className="lms-collapse" onClick={() => setCollapsed(!collapsed)} aria-label={collapsed ? 'Expand navigation' : 'Collapse navigation'}>{collapsed ? <Menu size={18}/> : <><ArrowLeft size={17}/> Collapse menu</>}</button>
    </aside>
    <section className="lms-main-shell">
      <header className="lms-topbar"><button className="lms-icon-btn" onClick={() => setCollapsed(!collapsed)} aria-label="Toggle sidebar"><Menu size={20}/></button><label className="lms-search"><Search size={17}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search courses, resources, or anything…" aria-label="Search courses"/></label><div className="lms-top-actions"><Link to="/student/announcements" className="lms-icon-btn" aria-label="Notifications"><Bell size={19}/></Link><Link to="/student/messages" className="lms-icon-btn" aria-label="Messages"><Mail size={19}/></Link><button className="lms-icon-btn" onClick={()=>setDark(!dark)} aria-label="Toggle dark mode">{dark ? <Sun size={19}/> : <Moon size={19}/>}</button><div className="lms-user"><span className="lms-avatar">{(user?.name || 'S').split(' ').map(x=>x[0]).slice(0,2).join('').toUpperCase()}</span><span><strong>{user?.name || 'Student'}</strong><small>Student</small></span><button className="lms-icon-btn lms-logout" onClick={async()=>{await logout();navigate('/login',{replace:true});}} title="Sign out" aria-label="Sign out"><LogOut size={17}/></button></div></div></header>
      <main className="lms-content"><div className="lms-back-row"><Link to="/student" className="lms-back"><ArrowLeft size={16}/> Back to Student Portal</Link><span>Matara University / Learning Management System</span></div>
        {error && <div className="lms-error" role="alert">{error} <button onClick={()=>{setError('');setData(null);api.get('/lms/student/dashboard').then(({data:d})=>setData(d)).catch(()=>setError('Still unable to load your learning data.'));}}>Retry</button></div>}
        {!data ? <div className="lms-loading"><span className="lms-spinner"/>Loading your learning dashboard…</div> : <>
          <section className="lms-hero"><div className="lms-hero-copy"><p className="lms-eyebrow">✦ {getGreeting()}</p><h1>{user?.name || student.name || 'Student'} <span aria-hidden="true">👋</span></h1><p>Welcome back to Matara University. Keep learning, keep growing!</p><small>{student.adm_no || student.registration_number || ''}{data.term ? ` · ${data.term}` : ''}</small></div><blockquote>“Education is the most powerful weapon which you can use to change the world.”<cite>— Nelson Mandela</cite></blockquote><div className="lms-stats">
            <Link to="/student/units" className="lms-stat"><span className="lms-stat-icon blue"><BookOpen/></span><span><small>Enrolled Courses</small><strong>{data.unitsRegistered ?? courses.length ?? '—'}</strong></span></Link>
            <Link to="/student/content" className="lms-stat"><span className="lms-stat-icon green"><ClipboardList/></span><span><small>Pending Assignments</small><strong>{data.pendingAssignments ?? '—'}</strong></span></Link>
            <Link to="/student/exams" className="lms-stat"><span className="lms-stat-icon orange"><CalendarDays/></span><span><small>Upcoming Exams</small><strong>{data.upcomingExams ?? '—'}</strong></span></Link>
            <Link to="/student/results" className="lms-stat"><span className="lms-stat-icon purple"><Award/></span><span><small>Current GPA / Average</small><strong>{data.gpa ?? (data.latestAverage == null ? '—' : `${data.latestAverage}%`)}</strong></span></Link>
          </div></section>
          <div className="lms-columns"><div className="lms-primary-column"><section className="lms-panel"><div className="lms-panel-heading"><h2><BookOpen size={20}/> My Courses</h2><Link to="/student/units">View all courses <ArrowRight size={15}/></Link></div>{courses.length ? <div className="lms-course-grid">{courses.slice(0,6).map((course,i)=><Link to="/student/units" key={course.unit_id || course.id || `${course.unit_code}-${i}`} className={`lms-course-card tone-${i%6}`}><div className="lms-course-color"><span className="lms-course-icon"><BookMarked size={22}/></span><small>{course.unit_code || course.code || 'COURSE'}</small><strong>{course.unit_name || course.name || 'Course'}</strong>{course.lecturer && <span className="lms-lecturer">{course.lecturer}</span>}</div><div className="lms-course-progress"><span><i style={{width:`${Math.min(100,Math.max(0,Number(course.progress)||0))}%`}}/></span><small>{Number(course.progress)||0}%</small></div><div className="lms-course-footer"><span><CalendarDays size={13}/> {course.next_activity || 'Open course'}</span><ChevronRight size={15}/></div></Link>)}</div> : <div className="lms-empty"><BookOpen size={24}/><strong>No course list available</strong><p>Your registered units are available in the ERP student portal.</p><Link to="/student/units">Open My Units <ArrowRight size={14}/></Link></div>}</section>
          <section className="lms-panel"><div className="lms-panel-heading"><h2><Megaphone size={20}/> Recent Announcements</h2><Link to="/student/announcements">View all <ArrowRight size={15}/></Link></div><div className="lms-announcement"><span className="lms-announcement-dot"/><div><strong>University announcements</strong><p>Check the announcements area for official academic notices, course updates and university communications.</p><Link to="/student/announcements">Open announcements <ArrowRight size={13}/></Link></div></div></section></div>
          <aside className="lms-secondary-column"><section className="lms-panel"><div className="lms-panel-heading"><h2><CalendarDays size={19}/> Upcoming Deadlines</h2><Link to="/calendar">Calendar <ArrowRight size={14}/></Link></div>{deadlines.length ? deadlines.map((item,i)=><Link className="lms-deadline" to={item.type==='exam'?'/student/exams':'/student/content'} key={item.id||i}><span className="lms-date-box"><strong>{new Date(item.due_date||item.date).getDate()}</strong><small>{new Date(item.due_date||item.date).toLocaleDateString('en-GB',{month:'short',timeZone:'Africa/Nairobi'})}</small></span><span><strong>{item.title || item.name || item.unit_name || 'Academic activity'}</strong><small>{item.course_name || item.unit_name || item.type || 'University activity'}</small><small>{dateLabel(item.due_date||item.date)}</small></span></Link>) : <div className="lms-empty lms-empty-compact"><Clock3 size={22}/><p>No deadline feed is available yet. Check your timetable and course pages for scheduled work.</p></div>}</section>
          <section className="lms-panel"><div className="lms-panel-heading"><h2><ExternalLink size={19}/> Quick Links</h2></div>{[{label:'Course Materials',desc:'Lecture notes and study files',to:'/student/content',icon:LibraryBig,color:'blue'},{label:'Submit Assignment',desc:'Open course work',to:'/student/lms/assignments',icon:FileText,color:'green'},{label:'View Grades',desc:'Academic performance',to:'/student/results',icon:Award,color:'purple'},{label:'Student Handbook',desc:'Policies and guidelines',to:'/student/announcements',icon:BookMarked,color:'orange'}].map(({label,desc,to,icon:Icon,color})=><Link className="lms-quick-link" to={to} key={label}><span className={`lms-quick-icon ${color}`}><Icon size={19}/></span><span><strong>{label}</strong><small>{desc}</small></span><ChevronRight size={16}/></Link>)}</section>
          <section className="lms-study-tip"><div><h2><GraduationCap size={19}/> Study Tips</h2><p>Plan short, focused study sessions, review notes regularly, and start assignments before their deadlines. Ask for help when you need it.</p><Link to="/help-desk">Get academic support <ArrowRight size={14}/></Link></div></section></aside></div>
        </>}
      </main><footer className="lms-footer">Matara University · Learning Management System <span>Learn · Grow · Succeed</span></footer>
    </section>
  </div>;
}
