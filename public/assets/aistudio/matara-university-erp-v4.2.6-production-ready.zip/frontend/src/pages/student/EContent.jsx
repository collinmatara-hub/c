import { useEffect, useMemo, useState } from 'react';
import { BookOpenCheck, ExternalLink, Search, User } from 'lucide-react';
import DashboardLayout from '../../components/DashboardLayout.jsx';
import { EmptyState } from '../../components/Skeleton.jsx';
import api from '../../api/axios.js';
import { shortDate } from '../../utils/format.js';

export default function EContent() {
  const [items, setItems] = useState(null);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');
  const [unit, setUnit] = useState('all');
  const [mineOnly, setMineOnly] = useState(false);

  useEffect(() => {
    api.get('/portal/content')
      .then((res) => setItems(res.data.items))
      .catch((err) => setError(err.response?.data?.error || 'Could not load the e-content.'));
  }, []);

  const units = useMemo(() => {
    const names = new Map();
    (items || []).forEach((i) => { if (i.subject_id) names.set(i.subject_id, i.unit_name); });
    return [...names.entries()].sort((a, b) => a[1].localeCompare(b[1]));
  }, [items]);

  const shown = useMemo(() => {
    const text = search.toLowerCase();
    return (items || []).filter((i) => {
      if (unit !== 'all' && String(i.subject_id) !== unit) return false;
      if (mineOnly && !i.registered) return false;
      return `${i.title} ${i.description || ''} ${i.unit_name || ''}`.toLowerCase().includes(text);
    });
  }, [items, search, unit, mineOnly]);

  return (
    <DashboardLayout title="E-Content" subtitle="Notes, links and learning material from your lecturers">
      {error && <p className="mb-4 rounded-lg bg-clay/10 px-3 py-2 text-sm text-clay">{error}</p>}

      <div className="mb-5 flex flex-wrap items-center gap-3">
        <div className="relative min-w-[220px] flex-1">
          <Search className="absolute left-3 top-2.5 text-ink/40" size={17} />
          <input className="input pl-9" placeholder="Search e-content" value={search} onChange={(e) => setSearch(e.target.value)} aria-label="Search e-content" />
        </div>
        <select className="input !w-auto" value={unit} onChange={(e) => setUnit(e.target.value)} aria-label="Filter by unit">
          <option value="all">All units</option>
          {units.map(([id, name]) => <option key={id} value={String(id)}>{name}</option>)}
        </select>
        <label className="flex items-center gap-2 text-sm font-medium text-ink/70">
          <input type="checkbox" checked={mineOnly} onChange={(e) => setMineOnly(e.target.checked)} className="h-4 w-4 accent-[rgb(var(--forest))]" />
          My registered units only
        </label>
      </div>

      {!items ? (
        !error && <p className="text-sm text-ink/45">Loading…</p>
      ) : shown.length === 0 ? (
        <EmptyState icon={BookOpenCheck} title="No e-content found" hint="Material your lecturers upload for your class will show up here." />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {shown.map((item) => (
            <article key={item.id} className="card flex flex-col p-5">
              <div className="mb-3 flex items-start gap-3">
                <span className="icon-bubble h-11 w-11"><BookOpenCheck size={19} /></span>
                <div className="min-w-0">
                  <h3 className="text-sm font-bold text-ink">{item.title}</h3>
                  {item.unit_name && <p className="text-xs text-forest">{item.unit_name}</p>}
                </div>
              </div>
              {item.description && <p className="mb-3 text-sm text-ink/65">{item.description}</p>}
              <div className="mt-auto flex items-end justify-between gap-3 pt-2">
                <p className="text-xs text-ink/50">
                  {item.lecturer && <span className="flex items-center gap-1"><User size={12} /> {item.lecturer}</span>}
                  <span>{shortDate(item.created_at)}</span>
                </p>
                {item.url ? (
                  <a className="btn-primary !px-3 !py-2" href={item.url} target="_blank" rel="noopener noreferrer">
                    Open <ExternalLink size={14} />
                  </a>
                ) : item.file_path ? (
                  <span className="max-w-[10rem] truncate rounded-lg bg-paper px-2 py-1 font-mono text-xs text-ink/60" title={item.file_path}>{item.file_path}</span>
                ) : null}
              </div>
            </article>
          ))}
        </div>
      )}
    </DashboardLayout>
  );
}
