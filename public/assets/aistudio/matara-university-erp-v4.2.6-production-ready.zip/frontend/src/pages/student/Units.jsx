import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, Plus, Trash2, User, ListChecks } from 'lucide-react';
import DashboardLayout from '../../components/DashboardLayout.jsx';
import Panel from '../../components/dashboard/Panel.jsx';
import { EmptyState } from '../../components/Skeleton.jsx';
import api from '../../api/axios.js';

export default function Units() {
  const [data, setData] = useState(null);
  const [search, setSearch] = useState('');
  const [message, setMessage] = useState(null);
  const [busy, setBusy] = useState(false);

  async function load() {
    try {
      const res = await api.get('/portal/units');
      setData(res.data);
    } catch (err) {
      setMessage({ type: 'error', text: err.response?.data?.error || 'Could not load your units.' });
    }
  }
  useEffect(() => { load(); }, []);

  async function register(unit) {
    setBusy(true);
    setMessage(null);
    try {
      await api.post('/portal/units/register', { subject_id: unit.subject_id });
      setMessage({ type: 'ok', text: `${unit.name} registered.` });
      await load();
    } catch (err) {
      setMessage({ type: 'error', text: err.response?.data?.error || 'Could not register that unit.' });
    } finally {
      setBusy(false);
    }
  }

  async function drop(unit) {
    if (!confirm(`Drop ${unit.name} for this term?`)) return;
    setBusy(true);
    setMessage(null);
    try {
      await api.delete(`/portal/units/${unit.subject_id}`);
      setMessage({ type: 'ok', text: `${unit.name} dropped.` });
      await load();
    } catch (err) {
      setMessage({ type: 'error', text: err.response?.data?.error || 'Could not drop that unit.' });
    } finally {
      setBusy(false);
    }
  }

  const available = useMemo(() => {
    if (!data) return [];
    const text = search.toLowerCase();
    return data.available.filter((u) => `${u.name} ${u.code}`.toLowerCase().includes(text));
  }, [data, search]);

  return (
    <DashboardLayout title="My Units" subtitle="Register the units you will study this term">
      {message && (
        <p className={`mb-4 rounded-lg px-3 py-2 text-sm ${message.type === 'ok' ? 'bg-forest/10 text-forest' : 'bg-clay/10 text-clay'}`} role="status">
          {message.text}
        </p>
      )}

      {!data ? (
        <p className="text-sm text-ink/45">Loading…</p>
      ) : (
        <div className="grid gap-6 lg:grid-cols-2">
          <Panel
            icon={ListChecks}
            title="Registered units"
            subtitle={`${data.term} · ${data.registered.length} unit${data.registered.length === 1 ? '' : 's'}`}
          >
            {data.registered.length === 0 ? (
              <EmptyState title="No units registered yet" hint="Pick units from the list on the right to register them." />
            ) : (
              <ul className="divide-y divide-sage/60">
                {data.registered.map((unit) => (
                  <li key={unit.subject_id} className="flex items-center gap-3 py-3 first:pt-0 last:pb-0">
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-semibold text-ink">
                        {unit.name} <span className="font-mono text-xs font-normal text-ink/45">{unit.code}</span>
                      </p>
                      <p className="mt-0.5 flex items-center gap-1 text-xs text-ink/55">
                        <User size={12} /> {unit.lecturer || 'Lecturer not assigned yet'}
                      </p>
                    </div>
                    <button className="btn-ghost !px-3 !py-2" disabled={busy} onClick={() => drop(unit)} aria-label={`Drop ${unit.name}`}>
                      <Trash2 size={14} /> Drop
                    </button>
                  </li>
                ))}
              </ul>
            )}
            {data.registered.length > 0 && (
              <p className="mt-4 text-xs text-ink/50">
                See when they meet in your <Link to="/student/timetable" className="font-semibold text-forest">timetable</Link>, or open the
                {' '}<Link to="/student/content" className="font-semibold text-forest">e-content</Link>.
              </p>
            )}
          </Panel>

          <Panel icon={Plus} title="Available units" subtitle="Units you have not registered yet">
            <div className="relative mb-3">
              <Search className="absolute left-3 top-2.5 text-ink/40" size={17} />
              <input className="input pl-9" placeholder="Search by unit name or code" value={search} onChange={(e) => setSearch(e.target.value)} aria-label="Search units" />
            </div>
            {available.length === 0 ? (
              <EmptyState title={data.available.length === 0 ? 'You have registered every unit' : 'No unit matches your search'} />
            ) : (
              <ul className="divide-y divide-sage/60">
                {available.map((unit) => (
                  <li key={unit.subject_id} className="flex items-center gap-3 py-3 first:pt-0 last:pb-0">
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-semibold text-ink">
                        {unit.name} <span className="font-mono text-xs font-normal text-ink/45">{unit.code}</span>
                      </p>
                      <p className="mt-0.5 flex items-center gap-1 text-xs text-ink/55">
                        <User size={12} /> {unit.lecturer || 'Lecturer not assigned yet'}
                      </p>
                    </div>
                    <button className="btn-primary !px-3 !py-2" disabled={busy} onClick={() => register(unit)} aria-label={`Register ${unit.name}`}>
                      <Plus size={14} /> Register
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </Panel>
        </div>
      )}
    </DashboardLayout>
  );
}
