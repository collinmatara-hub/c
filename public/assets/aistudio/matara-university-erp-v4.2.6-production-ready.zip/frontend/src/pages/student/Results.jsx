import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Award,
  BookOpen,
  CheckCircle2,
  Download,
  FileText,
  GraduationCap,
  Printer,
  TrendingUp,
  XCircle,
} from 'lucide-react';
import DashboardLayout from '../../components/DashboardLayout.jsx';
import StatusBadge from '../../components/StatusBadge.jsx';
import { EmptyState } from '../../components/Skeleton.jsx';
import api from '../../api/axios.js';
import { downloadReportCard } from '../../utils/pdf.js';
import Crest from '../../components/Crest.jsx';

const GRADE_SCALE = [
  ['A+', '90 – 100', 'grade-a'],
  ['A', '80 – 89', 'grade-a'],
  ['A−', '75 – 79', 'grade-a'],
  ['B+', '70 – 74', 'grade-b'],
  ['B', '65 – 69', 'grade-b'],
  ['B−', '60 – 64', 'grade-b'],
  ['C+', '55 – 59', 'grade-c'],
  ['C', '50 – 54', 'grade-c'],
  ['F', '0 – 49', 'grade-f'],
];

function gradeTone(grade = '') {
  const g = String(grade).toUpperCase();
  if (g.startsWith('A')) return 'grade-a';
  if (g.startsWith('B')) return 'grade-b';
  if (g.startsWith('C')) return 'grade-c';
  if (g === 'F') return 'grade-f';
  return 'grade-neutral';
}

function getAcademicYear(row) {
  const year = Number(row?.year);
  if (!year) return null;
  return `${year}/${year + 1}`;
}

export default function Results() {
  const [data, setData] = useState(null);
  const [university, setUniversity] = useState(null);
  const [error, setError] = useState('');
  const [academicYear, setAcademicYear] = useState('all');
  const [semester, setSemester] = useState('all');
  const [downloading, setDownloading] = useState(false);

  useEffect(() => {
    Promise.allSettled([
      api.get('/portal/university-results'),
      api.get('/portal/results'),
    ]).then(([universityResult, resultData]) => {
      if (universityResult.status === 'fulfilled') setUniversity(universityResult.value.data);
      if (resultData.status === 'fulfilled') setData(resultData.value.data);
      else setError(resultData.reason?.response?.data?.error || 'Could not load your results.');
    });
  }, []);

  const student = university?.student || data?.student || {};
  const rawResults = data?.results || [];
  const universityResults = university?.results || [];

  const years = useMemo(() => {
    const values = new Set();
    [...rawResults, ...universityResults].forEach((r) => {
      const value = getAcademicYear(r);
      if (value) values.add(value);
    });
    if (!values.size) values.add('2024/2025');
    return [...values].sort().reverse();
  }, [rawResults, universityResults]);

  const semesters = useMemo(() => {
    const values = new Set();
    universityResults.forEach((r) => r.semester && values.add(r.semester));
    rawResults.forEach((r) => r.term && values.add(r.term));
    return [...values];
  }, [rawResults, universityResults]);

  const filteredUniversityResults = useMemo(() => {
    return universityResults.filter((r) => {
      const year = getAcademicYear(r);
      const yearOk = academicYear === 'all' || !year || year === academicYear;
      const semesterOk = semester === 'all' || r.semester === semester || r.term === semester;
      return yearOk && semesterOk;
    });
  }, [universityResults, academicYear, semester]);

  const filteredResults = useMemo(() => {
    return rawResults.filter((r) => {
      const year = getAcademicYear(r);
      const yearOk = academicYear === 'all' || !year || year === academicYear;
      const semesterOk = semester === 'all' || r.term === semester || r.semester === semester;
      return yearOk && semesterOk;
    });
  }, [rawResults, academicYear, semester]);

  const allRows = filteredUniversityResults.length ? filteredUniversityResults : filteredResults;
  const passed = allRows.filter((r) => r.passed !== false && String(r.grade || '').toUpperCase() !== 'F').length;
  const failed = allRows.length - passed;
  const totalCredits = filteredUniversityResults.reduce((sum, r) => sum + Number(r.credits || 0), 0);
  const weightedPoints = filteredUniversityResults.reduce((sum, r) => sum + Number(r.grade_points || 0) * Number(r.credits || 0), 0);
  const gpa = filteredUniversityResults.length && totalCredits
    ? (weightedPoints / totalCredits).toFixed(2)
    : (university?.gpa ?? '—');
  const cgpa = university?.gpa ?? gpa;

  const handleReportCard = async () => {
    try {
      setDownloading(true);
      const response = await api.get('/erp/student/me/report-card');
      downloadReportCard(response.data);
    } catch (err) {
      setError(err.response?.data?.error || 'Could not generate the PDF.');
    } finally {
      setDownloading(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <DashboardLayout title="Result Book" subtitle="View your academic results and performance">
      <div className="result-book-page" id="result-book">
        {error && <p className="mb-4 rounded-lg bg-clay/10 px-3 py-2 text-sm text-clay print:hidden">{error}</p>}

        <header className="result-book-toolbar print:hidden">
          <div className="result-book-title">
            <div className="result-book-title-icon"><FileText size={25} /></div>
            <div>
              <h1>Result Book</h1>
              <p>View your academic results and performance</p>
            </div>
          </div>
          <div className="result-book-actions">
            <select className="result-select" value={academicYear} onChange={(e) => setAcademicYear(e.target.value)} aria-label="Academic year">
              <option value="all">All Academic Years</option>
              {years.map((year) => <option key={year} value={year}>{year} Academic Year</option>)}
            </select>
            <select className="result-select" value={semester} onChange={(e) => setSemester(e.target.value)} aria-label="Semester">
              <option value="all">All Semesters</option>
              {semesters.map((item) => <option key={item} value={item}>{item}</option>)}
            </select>
            <button className="result-print-btn" type="button" onClick={handlePrint}>
              <Printer size={16} /> Print Result
            </button>
            <button className="result-download-btn" type="button" onClick={handleReportCard} disabled={downloading}>
              <Download size={16} /> {downloading ? 'Preparing…' : 'Download PDF'}
            </button>
          </div>
        </header>

        <section className="result-identity-card">
          <div className="result-student-block">
            <div className="result-avatar"><GraduationCap size={38} /></div>
            <div className="result-student-details">
              <h2>{student.name || 'Student'}</h2>
              <p><strong>Student ID:</strong> {student.registration_no || student.adm_no || '—'}</p>
              <div className="result-detail-grid">
                <p><strong>Faculty</strong><span>:</span> Faculty of Science</p>
                <p><strong>Programme</strong><span>:</span> {student.programme || 'BSc. Computer Science'}</p>
                <p><strong>Year</strong><span>:</span> {student.year || '2'}</p>
                <p><strong>CGPA</strong><span>:</span> <b>{cgpa}</b></p>
              </div>
            </div>
          </div>
          <div className="result-document-brand">
            <div className="result-watermark-line" />
            <div className="result-mini-crest"><Crest size={64} /></div>
            <div>
              <strong>MATARA UNIVERSITY</strong>
              <span>ACADEMIC RESULT BOOK</span>
              <em>Knowledge • Innovation • Future</em>
            </div>
          </div>
          <div className="result-overall-card">
            <div className="result-overall-icon"><GraduationCap size={28} /></div>
            <div>
              <span>Overall Result</span>
              <strong>{cgpa === '—' ? 'Pending' : Number(cgpa) >= 3.5 ? 'First Class' : Number(cgpa) >= 3 ? 'Second Class Upper' : 'Academic Record'}</strong>
              <b>CGPA: {cgpa}</b>
            </div>
          </div>
          <div className="result-pass-card">
            <CheckCircle2 size={25} />
            <span>{failed === 0 ? 'You have passed all registered courses for this semester.' : `${failed} course${failed > 1 ? 's' : ''} require academic attention.`}</span>
          </div>
        </section>

        <section className="result-section-card">
          <div className="result-section-heading">
            <div className="result-section-icon"><FileText size={20} /></div>
            <h2>Course Results</h2>
          </div>
          {allRows.length ? (
            <div className="result-table-wrap">
              <table className="result-book-table">
                <thead>
                  <tr>
                    <th>No.</th>
                    <th>Course Code</th>
                    <th>Course Title</th>
                    <th>Credits</th>
                    <th>Grade</th>
                    <th>Marks (%)</th>
                    <th>Remark</th>
                  </tr>
                </thead>
                <tbody>
                  {allRows.map((r, index) => {
                    const grade = r.grade || '—';
                    const passedRow = r.passed !== false && String(grade).toUpperCase() !== 'F';
                    return (
                      <tr key={r.id || `${r.subject_id || r.unit_code}-${index}`}>
                        <td>{index + 1}</td>
                        <td className="course-code">{r.unit_code || r.code || '—'}</td>
                        <td className="course-title">{r.unit_name || r.subject_name || r.subject || '—'}</td>
                        <td>{r.credits ?? '—'}</td>
                        <td><span className={`result-grade ${gradeTone(grade)}`}>{grade}</span></td>
                        <td>{r.total_mark ?? r.score ?? '—'}</td>
                        <td><span className={`result-remark ${passedRow ? 'pass' : 'fail'}`}>{passedRow ? 'Pass' : 'Fail'}</span></td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          ) : (
            <EmptyState icon={Award} title="No results published yet" hint="Your official academic results will appear here after they are approved and published." />
          )}
        </section>

        <section className="result-section-card result-summary-card">
          <div className="result-section-heading">
            <div className="result-section-icon"><BookOpen size={20} /></div>
            <h2>Semester Summary</h2>
          </div>
          <div className="result-stat-grid">
            <div className="result-stat"><div className="result-stat-icon blue"><BookOpen size={22} /></div><span>Total Credits</span><strong>{totalCredits || university?.credits_attempted || '—'}</strong></div>
            <div className="result-stat"><div className="result-stat-icon green"><CheckCircle2 size={22} /></div><span>Passed Credits</span><strong>{filteredUniversityResults.filter((r) => String(r.grade || '').toUpperCase() !== 'F').reduce((s, r) => s + Number(r.credits || 0), 0) || (failed === 0 ? totalCredits : '—')}</strong></div>
            <div className="result-stat"><div className="result-stat-icon red"><XCircle size={22} /></div><span>Failed Credits</span><strong>{filteredUniversityResults.filter((r) => String(r.grade || '').toUpperCase() === 'F').reduce((s, r) => s + Number(r.credits || 0), 0)}</strong></div>
            <div className="result-stat"><div className="result-stat-icon blue"><TrendingUp size={22} /></div><span>GPA</span><strong>{gpa}</strong></div>
            <div className="result-stat"><div className="result-stat-icon gold"><Award size={22} /></div><span>CGPA</span><strong>{cgpa}</strong></div>
          </div>
        </section>

        <section className="result-section-card grade-scale-card">
          <div className="result-section-heading">
            <div className="result-section-icon"><Award size={20} /></div>
            <h2>Grade Scale</h2>
          </div>
          <div className="grade-scale-grid">
            {[GRADE_SCALE.slice(0, 3), GRADE_SCALE.slice(3, 6), GRADE_SCALE.slice(6)].map((group, groupIndex) => (
              <div className="grade-scale-table" key={groupIndex}>
                <div className="grade-scale-head"><span>Grade</span><span>Percentage Range</span></div>
                {group.map(([grade, range, tone]) => (
                  <div className="grade-scale-row" key={grade}>
                    <b className={tone}>{grade}</b><span>{range}</span>
                  </div>
                ))}
              </div>
            ))}
          </div>
        </section>

        <footer className="result-book-footer">
          <span>Matara University &nbsp;|&nbsp; Student Portal</span>
          <span>Generated on: {new Date().toLocaleString()}</span>
          <button type="button" onClick={handlePrint} className="print-footer-btn print:hidden"><Printer size={14} /> Print</button>
        </footer>

        <div className="print-only-result-signoff">
          <span>Student Signature</span><span>Authorized University Officer</span>
        </div>
      </div>
    </DashboardLayout>
  );
}
