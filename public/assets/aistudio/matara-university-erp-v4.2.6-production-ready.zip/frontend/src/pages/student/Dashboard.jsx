import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  ListChecks, TrendingUp, FilePenLine, Wallet, CalendarDays, Award, BookOpenCheck,
  MessageSquare, FileQuestion, Clock,
} from 'lucide-react';
import DashboardLayout from '../../components/DashboardLayout.jsx';
import { DashboardSkeleton } from '../../components/Skeleton.jsx';
import Panel from '../../components/dashboard/Panel.jsx';
import StatTile from '../../components/dashboard/StatTile.jsx';
import api from '../../api/axios.js';
import { useAuth } from '../../context/AuthContext.jsx';
import { clockTime, firstName, greeting, kes, longDate } from '../../utils/format.js';

const SHORTCUTS = [
  { to: '/student/lms', label: 'My LMS', icon: BookOpenCheck },
  { to: '/student/units', label: 'My Units', icon: ListChecks },
  { to: '/student/timetable', label: 'Timetable', icon: CalendarDays },
  { to: '/student/content', label: 'E-Content', icon: BookOpenCheck },
  { to: '/student/results', label: 'CAT Results', icon: Award },
  { to: '/student/supplementary', label: 'Supplementary', icon: FilePenLine },
  { to: '/student/messages', label: 'Contact Lecturer', icon: MessageSquare, badge: 'unreadMessages' },
  { to: '/student/exams', label: 'Online Exams', icon: FileQuestion },
];

export default function StudentDashboard() {
  const { user } = useAuth();
  const [data, setData] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    api.get('/portal/overview')
      .then((res) => setData(res.data))
      .catch((err) => setError(err.response?.data?.error || 'Could not load your dashboard.'));
  }, []);

  if (error) {
    return (
      <DashboardLayout hideTitle>
        <div className="card mx-auto max-w-md p-8 text-center text-sm text-ink/70">{error}</div>
      </DashboardLayout>
    );
  }
  if (!data) {
    return (
      <DashboardLayout hideTitle>
        <DashboardSkeleton />
      </DashboardLayout>
    );
  }

  const { student } = data;

  return (
    <DashboardLayout hideTitle>
      <div className="space-y-6">
        <section className="card flex flex-wrap items-end justify-between gap-4 p-6 sm:p-7">
          <div>
            <h2 className="font-display text-3xl font-extrabold tracking-tight text-ink">
              {greeting()}, {firstName(user?.name)}!
            </h2>
            <p className="mt-2 text-sm text-ink/70">
              {student.class_name ? `${student.class_name} ${student.class_stream} · ` : ''}{student.adm_no} · {data.term}
            </p>
          </div>
          <span className="pill">{longDate()}</span>
        </section>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <Link to="/student/units">
            <StatTile icon={ListChecks} label="Registered units" value={data.unitsRegistered} hint={data.unitsRegistered === 0 ? 'Register your units' : data.term} />
          </Link>
          <Link to="/student/results">
            <StatTile icon={TrendingUp} label="Latest average" value={data.latestAverage === null ? '—' : `${data.latestAverage}%`} hint={data.latestAssessment || 'No results yet'} />
          </Link>
          <Link to="/student/supplementary">
            <StatTile icon={FilePenLine} label="Supplementary" value={data.pendingSupplementary} hint={data.failedUnits > 0 ? `${data.failedUnits} below pass mark` : 'Pending applications'} />
          </Link>
          <StatTile icon={Wallet} label="Fee balance" value={kes(data.feeBalance)} hint={data.feeBalance > 0 ? 'Please clear at the bursar' : 'Fully paid'} />
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          <Panel
            icon={Clock}
            title="Today's classes"
            action={<Link to="/student/timetable" className="pill hover:bg-forest/10">Full timetable</Link>}
          >
            {data.today.length === 0 ? (
              <p className="py-8 text-center text-sm text-ink/45">No classes on the timetable for today.</p>
            ) : (
              <ul className="divide-y divide-sage/60">
                {data.today.map((slot, i) => (
                  <li key={i} className="flex items-center gap-3 py-3 first:pt-0 last:pb-0">
                    <span className="w-24 shrink-0 text-xs font-semibold text-forest">{clockTime(slot.start_time)}</span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-semibold text-ink">{slot.unit_name || 'Lesson'}</p>
                      <p className="truncate text-xs text-ink/55">{[slot.lecturer, slot.room].filter(Boolean).join(' · ')}</p>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </Panel>

          <Panel
            icon={Award}
            title="Recent results"
            action={<Link to="/student/results" className="pill hover:bg-forest/10">All results</Link>}
          >
            {data.recentResults.length === 0 ? (
              <p className="py-8 text-center text-sm text-ink/45">No results have been published yet.</p>
            ) : (
              <ul className="divide-y divide-sage/60">
                {data.recentResults.map((r) => (
                  <li key={`${r.exam_id}-${r.subject_id}`} className="flex items-center gap-3 py-3 first:pt-0 last:pb-0">
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-semibold text-ink">{r.unit_name}</p>
                      <p className="truncate text-xs text-ink/55">{r.exam_name} · {r.term} {r.year}</p>
                    </div>
                    <span className={`badge ${r.passed ? 'badge-green' : 'badge-red'}`}>{r.score}%</span>
                  </li>
                ))}
              </ul>
            )}
          </Panel>
        </div>

        <Panel icon={ListChecks} title="Quick links">
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 xl:grid-cols-7">
            {SHORTCUTS.map(({ to, label, icon: Icon, badge }) => (
              <Link
                key={to}
                to={to}
                className="relative flex flex-col items-center gap-2 rounded-2xl border border-sage/70 bg-paper/60 px-2 py-4 text-center transition hover:-translate-y-0.5 hover:bg-forest/10"
              >
                <span className="icon-bubble h-11 w-11"><Icon size={19} /></span>
                <span className="text-[13px] font-medium leading-tight text-ink">{label}</span>
                {badge && data[badge] > 0 && (
                  <span className="absolute right-2 top-2 flex h-5 min-w-5 items-center justify-center rounded-full bg-clay px-1 text-[11px] font-bold text-white">{data[badge]}</span>
                )}
              </Link>
            ))}
          </div>
        </Panel>
      </div>
    </DashboardLayout>
  );
}
