import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { FilePenLine, History } from 'lucide-react';
import DashboardLayout from '../../components/DashboardLayout.jsx';
import Panel from '../../components/dashboard/Panel.jsx';
import StatusBadge from '../../components/StatusBadge.jsx';
import { EmptyState } from '../../components/Skeleton.jsx';
import api from '../../api/axios.js';
import { shortDate } from '../../utils/format.js';

export default function Supplementary() {
  const [params] = useSearchParams();
  const [data, setData] = useState(null);
  const [choice, setChoice] = useState('');
  const [reason, setReason] = useState('');
  const [message, setMessage] = useState(null);
  const [saving, setSaving] = useState(false);

  async function load() {
    try {
      const res = await api.get('/portal/supplementary');
      setData(res.data);
      // Coming from the results page pre-selects the unit
      const wanted = `${params.get('exam')}:${params.get('unit')}`;
      const match = res.data.eligible.find((e) => `${e.exam_id}:${e.subject_id}` === wanted);
      setChoice((current) => current || (match ? wanted : ''));
    } catch (err) {
      setMessage({ type: 'error', text: err.response?.data?.error || 'Could not load your applications.' });
    }
  }
  useEffect(() => { load(); }, []);

  async function submit(e) {
    e.preventDefault();
    setMessage(null);
    if (!choice) {
      setMessage({ type: 'error', text: 'Choose the unit you want to apply for.' });
      return;
    }
    const [exam_id, subject_id] = choice.split(':');
    setSaving(true);
    try {
      await api.post('/portal/supplementary', { exam_id, subject_id, reason });
      setMessage({ type: 'ok', text: 'Application sent. You will see the decision here.' });
      setChoice('');
      setReason('');
      await load();
    } catch (err) {
      setMessage({ type: 'error', text: err.response?.data?.error || 'Could not send your application.' });
    } finally {
      setSaving(false);
    }
  }

  async function withdraw(application) {
    if (!confirm('Withdraw this application?')) return;
    try {
      await api.delete(`/portal/supplementary/${application.id}`);
      await load();
    } catch (err) {
      setMessage({ type: 'error', text: err.response?.data?.error || 'Could not withdraw the application.' });
    }
  }

  return (
    <DashboardLayout title="Supplementary Exams" subtitle="Apply to sit again for a unit you did not pass">
      {message && (
        <p className={`mb-4 rounded-lg px-3 py-2 text-sm ${message.type === 'ok' ? 'bg-forest/10 text-forest' : 'bg-clay/10 text-clay'}`} role="status">
          {message.text}
        </p>
      )}

      {!data ? (
        <p className="text-sm text-ink/45">Loading…</p>
      ) : (
        <div className="grid gap-6 xl:grid-cols-[minmax(0,2fr)_minmax(0,3fr)]">
          <Panel icon={FilePenLine} title="New application" subtitle={`Open to results below the pass mark (${data.passMark})`}>
            {data.eligible.length === 0 ? (
              <EmptyState title="Nothing to apply for" hint="You have no results below the pass mark, or you have already applied for them." />
            ) : (
              <form onSubmit={submit} className="space-y-4">
                <label className="block">
                  <span className="label">Unit</span>
                  <select className="input" value={choice} onChange={(e) => setChoice(e.target.value)}>
                    <option value="">Choose a unit</option>
                    {data.eligible.map((e) => (
                      <option key={`${e.exam_id}:${e.subject_id}`} value={`${e.exam_id}:${e.subject_id}`}>
                        {e.unit_name} · {e.exam_name} ({e.score}%)
                      </option>
                    ))}
                  </select>
                </label>
                <label className="block">
                  <span className="label">Reason</span>
                  <textarea
                    className="input min-h-[110px]"
                    value={reason}
                    onChange={(e) => setReason(e.target.value)}
                    placeholder="Tell us why you should sit a supplementary, for example illness during the CAT."
                  />
                </label>
                <button type="submit" className="btn-primary" disabled={saving}>{saving ? 'Sending…' : 'Send application'}</button>
              </form>
            )}
          </Panel>

          <Panel icon={History} title="My applications">
            {data.applications.length === 0 ? (
              <EmptyState title="No applications yet" />
            ) : (
              <div className="overflow-x-auto">
                <table className="ledger-table">
                  <thead>
                    <tr><th>Unit</th><th>Result</th><th>Sent</th><th>Status</th><th /></tr>
                  </thead>
                  <tbody>
                    {data.applications.map((a) => (
                      <tr key={a.id}>
                        <td className="font-medium">
                          {a.unit_name}
                          <span className="block text-xs font-normal text-ink/50">{a.exam_name} · {a.term} {a.year}</span>
                          {a.staff_comment && <span className="mt-1 block text-xs font-normal italic text-ink/60">“{a.staff_comment}”</span>}
                        </td>
                        <td>{a.score === null ? '—' : `${a.score}%`}</td>
                        <td className="whitespace-nowrap text-ink/60">{shortDate(a.created_at)}</td>
                        <td><StatusBadge status={a.status} /></td>
                        <td className="text-right">
                          {a.status === 'pending' && (
                            <button className="btn-ghost !px-3 !py-1.5 text-xs" onClick={() => withdraw(a)}>Withdraw</button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </Panel>
        </div>
      )}
    </DashboardLayout>
  );
}
