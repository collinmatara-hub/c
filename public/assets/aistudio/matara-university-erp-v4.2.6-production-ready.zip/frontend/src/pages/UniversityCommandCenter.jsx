import React, { useEffect, useState } from 'react';
import api from '../api/axios';
import DashboardLayout from '../components/DashboardLayout.jsx';
import { Building2, GraduationCap, BookOpen, Users, Landmark, FlaskConical, ClipboardCheck, BedDouble, RefreshCw, Layers3 } from 'lucide-react';

const cards=[['campuses','Campuses',Building2],['faculties','Faculties',Building2],['departments','Departments',Building2],['programs','Programs',GraduationCap],['courses','University Units',BookOpen],['students','Students',Users],['staff','Staff & Academic Staff',Users],['active_enrollments','Active Enrolments',ClipboardCheck],['research_projects','Research Projects',FlaskConical],['accommodation','Accommodation Allocations',BedDouble],['outstanding','Outstanding Fees',Landmark],['pending_workflows','Pending Approvals',ClipboardCheck]];
const tabs=[['overview','Overview'],['organization','Faculties & Departments'],['programs','Programs'],['courses','University Units'],['enrollments','Enrolments']];

function Table({columns,rows,empty='No records available.'}){
 return <div className="overflow-x-auto"><table className="ledger-table"><thead><tr>{columns.map(([k,l])=><th key={k}>{l}</th>)}</tr></thead><tbody>{rows?.length?rows.slice(0,100).map((r,i)=><tr key={r.id??i}>{columns.map(([k])=><td key={k} className="max-w-[260px] truncate">{String(r[k]??'—')}</td>)}</tr>):<tr><td colSpan={columns.length} className="py-8 text-center text-muted">{empty}</td></tr>}</tbody></table></div>;
}

export default function UniversityCommandCenter(){
 const [data,setData]=useState(null); const [error,setError]=useState(''); const [loading,setLoading]=useState(true); const [tab,setTab]=useState('overview'); const [records,setRecords]=useState({});
 async function load(){
  setLoading(true);setError('');
  try{
   const overview=await api.get('/university/overview'); setData(overview.data);
   const endpoints={organization:'/university/organization',programs:'/university/programs',courses:'/university/courses',enrollments:'/university/enrollments'};
   const entries=await Promise.all(Object.entries(endpoints).map(async([key,url])=>{try{const r=await api.get(url);return [key,r.data]}catch(e){return [key,{error:e.response?.data?.error||'Restricted or unavailable'}]}}));
   setRecords(Object.fromEntries(entries));
  }catch(e){setError(e.response?.data?.error||'Could not load university dashboard.')}finally{setLoading(false)}
 }
 useEffect(()=>{load()},[]);
 const org=records.organization||{};
 return <DashboardLayout title="University Command Center" subtitle="University-wide operations, academic structure, finance and approvals."><div className="mx-auto w-full max-w-7xl min-w-0 space-y-6">
  <div className="flex flex-wrap items-center justify-between gap-4"><div><p className="text-sm font-semibold text-sage">UNIVERSITY ERP</p><h1 className="text-2xl font-bold text-ink">{data?.institution||'Matara University'} Command Center</h1><p className="text-sm text-muted mt-1">University-wide operations, academic structure, finance and approvals.</p></div><button onClick={load} className="inline-flex items-center gap-2 rounded-xl border border-line bg-white px-4 py-2 text-sm font-semibold hover:bg-paper"><RefreshCw size={16}/> Refresh</button></div>
  {error&&<div className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">{error}</div>}
  <div className="flex flex-wrap gap-2 rounded-2xl border border-line bg-white p-2 shadow-sm">{tabs.map(([id,label])=><button key={id} onClick={()=>setTab(id)} className={`rounded-xl px-4 py-2 text-sm font-semibold ${tab===id?'bg-navy text-white':'text-muted hover:bg-paper'}`}>{label}</button>)}</div>
  {loading?<div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">{Array.from({length:8}).map((_,i)=><div key={i} className="h-28 animate-pulse rounded-2xl bg-line/30"/>)}</div>:
   tab==='overview'?<>
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">{cards.map(([key,label,Icon])=><div key={key} className="rounded-2xl border border-line bg-white p-5 shadow-sm"><div className="flex items-center justify-between"><div><p className="text-xs font-semibold uppercase tracking-wide text-muted">{label}</p><p className="mt-2 text-2xl font-bold text-ink">{key==='outstanding'?`KES ${Number(data?.[key]||0).toLocaleString()}`:Number(data?.[key]||0).toLocaleString()}</p></div><div className="rounded-xl bg-sage/10 p-3 text-sage"><Icon size={21}/></div></div></div>)}</div>
    <div className="grid grid-cols-1 gap-5 xl:grid-cols-2"><section className="rounded-2xl border border-line bg-white p-5"><h2 className="font-bold text-ink">University operating model</h2><div className="mt-4 space-y-3 text-sm text-muted"><p><b className="text-ink">Organization:</b> Campus → Faculty → Department → Program.</p><p><b className="text-ink">Academics:</b> Curriculum → University Unit → Offering → Registration → Assessment → Examination → Result.</p><p><b className="text-ink">Student lifecycle:</b> Admission → Enrolment → Study → Graduation → Alumni.</p><p><b className="text-ink">Enterprise:</b> Finance, HR, Procurement, Research, Accommodation, Library, Facilities and Security.</p></div></section><section className="rounded-2xl border border-line bg-white p-5"><h2 className="font-bold text-ink">Security model</h2><div className="mt-4 grid grid-cols-2 gap-3 text-sm"><div className="rounded-xl bg-paper p-3">Role-based access</div><div className="rounded-xl bg-paper p-3">Department scoping</div><div className="rounded-xl bg-paper p-3">Audit logging</div><div className="rounded-xl bg-paper p-3">Workflow approvals</div></div></section></div>
   </>:
   tab==='organization'?<section className="space-y-5"><div className="rounded-2xl border border-line bg-white p-5"><div className="mb-4 flex items-center gap-2 font-bold"><Layers3 size={18}/> Faculties</div><Table columns={[["name","Faculty"],["code","Code"],["campus_name","Campus"],["description","Description"]]} rows={org.faculties}/></div><div className="rounded-2xl border border-line bg-white p-5"><div className="mb-4 flex items-center gap-2 font-bold"><Building2 size={18}/> Departments</div><Table columns={[["name","Department"],["code","Code"],["faculty_name","Faculty"],["campus_name","Campus"]]} rows={org.departments}/></div></section>:
   tab==='programs'?<section className="rounded-2xl border border-line bg-white p-5"><div className="mb-4 flex items-center gap-2 font-bold"><GraduationCap size={18}/> Academic Programs</div><Table columns={[["name","Program"],["code","Code"],["department_name","Department"],["faculty_name","Faculty"],["duration_years","Duration"]]} rows={records.programs?.error?[]:records.programs}/>{records.programs?.error&&<p className="mt-4 text-sm text-muted">{records.programs.error}</p>}</section>:
   tab==='courses'?<section className="rounded-2xl border border-line bg-white p-5"><div className="mb-4 flex items-center gap-2 font-bold"><BookOpen size={18}/> University Units</div><Table columns={[["code","Unit Code"],["name","Unit Name"],["credit_units","Credit Units"],["department_name","Department"]]} rows={records.courses?.error?[]:records.courses}/>{records.courses?.error&&<p className="mt-4 text-sm text-muted">{records.courses.error}</p>}</section>:
   <section className="rounded-2xl border border-line bg-white p-5"><div className="mb-4 flex items-center gap-2 font-bold"><ClipboardCheck size={18}/> Student Enrolments</div><Table columns={[["adm_no","Admission No."],["student_name","Student"],["program_name","Program"],["status","Status"],["year_of_study","Year"]]} rows={records.enrollments?.error?[]:records.enrollments}/>{records.enrollments?.error&&<p className="mt-4 text-sm text-muted">{records.enrollments.error}</p>}</section>}
 </div></DashboardLayout>;
}
