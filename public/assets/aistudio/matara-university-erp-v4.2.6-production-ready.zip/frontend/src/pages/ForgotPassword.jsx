import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowLeft, CheckCircle2, KeyRound } from 'lucide-react';
import Crest from '../components/Crest.jsx';
import api from '../api/axios.js';

export default function ForgotPassword() {
  const [form,setForm]=useState({email:'',recovery_code:'',new_password:'',confirm_password:''});
  const [busy,setBusy]=useState(false); const [error,setError]=useState(''); const [done,setDone]=useState(false);
  const navigate=useNavigate();
  async function submit(e){
    e.preventDefault(); setBusy(true); setError('');
    try { await api.post('/auth/forgot-password',form); setDone(true); }
    catch(err){setError(err.response?.data?.error||'Could not reset the password.');}
    finally{setBusy(false);}
  }
  return <div className="min-h-screen bg-paper flex items-center justify-center px-5 py-10">
    <div className="w-full max-w-md card p-7">
      <div className="flex items-center gap-3"><Crest size={44}/><div><p className="font-display font-semibold">Matara University</p><p className="text-xs text-ink/45">Account recovery</p></div></div>
      {!done ? <>
        <div className="mt-8"><div className="inline-flex rounded-xl bg-gold/15 p-2 text-gold-dark"><KeyRound size={20}/></div><h1 className="mt-4 font-display text-2xl font-semibold">Reset your password</h1><p className="mt-1 text-sm text-ink/55">Use the recovery code you saved in your profile. No administrator approval is required.</p></div>
        <form onSubmit={submit} className="mt-6 space-y-4">
          <label><span className="label">University email</span><input className="input" type="email" required value={form.email} onChange={e=>setForm({...form,email:e.target.value})} placeholder="you@matara.ac.ke"/></label>
          <label><span className="label">Recovery code</span><input className="input font-mono" required value={form.recovery_code} onChange={e=>setForm({...form,recovery_code:e.target.value})} placeholder="MU-XXXXXXXX-XXXXXXXX" autoComplete="one-time-code"/></label>
          <label><span className="label">New password</span><input className="input" type="password" minLength="8" required value={form.new_password} onChange={e=>setForm({...form,new_password:e.target.value})} autoComplete="new-password"/></label>
          <label><span className="label">Confirm new password</span><input className="input" type="password" minLength="8" required value={form.confirm_password} onChange={e=>setForm({...form,confirm_password:e.target.value})} autoComplete="new-password"/></label>
          {error&&<p className="rounded-xl bg-clay/10 p-3 text-sm text-clay">{error}</p>}
          <button className="btn-primary w-full" disabled={busy}>{busy?'Resetting…':'Reset password'}</button>
        </form>
      </> : <div className="mt-8 text-center"><CheckCircle2 className="mx-auto text-forest" size={44}/><h1 className="mt-4 font-display text-2xl font-semibold">Password reset</h1><p className="mt-2 text-sm text-ink/55">Your password was changed successfully. Sign in using your new password.</p><button className="btn-primary mt-6 w-full" onClick={()=>navigate('/login')}>Return to sign in</button></div>}
      <Link to="/login" className="mt-6 flex items-center justify-center gap-2 text-sm text-ink/55 hover:text-ink"><ArrowLeft size={15}/> Back to sign in</Link>
    </div>
  </div>;
}
