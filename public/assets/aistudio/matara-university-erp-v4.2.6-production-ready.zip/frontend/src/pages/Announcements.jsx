import { useEffect, useState } from 'react';
import { Megaphone, Plus, X, Trash2 } from 'lucide-react';
import DashboardLayout from '../components/DashboardLayout.jsx';
import api from '../api/axios.js';
import { useAuth } from '../context/AuthContext.jsx';

export default function Announcements() {
  const [list, setList] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ title: '', body: '', audience: 'all' });
  const { user } = useAuth();
  const canPost = user?.role === 'admin' || user?.role === 'teacher';

  async function load() {
    const res = await api.get('/announcements');
    setList(res.data);
  }
  useEffect(() => { load(); }, []);

  async function handleSubmit(e) {
    e.preventDefault();
    setSaving(true);
    try {
      await api.post('/announcements', form);
      setShowForm(false);
      setForm({ title: '', body: '', audience: 'all' });
      load();
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(id) {
    if (!confirm('Delete this announcement?')) return;
    await api.delete(`/announcements/${id}`);
    load();
  }

  return (
    <DashboardLayout title="Announcements" subtitle="Notices from the university office">
      {canPost && (
        <div className="mb-5 flex justify-end">
          <button className="btn-primary" onClick={() => setShowForm(true)}>
            <Plus size={16} /> New announcement
          </button>
        </div>
      )}

      <div className="space-y-4">
        {list.map((a) => (
          <div key={a.id} className="card p-5">
            <div className="flex items-start justify-between gap-4">
              <div className="flex items-start gap-3">
                <div className="mt-0.5 rounded-lg bg-gold/15 p-2 text-gold-dark">
                  <Megaphone size={16} />
                </div>
                <div>
                  <p className="font-display text-base font-semibold text-ink">{a.title}</p>
                  <p className="mt-1 text-sm leading-relaxed text-ink/65">{a.body}</p>
                  <p className="mt-2 text-xs text-ink/40">
                    {a.author} · {new Date(a.created_at).toLocaleDateString()} · <span className="capitalize">{a.audience}</span>
                  </p>
                </div>
              </div>
              {canPost && (
                <button onClick={() => handleDelete(a.id)} className="rounded-md p-1.5 text-ink/40 hover:bg-clay/10 hover:text-clay">
                  <Trash2 size={15} />
                </button>
              )}
            </div>
          </div>
        ))}
        {list.length === 0 && <p className="text-sm text-ink/40">No announcements yet.</p>}
      </div>

      {showForm && (
        <div className="fixed inset-0 z-30 flex items-center justify-center bg-navy/50 px-4">
          <div className="card w-full max-w-lg p-6">
            <div className="mb-5 flex items-center justify-between">
              <h3 className="font-display text-lg font-semibold">New announcement</h3>
              <button onClick={() => setShowForm(false)} className="text-ink/40 hover:text-ink"><X size={20} /></button>
            </div>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="label">Title</label>
                <input required className="input" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
              </div>
              <div>
                <label className="label">Message</label>
                <textarea required rows={4} className="input" value={form.body} onChange={(e) => setForm({ ...form, body: e.target.value })} />
              </div>
              <div>
                <label className="label">Audience</label>
                <select className="input" value={form.audience} onChange={(e) => setForm({ ...form, audience: e.target.value })}>
                  <option value="all">Everyone</option>
                  <option value="teacher">Teachers only</option>
                  <option value="student">Students only</option>
                </select>
              </div>
              <div className="flex justify-end gap-3">
                <button type="button" className="btn-ghost" onClick={() => setShowForm(false)}>Cancel</button>
                <button type="submit" disabled={saving} className="btn-primary">{saving ? 'Posting…' : 'Post announcement'}</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </DashboardLayout>
  );
}
