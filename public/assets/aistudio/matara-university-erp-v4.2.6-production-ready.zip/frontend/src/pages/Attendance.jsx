import { useEffect, useState } from 'react';
import { Check, Clock, X as XIcon, Save } from 'lucide-react';
import DashboardLayout from '../components/DashboardLayout.jsx';
import api from '../api/axios.js';

const STATUS_OPTS = [
  { key: 'present', label: 'Present', icon: Check, cls: 'badge-green' },
  { key: 'late', label: 'Late', icon: Clock, cls: 'badge-gold' },
  { key: 'absent', label: 'Absent', icon: XIcon, cls: 'badge-red' },
];

export default function Attendance() {
  const [date, setDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [classes, setClasses] = useState([]);
  const [classId, setClassId] = useState('');
  const [records, setRecords] = useState([]);
  const [dirty, setDirty] = useState({});
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    api.get('/classes').then((res) => setClasses(res.data));
  }, []);

  async function loadAttendance() {
    const params = { date };
    if (classId) params.class_id = classId;
    const res = await api.get('/attendance', { params });
    setRecords(res.data.records);
    setDirty({});
    setSaved(false);
  }

  useEffect(() => { loadAttendance(); }, [date, classId]);

  function setStatus(studentId, status) {
    setDirty((d) => ({ ...d, [studentId]: status }));
    setSaved(false);
  }

  async function handleSave() {
    const changed = Object.entries(dirty);
    if (changed.length === 0) return;
    setSaving(true);
    try {
      await api.post('/attendance/bulk', {
        date,
        records: changed.map(([student_id, status]) => ({ student_id: Number(student_id), status })),
      });
      setSaved(true);
      loadAttendance();
    } finally {
      setSaving(false);
    }
  }

  const summary = records.reduce(
    (acc, r) => {
      const s = dirty[r.student_id] ?? r.status;
      if (s) acc[s] = (acc[s] || 0) + 1;
      return acc;
    },
    { present: 0, late: 0, absent: 0 }
  );

  return (
    <DashboardLayout title="Attendance Register" subtitle="Mark today's register, class by class">
      <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-wrap gap-3">
          <input type="date" className="input w-auto" value={date} onChange={(e) => setDate(e.target.value)} />
          <select className="input w-auto" value={classId} onChange={(e) => setClassId(e.target.value)}>
            <option value="">All classes</option>
            {classes.map((c) => <option key={c.id} value={c.id}>{c.name} {c.stream}</option>)}
          </select>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex gap-2 text-xs">
            <span className="badge badge-green">{summary.present} present</span>
            <span className="badge badge-gold">{summary.late} late</span>
            <span className="badge badge-red">{summary.absent} absent</span>
          </div>
          <button className="btn-primary" onClick={handleSave} disabled={saving || Object.keys(dirty).length === 0}>
            <Save size={16} /> {saving ? 'Saving…' : saved ? 'Saved' : 'Save changes'}
          </button>
        </div>
      </div>

      <div className="card overflow-x-auto">
        <table className="ledger-table">
          <thead>
            <tr>
              <th>Adm. No.</th>
              <th>Name</th>
              <th>Class</th>
              <th>Mark attendance</th>
            </tr>
          </thead>
          <tbody>
            {records.map((r) => {
              const current = dirty[r.student_id] ?? r.status;
              return (
                <tr key={r.student_id}>
                  <td className="font-mono text-xs text-ink/70">{r.adm_no}</td>
                  <td className="font-medium">{r.name}</td>
                  <td className="text-ink/60">{r.class_name} {r.stream}</td>
                  <td>
                    <div className="flex gap-2">
                      {STATUS_OPTS.map(({ key, label, icon: Icon, cls }) => (
                        <button
                          key={key}
                          onClick={() => setStatus(r.student_id, key)}
                          className={`badge border transition ${current === key ? cls + ' border-transparent' : 'border-sage text-ink/40 hover:border-ink/30'}`}
                        >
                          <Icon size={12} /> {label}
                        </button>
                      ))}
                    </div>
                  </td>
                </tr>
              );
            })}
            {records.length === 0 && (
              <tr><td colSpan={4} className="py-8 text-center text-ink/40">No students in this class.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </DashboardLayout>
  );
}
