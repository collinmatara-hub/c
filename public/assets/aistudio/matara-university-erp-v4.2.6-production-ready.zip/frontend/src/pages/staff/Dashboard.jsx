import { useEffect, useState } from 'react';
import { BadgeCheck, Building2, Phone, Megaphone } from 'lucide-react';
import DashboardLayout from '../../components/DashboardLayout.jsx';
import StatCard from '../../components/StatCard.jsx';
import api from '../../api/axios.js';
import { useAuth } from '../../context/AuthContext.jsx';
import { roleLabel } from '../../config/roles.js';

// Home page for staff, accounts, librarian, nurse and ICT accounts
export default function StaffDashboard() {
  const { user } = useAuth();
  const [profile, setProfile] = useState(null);
  const [announcements, setAnnouncements] = useState([]);

  useEffect(() => {
    api.get('/auth/profile').then((res) => setProfile(res.data.profile));
    api.get('/announcements').then((res) => setAnnouncements(res.data.slice(0, 5)));
  }, []);

  return (
    <DashboardLayout
      title={`Welcome, ${user?.name?.split(' ')[0]}`}
      subtitle={profile?.position || roleLabel(user?.role)}
    >
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <StatCard label="Employee number" value={profile?.employee_no || '—'} icon={BadgeCheck} tone="green" />
        <StatCard label="Department" value={profile?.department_name || '—'} icon={Building2} tone="gold" />
        <StatCard label="Phone" value={profile?.phone || '—'} icon={Phone} tone="clay" />
      </div>

      <div className="card mt-6 p-5">
        <h3 className="mb-4 font-display text-lg font-semibold text-ink">Latest announcements</h3>
        {announcements.length === 0 ? (
          <p className="text-sm text-ink/40">No announcements yet.</p>
        ) : (
          <div className="space-y-4">
            {announcements.map((a) => (
              <div key={a.id} className="flex items-start gap-3">
                <div className="mt-0.5 rounded-lg bg-gold/15 p-2 text-gold-dark">
                  <Megaphone size={16} />
                </div>
                <div>
                  <p className="font-semibold text-ink">{a.title}</p>
                  <p className="mt-1 text-sm leading-relaxed text-ink/65">{a.body}</p>
                  <p className="mt-1 text-xs text-ink/40">
                    {a.author} · {new Date(a.created_at).toLocaleDateString()}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
