import { useEffect, useMemo, useState } from 'react';
import { Banknote, BookOpen, HeartPulse, RefreshCw, Search, RotateCcw, Plus, ShieldCheck } from 'lucide-react';
import DashboardLayout from '../../components/DashboardLayout.jsx';
import api from '../../api/axios.js';
import { useAuth } from '../../context/AuthContext.jsx';

const roleConfig = {
  accounts: { title: 'Finance Desk', subtitle: 'Collect payments, review balances and monitor the school ledger' },
  librarian: { title: 'Library Desk', subtitle: 'Manage the catalogue, lending and returns' },
  nurse: { title: 'Medical Desk', subtitle: 'Record student clinic visits and care notes' },
  ict: { title: 'System Operations', subtitle: 'Monitor access, audit activity and system configuration' },
};

export default function StaffOperations({ type }) {
  const { user } = useAuth();
  const cfg = roleConfig[type] || roleConfig[user?.role];
  const [rows,setRows]=useState([]); const [books,setBooks]=useState([]); const [students,setStudents]=useState([]);
  const [q,setQ]=useState(''); const [busy,setBusy]=useState(false); const [form,setForm]=useState({}); const [error,setError]=useState('');
  const [audit,setAudit]=useState([]); const [settings,setSettings]=useState([]);

  async function load(){
    setBusy(true); setError('');
    try {
      if(type==='accounts'){
        const r=await api.get('/fees'); setRows(r.data);
      } else if(type==='librarian'){
        const [b,l,s]=await Promise.all([api.get('/modules/books'),api.get('/modules/library/borrowings'),api.get('/modules/lookups')]);
        setBooks(b.data); setRows(l.data); setStudents(s.data.students);
      } else if(type==='nurse'){
        const [m,l]=await Promise.all([api.get('/modules/medical'),api.get('/modules/lookups')]);
        setRows(m.data); setStudents(l.data.students);
      } else if(type==='ict'){
        const [a,s]=await Promise.all([api.get('/modules/audit'),api.get('/modules/settings')]); setAudit(a.data); setSettings(s.data);
      }
    } catch(e){ setError(e.response?.data?.error || 'Could not load this desk.'); }
    finally{setBusy(false)}
  }
  useEffect(()=>{load()},[type]);

  const filtered=useMemo(()=>rows.filter(r=>Object.values(r).some(v=>String(v??'').toLowerCase().includes(q.toLowerCase()))),[rows,q]);

  async function pay(id){
    const amount=prompt('Payment amount (KES):'); if(!amount||Number(amount)<=0)return;
    try { const r=await api.put(`/fees/${id}/pay`,{amount:Number(amount),method:'Cash'}); alert(`Receipt ${r.data.receipt.receipt_no} created.`); load(); }
    catch(e){alert(e.response?.data?.error||'Could not record payment.')}
  }
  async function borrow(){
    if(!form.book_id||!form.student_id||!form.due_date){setError('Choose a book, student and due date.');return}
    try{await api.post('/modules/library/borrow',form);setForm({});load()}catch(e){setError(e.response?.data?.error||'Could not issue book.')}
  }
  async function returnBook(id){
    try{await api.post(`/modules/library/return/${id}`);load()}catch(e){setError(e.response?.data?.error||'Could not return book.')}
  }
  async function addVisit(e){
    e.preventDefault();
    try{await api.post('/modules/medical',form);setForm({});load()}catch(e){setError(e.response?.data?.error||'Could not save visit.')}
  }

  return <DashboardLayout title={cfg.title} subtitle={cfg.subtitle}>
    {error && <div className="mb-4 rounded-xl bg-clay/10 p-3 text-sm text-clay">{error}</div>}
    <div className="mb-5 flex gap-3">
      <div className="relative flex-1"><Search className="absolute left-3 top-2.5 text-ink/40" size={17}/><input className="input pl-9" placeholder="Search records…" value={q} onChange={e=>setQ(e.target.value)}/></div>
      <button className="btn-ghost" onClick={load}><RefreshCw size={16}/> Refresh</button>
    </div>

    {type==='accounts' && <div className="card overflow-x-auto"><table className="ledger-table"><thead><tr><th>Student</th><th>Term</th><th>Due</th><th>Paid</th><th>Balance</th><th>Action</th></tr></thead><tbody>{filtered.map(r=><tr key={r.id}><td>{r.student_name}<div className="text-xs text-ink/45">{r.adm_no}</div></td><td>{r.term}</td><td>KES {Number(r.amount_due).toLocaleString()}</td><td>KES {Number(r.amount_paid).toLocaleString()}</td><td className="font-semibold">KES {(Number(r.amount_due)-Number(r.amount_paid)).toLocaleString()}</td><td><button className="btn-primary !py-1.5" onClick={()=>pay(r.id)}><Banknote size={14}/> Record payment</button></td></tr>)}</tbody></table></div>}

    {type==='librarian' && <div className="space-y-6">
      <div className="card p-5"><h2 className="font-display text-lg font-semibold">Issue a book</h2><div className="mt-4 grid gap-3 md:grid-cols-3">
        <select className="input" value={form.book_id||''} onChange={e=>setForm({...form,book_id:e.target.value})}><option value="">Choose book</option>{books.filter(b=>b.available>0).map(b=><option key={b.id} value={b.id}>{b.title} ({b.available} available)</option>)}</select>
        <select className="input" value={form.student_id||''} onChange={e=>setForm({...form,student_id:e.target.value})}><option value="">Choose student</option>{students.map(s=><option key={s.id} value={s.id}>{s.name} ({s.adm_no})</option>)}</select>
        <div className="flex gap-2"><input className="input" type="date" value={form.due_date||''} onChange={e=>setForm({...form,due_date:e.target.value})}/><button className="btn-primary" onClick={borrow}><Plus size={15}/> Issue</button></div>
      </div></div>
      <div className="card overflow-x-auto"><table className="ledger-table"><thead><tr><th>Book</th><th>Student</th><th>Borrowed</th><th>Due</th><th>Status</th><th></th></tr></thead><tbody>{filtered.map(r=><tr key={r.id}><td>{r.title}</td><td>{r.student_name}</td><td>{r.borrowed_at}</td><td>{r.due_date||'—'}</td><td>{r.returned_at?'Returned':'On loan'}</td><td>{!r.returned_at&&<button className="btn-ghost !p-2" onClick={()=>returnBook(r.id)} title="Return book"><RotateCcw size={15}/></button>}</td></tr>)}</tbody></table></div>
    </div>}

    {type==='nurse' && <div className="space-y-6">
      <form onSubmit={addVisit} className="card p-5"><div className="flex items-center gap-2"><HeartPulse size={19}/><h2 className="font-display text-lg font-semibold">Record clinic visit</h2></div><div className="mt-4 grid gap-3 md:grid-cols-2">
        <select className="input" value={form.student_id||''} onChange={e=>setForm({...form,student_id:e.target.value})} required><option value="">Choose student</option>{students.map(s=><option key={s.id} value={s.id}>{s.name} ({s.adm_no})</option>)}</select>
        <input className="input" type="date" value={form.visit_date||''} onChange={e=>setForm({...form,visit_date:e.target.value})}/>
        <input className="input" placeholder="Complaint" value={form.complaint||''} onChange={e=>setForm({...form,complaint:e.target.value})}/>
        <input className="input" placeholder="Treatment" value={form.treatment||''} onChange={e=>setForm({...form,treatment:e.target.value})}/>
        <input className="input" placeholder="Medical officer" value={form.officer||user?.name||''} onChange={e=>setForm({...form,officer:e.target.value})}/>
        <input className="input" placeholder="Notes" value={form.notes||''} onChange={e=>setForm({...form,notes:e.target.value})}/>
      </div><button className="btn-primary mt-4"><Plus size={15}/> Save visit</button></form>
      <div className="card overflow-x-auto"><table className="ledger-table"><thead><tr><th>Date</th><th>Student</th><th>Complaint</th><th>Treatment</th><th>Officer</th></tr></thead><tbody>{filtered.map(r=><tr key={r.id}><td>{r.visit_date}</td><td>{r.student_name||r.student_id}</td><td>{r.complaint||'—'}</td><td>{r.treatment||'—'}</td><td>{r.officer||'—'}</td></tr>)}</tbody></table></div>
    </div>}

    {type==='ict' && <div className="grid gap-6 lg:grid-cols-2">
      <div className="card overflow-x-auto"><div className="p-5"><h2 className="font-display text-lg font-semibold flex items-center gap-2"><ShieldCheck size={18}/> Recent audit activity</h2></div><table className="ledger-table"><thead><tr><th>When</th><th>User</th><th>Action</th><th>Details</th></tr></thead><tbody>{audit.map(r=><tr key={r.id}><td>{r.created_at}</td><td>{r.user_name||'System'}</td><td>{r.action}</td><td>{r.details||'—'}</td></tr>)}</tbody></table></div>
      <div className="card p-5"><h2 className="font-display text-lg font-semibold">System settings</h2><div className="mt-4 space-y-3">{settings.map(r=><div key={r.key} className="rounded-xl bg-paper p-3"><div className="text-xs text-ink/45">{r.key}</div><div className="font-semibold">{r.value}</div></div>)}</div></div>
    </div>}
  </DashboardLayout>;
}
