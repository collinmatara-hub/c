import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowRight, ShieldCheck, Users2, LineChart } from 'lucide-react';
import Crest from '../components/Crest.jsx';
import { ThemeIconButton } from '../components/ThemeToggle.jsx';
import { useAuth } from '../context/AuthContext.jsx';
import { homeFor } from '../config/roles.js';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState('');
  const [twoFactorCode, setTwoFactorCode] = useState('');
  const [needs2fa, setNeeds2fa] = useState(false);
  const { login, verifyTwoFactor, twoFactorChallenge } = useAuth();
  const navigate = useNavigate();

  async function handleSubmit(e) {
    e.preventDefault();
    setFormError('');
    setSubmitting(true);
    try {
      const user = await login(email, password);
      if (user?.requires2fa || twoFactorChallenge) { setNeeds2fa(true); return; }
      navigate(homeFor(user.role));
    } catch (err) {
      setFormError(err.message);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="relative min-h-screen bg-paper md:grid md:grid-cols-2">
      <div className="absolute right-4 top-4 z-10"><ThemeIconButton /></div>
      {/* Left: brand / ledger panel */}
      <div className="relative hidden min-h-screen flex-col justify-between overflow-hidden bg-navy px-10 py-10 text-white lg:px-14 lg:py-12 md:flex">
        <div
          className="pointer-events-none absolute inset-0 opacity-[0.07]"
          style={{ backgroundImage: 'radial-gradient(circle at 1px 1px, #C99A3B 1px, transparent 0)', backgroundSize: '22px 22px' }}
        />
        <div className="relative flex items-center gap-3">
          <Crest size={48} />
          <div>
            <p className="font-display text-lg font-semibold leading-tight">Matara University</p>
            <p className="text-xs font-medium tracking-widest text-gold-light/80">KNOWLEDGE • INTEGRITY • EXCELLENCE</p>
          </div>
        </div>

        <div className="relative max-w-lg">
          <p className="font-display text-[15px] italic text-gold-light/90">
            "Elimu ni ufunguo wa maisha" — Education is the key to life.
          </p>
          <h2 className="mt-6 font-display text-4xl font-semibold leading-[1.08] text-white lg:text-5xl">
            One trusted platform for every student, lecturer and university operation.
          </h2>
          <p className="mt-4 text-sm leading-relaxed text-white/60">
            Matara University ERP brings admissions, registration, units, results, finance and student services together in one secure platform.
          </p>

          <div className="mt-10 grid gap-3 border-t border-white/10 pt-8 sm:grid-cols-3 md:block md:space-y-4">
            <Feature icon={Users2} text="Admissions, programmes and staff records in one university register" />
            <Feature icon={ShieldCheck} text="Attendance and academic activity with university-wide summaries" />
            <Feature icon={LineChart} text="Fee ledgers and academic results, tracked semester by semester" />
          </div>
        </div>

        <p className="relative text-xs text-white/40">
          © {new Date().getFullYear()} Matara University. Secure university records and controlled access.
        </p>
      </div>

      {/* Right: login card */}
      <div className="flex flex-col justify-center px-5 py-10 sm:px-10 lg:px-16 xl:px-20">
        <div className="mx-auto w-full max-w-md rounded-3xl border border-sage/70 bg-surface p-6 shadow-[0_25px_70px_-35px_rgba(19,36,54,.35)] sm:p-8">
          <div className="mb-8 flex items-center gap-3 md:hidden">
            <Crest size={40} />
            <div>
              <p className="font-display text-base font-semibold">Matara University</p>
              <p className="text-[11px] font-medium tracking-widest text-gold-dark">KNOWLEDGE • INTEGRITY • EXCELLENCE</p>
            </div>
          </div>

          <p className="text-[11px] font-bold uppercase tracking-[.14em] text-forest">
            Staff & Student Portal
          </p>
          <h1 className="mt-2 font-display text-3xl font-semibold tracking-tight text-ink sm:text-4xl">Welcome back</h1>
          <p className="mt-2 text-sm text-ink/55">
            Sign in with the email and password issued to you by the university office.
          </p>

          {!needs2fa ? <form onSubmit={handleSubmit} className="mt-7 space-y-4">
            <div><label className="label" htmlFor="email">Email address</label><input id="email" type="email" required className="input" placeholder="you@matara.ac.ke" value={email} onChange={(e)=>setEmail(e.target.value)}/></div>
            <div><label className="label" htmlFor="password">Password</label><input id="password" type="password" required className="input" placeholder="••••••••" value={password} onChange={(e)=>setPassword(e.target.value)}/></div>
            {formError&&<p className="rounded-lg bg-clay/10 px-3.5 py-2.5 text-sm text-clay">{formError}</p>}
            <button type="submit" disabled={submitting} className="btn-primary w-full">{submitting?'Signing in…':'Sign in'}<ArrowRight size={16}/></button>
            <div className="text-center"><Link to="/forgot-password" className="text-sm font-semibold text-forest hover:underline">Forgot your password?</Link></div>
          </form> : <form onSubmit={handleTwoFactor} className="mt-7 space-y-4">
            <div><label className="label" htmlFor="twoFactorCode">Authenticator code</label><input id="twoFactorCode" inputMode="numeric" autoFocus required className="input text-center text-2xl tracking-[.35em]" placeholder="123456" value={twoFactorCode} onChange={(e)=>setTwoFactorCode(e.target.value)}/><p className="mt-2 text-xs text-muted">Enter the 6-digit code from your authenticator app. A backup code can also be used.</p></div>
            {formError&&<p className="rounded-lg bg-clay/10 px-3.5 py-2.5 text-sm text-clay">{formError}</p>}
            <button type="submit" disabled={submitting} className="btn-primary w-full">{submitting?'Verifying…':'Verify & sign in'}<ShieldCheck size={16}/></button>
          </form>}
        </div>
      </div>
    </div>
  );
}

function Feature({ icon: Icon, text }) {
  return (
    <div className="flex items-start gap-3 rounded-xl border border-white/5 bg-white/[0.035] p-3 md:border-0 md:bg-transparent md:p-0">
      <div className="mt-0.5 rounded-md bg-white/10 p-1.5 text-gold-light">
        <Icon size={15} />
      </div>
      <p className="text-sm text-white/75">{text}</p>
    </div>
  );
}
