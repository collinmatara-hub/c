import { useEffect, useState } from 'react';
import { Plus, Save } from 'lucide-react';
import DashboardLayout from '../../components/DashboardLayout.jsx';
import { EmptyState } from '../../components/Skeleton.jsx';
import api from '../../api/axios.js';

// Enter CAT and exam marks for a unit. Used by lecturers and admins.
export default function Marks() {
  const [setup, setSetup] = useState(null);
  const [examId, setExamId] = useState('');
  const [unitId, setUnitId] = useState('');
  const [roster, setRoster] = useState(null);
  const [scores, setScores] = useState({});
  const [creating, setCreating] = useState(false);
  const [newExam, setNewExam] = useState({ name: '', kind: 'CAT' });
  const [message, setMessage] = useState(null);
  const [saving, setSaving] = useState(false);

  async function loadSetup() {
    const res = await api.get('/assessments/setup');
    setSetup(res.data);
    return res.data;
  }
  useEffect(() => {
    loadSetup().catch((err) => setMessage({ type: 'error', text: err.response?.data?.error || 'Could not load the page.' }));
  }, []);

  async function loadRoster(exam, unit) {
    setRoster(null);
    if (!exam || !unit) return;
    try {
      const res = await api.get('/assessments/roster', { params: { exam_id: exam, subject_id: unit } });
      setRoster(res.data);
      setScores(Object.fromEntries(res.data.students.map((s) => [s.student_id, s.score === null ? '' : String(s.score)])));
    } catch (err) {
      setMessage({ type: 'error', text: err.response?.data?.error || 'Could not load the students.' });
    }
  }

  function choose(exam, unit) {
    setExamId(exam);
    setUnitId(unit);
    setMessage(null);
    loadRoster(exam, unit);
  }

  async function createExam(e) {
    e.preventDefault();
    setMessage(null);
    try {
      const res = await api.post('/assessments/exams', newExam);
      await loadSetup();
      setCreating(false);
      setNewExam({ name: '', kind: 'CAT' });
      choose(String(res.data.id), unitId);
    } catch (err) {
      setMessage({ type: 'error', text: err.response?.data?.error || 'Could not create the assessment.' });
    }
  }

  async function save() {
    setSaving(true);
    setMessage(null);
    try {
      const marks = roster.students.map((s) => ({ student_id: s.student_id, score: scores[s.student_id] ?? '' }));
      const res = await api.put('/assessments/marks', { exam_id: examId, subject_id: unitId, marks });
      setMessage({ type: 'ok', text: `Saved ${res.data.saved} mark${res.data.saved === 1 ? '' : 's'}${res.data.cleared ? `, cleared ${res.data.cleared}` : ''}.` });
      loadRoster(examId, unitId);
    } catch (err) {
      setMessage({ type: 'error', text: err.response?.data?.error || 'Could not save the marks.' });
    } finally {
      setSaving(false);
    }
  }

  const filled = roster ? roster.students.filter((s) => (scores[s.student_id] ?? '') !== '').length : 0;

  return (
    <DashboardLayout title="CAT Marks" subtitle="Enter marks for a CAT or exam, one unit at a time">
      {message && (
        <p className={`mb-4 rounded-lg px-3 py-2 text-sm ${message.type === 'ok' ? 'bg-forest/10 text-forest' : 'bg-clay/10 text-clay'}`} role="status">
          {message.text}
        </p>
      )}

      {!setup ? (
        <p className="text-sm text-ink/45">Loading…</p>
      ) : (
        <>
          <div className="card mb-6 grid gap-4 p-5 md:grid-cols-[1fr_1fr_auto] md:items-end">
            <label className="block">
              <span className="label">Assessment</span>
              <select className="input" value={examId} onChange={(e) => choose(e.target.value, unitId)}>
                <option value="">Choose an assessment</option>
                {setup.exams.map((x) => (
                  <option key={x.id} value={x.id}>{x.name} · {x.term} {x.year} ({x.kind})</option>
                ))}
              </select>
            </label>
            <label className="block">
              <span className="label">Unit</span>
              <select className="input" value={unitId} onChange={(e) => choose(examId, e.target.value)}>
                <option value="">Choose a unit</option>
                {setup.units.map((u) => (
                  <option key={u.id} value={u.id}>{u.name} ({u.code})</option>
                ))}
              </select>
            </label>
            <button className="btn-ghost" onClick={() => setCreating(!creating)}><Plus size={16} /> New assessment</button>

            {creating && (
              <form onSubmit={createExam} className="grid gap-3 border-t border-sage/60 pt-4 md:col-span-3 md:grid-cols-[1fr_180px_auto] md:items-end">
                <label className="block">
                  <span className="label">Name</span>
                  <input className="input" value={newExam.name} onChange={(e) => setNewExam({ ...newExam, name: e.target.value })} placeholder="CAT 1" required />
                </label>
                <label className="block">
                  <span className="label">Type</span>
                  <select className="input" value={newExam.kind} onChange={(e) => setNewExam({ ...newExam, kind: e.target.value })}>
                    <option value="CAT">CAT</option>
                    <option value="Exam">Exam</option>
                  </select>
                </label>
                <button type="submit" className="btn-primary">Create for {setup.term}</button>
              </form>
            )}
          </div>

          {!examId || !unitId ? (
            <EmptyState title="Choose an assessment and a unit" hint="The students registered for that unit will appear here." />
          ) : !roster ? (
            <p className="text-sm text-ink/45">Loading…</p>
          ) : (
            <div className="card overflow-x-auto p-5">
              <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h3 className="text-base font-bold text-ink">{roster.exam.name} · {roster.unit.name}</h3>
                  <p className="text-xs text-ink/50">{filled} of {roster.students.length} marks entered. Leave a box empty to skip a student.</p>
                </div>
                <button className="btn-primary" onClick={save} disabled={saving}><Save size={15} /> {saving ? 'Saving…' : 'Save marks'}</button>
              </div>
              {roster.fallback && (
                <p className="mb-4 rounded-lg bg-gold/15 px-3 py-2 text-sm text-gold-dark">
                  Nobody has registered this unit for {roster.exam.term} {roster.exam.year}, so all active students are listed.
                </p>
              )}
              <table className="ledger-table">
                <thead>
                  <tr><th>Student</th><th>Adm. no.</th><th>Class</th><th>Mark (0 to 100)</th></tr>
                </thead>
                <tbody>
                  {roster.students.map((s) => (
                    <tr key={s.student_id}>
                      <td className="font-medium">{s.name}</td>
                      <td className="font-mono text-xs text-ink/60">{s.adm_no}</td>
                      <td className="text-ink/60">{s.class_name || '—'}</td>
                      <td>
                        <input
                          type="number" min="0" max="100" step="any"
                          className="input !w-28"
                          aria-label={`Mark for ${s.name}`}
                          value={scores[s.student_id] ?? ''}
                          onChange={(e) => setScores({ ...scores, [s.student_id]: e.target.value })}
                        />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </>
      )}
    </DashboardLayout>
  );
}
