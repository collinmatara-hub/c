import { useEffect, useMemo, useState } from 'react';
import { FilePenLine } from 'lucide-react';
import DashboardLayout from '../../components/DashboardLayout.jsx';
import StatusBadge from '../../components/StatusBadge.jsx';
import { EmptyState } from '../../components/Skeleton.jsx';
import api from '../../api/axios.js';
import { shortDate } from '../../utils/format.js';

// Staff decide supplementary applications here
export default function SupplementaryReview() {
  const [rows, setRows] = useState(null);
  const [tab, setTab] = useState('pending');
  const [comments, setComments] = useState({});
  const [message, setMessage] = useState(null);

  async function load() {
    try {
      const res = await api.get('/assessments/supplementary');
      setRows(res.data);
    } catch (err) {
      setMessage({ type: 'error', text: err.response?.data?.error || 'Could not load the applications.' });
    }
  }
  useEffect(() => { load(); }, []);

  async function decide(row, status) {
    setMessage(null);
    try {
      await api.put(`/assessments/supplementary/${row.id}`, { status, comment: comments[row.id] || '' });
      setMessage({ type: 'ok', text: `${row.student_name}'s application was ${status}.` });
      await load();
    } catch (err) {
      setMessage({ type: 'error', text: err.response?.data?.error || 'Could not save your decision.' });
    }
  }

  const shown = useMemo(() => (rows || []).filter((r) => tab === 'all' || r.status === 'pending'), [rows, tab]);
  const pendingCount = (rows || []).filter((r) => r.status === 'pending').length;

  return (
    <DashboardLayout title="Supplementary Applications" subtitle="Approve or reject students' requests to sit again">
      {message && (
        <p className={`mb-4 rounded-lg px-3 py-2 text-sm ${message.type === 'ok' ? 'bg-forest/10 text-forest' : 'bg-clay/10 text-clay'}`} role="status">
          {message.text}
        </p>
      )}

      <div className="mb-5 flex gap-2" role="tablist">
        <button role="tab" aria-selected={tab === 'pending'} onClick={() => setTab('pending')}
          className={`rounded-full border px-4 py-1.5 text-sm font-semibold ${tab === 'pending' ? 'border-forest bg-forest text-on-forest' : 'border-sage bg-surface text-ink/70'}`}>
          Pending ({pendingCount})
        </button>
        <button role="tab" aria-selected={tab === 'all'} onClick={() => setTab('all')}
          className={`rounded-full border px-4 py-1.5 text-sm font-semibold ${tab === 'all' ? 'border-forest bg-forest text-on-forest' : 'border-sage bg-surface text-ink/70'}`}>
          All applications
        </button>
      </div>

      {!rows ? (
        <p className="text-sm text-ink/45">Loading…</p>
      ) : shown.length === 0 ? (
        <EmptyState icon={FilePenLine} title={tab === 'pending' ? 'No applications waiting' : 'No applications yet'} />
      ) : (
        <div className="card overflow-x-auto p-2">
          <table className="ledger-table">
            <thead>
              <tr><th>Student</th><th>Unit</th><th>Score</th><th>Reason</th><th>Status</th><th>Decision</th></tr>
            </thead>
            <tbody>
              {shown.map((r) => (
                <tr key={r.id}>
                  <td className="font-medium">
                    {r.student_name}
                    <span className="block text-xs font-normal text-ink/50">{r.adm_no}{r.class_name ? ` · ${r.class_name}` : ''}</span>
                  </td>
                  <td>
                    {r.unit_name}
                    <span className="block text-xs text-ink/50">{r.exam_name} · {r.term} {r.year}</span>
                  </td>
                  <td className="font-semibold">{r.score === null ? '—' : `${r.score}%`}</td>
                  <td className="max-w-xs text-ink/70">
                    {r.reason}
                    <span className="block text-xs text-ink/40">{shortDate(r.created_at)}</span>
                  </td>
                  <td><StatusBadge status={r.status} /></td>
                  <td>
                    {r.status === 'pending' ? (
                      <div className="flex min-w-[220px] flex-col gap-2">
                        <input className="input" placeholder="Comment (optional)" aria-label={`Comment for ${r.student_name}`}
                          value={comments[r.id] || ''} onChange={(e) => setComments({ ...comments, [r.id]: e.target.value })} />
                        <div className="flex gap-2">
                          <button className="btn-primary !px-3 !py-1.5" onClick={() => decide(r, 'approved')}>Approve</button>
                          <button className="btn-ghost !px-3 !py-1.5" onClick={() => decide(r, 'rejected')}>Reject</button>
                        </div>
                      </div>
                    ) : (
                      <span className="text-xs italic text-ink/55">{r.staff_comment || 'No comment'}</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </DashboardLayout>
  );
}
