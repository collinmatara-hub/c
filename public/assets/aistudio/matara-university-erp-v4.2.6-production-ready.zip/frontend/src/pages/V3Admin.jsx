import { useEffect, useState } from 'react';
import DashboardLayout from '../components/DashboardLayout.jsx';
import api from '../api/axios.js';

const configs={
 admissions:{title:'Admissions & KUCCPS',endpoint:'/v3/admissions'},
 payroll:{title:'HR Payroll & Statutory Configuration',endpoint:'/v3/payroll/statutory'},
 payments:{title:'M-Pesa & Payment Transactions',endpoint:'/v3/payments'},
 documents:{title:'Transcripts & Certificates',endpoint:null},
 lms:{title:'LMS Integrations',endpoint:'/v3/lms/integrations'},
 backups:{title:'Backups & Object Storage',endpoint:'/v3/backups'},
};
export default function V3Admin({type='admissions'}){
 const c=configs[type]||configs.admissions; const [rows,setRows]=useState([]); const [loading,setLoading]=useState(true); const [error,setError]=useState('');
 async function load(){setLoading(true);setError('');try{if(c.endpoint){const r=await api.get(c.endpoint);setRows(Array.isArray(r.data)?r.data:[]);}}catch(e){setError(e.response?.data?.error||'Could not load this module.')}finally{setLoading(false)}}
 useEffect(()=>{load()},[type]);
 return <DashboardLayout title={c.title} subtitle="Version 3 university services"><div className="card p-6"><div className="flex flex-wrap items-center justify-between gap-3"><div><h2 className="font-display text-xl font-semibold">{c.title}</h2><p className="text-sm text-ink/55">Production-ready service controls with role-based access.</p></div><button className="btn-secondary" onClick={load}>Refresh</button></div>{error&&<div className="mt-4 rounded-xl bg-clay/10 p-3 text-sm text-clay">{error}</div>}{loading?<div className="mt-6 animate-pulse space-y-3"><div className="h-10 rounded-xl bg-paper"/><div className="h-10 rounded-xl bg-paper"/><div className="h-10 rounded-xl bg-paper"/></div>:type==='documents'?<div className="mt-6 grid gap-4 md:grid-cols-3"><div className="rounded-2xl border border-line p-5"><b>Transcript</b><p className="mt-1 text-sm text-ink/55">Issue an official transcript and create a verification QR/code.</p></div><div className="rounded-2xl border border-line p-5"><b>Certificate</b><p className="mt-1 text-sm text-ink/55">Issue a certificate with a tamper-evident verification hash.</p></div><div className="rounded-2xl border border-line p-5"><b>Verification</b><p className="mt-1 text-sm text-ink/55">Public verification endpoint: /api/v3/verify/:code</p></div></div>:rows.length===0?<div className="mt-6 rounded-xl bg-paper p-6 text-sm text-ink/55">No records yet.</div>:<div className="mt-6 overflow-x-auto"><table className="min-w-full text-sm"><thead><tr className="border-b border-line text-left">{Object.keys(rows[0]).slice(0,8).map(k=><th key={k} className="px-3 py-3 font-semibold">{k.replaceAll('_',' ')}</th>)}</tr></thead><tbody>{rows.map((r,i)=><tr key={r.id||i} className="border-b border-line/60">{Object.keys(rows[0]).slice(0,8).map(k=><td key={k} className="px-3 py-3 align-top">{typeof r[k]==='object'?JSON.stringify(r[k]):String(r[k]??'')}</td>)}</tr>)}</tbody></table></div>}</div></DashboardLayout>
}
