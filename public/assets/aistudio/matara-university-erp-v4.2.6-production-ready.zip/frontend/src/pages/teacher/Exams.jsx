import { useState } from 'react';
import { FileQuestion, Plus, Send, Users } from 'lucide-react';
import DashboardLayout from '../../components/DashboardLayout.jsx';
import PageHeader from '../../components/PageHeader.jsx';
import { EmptyState } from '../../components/Skeleton.jsx';

const seed = [
  { id: 1, title: 'Computer Networks CAT 1', subject: 'Data Communication', className: 'BBIT Year 1', questions: 10, duration: 45, status: 'Published', submissions: 18 },
  { id: 2, title: 'Python Fundamentals', subject: 'Introduction to Python', className: 'BBIT Year 1', questions: 15, duration: 60, status: 'Draft', submissions: 0 },
];

export default function LecturerExams() {
  const [exams, setExams] = useState(seed);
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState('');

  function create(e) {
    e.preventDefault();
    if (!title.trim()) return;
    setExams([
      { id: Date.now(), title, subject: 'New university unit', className: 'Select class', questions: 0, duration: 30, status: 'Draft', submissions: 0 },
      ...exams,
    ]);
    setTitle('');
    setOpen(false);
  }

  return (
    <DashboardLayout title="Online Examinations" subtitle="Create assessments, publish tests and review student submissions">
      <PageHeader
        eyebrow="Lecturer workspace"
        title="Exams & assessments"
        actions={
          <>
            <a href="/teacher/grading" className="btn-ghost">Grade submissions</a>
            <button className="btn-gold" onClick={() => setOpen(!open)}>
              <Plus size={17} /> Create exam
            </button>
          </>
        }
      />

      {open && (
        <form onSubmit={create} className="card mb-6 flex gap-3 p-5">
          <div className="flex-1">
            <span className="label">Exam title</span>
            <input className="input" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Networking CAT 2" />
          </div>
          <button className="btn-primary mt-5" type="submit">Create draft</button>
        </form>
      )}

      {exams.length === 0 ? (
        <EmptyState icon={FileQuestion} title="No exams yet" hint="Create your first assessment to get started." />
      ) : (
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          {exams.map((x) => (
            <div className="card p-5" key={x.id}>
              <div className="flex items-start justify-between">
                <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-forest/10 text-forest">
                  <FileQuestion size={22} />
                </div>
                <span className={`badge ${x.status === 'Published' ? 'badge-green' : 'badge-gold'}`}>{x.status}</span>
              </div>
              <h3 className="mt-4 font-display text-lg font-semibold">{x.title}</h3>
              <p className="text-sm text-ink/50">{x.subject} · {x.className}</p>
              <div className="mt-5 grid grid-cols-3 gap-2 text-sm">
                <div className="rounded-xl bg-paper p-3"><p className="text-xs text-ink/45">Questions</p><b>{x.questions}</b></div>
                <div className="rounded-xl bg-paper p-3"><p className="text-xs text-ink/45">Duration</p><b>{x.duration} min</b></div>
                <div className="rounded-xl bg-paper p-3"><p className="text-xs text-ink/45">Submitted</p><b>{x.submissions}</b></div>
              </div>
              <div className="mt-5 flex gap-2">
                <button className="btn-primary flex-1">Edit exam</button>
                {x.status === 'Draft' ? (
                  <button className="btn-gold"><Send size={15} /> Publish</button>
                ) : (
                  <a className="btn-ghost" href="/teacher/grading"><Users size={15} /> Grade</a>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </DashboardLayout>
  );
}
