import { useState } from 'react';
import { Check, FileQuestion, Save, Search } from 'lucide-react';
import DashboardLayout from '../../components/DashboardLayout.jsx';
import PageHeader from '../../components/PageHeader.jsx';

const seed = [
  { id: 1, student: 'Brian Mwangi', exam: 'Computer Networks CAT 1', submitted: '18 Sep · 14:22', auto: 72, mark: 72, feedback: 'Good understanding of routing concepts.' },
  { id: 2, student: 'Sharon Wanjiku', exam: 'Computer Networks CAT 1', submitted: '18 Sep · 15:04', auto: 86, mark: 86, feedback: '' },
  { id: 3, student: 'Kevin Otieno', exam: 'Computer Networks CAT 1', submitted: '18 Sep · 16:11', auto: 64, mark: 64, feedback: '' },
];

const QUESTIONS = [
  { q: 'What is the main purpose of a router?', answer: 'Connect different networks.' },
  { q: 'Which OSI layer handles logical addressing?', answer: 'Network layer.' },
  { q: 'Explain one advantage of VLANs.', answer: 'They separate broadcast domains.' },
];

export default function Grading() {
  const [rows, setRows] = useState(seed);
  const [selected, setSelected] = useState(rows[0]);
  const [mark, setMark] = useState(rows[0].mark);
  const [feedback, setFeedback] = useState(rows[0].feedback);
  const [q, setQ] = useState('');

  function save() {
    setRows(rows.map((r) => (r.id === selected.id ? { ...r, mark: Number(mark), feedback } : r)));
    setSelected({ ...selected, mark: Number(mark), feedback });
  }

  function choose(r) {
    setSelected(r);
    setMark(r.mark);
    setFeedback(r.feedback);
  }

  const list = rows.filter((r) => r.student.toLowerCase().includes(q.toLowerCase()));

  return (
    <DashboardLayout title="Grade Submissions" subtitle="Review online exams and record marks for students">
      <PageHeader eyebrow="Lecturer workspace" title="Grade exam submissions" />

      <div className="grid grid-cols-1 gap-5 xl:grid-cols-[360px_1fr]">
        <div className="card overflow-hidden">
          <div className="border-b border-sage p-5">
            <p className="page-eyebrow">Submissions</p>
            <h3 className="mt-1 font-display text-lg font-semibold">Computer Networks CAT 1</h3>
            <div className="relative mt-4">
              <Search className="absolute left-3 top-2.5 text-ink/40" size={16} />
              <input className="input pl-9" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Find student..." />
            </div>
          </div>
          <div>
            {list.map((r) => (
              <button
                key={r.id}
                onClick={() => choose(r)}
                className={`w-full border-b border-sage/60 p-4 text-left transition ${selected.id === r.id ? 'bg-forest/[.06]' : ''}`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-semibold">{r.student}</span>
                  <span className={`badge ${r.mark >= 70 ? 'badge-green' : r.mark >= 50 ? 'badge-gold' : 'badge-red'}`}>{r.mark}%</span>
                </div>
                <p className="mt-1 text-xs text-ink/45">Submitted {r.submitted}</p>
              </button>
            ))}
          </div>
        </div>

        <div className="card p-5 md:p-7">
          <div className="flex flex-wrap items-start justify-between gap-3 border-b border-sage pb-5">
            <div>
              <p className="page-eyebrow">Student submission</p>
              <h2 className="mt-1 font-display text-2xl font-semibold">{selected.student}</h2>
              <p className="text-sm text-ink/50">{selected.exam} · Submitted {selected.submitted}</p>
            </div>
            <span className="badge badge-green"><Check size={13} /> Auto-marked {selected.auto}%</span>
          </div>

          <div className="mt-6 rounded-2xl bg-paper p-5">
            <div className="flex items-center gap-3">
              <FileQuestion className="text-forest" />
              <div>
                <p className="font-semibold">Answer sheet</p>
                <p className="text-sm text-ink/50">Review objective answers and manually marked questions.</p>
              </div>
            </div>
            <div className="mt-5 space-y-3">
              {QUESTIONS.map((item, i) => (
                <div className="rounded-xl border border-sage bg-surface p-4" key={item.q}>
                  <p className="text-xs font-bold uppercase tracking-wide text-ink/40">Question {i + 1}</p>
                  <p className="mt-1 font-medium">{item.q}</p>
                  <p className="mt-2 text-sm text-ink/60">Student answer: <span className="text-ink">{item.answer}</span></p>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-6 grid gap-4 md:grid-cols-[180px_1fr]">
            <label>
              <span className="label">Final mark (%)</span>
              <input className="input text-lg font-bold" type="number" min="0" max="100" value={mark} onChange={(e) => setMark(e.target.value)} />
            </label>
            <label>
              <span className="label">Lecturer feedback</span>
              <textarea className="input min-h-24 resize-y" value={feedback} onChange={(e) => setFeedback(e.target.value)} placeholder="Write feedback for the student..." />
            </label>
          </div>
          <button className="btn-primary mt-5" onClick={save}><Save size={16} /> Save grade</button>
        </div>
      </div>
    </DashboardLayout>
  );
}
