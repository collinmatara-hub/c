import { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  ArrowLeft, ArrowRight, Award, Bell, BookOpen, BookOpenCheck, CalendarDays,
  CheckSquare, ChevronRight, ClipboardCheck, FileText, GraduationCap, Library,
  LogOut, Mail, Menu, MessageSquare, Moon, Search, Sun, Users, UploadCloud,
  Video, Megaphone, BarChart3, UserRound, LifeBuoy, Clock3
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext.jsx';
import api from '../../api/axios.js';
import '../../styles/lms.css';

const navItems = [
  { label: 'Dashboard', to: '/lecturer/lms', icon: GraduationCap },
  { label: 'Online Classes & Whiteboard', to: '/lecturer/lms/online-classes', icon: Video },
  { label: 'My Courses & Classes', to: '/teacher', icon: BookOpen },
  { label: 'Course Materials', to: '/teacher/materials', icon: Library },
  { label: 'Lessons & Topics', to: '/teacher/materials', icon: BookOpenCheck },
  { label: 'Assignments', to: '/lecturer/lms/assignments', icon: FileText },
  { label: 'Student Submissions', to: '/lecturer/lms/assignments', icon: ClipboardCheck },
  { label: 'Quizzes & Assessments', to: '/teacher/online-exams', icon: CheckSquare },
  { label: 'Grade Book', to: '/teacher/marks', icon: Award },
  { label: 'Class Lists', to: '/teacher', icon: Users },
  { label: 'Attendance', to: '/teacher/attendance', icon: CalendarDays },
  { label: 'Discussions', to: '/teacher/messages', icon: MessageSquare },
  { label: 'Announcements', to: '/teacher/announcements', icon: Megaphone },
  { label: 'Teaching Calendar', to: '/calendar', icon: CalendarDays },
  { label: 'Messages', to: '/teacher/messages', icon: Mail },
  { label: 'Reports & Analytics', to: '/teacher/marks', icon: BarChart3 },
  { label: 'My Profile', to: '/profile', icon: UserRound },
  { label: 'Help & Support', to: '/help-desk', icon: LifeBuoy },
];
const greeting = () => { const h = new Date().getHours(); return h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening'; };

export default function LecturerLMSDashboard() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [data, setData] = useState(null);
  const [error, setError] = useState('');
  const [collapsed, setCollapsed] = useState(false);
  const [dark, setDark] = useState(() => localStorage.getItem('matara_lecturer_lms_theme') === 'dark');
  const [query, setQuery] = useState('');
  const [mobileOpen, setMobileOpen] = useState(false);

  const load = () => { setError(''); api.get('/lms/lecturer/dashboard').then(({ data: result }) => setData(result)).catch((e) => setError(e.response?.data?.error || 'Could not load teaching data. Check that your lecturer account is linked to a teaching record.')); };
  useEffect(() => { load(); }, []);
  useEffect(() => { localStorage.setItem('matara_lecturer_lms_theme', dark ? 'dark' : 'light'); }, [dark]);
  const classes = useMemo(() => (data?.classes || []).filter(c => `${c.name || ''} ${c.stream || ''}`.toLowerCase().includes(query.toLowerCase())), [data, query]);
  const timetable = data?.timetable || [];
  const assignments = data?.assignments || [];
  const students = data?.students || [];
  const pending = Number(data?.pendingGrading ?? assignments.reduce((n, a) => n + Number(a.pending_marking || 0), 0));

  const quick = [
    { label: 'Create Assignment', desc: 'Prepare and manage coursework', to: '/lecturer/lms/assignments', icon: FileText, color: 'blue' },
    { label: 'Upload Learning Materials', desc: 'Share notes and resources', to: '/teacher/materials', icon: UploadCloud, color: 'green' },
    { label: 'Online Classes', desc: 'Schedule live teaching sessions', to: '/lecturer/lms/online-classes', icon: Video, color: 'purple' },
    { label: 'Open Grade Book', desc: 'Review marks and results', to: '/teacher/marks', icon: Award, color: 'orange' },
    { label: 'View Class Lists', desc: 'Review your assigned classes', to: '/teacher', icon: Users, color: 'blue' },
    { label: 'Post Announcement', desc: 'Share a course or class notice', to: '/teacher/announcements', icon: Megaphone, color: 'green' },
  ];

  return <div className={`lms-app ${dark ? 'lms-dark' : ''}`}>
    <aside className={`lms-sidebar ${collapsed ? 'lms-sidebar-collapsed' : ''} ${mobileOpen ? 'lecturer-mobile-open' : ''}`}>
      <div className="lms-brand"><div className="lms-crest"><GraduationCap size={27}/></div>{!collapsed && <div><strong>MATARA<br/>UNIVERSITY</strong><small>Knowledge | Integrity | Impact</small></div>}</div>
      <nav className="lms-nav" aria-label="Lecturer LMS navigation">{navItems.map(({label,icon:Icon,to})=><Link key={label} to={to} title={collapsed?label:undefined} onClick={()=>setMobileOpen(false)} className={`lms-nav-link ${to==='/lecturer/lms'?'lms-active':''}`}><Icon size={19}/>{!collapsed&&<span>{label}</span>}</Link>)}</nav>
      {!collapsed && <div className="lms-sidebar-campus"><div className="lms-campus-overlay"><strong>Matara University LMS</strong><span>Teach · Inspire · Empower</span></div></div>}
      <button className="lms-collapse" onClick={()=>setCollapsed(!collapsed)} aria-label={collapsed?'Expand navigation':'Collapse navigation'}>{collapsed?<Menu size={18}/>:<><ArrowLeft size={17}/> Collapse menu</>}</button>
    </aside>
    <section className="lms-main-shell">
      <header className="lms-topbar"><button className="lms-icon-btn" onClick={()=>{setCollapsed(!collapsed);setMobileOpen(!mobileOpen)}} aria-label="Toggle sidebar"><Menu size={20}/></button><label className="lms-search"><Search size={17}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search your classes and teaching activities…" aria-label="Search teaching courses"/></label><div className="lms-top-actions"><Link to="/teacher/announcements" className="lms-icon-btn" aria-label="Announcements"><Bell size={19}/></Link><Link to="/teacher/messages" className="lms-icon-btn" aria-label="Messages"><Mail size={19}/></Link><button className="lms-icon-btn" onClick={()=>setDark(!dark)} aria-label="Toggle dark mode">{dark?<Sun size={19}/>:<Moon size={19}/>}</button><div className="lms-user"><span className="lms-avatar">{(user?.name||'L').split(' ').map(x=>x[0]).slice(0,2).join('').toUpperCase()}</span><span><strong>{user?.name||'Lecturer'}</strong><small>Lecturer</small></span><button className="lms-icon-btn lms-logout" onClick={async()=>{await logout();navigate('/login',{replace:true});}} title="Sign out" aria-label="Sign out"><LogOut size={17}/></button></div></div></header>
      <main className="lms-content"><div className="lms-back-row"><Link to="/teacher" className="lms-back"><ArrowLeft size={16}/> Back to ERP Portal</Link><span>Matara University / Lecturer Learning Management System</span></div>
        {error&&<div className="lms-error" role="alert">{error}<button onClick={load}>Retry</button></div>}
        {!data&&!error?<div className="lms-loading"><span className="lms-spinner"/>Loading your teaching dashboard…</div>:<>
          <section className="lms-hero"><div className="lms-hero-copy"><p className="lms-eyebrow">✦ {greeting()}</p><h1>{user?.name||data?.teacher?.name||'Lecturer'} <span aria-hidden="true">👋</span></h1><p>Welcome to your teaching workspace. Inspire learning, manage coursework, and support student success.</p><small>Matara University · Lecturer Portal</small></div><blockquote>“Teaching is the one profession that creates all other professions.”<cite>— General teaching wisdom</cite></blockquote><div className="lms-stats">
            <Link to="/teacher" className="lms-stat"><span className="lms-stat-icon blue"><BookOpen/></span><span><small>My Classes</small><strong>{data?.classes?.length ?? '—'}</strong></span></Link>
            <Link to="/teacher" className="lms-stat"><span className="lms-stat-icon green"><Users/></span><span><small>Total Students</small><strong>{data?.students?.length ?? '—'}</strong></span></Link>
            <Link to="/teacher/grading" className="lms-stat"><span className="lms-stat-icon orange"><ClipboardCheck/></span><span><small>Pending Grading</small><strong>{data ? pending : '—'}</strong></span></Link>
            <Link to="/my-timetable" className="lms-stat"><span className="lms-stat-icon purple"><CalendarDays/></span><span><small>Scheduled Classes</small><strong>{data?.timetable?.length ?? '—'}</strong></span></Link>
          </div></section>
          <div className="lms-columns"><div className="lms-primary-column">
            <section className="lms-panel"><div className="lms-panel-heading"><h2><BookOpen size={20}/> My Teaching Courses & Classes</h2><Link to="/teacher">Open workspace <ArrowRight size={15}/></Link></div>{classes.length?<div className="lms-course-grid">{classes.slice(0,6).map((c,i)=><Link to="/teacher" key={c.id||i} className={`lms-course-card tone-${i%6}`}><div className="lms-course-color"><span className="lms-course-icon"><BookOpenCheck size={22}/></span><small>{c.stream||'Assigned class'}</small><strong>{c.name||'Teaching class'}</strong><span className="lms-lecturer">{c.student_count??0} enrolled students</span></div><div className="lms-course-progress"><span><i style={{width:'0%'}}/></span><small>Progress tracked in course</small></div><div className="lms-course-footer"><span><Users size={13}/> Open class list</span><ChevronRight size={15}/></div></Link>)}</div>:<div className="lms-empty"><BookOpen size={24}/><strong>{data?'No linked teaching classes found':'Teaching classes unavailable'}</strong><p>{data?'Your lecturer account has no class-teacher assignments in the current data model.':'Retry loading your teaching records.'}</p><Link to="/teacher">Open existing lecturer workspace <ArrowRight size={14}/></Link></div>}</section>
            <section className="lms-panel"><div className="lms-panel-heading"><h2><Clock3 size={20}/> Upcoming Teaching Activities</h2><Link to="/my-timetable">View timetable <ArrowRight size={15}/></Link></div>{timetable.length?<div className="lms-table-wrap"><table className="ledger-table"><thead><tr><th>Day</th><th>Time</th><th>Class</th><th>Course / Unit</th><th>Room</th></tr></thead><tbody>{timetable.slice(0,6).map((t,i)=><tr key={t.id||i}><td>{t.day||'—'}</td><td>{t.start_time||'—'}–{t.end_time||'—'}</td><td>{t.class_name||'—'} {t.stream||''}</td><td>{t.subject_name||'—'}</td><td>{t.room||t.room_name||'—'}</td></tr>)}</tbody></table></div>:<div className="lms-empty lms-empty-compact"><CalendarDays size={22}/><p>No teaching timetable entries are currently available for your account.</p><Link to="/my-timetable">Open timetable <ArrowRight size={14}/></Link></div>}</section>
            <section className="lms-panel"><div className="lms-panel-heading"><h2><FileText size={20}/> Assignment Overview</h2><Link to="/teacher/grading">Manage assessments <ArrowRight size={15}/></Link></div>{assignments.length?<div className="lms-table-wrap"><table className="ledger-table"><thead><tr><th>Assignment</th><th>Class</th><th>Course</th><th>Due date</th><th>Max marks</th></tr></thead><tbody>{assignments.slice(0,6).map((a,i)=><tr key={a.id||i}><td>{a.title||'Assignment'}</td><td>{a.class_name||'—'}</td><td>{a.subject_name||'—'}</td><td>{a.due_date||'—'}</td><td>{a.max_marks??'—'}</td></tr>)}</tbody></table></div>:<div className="lms-empty lms-empty-compact"><FileText size={22}/><p>No assignment records are available in the current lecturer feed.</p><Link to="/teacher/grading">Open assessments <ArrowRight size={14}/></Link></div>}</section>
          </div><aside className="lms-secondary-column">
            <section className="lms-panel"><div className="lms-panel-heading"><h2><ZapIcon/> Quick Actions</h2></div>{quick.map(({label,desc,to,icon:Icon,color})=><Link className="lms-quick-link" to={to} key={label}><span className={`lms-quick-icon ${color}`}><Icon size={19}/></span><span><strong>{label}</strong><small>{desc}</small></span><ChevronRight size={16}/></Link>)}</section>
            <section className="lms-panel"><div className="lms-panel-heading"><h2><Users size={19}/> Student Roster</h2><Link to="/teacher">View classes <ArrowRight size={14}/></Link></div>{students.length?students.slice(0,5).map((s,i)=><div className="lms-deadline" key={s.id||i}><span className="lms-date-box"><UserRound size={18}/></span><span><strong>{s.name||'Student'}</strong><small>{s.adm_no||'Registration number unavailable'} · {s.class_name||'Assigned class'}</small></span></div>):<div className="lms-empty lms-empty-compact"><Users size={22}/><p>Student roster is empty or not linked to this lecturer record.</p></div>}</section>
            <section className="lms-study-tip"><div><h2><GraduationCap size={19}/> Teaching Tip</h2><p>Set clear learning outcomes, share resources before class, and provide specific, timely feedback to help students improve.</p><Link to="/help-desk">Get support <ArrowRight size={14}/></Link></div></section>
          </aside></div>
        </>}
      </main><footer className="lms-footer">Matara University · Lecturer Learning Management System <span>Teach · Inspire · Empower</span></footer>
    </section>
  </div>;
}
function ZapIcon(){ return <UploadCloud size={19}/>; }
