import { useCallback, useEffect, useMemo, useState } from 'react';
import DashboardLayout from '../components/DashboardLayout.jsx';
import api from '../api/axios.js';
import { useAuth } from '../context/AuthContext.jsx';
import { hasCap, roleInfo } from '../config/roles.js';

// ---------- small shared pieces ----------

function useNotice() {
  const [notice, setNotice] = useState(null);
  const ok = (text) => setNotice({ kind: 'ok', text });
  const bad = (err) => setNotice({ kind: 'bad', text: typeof err === 'string' ? err : (err?.response?.data?.error || 'Something went wrong.') });
  const view = notice && (
    <div role="status" className={`mb-4 rounded-xl p-3 text-sm ${notice.kind === 'ok' ? 'bg-emerald-500/10 text-emerald-700' : 'bg-clay/10 text-clay'}`}>{notice.text}</div>
  );
  return { ok, bad, view, clear: () => setNotice(null) };
}

function Card({ title, hint, children, actions }) {
  return (
    <section className="card mb-5 p-5">
      <div className="mb-3 flex flex-wrap items-start justify-between gap-2">
        <div>
          <h3 className="font-display text-lg font-semibold text-ink">{title}</h3>
          {hint && <p className="mt-0.5 text-sm text-ink/55">{hint}</p>}
        </div>
        {actions}
      </div>
      {children}
    </section>
  );
}

function Field({ label, children, wide }) {
  return <label className={wide ? 'md:col-span-2' : ''}><span className="label">{label}</span>{children}</label>;
}

function Table({ head, rows, empty = 'Nothing here yet.' }) {
  if (!rows.length) return <p className="text-sm text-ink/55">{empty}</p>;
  return (
    <div className="overflow-x-auto">
      <table className="ledger-table">
        <thead><tr>{head.map((h) => <th key={h}>{h}</th>)}</tr></thead>
        <tbody>{rows.map((cells, i) => <tr key={i}>{cells.map((c, j) => <td key={j}>{c}</td>)}</tr>)}</tbody>
      </table>
    </div>
  );
}

const when = (t) => (t ? String(t).replace('T', ' ').slice(0, 16) : '—');

// Type a name or registration number, pick a student.
function StudentPicker({ value, onChange, label = 'Student' }) {
  const [q, setQ] = useState('');
  const [found, setFound] = useState([]);
  useEffect(() => {
    if (q.trim().length < 2) { setFound([]); return undefined; }
    const timer = setTimeout(() => {
      api.get('/role-ops/lookup/students', { params: { q } }).then((r) => setFound(r.data)).catch(() => setFound([]));
    }, 250);
    return () => clearTimeout(timer);
  }, [q]);
  return (
    <div>
      <span className="label">{label}</span>
      <input className="input" placeholder="Name or registration number" value={value ? `${value.adm_no} · ${value.name}` : q}
        onChange={(e) => { onChange(null); setQ(e.target.value); }} />
      {!value && found.length > 0 && (
        <ul className="mt-1 max-h-40 overflow-auto rounded-xl border border-ink/10 bg-white text-sm shadow dark:bg-navy">
          {found.map((s) => (
            <li key={s.id}><button type="button" className="block w-full px-3 py-2 text-left hover:bg-sage/40" onClick={() => { onChange(s); setFound([]); setQ(''); }}>{s.adm_no} · {s.name} <span className="text-ink/45">({s.status})</span></button></li>
          ))}
        </ul>
      )}
    </div>
  );
}

// ---------- grade lock ----------

function GradeLock() {
  const n = useNotice();
  const [lock, setLock] = useState(null);
  const [deadline, setDeadline] = useState('');
  const load = useCallback(() => api.get('/role-ops/grade-lock').then((r) => { setLock(r.data); setDeadline(r.data.deadline ? r.data.deadline.slice(0, 16) : ''); }).catch(n.bad), []); // eslint-disable-line
  useEffect(() => { load(); }, [load]);
  async function save(locked) {
    try {
      const { data } = await api.put('/role-ops/grade-lock', { locked, deadline: deadline ? new Date(deadline).toISOString() : null });
      setLock(data); n.ok(locked ? 'Grade Lock is ON. Lecturers can no longer change marks.' : 'Grade Lock is off.');
    } catch (e) { n.bad(e); }
  }
  return (
    <Card title="Grade Lock" hint="Removes mark editing from lecturers, teaching assistants and lab technicians once the grading deadline passes.">
      {n.view}
      {lock && (
        <div className="mb-4 flex flex-wrap items-center gap-3">
          <span className={`badge ${lock.locked ? 'badge-gold' : ''}`}>{lock.locked ? (lock.deadlinePassed && !lock.manual ? 'Locked: deadline passed' : 'Locked') : 'Open for editing'}</span>
          {lock.locked_at && <span className="text-xs text-ink/55">Last changed {when(lock.locked_at)}{lock.locked_by_name ? ` by ${lock.locked_by_name}` : ''}</span>}
        </div>
      )}
      <div className="grid gap-4 md:grid-cols-2">
        <Field label="Grading deadline (optional)"><input type="datetime-local" className="input" value={deadline} onChange={(e) => setDeadline(e.target.value)} /></Field>
        <div className="flex items-end gap-2">
          <button className="btn-primary" onClick={() => save(true)}>Lock grades now</button>
          <button className="btn-secondary" onClick={() => save(false)}>Open grades</button>
        </div>
      </div>
      <p className="mt-3 text-xs text-ink/55">Opening grades keeps the deadline. A deadline in the past locks grades automatically, so clear the deadline to reopen.</p>
    </Card>
  );
}

// ---------- financial holds ----------

function Holds() {
  const n = useNotice();
  const [rows, setRows] = useState([]);
  const [student, setStudent] = useState(null);
  const [form, setForm] = useState({ reason: '', amount: '' });
  const load = useCallback(() => api.get('/role-ops/holds').then((r) => setRows(r.data)).catch(n.bad), []); // eslint-disable-line
  useEffect(() => { load(); }, [load]);
  async function place(e) {
    e.preventDefault();
    try { await api.post('/role-ops/holds', { student_id: student?.id, ...form }); n.ok('Financial hold placed.'); setForm({ reason: '', amount: '' }); setStudent(null); load(); } catch (err) { n.bad(err); }
  }
  async function release(id) {
    const note = window.prompt('Note for releasing this hold (optional):') ?? null;
    if (note === null) return;
    try { await api.post(`/role-ops/holds/${id}/release`, { note }); n.ok('Hold released.'); load(); } catch (err) { n.bad(err); }
  }
  return (
    <>
      <Card title="Place a financial hold" hint="A held student cannot register for units and cannot be issued transcripts or certificates until it is released.">
        {n.view}
        <form onSubmit={place} className="grid gap-4 md:grid-cols-2">
          <StudentPicker value={student} onChange={setStudent} />
          <Field label="Amount owed (KES, optional)"><input type="number" min="0" className="input" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} /></Field>
          <Field label="Reason" wide><input className="input" required value={form.reason} onChange={(e) => setForm({ ...form, reason: e.target.value })} /></Field>
          <div className="md:col-span-2"><button className="btn-primary" disabled={!student}>Place hold</button></div>
        </form>
      </Card>
      <Card title="Holds">
        <Table head={['Student', 'Reason', 'Amount', 'Placed', 'Status', '']} rows={rows.map((h) => [
          `${h.adm_no} · ${h.student_name}`, h.reason, h.amount ? `KES ${Number(h.amount).toLocaleString()}` : '—', `${when(h.placed_at)}${h.placed_by_name ? ` by ${h.placed_by_name}` : ''}`,
          h.released_at ? `Released ${when(h.released_at)}` : 'Active',
          h.released_at ? '' : <button className="btn-ghost" onClick={() => release(h.id)}>Release</button>,
        ])} />
      </Card>
    </>
  );
}

// ---------- gate scanner and bans ----------

function Gate({ canBan }) {
  const n = useNotice();
  const [code, setCode] = useState('');
  const [result, setResult] = useState(null);
  const [bans, setBans] = useState([]);
  const [log, setLog] = useState([]);
  const [ban, setBan] = useState({ code: '', reason: '' });
  const load = useCallback(() => {
    if (!canBan) return;
    api.get('/role-ops/bans').then((r) => setBans(r.data)).catch(() => {});
    api.get('/role-ops/gate/log').then((r) => setLog(r.data)).catch(() => {});
  }, [canBan]);
  useEffect(() => { load(); }, [load]);
  async function scan(e) {
    e.preventDefault();
    try { const { data } = await api.post('/role-ops/gate/scan', { code }); setResult(data); setCode(''); load(); } catch (err) { setResult(null); n.bad(err); }
  }
  async function addBan(e) {
    e.preventDefault();
    try { await api.post('/role-ops/bans', ban); n.ok('Flagged as Banned from Campus.'); setBan({ code: '', reason: '' }); load(); } catch (err) { n.bad(err); }
  }
  async function lift(id) { try { await api.post(`/role-ops/bans/${id}/lift`); load(); } catch (err) { n.bad(err); } }
  return (
    <>
      <Card title="Gate scan" hint="Scan or type a registration number, staff number or email. The screen shows Green (cleared) or Red.">
        {n.view}
        <form onSubmit={scan} className="flex flex-wrap gap-2">
          <input className="input max-w-sm" autoFocus placeholder="Scan or type ID" value={code} onChange={(e) => setCode(e.target.value)} />
          <button className="btn-primary" disabled={!code.trim()}>Check</button>
        </form>
        {result && (
          <div data-testid="gate-result" className={`mt-4 grid h-40 place-items-center rounded-2xl text-center text-white ${result.result === 'green' ? 'bg-emerald-600' : 'bg-red-600'}`}>
            <div>
              <p className="text-4xl font-extrabold tracking-wide">{result.result === 'green' ? 'GREEN' : 'RED'}</p>
              {result.reason && <p className="mt-1 text-sm">{result.reason}{result.name ? ` · ${result.name}` : ''}</p>}
            </div>
          </div>
        )}
      </Card>
      {canBan && (
        <>
          <Card title="Ban from campus" hint="A banned student or staff member shows Red at every gate until the ban is lifted.">
            <form onSubmit={addBan} className="grid gap-4 md:grid-cols-2">
              <Field label="Registration / staff number"><input className="input" required value={ban.code} onChange={(e) => setBan({ ...ban, code: e.target.value })} /></Field>
              <Field label="Reason"><input className="input" required value={ban.reason} onChange={(e) => setBan({ ...ban, reason: e.target.value })} /></Field>
              <div className="md:col-span-2"><button className="btn-primary">Flag as banned</button></div>
            </form>
            <div className="mt-4"><Table head={['Person', 'Reason', 'Banned', 'Status', '']} rows={bans.map((b) => [
              b.person_name || `User ${b.subject_id}`, b.reason, `${when(b.banned_at)}${b.banned_by_name ? ` by ${b.banned_by_name}` : ''}`, b.lifted_at ? `Lifted ${when(b.lifted_at)}` : 'Active',
              b.lifted_at ? '' : <button className="btn-ghost" onClick={() => lift(b.id)}>Lift ban</button>])} /></div>
          </Card>
          <Card title="Recent scans"><Table head={['Time', 'Code', 'Person', 'Result', 'Reason']} rows={log.slice(0, 50).map((g) => [when(g.scanned_at), g.scanned_code, g.person_name || '—', g.result, g.reason])} /></Card>
        </>
      )}
    </>
  );
}

// ---------- exam invigilation ----------

function Invigilation() {
  const n = useNotice();
  const [exam, setExam] = useState('');
  const [code, setCode] = useState('');
  const [last, setLast] = useState(null);
  const [rows, setRows] = useState([]);
  const [flag, setFlag] = useState({ code: '', description: '' });
  const load = useCallback(() => { if (exam.trim()) api.get('/role-ops/exam-attendance', { params: { exam_label: exam } }).then((r) => setRows(r.data)).catch(() => {}); }, [exam]);
  useEffect(() => { load(); }, [load]);
  async function scan(e) {
    e.preventDefault();
    try { const { data } = await api.post('/role-ops/exam-attendance/scan', { code, exam_label: exam }); setLast(data); setCode(''); load(); } catch (err) { setLast(null); n.bad(err); }
  }
  async function flagIt(e) {
    e.preventDefault();
    try { await api.post('/role-ops/malpractice', { ...flag, exam_label: exam }); n.ok('Malpractice flagged. The Disciplinary Committee can see it.'); setFlag({ code: '', description: '' }); } catch (err) { n.bad(err); }
  }
  return (
    <>
      <Card title="Exam attendance" hint="Scan each student's ID as they sit the exam.">
        {n.view}
        <div className="grid gap-4 md:grid-cols-2">
          <Field label="Exam (for example BIT 2216 Final)"><input className="input" value={exam} onChange={(e) => setExam(e.target.value)} /></Field>
          <form onSubmit={scan} className="flex items-end gap-2">
            <label className="flex-1"><span className="label">Scan or type registration number</span><input className="input" value={code} onChange={(e) => setCode(e.target.value)} /></label>
            <button className="btn-primary" disabled={!exam.trim() || !code.trim()}>Record</button>
          </form>
        </div>
        {last && (
          <p className={`mt-3 rounded-xl p-3 text-sm ${last.already_recorded ? 'bg-gold/15 text-ink' : 'bg-emerald-500/10 text-emerald-700'}`}>
            {last.name} ({last.adm_no}) {last.already_recorded ? 'was already marked present.' : 'marked present.'} {last.financial_hold ? 'Note: this student has a financial hold.' : ''}
          </p>
        )}
        <div className="mt-4"><Table head={['Student', 'Recorded']} rows={rows.map((r) => [`${r.adm_no} · ${r.student_name}`, when(r.recorded_at)])} empty="No one recorded for this exam yet." /></div>
      </Card>
      <Card title="Flag malpractice" hint="Sent straight to the Disciplinary Committee.">
        <form onSubmit={flagIt} className="grid gap-4 md:grid-cols-2">
          <Field label="Registration number"><input className="input" required value={flag.code} onChange={(e) => setFlag({ ...flag, code: e.target.value })} /></Field>
          <Field label="What happened" wide><textarea className="input min-h-24" required value={flag.description} onChange={(e) => setFlag({ ...flag, description: e.target.value })} /></Field>
          <div className="md:col-span-2"><button className="btn-primary" disabled={!exam.trim()}>Flag malpractice</button>{!exam.trim() && <span className="ml-3 text-xs text-ink/55">Enter the exam name above first.</span>}</div>
        </form>
      </Card>
    </>
  );
}

// ---------- discipline ----------

function Discipline({ canAct }) {
  const n = useNotice();
  const [flags, setFlags] = useState([]);
  const [cases, setCases] = useState([]);
  const [student, setStudent] = useState(null);
  const [form, setForm] = useState({ reason: '', hearing_date: '' });
  const load = useCallback(() => {
    api.get('/role-ops/malpractice').then((r) => setFlags(r.data)).catch(() => {});
    if (canAct) api.get('/role-ops/discipline/cases').then((r) => setCases(r.data)).catch(() => {});
  }, [canAct]);
  useEffect(() => { load(); }, [load]);
  async function act(path, body, message) {
    try { await api.post(path, body); n.ok(message); setStudent(null); setForm({ reason: '', hearing_date: '' }); load(); } catch (err) { n.bad(err); }
  }
  async function setStatus(id, status) { try { await api.put(`/role-ops/malpractice/${id}`, { status }); load(); } catch (err) { n.bad(err); } }
  return (
    <>
      {n.view}
      <Card title="Malpractice reports">
        <Table head={['Student', 'Exam', 'What happened', 'Flagged by', 'Status']} rows={flags.map((f) => [
          `${f.adm_no} · ${f.student_name}`, f.exam_label, f.description, f.flagged_by_name || '—',
          canAct ? <select className="input !w-auto" value={f.status} onChange={(e) => setStatus(f.id, e.target.value)}>{['open', 'under_review', 'upheld', 'dismissed'].map((s) => <option key={s} value={s}>{s.replace('_', ' ')}</option>)}</select> : f.status,
        ])} empty="No malpractice reports." />
      </Card>
      {canAct && (
        <>
          <Card title="Suspend or expel a student" hint="Suspended students see only a page with the reason and hearing date. Expelled students lose their login.">
            <div className="grid gap-4 md:grid-cols-2">
              <StudentPicker value={student} onChange={setStudent} />
              <Field label="Hearing date (required to suspend)"><input type="date" className="input" value={form.hearing_date} onChange={(e) => setForm({ ...form, hearing_date: e.target.value })} /></Field>
              <Field label="Reason" wide><input className="input" value={form.reason} onChange={(e) => setForm({ ...form, reason: e.target.value })} /></Field>
              <div className="flex gap-2 md:col-span-2">
                <button className="btn-primary" disabled={!student || !form.reason || !form.hearing_date} onClick={() => act('/role-ops/discipline/suspend', { student_id: student.id, ...form }, 'Student suspended.')}>Suspend</button>
                <button className="btn-secondary" disabled={!student || !form.reason} onClick={() => window.confirm('Expel this student? Their login will be switched off.') && act('/role-ops/discipline/expel', { student_id: student.id, reason: form.reason }, 'Student expelled.')}>Expel</button>
              </div>
            </div>
          </Card>
          <Card title="Disciplinary cases">
            <Table head={['Student', 'Type', 'Reason', 'Hearing', 'Imposed', 'Status', '']} rows={cases.map((c) => [
              `${c.adm_no} · ${c.student_name}`, c.kind, c.reason, c.hearing_date || '—', `${when(c.imposed_at)}${c.imposed_by_name ? ` by ${c.imposed_by_name}` : ''}`, c.ended_at ? `Closed ${when(c.ended_at)}` : 'Open',
              !c.ended_at && c.kind === 'suspension' ? <button className="btn-ghost" onClick={() => act(`/role-ops/discipline/${c.id}/reinstate`, {}, 'Student reinstated.')}>Reinstate</button> : '',
            ])} empty="No disciplinary cases." />
          </Card>
        </>
      )}
    </>
  );
}

// ---------- curve suggestions ----------

function Curves({ canSuggest, canReview }) {
  const n = useNotice();
  const [rows, setRows] = useState([]);
  const [form, setForm] = useState({ course_code: '', adjustment: '', rationale: '' });
  const load = useCallback(() => api.get('/role-ops/curve-suggestions').then((r) => setRows(r.data)).catch(() => {}), []);
  useEffect(() => { load(); }, [load]);
  async function submit(e) { e.preventDefault(); try { await api.post('/role-ops/curve-suggestions', form); n.ok('Suggestion sent to the Examinations office.'); setForm({ course_code: '', adjustment: '', rationale: '' }); load(); } catch (err) { n.bad(err); } }
  async function decide(id, status) { try { await api.post(`/role-ops/curve-suggestions/${id}/decide`, { status }); load(); } catch (err) { n.bad(err); } }
  return (
    <>
      {n.view}
      {canSuggest && (
        <Card title="Suggest a grade-curve adjustment" hint="Your suggestion is reviewed by the Examinations office. You cannot change grades yourself.">
          <form onSubmit={submit} className="grid gap-4 md:grid-cols-2">
            <Field label="Course code"><input className="input" required value={form.course_code} onChange={(e) => setForm({ ...form, course_code: e.target.value })} /></Field>
            <Field label="Adjustment"><input className="input" required placeholder="+3 marks for all scripts" value={form.adjustment} onChange={(e) => setForm({ ...form, adjustment: e.target.value })} /></Field>
            <Field label="Why" wide><textarea className="input min-h-24" required value={form.rationale} onChange={(e) => setForm({ ...form, rationale: e.target.value })} /></Field>
            <div className="md:col-span-2"><button className="btn-primary">Send suggestion</button></div>
          </form>
        </Card>
      )}
      <Card title={canReview ? 'Curve suggestions to review' : 'My suggestions'}>
        <Table head={['Course', 'Adjustment', 'Why', 'From', 'Status', '']} rows={rows.map((r) => [
          r.course_code, r.adjustment, r.rationale, r.suggested_by_name || '—', r.status,
          canReview && r.status === 'pending' ? <span className="flex gap-1"><button className="btn-ghost" onClick={() => decide(r.id, 'accepted')}>Accept</button><button className="btn-ghost" onClick={() => decide(r.id, 'declined')}>Decline</button></span> : '',
        ])} />
      </Card>
    </>
  );
}

// ---------- senate and graduation ----------

function Senate({ canVote, canManage, canSign }) {
  const n = useNotice();
  const [motions, setMotions] = useState([]);
  const [list, setList] = useState([]);
  const [year, setYear] = useState(String(new Date().getFullYear()));
  const [picked, setPicked] = useState({});
  const [form, setForm] = useState({ title: '', motion_type: 'curriculum', details: '' });
  const load = useCallback(() => {
    api.get('/role-ops/senate/motions').then((r) => setMotions(r.data)).catch(() => {});
    if (canSign) api.get('/role-ops/senate/graduation-list', { params: { academic_year: year } }).then((r) => setList(r.data)).catch(() => {});
  }, [canSign, year]);
  useEffect(() => { load(); }, [load]);
  async function create(e) { e.preventDefault(); try { await api.post('/role-ops/senate/motions', form); n.ok('Motion opened for voting.'); setForm({ title: '', motion_type: 'curriculum', details: '' }); load(); } catch (err) { n.bad(err); } }
  async function vote(id, v) { try { await api.post(`/role-ops/senate/motions/${id}/vote`, { vote: v }); load(); } catch (err) { n.bad(err); } }
  async function close(id) { try { const { data } = await api.post(`/role-ops/senate/motions/${id}/close`); n.ok(`Motion ${data.status}.`); load(); } catch (err) { n.bad(err); } }
  async function sign() {
    const ids = Object.keys(picked).filter((k) => picked[k]).map(Number);
    try { const { data } = await api.post('/role-ops/senate/graduation-signoff', { academic_year: year, student_ids: ids }); n.ok(`${data.signed} student(s) signed off${data.skipped ? `, ${data.skipped} skipped (not ready)` : ''}.`); setPicked({}); load(); } catch (err) { n.bad(err); }
  }
  return (
    <>
      {n.view}
      {canManage && (
        <Card title="Open a motion" hint="Curriculum changes and new degree programmes go to the Senate for a vote.">
          <form onSubmit={create} className="grid gap-4 md:grid-cols-2">
            <Field label="Title"><input className="input" required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} /></Field>
            <Field label="Type"><select className="input" value={form.motion_type} onChange={(e) => setForm({ ...form, motion_type: e.target.value })}><option value="curriculum">Curriculum change</option><option value="degree_programme">New degree programme</option><option value="other">Other</option></select></Field>
            <Field label="Details" wide><textarea className="input min-h-20" value={form.details} onChange={(e) => setForm({ ...form, details: e.target.value })} /></Field>
            <div className="md:col-span-2"><button className="btn-primary">Open motion</button></div>
          </form>
        </Card>
      )}
      <Card title="Senate motions">
        <Table head={['Motion', 'Type', 'For', 'Against', 'Abstain', 'Status', '']} rows={motions.map((m) => [
          <span><strong>{m.title}</strong>{m.details && <span className="block text-xs text-ink/55">{m.details}</span>}</span>, m.motion_type.replace('_', ' '), m.tally.for, m.tally.against, m.tally.abstain,
          m.status === 'open' ? 'Open' : m.status,
          <span className="flex flex-wrap gap-1">
            {m.status === 'open' && canVote && ['for', 'against', 'abstain'].map((v) => <button key={v} className={m.my_vote === v ? 'btn-primary' : 'btn-ghost'} onClick={() => vote(m.id, v)}>{v}</button>)}
            {m.status === 'open' && canManage && <button className="btn-secondary" onClick={() => close(m.id)}>Close vote</button>}
          </span>,
        ])} empty="No motions yet." />
      </Card>
      {canSign && (
        <Card title="Final graduation list" hint="Tick the students who have completed their programme and sign them off.">
          <div className="mb-3 flex items-end gap-2"><label><span className="label">Academic year</span><input className="input !w-32" value={year} onChange={(e) => setYear(e.target.value)} /></label><button className="btn-primary" onClick={sign} disabled={!Object.values(picked).some(Boolean)}>Sign off selected</button></div>
          <Table head={['', 'Student', 'Academic', 'Senate']} rows={list.map((g) => [
            g.senate_status === 'approved' || g.academic_status !== 'ready' ? '' : <input type="checkbox" aria-label={`Select ${g.student_name}`} checked={Boolean(picked[g.student_id])} onChange={(e) => setPicked({ ...picked, [g.student_id]: e.target.checked })} />,
            `${g.adm_no} · ${g.student_name}`, g.academic_status, g.senate_status])} empty="No one is on the graduation list for this year." />
        </Card>
      )}
    </>
  );
}

function Graduation() {
  const n = useNotice();
  const [year, setYear] = useState(String(new Date().getFullYear()));
  const [list, setList] = useState([]);
  const load = useCallback(() => api.get('/role-ops/senate/graduation-list', { params: { academic_year: year } }).then((r) => setList(r.data)).catch(() => {}), [year]);
  useEffect(() => { load(); }, [load]);
  async function post(path, body, ok) { try { await api.post(path, body); n.ok(ok); load(); } catch (err) { n.bad(err); } }
  return (
    <Card title="Graduation clearance and gowns" hint="A student can be cleared once the academic requirements are met, Senate has signed off and there is no financial hold.">
      {n.view}
      <label className="mb-3 block"><span className="label">Academic year</span><input className="input !w-32" value={year} onChange={(e) => setYear(e.target.value)} /></label>
      <Table head={['Student', 'Academic', 'Senate', 'Cleared', 'Gown', '']} rows={list.map((g) => [
        `${g.adm_no} · ${g.student_name}`, g.academic_status, g.senate_status, g.cleared_at ? when(g.cleared_at) : 'No', g.gown_status || '—',
        <span className="flex gap-1">
          {!g.cleared_at && <button className="btn-ghost" onClick={() => post('/role-ops/graduation/clear', { student_id: g.student_id, academic_year: g.academic_year }, 'Student cleared for graduation.')}>Clear</button>}
          {g.cleared_at && g.gown_status !== 'issued' && <button className="btn-ghost" onClick={() => post('/role-ops/graduation/gown', { student_id: g.student_id, action: 'issue' }, 'Gown issued.')}>Issue gown</button>}
          {g.gown_status === 'issued' && <button className="btn-ghost" onClick={() => post('/role-ops/graduation/gown', { student_id: g.student_id, action: 'return' }, 'Gown returned.')}>Gown returned</button>}
        </span>])} empty="No one is on the graduation list for this year." />
    </Card>
  );
}

function Readmission() {
  const n = useNotice();
  const [rows, setRows] = useState([]);
  const load = useCallback(() => api.get('/role-ops/readmission').then((r) => setRows(r.data)).catch(() => {}), []);
  useEffect(() => { load(); }, [load]);
  async function decide(id, approve) {
    const note = window.prompt(approve ? 'Note for the student (optional):' : 'Why is the request declined?') ?? null;
    if (note === null) return;
    try { await api.post(`/role-ops/readmission/${id}/decide`, { approve, note }); n.ok(approve ? 'Student readmitted.' : 'Request declined.'); load(); } catch (err) { n.bad(err); }
  }
  return (
    <Card title="Readmission requests" hint="Approving returns the student to Active status.">
      {n.view}
      <Table head={['Student', 'Reason', 'Requested', 'Status', '']} rows={rows.map((r) => [`${r.adm_no} · ${r.student_name}`, r.reason, when(r.requested_at), r.status,
        r.status === 'pending' ? <span className="flex gap-1"><button className="btn-ghost" onClick={() => decide(r.id, true)}>Approve</button><button className="btn-ghost" onClick={() => decide(r.id, false)}>Decline</button></span> : r.decision_note || ''])} empty="No requests." />
    </Card>
  );
}

// ---------- helpdesk ----------

function Helpdesk({ level2 }) {
  const n = useNotice();
  const [users, setUsers] = useState([]);
  const [q, setQ] = useState('');
  const [secret, setSecret] = useState(null);
  const [checks, setChecks] = useState([]);
  const { roleOptions } = useRoleOptions();
  const load = useCallback(() => api.get('/users').then((r) => setUsers(r.data)).catch(n.bad), []); // eslint-disable-line
  useEffect(() => { load(); }, [load]);
  const loadChecks = useCallback(() => { if (level2) api.get('/role-ops/helpdesk/integrity').then((r) => setChecks(r.data)).catch(() => {}); }, [level2]);
  useEffect(() => { loadChecks(); }, [loadChecks]);
  const shown = useMemo(() => users.filter((u) => u.role !== 'admin' && `${u.name} ${u.email} ${u.reference_no || ''}`.toLowerCase().includes(q.toLowerCase())).slice(0, 30), [users, q]);
  async function run(fn, ok) { try { const r = await fn(); if (ok) n.ok(ok); load(); return r; } catch (e) { n.bad(e); return null; } }
  async function reset(u) {
    if (!window.confirm(`Reset the password for ${u.name}?`)) return;
    const r = await run(() => api.put(`/users/${u.id}/password`, {}));
    if (r) setSecret({ name: r.data.name, email: r.data.email, password: r.data.password });
  }
  async function phone(u) {
    const value = window.prompt(`New phone number for ${u.name}:`);
    if (!value) return;
    await run(() => api.put(`/users/${u.id}/contact`, { phone: value }), 'Contact details updated.');
  }
  async function changeRole(u, role) {
    if (!role || role === u.role) return;
    if (!window.confirm(`Change ${u.name} to ${role.replaceAll('_', ' ')}? They will be signed out.`)) return;
    await run(() => api.put(`/users/${u.id}/role`, { role }), 'Role changed.');
  }
  async function fix(key) { const r = await run(() => api.post('/role-ops/helpdesk/integrity/fix', { check: key })); if (r) { n.ok(`Removed ${r.data.removed} broken row(s).`); setChecks(r.data.checks); } }
  return (
    <>
      {n.view}
      {secret && (
        <div className="mb-4 rounded-xl border border-gold/40 bg-gold/10 p-4 text-sm">
          <p className="font-semibold">New password for {secret.name} ({secret.email})</p>
          <p className="mt-1 font-mono text-base">{secret.password}</p>
          <p className="mt-1 text-xs text-ink/60">Shown once. Give it to the account owner securely.</p>
          <button className="btn-ghost mt-2" onClick={() => setSecret(null)}>Done</button>
        </div>
      )}
      <Card title="Find an account" hint={level2 ? 'Level 2: reset passwords, unlock accounts, update contact details and change roles.' : 'Level 1: reset passwords, unlock accounts and update contact details.'}>
        <input className="input mb-3 max-w-md" placeholder="Search by name, email or ID number" value={q} onChange={(e) => setQ(e.target.value)} />
        <Table head={['Name', 'Email', 'Role', 'State', 'Actions']} rows={shown.map((u) => {
          const locked = u.locked_until && new Date(u.locked_until.replace(' ', 'T') + 'Z') > new Date();
          return [u.name, u.email,
            level2 ? <select className="input !w-48" value={u.role} onChange={(e) => changeRole(u, e.target.value)}>{roleOptions.map((r) => <option key={r.value} value={r.value}>{r.label}</option>)}</select> : u.role.replaceAll('_', ' '),
            u.active ? (locked ? 'Locked' : 'Active') : 'Deactivated',
            <span className="flex flex-wrap gap-1">
              <button className="btn-ghost" onClick={() => reset(u)}>Reset password</button>
              <button className="btn-ghost" onClick={() => run(() => api.post(`/users/${u.id}/unlock`), 'Account unlocked.')}>Unlock</button>
              {!u.active && <button className="btn-ghost" onClick={() => run(() => api.put(`/users/${u.id}/status`, { active: true }), 'Account reactivated.')}>Reactivate</button>}
              <button className="btn-ghost" onClick={() => phone(u)}>Update phone</button>
            </span>];
        })} empty="No matching accounts." />
      </Card>
      {level2 && (
        <Card title="Data integrity" hint="Finds broken records. Fixing removes rows that point at a student or unit that no longer exists.">
          <Table head={['Check', 'Problems found', '']} rows={checks.map((c) => [c.label, c.count, c.fixable && c.count > 0 ? <button className="btn-secondary" onClick={() => fix(c.key)}>Fix now</button> : ''])} />
          <button className="btn-ghost mt-3" onClick={loadChecks}>Run checks again</button>
        </Card>
      )}
    </>
  );
}

// Role list for the helpdesk role picker: everything except Super Administrator and Machine User.
function useRoleOptions() {
  const roleOptions = useMemo(() => ROLE_OPTIONS_FOR_HELPDESK, []);
  return { roleOptions };
}
import { ROLE_OPTIONS } from '../config/roles.js';
const ROLE_OPTIONS_FOR_HELPDESK = ROLE_OPTIONS.filter((r) => !['admin', 'machine_user'].includes(r.value));

// ---------- audit ----------

function Audit() {
  const [data, setData] = useState(null);
  const n = useNotice();
  useEffect(() => { api.get('/role-ops/audit/overview').then((r) => setData(r.data)).catch(n.bad); }, []); // eslint-disable-line
  if (!data) return n.view || <p className="text-sm text-ink/55">Loading…</p>;
  return (
    <>
      <Card title="Failed sign-ins by address (last 24 hours)"><Table head={['IP address', 'Failures']} rows={data.failed_by_ip.map((r) => [r.ip || '—', r.failures])} empty="No failed sign-ins." /></Card>
      <Card title="Changes to grades and results" hint="Who changed marks, grade locks and result approvals, and from where.">
        <Table head={['When', 'Who', 'Action', 'Details']} rows={[
          ...data.grade_changes.map((g) => [when(g.created_at), g.user_name || '—', g.action, g.details]),
          ...data.result_changes.map((g) => [when(g.created_at), g.user_name || '—', `${g.module}: ${g.action}`, `${g.reason || ''} ${g.ip ? `(IP ${g.ip})` : ''}`]),
        ].sort((a, b) => String(b[0]).localeCompare(String(a[0]))).slice(0, 100)} empty="No grade changes recorded." />
      </Card>
      <Card title="Account changes"><Table head={['When', 'Who', 'Action', 'Details']} rows={data.account_changes.map((g) => [when(g.created_at), g.user_name || '—', g.action, g.details])} empty="No account changes." /></Card>
      <Card title="Sign-in log"><Table head={['When', 'Email', 'Result', 'IP address']} rows={data.logins.map((l) => [when(l.attempted_at), l.email, l.success ? 'Signed in' : 'Failed', l.ip || '—'])} /></Card>
    </>
  );
}

// ---------- counselling ----------

function Counselling() {
  const n = useNotice();
  const [rows, setRows] = useState([]);
  const [student, setStudent] = useState(null);
  const [form, setForm] = useState({ session_date: new Date().toISOString().slice(0, 10), topic: '', notes: '' });
  const load = useCallback(() => api.get('/role-ops/counselling').then((r) => setRows(r.data)).catch(() => {}), []);
  useEffect(() => { load(); }, [load]);
  async function save(e) { e.preventDefault(); try { await api.post('/role-ops/counselling', { student_id: student?.id, ...form }); n.ok('Session logged. Only you can read these notes.'); setForm({ ...form, topic: '', notes: '' }); setStudent(null); load(); } catch (err) { n.bad(err); } }
  return (
    <>
      <Card title="Log a session" hint="Session notes are private to you. No administrator, including the Super Administrator, can open them.">
        {n.view}
        <form onSubmit={save} className="grid gap-4 md:grid-cols-2">
          <StudentPicker value={student} onChange={setStudent} />
          <Field label="Date"><input type="date" className="input" value={form.session_date} onChange={(e) => setForm({ ...form, session_date: e.target.value })} /></Field>
          <Field label="Topic" wide><input className="input" value={form.topic} onChange={(e) => setForm({ ...form, topic: e.target.value })} /></Field>
          <Field label="Private notes" wide><textarea className="input min-h-28" value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></Field>
          <div className="md:col-span-2"><button className="btn-primary" disabled={!student}>Save session</button></div>
        </form>
      </Card>
      <Card title="My sessions"><Table head={['Date', 'Student', 'Topic', 'Notes']} rows={rows.map((r) => [r.session_date, `${r.adm_no} · ${r.student_name}`, r.topic || '—', r.notes || '—'])} empty="No sessions logged." /></Card>
    </>
  );
}

// ---------- super administrator ----------

function AdminTools() {
  const n = useNotice();
  const { viewAs } = useAuth();
  const [keys, setKeys] = useState({ keys: [], machine_users: [] });
  const [form, setForm] = useState({ user_id: '', name: '', scopes: '', expires_at: '' });
  const [secret, setSecret] = useState(null);
  const [runs, setRuns] = useState([]);
  const [users, setUsers] = useState([]);
  const [who, setWho] = useState('');
  const [sql, setSql] = useState('SELECT role, COUNT(*) AS accounts FROM users GROUP BY role ORDER BY accounts DESC');
  const [out, setOut] = useState(null);
  const loadKeys = useCallback(() => {
    api.get('/role-ops/api-keys').then((r) => setKeys(r.data)).catch(() => {});
    api.get('/role-ops/machine/job-runs').then((r) => setRuns(r.data)).catch(() => {});
  }, []);
  useEffect(() => { loadKeys(); api.get('/users').then((r) => setUsers(r.data)).catch(() => {}); }, [loadKeys]);
  async function createKey(e) {
    e.preventDefault();
    try { const { data } = await api.post('/role-ops/api-keys', form); setSecret(data.api_key); setForm({ user_id: '', name: '', scopes: '', expires_at: '' }); loadKeys(); } catch (err) { n.bad(err); }
  }
  async function revoke(id) { if (!window.confirm('Revoke this key? Jobs using it will stop working.')) return; try { await api.post(`/role-ops/api-keys/${id}/revoke`); loadKeys(); } catch (err) { n.bad(err); } }
  async function runSql(e) { e.preventDefault(); try { const { data } = await api.post('/role-ops/sql', { query: sql }); setOut(data); } catch (err) { setOut(null); n.bad(err); } }
  async function startView() {
    if (!who) return;
    try { await viewAs(Number(who)); window.location.assign('/'); } catch (err) { n.bad(err); }
  }
  const cols = out && out.rows[0] ? Object.keys(out.rows[0]) : [];
  return (
    <>
      {n.view}
      <Card title="View as another user" hint="See the system exactly as that person sees it, for debugging. The view is read-only, lasts one hour and is recorded in the audit log.">
        <div className="flex flex-wrap gap-2">
          <select className="input max-w-md" value={who} onChange={(e) => setWho(e.target.value)}>
            <option value="">Choose a user…</option>
            {users.filter((u) => u.role !== 'admin' && u.role !== 'machine_user' && u.active).map((u) => <option key={u.id} value={u.id}>{u.name} · {u.role.replaceAll('_', ' ')}</option>)}
          </select>
          <button className="btn-primary" disabled={!who} onClick={startView}>View as this user</button>
        </div>
      </Card>
      <Card title="API keys for machine users" hint="Create a Machine User account first (Staff & User Management). Its key lets automated jobs and integrations call the API. Keys are shown once.">
        {secret && (
          <div className="mb-4 rounded-xl border border-gold/40 bg-gold/10 p-4 text-sm">
            <p className="font-semibold">Copy this key now. It cannot be shown again.</p>
            <p className="mt-1 break-all font-mono">{secret}</p>
            <button className="btn-ghost mt-2" onClick={() => setSecret(null)}>I have copied it</button>
          </div>
        )}
        <form onSubmit={createKey} className="mb-4 grid gap-4 md:grid-cols-2">
          <Field label="Machine user"><select className="input" required value={form.user_id} onChange={(e) => setForm({ ...form, user_id: e.target.value })}><option value="">Choose…</option>{keys.machine_users.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}</select></Field>
          <Field label="Key name"><input className="input" required placeholder="Midnight penalty fees" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Field>
          <Field label="Allowed jobs (comma separated, blank = any)"><input className="input" placeholder="late-fees, moodle-sync" value={form.scopes} onChange={(e) => setForm({ ...form, scopes: e.target.value })} /></Field>
          <Field label="Expires (optional)"><input type="date" className="input" value={form.expires_at} onChange={(e) => setForm({ ...form, expires_at: e.target.value })} /></Field>
          <div className="md:col-span-2"><button className="btn-primary">Create key</button></div>
        </form>
        <Table head={['Name', 'Machine user', 'Key starts with', 'Last used', 'Expires', 'State', '']} rows={keys.keys.map((k) => [k.name, k.machine_name, k.key_prefix, when(k.last_used_at), k.expires_at || '—', k.revoked_at ? 'Revoked' : 'Active', k.revoked_at ? '' : <button className="btn-ghost" onClick={() => revoke(k.id)}>Revoke</button>])} empty="No keys yet." />
      </Card>
      <Card title="Recent machine job runs"><Table head={['When', 'Machine', 'Job', 'Status', 'Details']} rows={runs.map((r) => [when(r.ran_at), r.machine_name, r.job, r.status, r.details || ''])} empty="No job runs reported yet." /></Card>
      <Card title="Database query (read-only)" hint="SELECT statements only, 500 rows at most. Password, secret and counselling-note columns are blocked. Every query is logged.">
        <form onSubmit={runSql}>
          <textarea className="input min-h-24 font-mono text-sm" value={sql} onChange={(e) => setSql(e.target.value)} aria-label="SQL query" />
          <button className="btn-primary mt-2">Run query</button>
        </form>
        {out && <div className="mt-4"><p className="mb-2 text-xs text-ink/55">{out.rows.length} row(s){out.truncated ? ' (limited to 500)' : ''}</p><Table head={cols} rows={out.rows.map((r) => cols.map((c) => String(r[c] ?? '')))} empty="The query returned no rows." /></div>}
      </Card>
    </>
  );
}

function MachineInfo() {
  return <Card title="API-only account" hint="This account signs in with an API key, never a password. Report job results to POST /api/role-ops/machine/job-runs with the X-API-Key header." />;
}

// ---------- student status (suspended / deferred / holds) ----------

function MyStatus({ canApply }) {
  const n = useNotice();
  const [data, setData] = useState(null);
  const [reason, setReason] = useState('');
  const load = useCallback(() => api.get('/role-ops/my-status').then((r) => setData(r.data)).catch(n.bad), []); // eslint-disable-line
  useEffect(() => { load(); }, [load]);
  async function apply(e) {
    e.preventDefault();
    try { await api.post('/role-ops/readmission', { reason }); n.ok('Your readmission request was sent to the Registrar.'); setReason(''); load(); } catch (err) { n.bad(err); }
  }
  if (!data) return <p className="text-sm text-ink/55">Loading…</p>;
  const { student, suspension, hold, readmission } = data;
  return (
    <>
      {n.view}
      {suspension && (
        <Card title={suspension.kind === 'expulsion' ? 'Your enrolment has ended' : 'Your account is suspended'} hint="You can only see this page until the case is closed.">
          <p className="text-sm text-ink"><strong>Reason:</strong> {suspension.reason}</p>
          {suspension.hearing_date && <p className="mt-2 text-sm text-ink"><strong>Disciplinary hearing:</strong> {suspension.hearing_date}</p>}
          <p className="mt-2 text-xs text-ink/55">Suspended on {when(suspension.imposed_at)}. Please contact the Disciplinary Committee about the hearing.</p>
        </Card>
      )}
      {hold && (
        <Card title="Financial hold" hint="Unit registration and document requests are paused until the hold is released.">
          <p className="text-sm text-ink"><strong>Reason:</strong> {hold.reason}{hold.amount ? ` (KES ${Number(hold.amount).toLocaleString()})` : ''}</p>
          <p className="mt-2 text-xs text-ink/55">Placed on {when(hold.placed_at)}. Please contact Student Accounts.</p>
        </Card>
      )}
      {readmission && (
        <Card title="Readmission request">
          <p className="text-sm text-ink">{readmission.reason}</p>
          <p className="mt-2 text-xs text-ink/55">Status: {readmission.status}{readmission.decision_note ? `. ${readmission.decision_note}` : ''}</p>
        </Card>
      )}
      {canApply && (!readmission || readmission.status !== 'pending') && (
        <Card title="Apply for readmission" hint="You are on leave. Tell the Registrar why you want to return.">
          <form onSubmit={apply}>
            <textarea className="input min-h-24" required value={reason} onChange={(e) => setReason(e.target.value)} aria-label="Reason for returning" />
            <button className="btn-primary mt-2">Send request</button>
          </form>
        </Card>
      )}
      {!suspension && !hold && !readmission && !canApply && <Card title="Your account"><p className="text-sm text-ink/70">{student ? `${student.adm_no} · ${student.name}: no holds or restrictions.` : 'No student record is linked to this login.'}</p></Card>}
    </>
  );
}

// ---------- the desk ----------

const TABS = [
  { id: 'status', label: 'My Status', caps: ['status.view', 'readmission.apply'], render: (c) => <MyStatus canApply={c('readmission.apply')} /> },
  { id: 'grade', label: 'Grade Lock', caps: ['grade.lock'], render: () => <GradeLock /> },
  { id: 'holds', label: 'Financial Holds', caps: ['holds.manage'], render: () => <Holds /> },
  { id: 'gate', label: 'Gate Scanner', caps: ['gate.scan'], render: (c) => <Gate canBan={c('campus.ban')} /> },
  { id: 'invig', label: 'Exam Attendance', caps: ['exam.invigilate'], render: () => <Invigilation /> },
  { id: 'discipline', label: 'Discipline', caps: ['malpractice.view', 'discipline.act'], render: (c) => <Discipline canAct={c('discipline.act')} /> },
  { id: 'curve', label: 'Grade Curves', caps: ['curve.suggest', 'curve.review'], render: (c) => <Curves canSuggest={c('curve.suggest')} canReview={c('curve.review')} /> },
  { id: 'senate', label: 'Senate', caps: ['senate.vote', 'senate.manage', 'graduation.signoff'], render: (c) => <Senate canVote={c('senate.vote')} canManage={c('senate.manage')} canSign={c('graduation.signoff')} /> },
  { id: 'graduation', label: 'Graduation', caps: ['graduation.clear'], render: () => <Graduation /> },
  { id: 'readmission', label: 'Readmission', caps: ['readmission.review'], render: () => <Readmission /> },
  { id: 'helpdesk', label: 'User Support', caps: ['helpdesk.l1', 'helpdesk.l2'], render: (c) => <Helpdesk level2={c('helpdesk.l2')} /> },
  { id: 'audit', label: 'Audit Trail', caps: ['audit.read'], render: () => <Audit /> },
  { id: 'counselling', label: 'Counselling', caps: ['counselling.notes'], render: () => <Counselling /> },
  { id: 'admin', label: 'Admin Tools', caps: ['apikeys.manage'], render: () => <AdminTools /> },
  { id: 'machine', label: 'API Access', caps: ['machine.run'], render: () => <MachineInfo /> },
];

export default function RoleDesk() {
  const { user } = useAuth();
  const actual = user?.actual_role || user?.role;
  const can = useCallback((cap) => hasCap(actual, cap), [actual]);
  const tabs = useMemo(() => TABS.filter((t) => t.caps.some(can)), [can]);
  const [tab, setTab] = useState(() => { try { return sessionStorage.getItem('desk_tab') || ''; } catch (_) { return ''; } });
  const [me, setMe] = useState(null);
  useEffect(() => { api.get('/role-ops/me').then((r) => setMe(r.data)).catch(() => {}); }, []);
  const current = tabs.find((t) => t.id === tab) || tabs[0];
  const info = roleInfo(actual);
  function pick(id) { setTab(id); try { sessionStorage.setItem('desk_tab', id); } catch (_) { /* optional */ } }
  return (
    <DashboardLayout title="My Role Desk" subtitle={info ? `${info.label}: ${info.description}` : ''}>
      {me?.temporary && (
        <div className="mb-4 rounded-xl bg-gold/10 p-3 text-sm text-ink">This is a temporary account{me.access_expires_at ? `. Access ends on ${String(me.access_expires_at).slice(0, 10)}.` : '.'}</div>
      )}
      {me?.read_only && <div className="mb-4 rounded-xl bg-sage/40 p-3 text-sm text-ink">This role has read-only access to the rest of the system.</div>}
      {tabs.length === 0 && <p className="text-sm text-ink/55">Your role has no desk tools. Use the menu to open your pages.</p>}
      {tabs.length > 1 && (
        <div role="tablist" className="mb-5 flex flex-wrap gap-2">
          {tabs.map((t) => (
            <button key={t.id} role="tab" aria-selected={current?.id === t.id} onClick={() => pick(t.id)}
              className={current?.id === t.id ? 'btn-primary' : 'btn-secondary'}>{t.label}</button>
          ))}
        </div>
      )}
      {current && <div key={current.id}>{current.render(can)}</div>}
    </DashboardLayout>
  );
}
