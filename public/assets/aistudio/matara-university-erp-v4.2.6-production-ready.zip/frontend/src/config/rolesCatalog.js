// AUTO-GENERATED from backend/lib/roles.js by scripts/sync-roles.js. Do not edit by hand.
export const ROLE_CATEGORIES = [
  {
    "key": "system",
    "label": "1. System & IT Operations"
  },
  {
    "key": "executive",
    "label": "2. Executive & Governance"
  },
  {
    "key": "registry",
    "label": "3. Academic Administration (Registrar)"
  },
  {
    "key": "exams",
    "label": "4. Examination & Assessment"
  },
  {
    "key": "faculty",
    "label": "5. Faculty & Instruction"
  },
  {
    "key": "finance",
    "label": "6. Financial Operations (Bursary)"
  },
  {
    "key": "students",
    "label": "7. Student States"
  },
  {
    "key": "welfare",
    "label": "8. Student Welfare & Campus Life"
  },
  {
    "key": "security",
    "label": "9. Security & Logistics"
  },
  {
    "key": "other",
    "label": "Other staff roles"
  }
];

export const ROLE_CATALOG = [
  {
    "value": "admin",
    "label": "Super Administrator (Root)",
    "group": null,
    "category": "system",
    "acts_as": "admin",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [
      "apikeys.manage",
      "impersonate",
      "sql.read",
      "audit.read",
      "helpdesk.l1",
      "helpdesk.l2",
      "grade.lock",
      "holds.manage",
      "gate.scan",
      "campus.ban",
      "exam.invigilate",
      "malpractice.view",
      "discipline.act",
      "curve.review",
      "senate.manage",
      "graduation.clear",
      "readmission.review"
    ],
    "description": "Broad technical administration. Privileged actions remain logged; official academic and financial decisions must follow their approval workflows, and credentials are never readable in plaintext."
  },
  {
    "value": "security_audit_officer",
    "label": "Security & Audit Officer",
    "group": "staff",
    "category": "system",
    "acts_as": "auditor",
    "read_only": true,
    "temporary": false,
    "limited_nav": false,
    "caps": [
      "audit.read"
    ],
    "description": "Read-only access to all audit logs. Tracks IP addresses, login times and changes to grade tables to detect internal fraud."
  },
  {
    "value": "helpdesk_l1",
    "label": "Helpdesk Level 1",
    "group": "staff",
    "category": "system",
    "acts_as": "staff",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [
      "helpdesk.l1"
    ],
    "description": "Resets passwords, unlocks accounts and updates basic contact details. Cannot view grades or financial ledgers."
  },
  {
    "value": "helpdesk_l2",
    "label": "Helpdesk Level 2 (Technical)",
    "group": "staff",
    "category": "system",
    "acts_as": "ict",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [
      "helpdesk.l1",
      "helpdesk.l2"
    ],
    "description": "Everything Level 1 can do, plus changing user roles, fixing broken enrolments and running data-integrity checks."
  },
  {
    "value": "machine_user",
    "label": "Machine User / API Agent",
    "group": null,
    "category": "system",
    "acts_as": "staff",
    "read_only": true,
    "temporary": false,
    "limited_nav": false,
    "caps": [
      "machine.run"
    ],
    "description": "Non-human account with a dedicated API key. Runs automated jobs (for example midnight penalty fees) and integrations such as Moodle, payment gateways and loan boards. Cannot sign in with a password."
  },
  {
    "value": "vice_chancellor",
    "label": "Vice Chancellor / President",
    "group": "staff",
    "category": "executive",
    "acts_as": "vice_chancellor",
    "read_only": true,
    "temporary": false,
    "limited_nav": false,
    "caps": [],
    "description": "Global analytics (revenue, enrolment, graduation rates). View-only: does not handle day-to-day data entry. Can still send messages and manage their own account security."
  },
  {
    "value": "deputy_vc",
    "label": "Deputy Vice Chancellor",
    "group": "staff",
    "category": "executive",
    "acts_as": "deputy_vc",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [],
    "description": "Deputy to the Vice Chancellor."
  },
  {
    "value": "senate_member",
    "label": "University Senate / Board Member",
    "group": "staff",
    "category": "executive",
    "acts_as": "exam_board",
    "read_only": true,
    "temporary": false,
    "limited_nav": false,
    "caps": [
      "senate.vote",
      "senate.manage",
      "graduation.signoff"
    ],
    "description": "Votes on curriculum changes, approves new degree programmes and digitally signs off the final graduation list."
  },
  {
    "value": "quality_assurance_director",
    "label": "Quality Assurance Director",
    "group": "staff",
    "category": "executive",
    "acts_as": "exam_board",
    "read_only": true,
    "temporary": false,
    "limited_nav": false,
    "caps": [],
    "description": "Reads course structures to confirm syllabi and exam formats meet national accreditation standards."
  },
  {
    "value": "registrar",
    "label": "Chief Academic Registrar",
    "group": "staff",
    "category": "registry",
    "acts_as": "registrar",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [
      "curve.review",
      "graduation.clear",
      "senate.manage",
      "readmission.review"
    ],
    "description": "Final authority on the student lifecycle: mass graduation, inter-faculty transfers and degree revocation."
  },
  {
    "value": "deputy_registrar",
    "label": "Deputy Registrar",
    "group": "staff",
    "category": "registry",
    "acts_as": "deputy_registrar",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [],
    "description": "Deputy to the Chief Academic Registrar."
  },
  {
    "value": "admissions_officer",
    "label": "Admissions Officer",
    "group": "staff",
    "category": "registry",
    "acts_as": "admissions_officer",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [],
    "description": "Processes applications, verifies index numbers, triggers acceptance letters and converts applicants to students."
  },
  {
    "value": "timetabling_officer",
    "label": "Timetabling & Scheduling Officer",
    "group": "staff",
    "category": "registry",
    "acts_as": "facilities_officer",
    "read_only": true,
    "temporary": false,
    "limited_nav": false,
    "caps": [],
    "description": "Books lecture halls, manages capacity, allocates time slots and resolves clashes."
  },
  {
    "value": "transcript_clerk",
    "label": "Transcript & Certification Clerk",
    "group": "staff",
    "category": "registry",
    "acts_as": "examination_officer",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [],
    "description": "Generates, signs and prints official transcripts and degree certificates. Cannot approve or change results."
  },
  {
    "value": "graduation_coordinator",
    "label": "Graduation Coordinator",
    "group": "staff",
    "category": "registry",
    "acts_as": "deputy_registrar",
    "read_only": true,
    "temporary": false,
    "limited_nav": false,
    "caps": [
      "graduation.clear"
    ],
    "description": "Runs the graduation module, clears students for the ceremony and manages gown issuance."
  },
  {
    "value": "examinations_director",
    "label": "Examinations Director",
    "group": "staff",
    "category": "exams",
    "acts_as": "examination_officer",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [
      "grade.lock",
      "exam.invigilate",
      "malpractice.view",
      "curve.review"
    ],
    "description": "Sets the grading timeline and triggers the Grade Lock that removes lecturer editing once the deadline passes."
  },
  {
    "value": "examination_officer",
    "label": "Examination Officer",
    "group": "staff",
    "category": "exams",
    "acts_as": "examination_officer",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [
      "exam.invigilate",
      "malpractice.view",
      "curve.review"
    ],
    "description": "Supports the Examinations Director with exam administration."
  },
  {
    "value": "exam_board",
    "label": "Examination Board",
    "group": "staff",
    "category": "exams",
    "acts_as": "exam_board",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [
      "curve.review"
    ],
    "description": "Approves results before publication."
  },
  {
    "value": "exam_invigilator",
    "label": "Exam Invigilator",
    "group": "staff",
    "category": "exams",
    "acts_as": "staff",
    "read_only": false,
    "temporary": true,
    "limited_nav": false,
    "caps": [
      "exam.invigilate"
    ],
    "description": "Temporary access in exam weeks. Scans student IDs to mark real-time attendance and flags malpractice."
  },
  {
    "value": "external_examiner",
    "label": "External Examiner / Moderator",
    "group": "staff",
    "category": "exams",
    "acts_as": "exam_board",
    "read_only": true,
    "temporary": true,
    "limited_nav": false,
    "caps": [
      "curve.suggest"
    ],
    "description": "Temporary read-only access to graded scripts and score distributions. Can suggest grade-curve adjustments."
  },
  {
    "value": "disciplinary_member",
    "label": "Disciplinary Committee Member",
    "group": "staff",
    "category": "exams",
    "acts_as": "student_affairs_officer",
    "read_only": true,
    "temporary": false,
    "limited_nav": false,
    "caps": [
      "discipline.act",
      "malpractice.view"
    ],
    "description": "Reads conduct records and malpractice logs, and can suspend, reinstate or expel a student."
  },
  {
    "value": "dean",
    "label": "Dean of Faculty",
    "group": "staff",
    "category": "faculty",
    "acts_as": "dean",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [],
    "description": "Evaluates lecturers and approves faculty grade sheets before Senate."
  },
  {
    "value": "deputy_dean",
    "label": "Deputy Dean",
    "group": "staff",
    "category": "faculty",
    "acts_as": "deputy_dean",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [],
    "description": "Deputy to the Dean of Faculty."
  },
  {
    "value": "hod",
    "label": "Head of Department (HOD)",
    "group": "staff",
    "category": "faculty",
    "acts_as": "hod",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [],
    "description": "Assigns units to lecturers, views departmental analytics and approves course structures."
  },
  {
    "value": "lecturer",
    "label": "Primary Lecturer",
    "group": "teacher",
    "category": "faculty",
    "acts_as": "lecturer",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [],
    "description": "Uploads materials, enters CAT marks, submits final exam marks and logs attendance."
  },
  {
    "value": "senior_lecturer",
    "label": "Senior Lecturer",
    "group": "teacher",
    "category": "faculty",
    "acts_as": "senior_lecturer",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [],
    "description": "Senior teaching staff."
  },
  {
    "value": "professor",
    "label": "Professor",
    "group": "teacher",
    "category": "faculty",
    "acts_as": "professor",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [],
    "description": "Professorial teaching staff."
  },
  {
    "value": "academic_staff",
    "label": "Academic Staff",
    "group": "teacher",
    "category": "faculty",
    "acts_as": "academic_staff",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [],
    "description": "General academic staff."
  },
  {
    "value": "teaching_assistant",
    "label": "Teaching Assistant (TA) / Grader",
    "group": "teacher",
    "category": "faculty",
    "acts_as": "academic_staff",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [
      "marks.cat_only"
    ],
    "description": "Enters raw CAT marks and grades assignments. Cannot submit or alter final exam marks."
  },
  {
    "value": "lab_technician",
    "label": "Lab Technician / Instructor",
    "group": "teacher",
    "category": "faculty",
    "acts_as": "academic_staff",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [
      "marks.practical_only"
    ],
    "description": "Books lab equipment, manages lab safety clearances and enters practical assessment marks only."
  },
  {
    "value": "finance_director",
    "label": "Chief Financial Officer (CFO)",
    "group": "staff",
    "category": "finance",
    "acts_as": "finance_director",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [
      "holds.manage"
    ],
    "description": "All revenue streams, expense ledgers and financial forecasting dashboards."
  },
  {
    "value": "finance_officer",
    "label": "Finance Officer",
    "group": "staff",
    "category": "finance",
    "acts_as": "finance_officer",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [],
    "description": "Finance operations."
  },
  {
    "value": "billing_admin",
    "label": "Billing & Fee Structure Admin",
    "group": "staff",
    "category": "finance",
    "acts_as": "finance_officer",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [],
    "description": "Defines what each course costs per semester and configures late-fee penalties and billing cycles."
  },
  {
    "value": "collections_officer",
    "label": "Student Accounts / Collections Officer",
    "group": "staff",
    "category": "finance",
    "acts_as": "accounts",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [
      "holds.manage"
    ],
    "description": "Applies fee waivers, processes scholarships and bursaries, and places or releases Financial Holds."
  },
  {
    "value": "cashier",
    "label": "Cashier",
    "group": "staff",
    "category": "finance",
    "acts_as": "accounts",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [],
    "description": "Operates the finance window: cash and cheque deposits and printed receipts."
  },
  {
    "value": "procurement_officer",
    "label": "Procurement Officer",
    "group": "staff",
    "category": "finance",
    "acts_as": "procurement_officer",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [],
    "description": "Supply chain module and vendor bids."
  },
  {
    "value": "payroll_officer",
    "label": "Payroll Officer",
    "group": "staff",
    "category": "finance",
    "acts_as": "hr_officer",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [],
    "description": "Runs the HR ledger, staff salaries and statutory deductions."
  },
  {
    "value": "hr_director",
    "label": "HR Director",
    "group": "staff",
    "category": "finance",
    "acts_as": "hr_director",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [],
    "description": "Human resources leadership."
  },
  {
    "value": "hr_officer",
    "label": "HR Officer",
    "group": "staff",
    "category": "finance",
    "acts_as": "hr_officer",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [],
    "description": "Human resources operations."
  },
  {
    "value": "applicant",
    "label": "Prospective Applicant",
    "group": "staff",
    "category": "students",
    "acts_as": "applicant",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [],
    "description": "Application portal only: uploads IDs, writes essays, pays the application fee."
  },
  {
    "value": "student",
    "label": "Active Student",
    "group": "student",
    "category": "students",
    "acts_as": "student",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [],
    "description": "Registers for units, views timetable, downloads exam cards, pays fees and views transcripts."
  },
  {
    "value": "class_representative",
    "label": "Class Representative",
    "group": "student",
    "category": "students",
    "acts_as": "student",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [
      "grievance.submit"
    ],
    "description": "Standard student access plus class-wide grievances and direct messages to the HOD."
  },
  {
    "value": "deferred_student",
    "label": "Deferred / On-Leave Student",
    "group": "student",
    "category": "students",
    "acts_as": "student",
    "read_only": true,
    "temporary": false,
    "limited_nav": true,
    "caps": [
      "readmission.apply"
    ],
    "description": "Can sign in and view past records and apply for readmission. Unit registration and campus access are disabled."
  },
  {
    "value": "suspended_student",
    "label": "Suspended Student",
    "group": "student",
    "category": "students",
    "acts_as": "suspended",
    "read_only": false,
    "temporary": false,
    "limited_nav": true,
    "caps": [
      "status.view"
    ],
    "description": "Locked to a single page explaining the suspension and the disciplinary hearing date."
  },
  {
    "value": "alumni",
    "label": "Alumni",
    "group": "staff",
    "category": "students",
    "acts_as": "alumni",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [],
    "description": "Alumni directory, replacement transcripts and the job board."
  },
  {
    "value": "dean_of_students",
    "label": "Dean of Students",
    "group": "staff",
    "category": "welfare",
    "acts_as": "student_affairs_officer",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [],
    "description": "Student clubs, student union elections and welfare programmes."
  },
  {
    "value": "student_affairs_officer",
    "label": "Student Affairs Officer",
    "group": "staff",
    "category": "welfare",
    "acts_as": "student_affairs_officer",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [],
    "description": "Student welfare support."
  },
  {
    "value": "accommodation_officer",
    "label": "Hostel / Accommodation Manager",
    "group": "staff",
    "category": "welfare",
    "acts_as": "accommodation_officer",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [],
    "description": "Dormitory capacity, bed allocation, room changes and damage fines."
  },
  {
    "value": "janitorial_staff",
    "label": "Janitorial / Maintenance Staff",
    "group": "staff",
    "category": "welfare",
    "acts_as": "non_academic_staff",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [],
    "description": "Views and closes repair requests in the ticketing system."
  },
  {
    "value": "catering_manager",
    "label": "Catering / Mess Manager",
    "group": "staff",
    "category": "welfare",
    "acts_as": "staff",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [],
    "description": "Validates meal-plan subscriptions at the cafeteria."
  },
  {
    "value": "counselor",
    "label": "University Counselor / Therapist",
    "group": "staff",
    "category": "welfare",
    "acts_as": "counselor",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [
      "counselling.notes"
    ],
    "description": "Logs therapy appointments. Session notes are private to the counsellor who wrote them."
  },
  {
    "value": "medical_officer",
    "label": "Chief Medical Officer (Clinic)",
    "group": "staff",
    "category": "welfare",
    "acts_as": "medical_officer",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [],
    "description": "Student medical histories, prescriptions and official medical exemptions."
  },
  {
    "value": "sports_director",
    "label": "Sports & Athletics Director",
    "group": "staff",
    "category": "welfare",
    "acts_as": "staff",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [],
    "description": "Athletic scholarships, team rosters and sports facilities."
  },
  {
    "value": "chaplain",
    "label": "University Chaplain",
    "group": "staff",
    "category": "welfare",
    "acts_as": "staff",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [],
    "description": "Religious service spaces and religious societies."
  },
  {
    "value": "security_officer",
    "label": "Chief Security Officer (CSO)",
    "group": "staff",
    "category": "security",
    "acts_as": "security_officer",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [
      "gate.scan",
      "campus.ban"
    ],
    "description": "Reads physical access-control logs and can flag a student or staff ID as Banned from Campus."
  },
  {
    "value": "gate_guard",
    "label": "Gate / Access Control Guard",
    "group": "staff",
    "category": "security",
    "acts_as": "staff",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [
      "gate.scan"
    ],
    "description": "Scans IDs on a mobile screen. The result is simply Green (cleared) or Red (suspended / not registered)."
  },
  {
    "value": "transport_officer",
    "label": "Transport & Fleet Manager",
    "group": "staff",
    "category": "security",
    "acts_as": "transport_officer",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [],
    "description": "Assigns buses, schedules trips and validates transport passes."
  },
  {
    "value": "staff",
    "label": "General Staff",
    "group": "staff",
    "category": "other",
    "acts_as": "staff",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [],
    "description": "General Staff"
  },
  {
    "value": "accounts",
    "label": "Accounts / Bursar",
    "group": "staff",
    "category": "other",
    "acts_as": "accounts",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [],
    "description": "Accounts / Bursar"
  },
  {
    "value": "librarian",
    "label": "Librarian",
    "group": "staff",
    "category": "other",
    "acts_as": "librarian",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [],
    "description": "Librarian"
  },
  {
    "value": "nurse",
    "label": "Nurse / Medical",
    "group": "staff",
    "category": "other",
    "acts_as": "nurse",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [],
    "description": "Nurse / Medical"
  },
  {
    "value": "ict",
    "label": "ICT Officer",
    "group": "staff",
    "category": "other",
    "acts_as": "ict",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [],
    "description": "ICT Officer"
  },
  {
    "value": "non_academic_staff",
    "label": "Non-Academic Staff",
    "group": "staff",
    "category": "other",
    "acts_as": "non_academic_staff",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [],
    "description": "Non-Academic Staff"
  },
  {
    "value": "stores_officer",
    "label": "Stores Officer",
    "group": "staff",
    "category": "other",
    "acts_as": "stores_officer",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [],
    "description": "Stores Officer"
  },
  {
    "value": "asset_officer",
    "label": "Asset Officer",
    "group": "staff",
    "category": "other",
    "acts_as": "asset_officer",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [],
    "description": "Asset Officer"
  },
  {
    "value": "facilities_officer",
    "label": "Facilities Officer",
    "group": "staff",
    "category": "other",
    "acts_as": "facilities_officer",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [],
    "description": "Facilities Officer"
  },
  {
    "value": "research_officer",
    "label": "Research Officer",
    "group": "staff",
    "category": "other",
    "acts_as": "research_officer",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [],
    "description": "Research Officer"
  },
  {
    "value": "auditor",
    "label": "Auditor",
    "group": "staff",
    "category": "other",
    "acts_as": "auditor",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [],
    "description": "Auditor"
  },
  {
    "value": "teacher",
    "label": "Teacher (legacy)",
    "group": "teacher",
    "category": "other",
    "acts_as": "teacher",
    "read_only": false,
    "temporary": false,
    "limited_nav": false,
    "caps": [],
    "description": "Original teaching role from earlier versions."
  }
];
