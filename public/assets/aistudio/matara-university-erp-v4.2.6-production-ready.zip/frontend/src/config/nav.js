import {
  LayoutDashboard, Users, UsersRound, GraduationCap, BookOpen, ClipboardCheck, Megaphone,
  Landmark, FileQuestion, ClipboardPenLine, CalendarDays, Bus, ShieldAlert, BarChart3,
  Library, Stethoscope, BedDouble, MessageSquare, ListChecks, BookOpenCheck, Award, FilePenLine, Wallet, ClipboardList, Building2, LifeBuoy, KeyRound, CreditCard, FileText,
} from 'lucide-react';
import { effectiveRole, hasDesk } from './roles.js';

// Single source of truth for role-based navigation.
// Sidebar (desktop) and Topbar (mobile menu) both read from here,
// so a route only ever needs to be added in one place.
// Staff, accounts, librarian, nurse and ICT accounts share one simple menu
const STAFF_NAV = [
  { to: '/staff', label: 'My Dashboard', icon: LayoutDashboard, end: true },
  { to: '/staff/messages', label: 'Messages', icon: MessageSquare },
  { to: '/staff/announcements', label: 'Announcements', icon: Megaphone },
  { to: '/calendar', label: 'University Calendar', icon: CalendarDays },
  { to: '/help-desk', label: 'Help & Service Desk', icon: LifeBuoy },
  { to: '/profile', label: 'My Profile & Security', icon: UsersRound },
];

const STAFF_ROLE_NAV = {
  staff: STAFF_NAV,
  accounts: [
    ...STAFF_NAV.slice(0, 1),
    { to: '/staff/finance', label: 'Finance Desk', icon: Landmark },
    ...STAFF_NAV.slice(1),
  ],
  librarian: [
    ...STAFF_NAV.slice(0, 1),
    { to: '/staff/library', label: 'Library Desk', icon: Library },
    ...STAFF_NAV.slice(1),
  ],
  nurse: [
    ...STAFF_NAV.slice(0, 1),
    { to: '/staff/medical', label: 'Medical Desk', icon: Stethoscope },
    ...STAFF_NAV.slice(1),
  ],
  ict: [
    ...STAFF_NAV.slice(0, 1),
    { to: '/admin/student-cards', label: 'Student ID & Exam Cards', icon: CreditCard },
    { to: '/staff/system', label: 'System Operations', icon: ShieldAlert },
    ...STAFF_NAV.slice(1),
  ],
};


const UNIVERSITY_NAV = [
  { to: '/university', label: 'University Overview', icon: LayoutDashboard, end: true },
  { to: '/calendar', label: 'University Calendar', icon: CalendarDays },
  { to: '/help-desk', label: 'Help & Service Desk', icon: LifeBuoy },
  { to: '/profile', label: 'My Profile & Security', icon: UsersRound },
];
// Vice Chancellor and Deputy: executive dashboard first, then the read-only university pages.
const VC_NAV = [
  { to: '/vc', label: 'Executive Dashboard', icon: LayoutDashboard, end: true },
  { to: '/university', label: 'University Overview', icon: Building2 },
  { to: '/admin/graduation', label: 'Graduation & Clearance', icon: GraduationCap },
  { to: '/admin/degree-audit', label: 'Degree Audit', icon: ClipboardList },
  { to: '/admin/advising', label: 'Academic Advising', icon: ClipboardCheck },
  { to: '/security', label: 'Security Centre', icon: ShieldAlert },
  { to: '/calendar', label: 'University Calendar', icon: CalendarDays },
  { to: '/help-desk', label: 'Help & Service Desk', icon: LifeBuoy },
  { to: '/profile', label: 'My Profile & Security', icon: UsersRound },
];
const SECURITY_NAV = [...UNIVERSITY_NAV.slice(0,1), { to: '/security', label: 'Security Centre', icon: ShieldAlert }, { to: '/admin/student-cards', label: 'Gate Card Access', icon: CreditCard }, ...UNIVERSITY_NAV.slice(1)];

const TEACHER_NAV = [
  { to: '/teacher', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/lecturer/lms', label: 'My LMS', icon: GraduationCap },
  { to: '/teacher/attendance', label: 'Attendance', icon: ClipboardCheck },
  { to: '/teacher/online-exams', label: 'Online Examinations', icon: FileQuestion },
  { to: '/teacher/grading', label: 'Assessments & Grading', icon: ClipboardPenLine },
  { to: '/teacher/marks', label: 'Marks & Results', icon: ClipboardPenLine },
  { to: '/teacher/supplementary', label: 'Supplementary & Resits', icon: FilePenLine },
  { to: '/teacher/materials', label: 'E-Content', icon: BookOpenCheck },
  { to: '/teacher/messages', label: 'Messages', icon: MessageSquare },
  { to: '/teacher/announcements', label: 'Announcements', icon: Megaphone },
  { to: '/calendar', label: 'University Calendar', icon: CalendarDays },
  { to: '/help-desk', label: 'Help & Service Desk', icon: LifeBuoy },
  { to: '/profile', label: 'My Profile & Security', icon: UsersRound },
];

export const ADMIN_NAV = [
  { to: '/admin', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { label: 'Academic', icon: GraduationCap, children: [
    { to: '/admin/students', label: 'Students' },
    { to: '/admin/student-cards', label: 'Student ID & Exam Cards' },
    { to: '/admin/teachers', label: 'Lecturers' },
    { to: '/university', label: 'Academic Programs' },
    { to: '/admin/classes', label: 'Cohorts / Sections' },
    { to: '/timetable-maker', label: 'Timetable Maker' },
    { to: '/admin/online-exams', label: 'Examinations' },
    { to: '/admin/marks', label: 'Grades & Results' },
    { to: '/admin/reports/academic', label: 'Transcript / Academic Reports' },
    { to: '/admin/degree-audit', label: 'Degree Audit' },
    { to: '/admin/advising', label: 'Academic Advising' },
    { to: '/admin/graduation', label: 'Graduation & Clearance' },
    { to: '/calendar', label: 'University Calendar' },
  ]},
  { label: 'Administration', icon: Building2, children: [
    { to: '/admin/users', label: 'Staff & User Management' },
    { to: '/admin/departments', label: 'Departments' },
    { to: '/university', label: 'Faculties' },
    { to: '/admin/control-center', label: 'Roles & Permissions' },
    { to: '/admin/editors', label: 'Appearance & Branding' },
    { to: '/admin/creatives', label: 'Creatives — Document Studio' },
    { to: '/admin/v3/admissions', label: 'Admissions & KUCCPS' },
    { to: '/admin/data-quality', label: 'Data Quality Centre' },
    { to: '/admin/v3/documents', label: 'Transcripts & Certificates' },
    { to: '/admin/v3/lms', label: 'LMS Integration' },
    { to: '/admin/announcements', label: 'Announcements' },
    { to: '/admin/messages', label: 'Messages' },
    { to: '/admin/documents', label: 'Document Centre' },
    { to: '/help-desk', label: 'Help & Service Desk' },
  ]},
  { label: 'Finance', icon: Wallet, children: [
    { to: '/admin/fees', label: 'Fees & Payments' },
    { to: '/admin/accounts', label: 'Invoices & Accounts' },
    { to: '/admin/scholarships', label: 'Scholarships' },
    { to: '/admin/expenses', label: 'Budget & Expenditure' },
    { to: '/admin/reports/finance', label: 'Financial Analytics' },
    { to: '/admin/v3/payments', label: 'M-Pesa & Payment Reconciliation' },
    { to: '/admin/v3/payroll', label: 'Payroll & Statutory Rules' },
  ]},
  { label: 'Operations', icon: ClipboardList, children: [
    { to: '/admin/books', label: 'Library' },
    { to: '/admin/boarding', label: 'Accommodation' },
    { to: '/admin/transport', label: 'Transport' },
    { to: '/admin/procurement', label: 'Procurement' },
    { to: '/admin/v3/backups', label: 'Backups & Disaster Recovery' },
  ]},
  { label: 'Security', icon: ShieldAlert, children: [
    { to: '/security', label: 'Security Centre' },
    { to: '/security?tab=incidents', label: 'Incidents' },
    { to: '/security?tab=visitors', label: 'Visitors & Access' },
    { to: '/security?tab=investigations', label: 'Investigations' },
    { to: '/security?tab=alerts', label: 'Emergency & Alerts' },
  ]},
  { label: 'Reports & Analytics', icon: BarChart3, children: [
    { to: '/admin/reports', label: 'Reports' },
    { to: '/admin/reports/academic', label: 'Analytics' },
  ]},
];

// Dedicated workspace for the Timetabling & Scheduling Officer. The detailed
// planning tools live inside the timetable module; don't create fake links that
// all pretend to be separate pages.
const TIMETABLER_NAV = [
  { to: '/timetable-maker', label: 'Timetable Maker', icon: CalendarDays, end: true },
  { to: '/profile', label: 'My Profile & Security', icon: UsersRound },
  { to: '/calendar', label: 'University Calendar', icon: CalendarDays },
  { to: '/help-desk', label: 'Help & Service Desk', icon: LifeBuoy },
];

// Dedicated role workspaces: each function sees only the navigation relevant to its duties.
const EXAM_NAV = [
  { to: '/university', label: 'Examination Dashboard', icon: LayoutDashboard, end: true },
  { to: '/admin/online-exams', label: 'Exam Management', icon: FileQuestion },
  { to: '/teacher/exams', label: 'Invigilator & Exam Sessions', icon: ClipboardCheck },
  { to: '/admin/marks', label: 'Marking & Results', icon: ClipboardPenLine },
  { to: '/admin/supplementary', label: 'Moderation & Resits', icon: FilePenLine },
  { to: '/admin/v3/documents', label: 'Transcripts & Certificates', icon: FileText },
  { to: '/admin/reports/academic', label: 'Examination Reports', icon: BarChart3 },
  { to: '/calendar', label: 'Academic Calendar', icon: CalendarDays },
  { to: '/profile', label: 'My Profile & Security', icon: UsersRound },
];
const FINANCE_NAV = [
  { to: '/university', label: 'Finance Overview', icon: LayoutDashboard, end: true },
  { to: '/admin/fees', label: 'Fees & Payments', icon: Wallet },
  { to: '/admin/accounts', label: 'Accounts & Invoices', icon: CreditCard },
  { to: '/admin/v3/payments', label: 'Payment Reconciliation', icon: Landmark },
  { to: '/admin/v3/payroll', label: 'Payroll', icon: UsersRound },
  { to: '/admin/reports/finance', label: 'Financial Reports', icon: BarChart3 },
  { to: '/calendar', label: 'University Calendar', icon: CalendarDays },
  { to: '/profile', label: 'My Profile & Security', icon: UsersRound },
];
const REGISTRY_NAV = [
  { to: '/university', label: 'Registry Overview', icon: LayoutDashboard, end: true },
  { to: '/admin/v3/admissions', label: 'Admissions & Registration', icon: GraduationCap },
  { to: '/admin/students', label: 'Student Records', icon: UsersRound },
  { to: '/admin/departments', label: 'Faculties & Departments', icon: Building2 },
  { to: '/admin/v3/documents', label: 'Official Documents', icon: FileText },
  { to: '/admin/degree-audit', label: 'Degree Audit', icon: ClipboardList },
  { to: '/admin/graduation', label: 'Graduation & Clearance', icon: Award },
  { to: '/admin/reports/academic', label: 'Registry Reports', icon: BarChart3 },
  { to: '/calendar', label: 'University Calendar', icon: CalendarDays },
  { to: '/profile', label: 'My Profile & Security', icon: UsersRound },
];
const HR_NAV = [
  { to: '/university', label: 'HR Overview', icon: LayoutDashboard, end: true },
  { to: '/admin/users', label: 'Staff Directory', icon: UsersRound },
  { to: '/admin/v3/payroll', label: 'Payroll & Benefits', icon: Wallet },
  { to: '/admin/reports', label: 'HR Reports', icon: BarChart3 },
  { to: '/calendar', label: 'University Calendar', icon: CalendarDays },
  { to: '/profile', label: 'My Profile & Security', icon: UsersRound },
];
const FACULTY_NAV = [
  { to: '/university', label: 'Faculty Overview', icon: LayoutDashboard, end: true },
  { to: '/admin/teachers', label: 'Lecturers', icon: UsersRound },
  { to: '/admin/classes', label: 'Courses & Cohorts', icon: BookOpen },
  { to: '/timetable-maker', label: 'Timetable Maker', icon: CalendarDays },
  { to: '/admin/marks', label: 'Grades & Results', icon: ClipboardPenLine },
  { to: '/admin/advising', label: 'Academic Advising', icon: ClipboardCheck },
  { to: '/admin/degree-audit', label: 'Degree Progress', icon: GraduationCap },
  { to: '/admin/reports/academic', label: 'Academic Reports', icon: BarChart3 },
  { to: '/calendar', label: 'University Calendar', icon: CalendarDays },
  { to: '/profile', label: 'My Profile & Security', icon: UsersRound },
];
const ADMISSIONS_NAV = [
  { to: '/university', label: 'Admissions Dashboard', icon: LayoutDashboard, end: true },
  { to: '/admin/v3/admissions', label: 'Applications & Admissions', icon: GraduationCap },
  { to: '/admin/students', label: 'Student Records', icon: UsersRound },
  { to: '/admin/student-cards', label: 'Student ID Cards', icon: CreditCard },
  { to: '/admin/reports/academic', label: 'Admissions Reports', icon: BarChart3 },
  { to: '/calendar', label: 'University Calendar', icon: CalendarDays },
  { to: '/profile', label: 'My Profile & Security', icon: UsersRound },
];
const OPERATIONS_NAV = [
  { to: '/university', label: 'Operations Overview', icon: LayoutDashboard, end: true },
  { to: '/admin/books', label: 'Library Operations', icon: Library },
  { to: '/admin/boarding', label: 'Accommodation', icon: BedDouble },
  { to: '/admin/transport', label: 'Transport', icon: Bus },
  { to: '/admin/procurement', label: 'Procurement', icon: ClipboardList },
  { to: '/admin/reports', label: 'Operations Reports', icon: BarChart3 },
  { to: '/help-desk', label: 'Help & Service Desk', icon: LifeBuoy },
  { to: '/profile', label: 'My Profile & Security', icon: UsersRound },
];

export const NAV = {
  admin: ADMIN_NAV, super_admin: ADMIN_NAV, timetabler: TIMETABLER_NAV, timetabling_officer: TIMETABLER_NAV,
  teacher: TEACHER_NAV,
  student: [
    { to: '/student', label: 'My Dashboard', icon: LayoutDashboard, end: true },
    { to: '/student/lms', label: 'Learning Management System', icon: BookOpenCheck },
    { to: '/student/units', label: 'My Units', icon: ListChecks },
    { to: '/my-timetable', label: 'Timetable', icon: CalendarDays },
    { to: '/student/content', label: 'E-Content', icon: BookOpenCheck },
    { to: '/student/results', label: 'Academic Results & GPA', icon: Award },
    { to: '/student/degree-audit', label: 'Degree Audit & Progress', icon: GraduationCap },
    { to: '/student/fees', label: 'Fee Statement', icon: Wallet },
    { to: '/student/supplementary', label: 'Supplementary', icon: FilePenLine },
    { to: '/student/messages', label: 'Contact Lecturer', icon: MessageSquare },
    { to: '/student/exams', label: 'Online Examinations', icon: FileQuestion },
    { to: '/student/exam-card', label: 'My Examination Card', icon: FileText },
    { to: '/student/announcements', label: 'Announcements', icon: Megaphone },
    { to: '/calendar', label: 'University Calendar', icon: CalendarDays },
    { to: '/help-desk', label: 'Help & Service Desk', icon: LifeBuoy },
  ],
  vice_chancellor: VC_NAV, deputy_vc: VC_NAV, registrar: REGISTRY_NAV, deputy_registrar: REGISTRY_NAV, finance_director: FINANCE_NAV, finance_officer: FINANCE_NAV, hr_director: HR_NAV, hr_officer: HR_NAV, dean: FACULTY_NAV, deputy_dean: FACULTY_NAV, hod: FACULTY_NAV, lecturer: TEACHER_NAV, senior_lecturer: TEACHER_NAV, professor: TEACHER_NAV, academic_staff: TEACHER_NAV, non_academic_staff: UNIVERSITY_NAV, admissions_officer: ADMISSIONS_NAV, examination_officer: EXAM_NAV, examinations_director: EXAM_NAV, exam_board: EXAM_NAV, procurement_officer: OPERATIONS_NAV, stores_officer: OPERATIONS_NAV, asset_officer: OPERATIONS_NAV, facilities_officer: OPERATIONS_NAV, transport_officer: OPERATIONS_NAV, security_officer: SECURITY_NAV, medical_officer: SECURITY_NAV, counselor: UNIVERSITY_NAV, research_officer: UNIVERSITY_NAV, student_affairs_officer: SECURITY_NAV, accommodation_officer: OPERATIONS_NAV, auditor: SECURITY_NAV, applicant: UNIVERSITY_NAV, alumni: UNIVERSITY_NAV,
  staff: STAFF_ROLE_NAV.staff,
  accounts: STAFF_ROLE_NAV.accounts,
  librarian: STAFF_ROLE_NAV.librarian,
  nurse: STAFF_ROLE_NAV.nurse,
  ict: STAFF_ROLE_NAV.ict,
};

const DESK_ITEM = { to: '/desk', label: 'My Role Desk', icon: KeyRound };

// The menu follows the older role the account inherits from. Roles with powers of their
// own also get a "My Role Desk" page, and a suspended student only gets that page.
// Roles that may open the timetable maker, and roles that only see their own published timetable.
const TIMETABLE_STAFF = ['registrar', 'deputy_registrar', 'dean', 'deputy_dean', 'hod'];
const OWN_TIMETABLE = ['teacher', 'lecturer', 'senior_lecturer', 'professor', 'academic_staff'];
function withTimetableLink(role, base) {
  const has = (path) => JSON.stringify(base).includes(path);
  const link = (to, label) => ({ to, label, icon: CalendarDays });
  if (TIMETABLE_STAFF.includes(role) && !has('/timetable-maker')) return [...base, link('/timetable-maker', 'Timetable Maker')];
  if (OWN_TIMETABLE.includes(role) && !has('/my-timetable')) return [...base, link('/my-timetable', 'My Timetable')];
  return base;
}

export function navFor(role) {
  const eff = effectiveRole(role);
  if (eff === 'suspended') return [DESK_ITEM];
  let base = NAV[role] || NAV[eff] || [];
  base = withTimetableLink(role, base);
  if (!hasDesk(role)) return base;
  const [first, ...rest] = base;
  return first ? [first, DESK_ITEM, ...rest] : [DESK_ITEM];
}

// Every page a role can open as one flat list. Used by the search box.
export function flattenNav(items) {
  const pages = [];
  items.forEach((item) => {
    if (item.children) {
      item.children.forEach((child) => pages.push({ to: child.to, label: child.label, group: item.label }));
    } else {
      pages.push({ to: item.to, label: item.label, group: null });
    }
  });
  return pages;
}
