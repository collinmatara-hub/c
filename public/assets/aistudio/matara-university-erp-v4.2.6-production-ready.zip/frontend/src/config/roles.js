// Every kind of account the university can create.
// The list itself lives in backend/lib/roles.js and is copied into rolesCatalog.js by
// scripts/sync-roles.js, so the browser and the API always agree.
//
//  - "role" is the real account type (for example helpdesk_l1).
//  - "acts_as" is the older role whose pages and permissions the account inherits.
//  - "group" decides which extra details the Add user form asks for.
import { ROLE_CATALOG, ROLE_CATEGORIES } from './rolesCatalog.js';

export { ROLE_CATEGORIES };

export const ROLE_OPTIONS = ROLE_CATALOG.map((r) => ({
  value: r.value, label: r.label, group: r.group, category: r.category, acts_as: r.acts_as,
  read_only: r.read_only, temporary: r.temporary, limited_nav: r.limited_nav, caps: r.caps, description: r.description,
}));

const BY_VALUE = Object.fromEntries(ROLE_OPTIONS.map((r) => [r.value, r]));

export function roleInfo(role) { return BY_VALUE[role] || null; }
export function roleLabel(role) { return BY_VALUE[role] ? BY_VALUE[role].label : role; }
export function groupOf(role) { return BY_VALUE[role] ? BY_VALUE[role].group : null; }
export function hasCap(role, cap) { return Boolean(BY_VALUE[role] && BY_VALUE[role].caps.includes(cap)); }
export function isTemporary(role) { return Boolean(BY_VALUE[role] && BY_VALUE[role].temporary); }

// The older role whose pages this account uses.
export function effectiveRole(role) { return BY_VALUE[role] ? BY_VALUE[role].acts_as : role; }

// True when the role has a "My Role Desk" page of its own (grade lock, holds, gate scans...).
export function hasDesk(role) {
  const r = BY_VALUE[role];
  return Boolean(r && r.caps.length > 0);
}

// These roles share the simple staff portal
export const STAFF_ROLES = ROLE_OPTIONS.filter((r) => r.group === 'staff').map((r) => r.value);
export const ACADEMIC_ROLES = ['teacher', 'lecturer', 'senior_lecturer', 'professor', 'academic_staff'];
export const UNIVERSITY_ROLES = ROLE_OPTIONS.filter((r) => !['admin', 'student', 'teacher'].includes(r.value)).map((r) => r.value);
export const STUDENT_VIEW_ROLES = ['admin', ...UNIVERSITY_ROLES, ...ACADEMIC_ROLES, 'accounts', 'librarian', 'nurse', 'ict', 'staff'];

// Where a user lands after signing in
export function homeFor(role) {
  const eff = effectiveRole(role);
  if (eff === 'admin') return '/admin';
  if (role === 'timetabling_officer') return '/timetable-maker';
  if (role === 'timetabler' || eff === 'timetabler') return '/admin/timetable';
  if (eff === 'student') return '/student';
  if (eff === 'suspended') return '/desk';
  if (eff === 'vice_chancellor' || eff === 'deputy_vc') return '/vc';
  if (ACADEMIC_ROLES.includes(eff)) return '/teacher';
  return '/university';
}
