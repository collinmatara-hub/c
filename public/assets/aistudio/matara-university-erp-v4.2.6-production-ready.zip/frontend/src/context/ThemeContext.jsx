import { createContext, useContext, useEffect, useState } from 'react';

// "light" or "dark". The choice is remembered in the browser.
const ThemeContext = createContext({ theme: 'light', toggleTheme: () => {} });

function savedTheme() {
  try {
    return localStorage.getItem('matara_theme') === 'dark' ? 'dark' : 'light';
  } catch (err) {
    return 'light';
  }
}

export function ThemeProvider({ children }) {
  const [theme, setTheme] = useState(savedTheme);

  useEffect(() => {
    document.documentElement.classList.toggle('dark', theme === 'dark');
    document.documentElement.style.colorScheme = theme;
    try {
      localStorage.setItem('matara_theme', theme);
    } catch (err) {
      // Private browsing can block storage. The theme still works for this visit.
    }
  }, [theme]);

  function toggleTheme() {
    setTheme((current) => (current === 'dark' ? 'light' : 'dark'));
  }

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  return useContext(ThemeContext);
}
